"""Check every 9-clique of positive edges in the universal ternary graph."""
import itertools as it
import json

points=list(it.product(range(3),repeat=2))
vectors=set()
for a,b in points:
    if (a,b)==(0,0):
        continue
    for c in range(3):
        labels=[(a*x+b*y+c)%3 for x,y in points]
        zero=[i for i,z in enumerate(labels) if not z]
        for positive,negative,split in it.permutations(zero):
            for sign in (1,-1):
                v=[(1 if z==1 else -1) for z in labels for i in range(2)]
                for k in range(2):
                    v[2*positive+k]=3
                    v[2*negative+k]=-3
                    v[2*split+k]=3*sign*(-1)**k
                vectors.add(tuple(v))
V=sorted(vectors)
assert len(V)==288
# All candidates have upward normal coordinate 2/sqrt(3). The horizontal
# coordinates are V/(3 sqrt(2)), so +1 and -1 correspond to dot -6 and -42.
positive_edges=[0]*len(V)
all_edges=[0]*len(V)
for i,x in enumerate(V):
    assert sum(x)==0 and sum(z*z for z in x)==66
    for j,y in enumerate(V[:i]):
        d=sum(a*b for a,b in zip(x,y))
        if d in (-6,-42):
            all_edges[i]|=1<<j
            all_edges[j]|=1<<i
            if d==-6:
                positive_edges[i]|=1<<j
                positive_edges[j]|=1<<i

nines=0
def visit(size,remaining,common):
    global nines
    if size==9:
        nines+=1
        assert not common, 'found 10-clique!'
        return
    while bin(remaining).count('1')>=9-size:
        bit=remaining & -remaining
        i=bit.bit_length()-1
        remaining^=bit
        visit(size+1,remaining & positive_edges[i],common & all_edges[i])

all_points=(1<<len(V))-1
visit(0,all_points,all_points)
print(json.dumps(dict(vertices=len(V),positive_9_cliques=nines,
                      compatible_10_cliques=0)))

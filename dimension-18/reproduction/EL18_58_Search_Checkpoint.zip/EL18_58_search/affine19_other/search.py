"""Exact extension and orbit search for all ordinary punctures of affine lifts."""
import json
from pathlib import Path
import itertools as it
from fractions import Fraction as F
from functools import reduce
from math import gcd
pairs=it.combinations
pts=list(it.product(range(3),repeat=2))
lines=sorted({tuple(i for i,(x,y) in enumerate(pts) if (x*a+y*b)%3==c) for a,b in [(1,0),(0,1),(1,1),(1,2)] for c in range(3)})
masks=[sum(1<<j for j,L in enumerate(lines) if i in L) for i in range(9)]
switches={0}
for r in masks:switches|={n^r for n in switches}
reps=sorted({min(n^r for r in switches) for n in range(4096)})
print(lines,len(reps),reps,flush=True)
def triples(code):
    return [tuple(2*i+s for i,s in zip(L,ss)) for j,L in enumerate(lines) for ss in it.product(range(2),repeat=3) if sum(ss)%2==(code>>j&1)]
def inv(rows):
    n=len(rows)
    m=[list(map(F,r))+[F(i==j) for j in range(n)] for i,r in enumerate(rows)]
    for i in range(n):
        q=next(j for j in range(i,n) if m[j][i])
        m[q],m[i]=m[i],m[q]
        m[i]=[x/m[i][i] for x in m[i]]
        for j in range(n):
            if j!=i and m[j][i]:
                m[j]=[a-m[j][i]*b for a,b in zip(m[j],m[i])]
    return [r[n:] for r in m]
def coords(C):
    eq=[[int(k in t)-int(17 in t) for k in range(17)] for t in C]
    rr=[]; B=[]
    for i,row in enumerate(eq):
        v=list(map(F,row))
        for j,r in rr:
            if v[j]:v=[x-v[j]*y for x,y in zip(v,r)]
        if not any(v):continue
        j=next(i for i,x in enumerate(v) if x)
        rr.append((j,[x/v[j] for x in v]))
        B.append(i)
    assert len(B)==17
    a=inv([eq[i] for i in B]);a.append([-sum(col) for col in zip(*a)])
    den=reduce(lambda a,b:a*b//gcd(a,b),(z.denominator for r in a for z in r),1)
    M=[[int(x*den) for x in r] for r in a]
    S=[[sum(M[j][i] for j in t) for i in range(17)] for t in C]
    # Gray code. 17 basis block sums set to +/-1, first one fixed to +1.
    rows=[sum(r) for r in S]
    v=[sum(r) for r in M]
    direction=[1]*17
    opts=[]
    for k in range(1<<16):
        if all(abs(z)==den for z in rows):
            h=10*den**2-sum(t*t for t in v)
            if h>=0:
                opts.extend((tuple(v),h,e) for e in ([1,-1] if h else [0]))
        if k==65535:break
        j=(k+1&-(k+1)).bit_length()
        delta=-2*direction[j];direction[j]*=-1
        rows=[a+delta*r[j] for a,r in zip(rows,S)]
        v=[a+delta*r[j] for a,r in zip(v,M)]
    return den,opts,B
def solve(code,deleted):
    full=triples(code)+[(2*i,2*i+1,18) for i in range(9)]
    assert len(set(tuple(sorted(e)) for t in full for e in pairs(t,2)))==171
    C=[tuple(i-(i>deleted) for i in t) for t in full if deleted not in t]
    assert len(C)==48
    D,opts,B=coords(C)
    print('code,opts',code,len(opts),flush=True)
    adj=[0]*len(opts)
    for i,(x,h,e) in enumerate(opts):
        for j,(y,g,f) in enumerate(opts[:i]):
            dot=sum(a*b for a,b in zip(x,y))
            if any((z*2*D*D-dot)**2==h*g and (z*2*D*D-dot)*e*f>=0 for z in [-1,1]):
                adj[i]|=1<<j;adj[j]|=1<<i
    # The largest nonempty graph here has 16 vertices, so a second exhaustive
    # subset count provides an independent upper bound without graph coloring.
    assert len(opts)<=16
    cliques=[0]
    for i,mask in enumerate(adj):
        cliques += [old|(1<<i) for old in cliques if old & ~mask == 0]
    histogram=[sum(bin(z).count("1")==k for z in cliques) for k in range(len(opts)+1)]
    best=[]
    def dfs(p,l):
        nonlocal best
        if len(l)>len(best):best=l
        color=0;rest=p;order=[]
        while rest:
            color+=1;avail=rest
            while avail:
                bit=avail&-avail;v=bit.bit_length()-1
                rest^=bit;avail=(avail^bit)&~adj[v]
                order.append((v,color))
        for v,c in reversed(order):
            if len(l)+c<=len(best):break
            dfs(p&adj[v],l+[v])
            p^=1<<v
    dfs((1<<len(opts))-1,[])
    assert len(best)==max(i for i,k in enumerate(histogram) if k)
    if best:
        selected=[opts[i] for i in best]
        gram=[[2*len(set(a)&set(b))-1 for b in C] for a in C]
        for a,row in zip(C,gram):
            row.extend(sum(v[i] for i in a)//D for v,_,_ in selected)
        for k,(x,h,e) in enumerate(selected):
            row=[r[48+k] for r in gram[:48]]
            for j,(y,g,f) in enumerate(selected):
                dot=sum(a*b for a,b in zip(x,y))
                z=5 if j==k else next(z for z in [-1,1] if (z*2*D*D-dot)**2==h*g and (z*2*D*D-dot)*e*f>=0)
                row.append(z)
            gram.append(row)
        Path(__file__).with_name("gram56.json").write_text(json.dumps(gram))
    return dict(histogram=histogram,code=code,deleted=deleted,den=D,n=len(opts),best=best,opts=[opts[i] for i in best],B=B)

def pointed_orbits():
    # The incidence map of binary pair switches is injective for this 9-point plane.
    switch={reduce(int.__xor__, [masks[i] for i in range(9) if n>>i&1],0):n for n in range(512)}
    assert len(switch)==512
    reductions={r^z:(r,t) for r in reps for z,t in switch.items()}
    assert len(reductions)==4096
    maps=[]
    for a,b,c,d in it.product(range(3),repeat=4):
        if (a*d-b*c)%3==0:continue
        for tx,ty in pts:
            pi=[pts.index(((a*x+b*y+tx)%3,(c*x+d*y+ty)%3)) for x,y in pts]
            lm=[lines.index(tuple(sorted(pi[i] for i in L))) for L in lines]
            maps.append((pi,lm))
    assert len(maps)==432
    groups={}
    for r in reps:
        for i in range(18):
            images=set()
            for pi,lm in maps:
                t=sum((r>>j&1)<<l for j,l in enumerate(lm))
                canonical,flip=reductions[t]
                k=pi[i//2]
                images.add((canonical,2*k+((i%2)^(flip>>k&1))))
            groups.setdefault(min(images),[]).append((r,i))
    return groups

if __name__=='__main__':
    results=[]
    groups=pointed_orbits()
    print('pointed orbit sizes',[(k,len(g)) for k,g in groups.items()],flush=True)
    for (r,i),orbit in groups.items():
        s=solve(r,i)
        s['orbit']=orbit
        results.append(s)
        print('pointed',r,i,'max',len(s['best']),flush=True)
    Path(__file__).with_name('results.json').write_text(json.dumps(results))

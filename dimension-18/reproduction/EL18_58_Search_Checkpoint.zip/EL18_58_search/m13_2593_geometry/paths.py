"""All surviving pair values and plane lengths used in the first population deck."""
from squares import *
n=[14,20,0,0,0,0,0,0,0,4,20,0,0,0,0,0]
rec,=[x for x in json.loads((P/'m13_rank2/survive_2593.json').read_text()) if x['counts']==n]
def ev(q,t):
 return sum(v*t**k for k,v in enumerate(reversed(q)))
def products(i,j):
 return {abs(1-F(p[-1],16)) for a,b,p in rec['edges'] if a==min(i,j) and b==max(i,j)}
def main():
 mp=[v*(len(M)-1-i) for i,v in enumerate(M[:-1])]
 E=lambda i,t:F((2*t+16)*ev(h[i],t),2*ev(mp,t))
 # rational t=-2 direction, rational t=2 plane, conjugate quadratic plane
 lengths={i:(E(i,-2),E(i,2),diag(i)-E(i,-2)-E(i,2)) for i in (0,1,9,10)}
 assert lengths=={0:(0,0,1),1:(0,1,F(1,2)),9:(F(1,2),0,F(3,2)),10:(F(1,2),1,0)}
 assert products(0,0)=={1} and products(0,9)=={1} and products(0,1)==products(0,10)=={0}
 # physical quadratic eigenvalues 15±sqrt(17)
 assert 18*12-(15**2-17)==8
 for m in (2,3,4):
    # squared projection of g onto a path when signs at ends opposite
    assert F(m-1,2*(m+1))<F(1,2)
 print('Verified first deck lengths and all exceptional products; completing both paths gives 60 lines.')
if __name__=='__main__':main()

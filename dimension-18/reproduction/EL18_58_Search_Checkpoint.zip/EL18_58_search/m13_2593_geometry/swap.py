"""Independent trace, sign, replacement and characteristic-polynomial checks for the last deck."""
from paths import ev
from squares import P,M,h,diag,F,json
from itertools import product,permutations
from math import prod
n=[8,12,2,8,0,4,0,0,24,0,0,0,0,0,0,0]
rec,=[x for x in json.loads((P/'m13_rank2/survive_2593.json').read_text()) if x['counts']==n]
def values(i,j):
 return {abs(1-F(p[-1],16)) for a,b,p in rec['edges'] if (a,b)==(min(i,j),max(i,j))}
def main():
 assert rec['squareclass']==2
 mp=[v*(len(M)-1-i) for i,v in enumerate(M[:-1])]
 E=lambda i,t:F((2*t+16)*ev(h[i],t),2*ev(mp,t))
 trace3={}
 for i in (0,1,2,3,5,8):
  A=E(i,-2);B=E(i,2);trace3[i]=(A,B,diag(i)-A-B)
 assert trace3=={0:(0,0,1),1:(0,1,F(1,2)),2:(0,0,3),3:(1,1,1),5:(1,2,F(1,2)),8:(0,F(1,2),0)}
 assert values(0,0)==values(0,2)==values(0,3)=={1}
 assert all(values(0,i)=={0} for i in (1,5,8))
 assert values(8,8)=={F(1,2)}
 assert values(8,5)=={1} and values(8,3)=={0}
 assert all(values(3,i)=={1} for i in (0,1,2,5))
 assert values(3,3)=={1,3}
 assert 18*(30-18)-(15**2-17)==8
 # Four sign populations exhaust the eight type-3 rows.
 cells=list(product((1,-1),repeat=2))
 sol=[ns for ns in product(range(9),repeat=4) if sum(ns)==8 and
      all(sum(k*z for k,z in zip(ns,vs))==0 for vs in
          ([s for s,t in cells],[t for s,t in cells],[s*t for s,t in cells]))]
 assert sol==[(2,2,2,2)]
 for s,t in cells:
  assert [1+s*p+t*q for p,q in cells if (p,q)!=(s,t)].count(-1)==1
 # Frame in basis (u, e'/sqrt(2), s g, t b, a). Coordinate matrix need not be symmetric
 # in this nonnormalized basis. e'/sqrt(2) has squared norm 1/2.
 X=[[18,2,0,0,0],[4,12,0,0,0],[0,0,12,0,0],[0,0,0,20,0],[0,0,0,0,20]]
 def outer(v):
  weights=[1,F(1,2),1,1,1]
  return [[v[i]*v[j]*weights[j] for j in range(5)] for i in range(5)]
 V=outer([1,-2,0,0,0]);W=outer([1,0,1,1,0])
 Y=[[X[i][j]+2*(V[i][j]-W[i][j]) for j in range(5)] for i in range(5)]
 assert Y[1]==[0,16,0,0,0] and [r[1] for r in Y]==Y[1]
 for x in range(6):
  A=[[x*(i==j)-Y[i][j] for j in range(5)] for i in range(5)]
  det=sum((-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))*prod(A[i][p[i]] for i in range(5)) for p in permutations(range(5)))
  assert det==(x-16)*(x-20)**2*(x*x-26*x+152)
 # PSD, all 18 dimensions, and the reduction to known quartic #369.
 assert json.loads((P/'m14/quartic_results.json').read_text())[369]['tail']==[1,-1,-10,20,-8]
 print('Third deck checked: replacing one antipodal residual pair gives exactly m=14, quartic 369.')
if __name__=='__main__':main()

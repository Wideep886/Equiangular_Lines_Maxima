"""Verify all exceptional products used by the second deck, independently of anchor choices."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations
import json
P=Path(__file__).resolve().parent.parent
D=json.loads((P/'m13_joint/input_2593.json').read_text())
n=[16,16,2,0,0,0,0,0,0,0,24,0,0,0,0,0]
rec,=[x for x in json.loads((P/'m13_rank2/survive_2593.json').read_text()) if x['counts']==n]
assert rec['squareclass']==1
h=D['deck'];M=D['minimal'];assert M[-2]==128
def diag(i):return 5-F(h[i][-1],16)
def allowed(i,j):
 i,j=sorted((i,j))
 return {abs(1-F(p[-1],16)) for a,b,p in rec['edges'] if a==i and b==j}
def main():
 ids=[0,1,2,10]
 assert [diag(i) for i in ids]==[1,F(3,2),3,F(3,2)]
 assert allowed(0,0)=={1} and allowed(2,2)=={3}
 assert allowed(0,2)==allowed(1,2)=={1} and allowed(2,10)=={0}
 assert allowed(0,1)==allowed(0,10)=={0}
 assert allowed(1,1)==allowed(10,10)=={F(1,2),F(3,2)}
 assert allowed(1,10)=={0,1}
 # Enumerate all connected graphs on 3,4 vertices whose adjacency has spectral
 # radius 2: PSD of 2I−A follows by assumption; positivity of its proper
 # principal minors and determinant zero exactly detect the singular cases here.
 from itertools import permutations
 def det(A):
  m=len(A)
  from math import prod
  return sum((-1)**sum(p[i]>p[j] for i in range(m) for j in range(i+1,m))*prod(A[i][p[i]] for i in range(m)) for p in permutations(range(m)))
 for k in [3,4]:
  E=list(combinations(range(k),2));out=[]
  for mask in range(1<<len(E)):
   A=[[2*int(i==j) for j in range(k)] for i in range(k)]
   for j,(a,b) in enumerate(E):
    if mask>>j&1:A[a][b]=A[b][a]=-1
   if det(A)!=0:continue
   if any(det([[A[i][j] for j in I] for i in I])<=0 for l in range(1,k) for I in combinations(range(k),l)):continue
   out.append(sorted(2-sum(row) for row in A))
  assert out and all(d==[2]*k for d in out)
 # The 16×16 Gram and the one orthogonal residual axis force all four cycles.
 # No one- or two-point connected simple graph has spectral radius 2.
 one=list(combinations(range(4),1));two=list(combinations(range(4),2))
 for x in one:
  eligible=[t for t in two if not(set(x)&set(t))]
  assert all(len(set(a)&set(b))==1 for a,b in combinations(eligible,2))
  assert all(len(set(range(4))-set(x)-set(t))==1 for t in eligible)
 print('Verified both parity-product classes, four forced squares and one missing alternating axis.')
if __name__=='__main__':main()

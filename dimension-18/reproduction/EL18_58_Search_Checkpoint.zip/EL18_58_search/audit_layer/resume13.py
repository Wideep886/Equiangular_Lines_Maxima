"""Continue the m=13 one-point screen using the frozen m13 modules."""
from concurrent.futures import ProcessPoolExecutor
import argparse, gzip, json, os, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'m13'
sys.path.insert(0,str(SOURCE))
sys.dont_write_bytecode=True
import anchor
import fastdeck
fastdeck.HERE=HERE

def work(task):
    idx,h=task
    n, rounds, remaining=anchor.anchor(13,h)
    return [13,idx,h,n,rounds,remaining]

def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--start',type=int,default=1006)
    cli.add_argument('--end',type=int,default=2965)
    cli.add_argument('--jobs',type=int,default=3)
    args=cli.parse_args()
    parents=json.loads((SOURCE/'parents.json').read_text())
    assert len(parents)==len({tuple(p) for p in parents})==2965
    old=[json.loads(l) for l in gzip.open(SOURCE/'anchor_done.jsonl.gz','rt')]
    assert {r[1] for r in old}==set(range(1006))
    assert sum(r[-1]==0 for r in old)==987
    dest=HERE/'extra13.jsonl'
    saved={r[1]:r for r in map(json.loads,dest.read_text().splitlines())} if dest.exists() else {}
    assert all(r[2]==parents[i] for i,r in saved.items())
    tasks=[(i,parents[i]) for i in range(args.start,args.end) if i not in saved]
    with ProcessPoolExecutor(args.jobs) as ex, dest.open('a',buffering=1) as f:
        for row in ex.map(work,tasks,chunksize=2):
            print(json.dumps(row,separators=(',',':')),file=f)
            if row[1]%50==0:print(row[1],flush=True)
if __name__=='__main__':main()

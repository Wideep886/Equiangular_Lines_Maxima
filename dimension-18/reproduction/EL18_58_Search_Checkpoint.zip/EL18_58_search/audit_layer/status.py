from pathlib import Path
import json,gzip
root=Path(__file__).resolve().parent
from collections import Counter
def read(path):
    return [json.loads(line) for line in path.read_text().splitlines()]
parents=json.loads((root.parent/'m13'/'parents.json').read_text())
old=list(map(json.loads,gzip.open(root.parent/'m13'/'anchor_done.jsonl.gz','rt')))
extra=read(root/'extra13.jsonl')
allrows=old+extra
assert len(allrows)==len(parents)==len(set(tuple(h) for h in parents))==2965
assert [r[1] for r in allrows]==list(range(2965))
assert all(r[2]==parents[r[1]] and r[0]==13 for r in allrows)
active={r[1] for r in allrows if r[-1]}
print('complete m=13 parents',len(parents),'after anchor',len(active))
for f in ['rows13.jsonl','poly13_final.jsonl']:
    r=read(root/f)
    assert len(r)==len(active) and {a[0] for a in r}==active
    active={a[0] for a in r if a[2]}
    print(f,'survivors',len(active))
assert len(active)==13
for idx in sorted(active):print(idx,parents[idx])

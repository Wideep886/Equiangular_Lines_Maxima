"""Necessary rank-one interpolation and exact row identities for m=13 survivors."""
import argparse,sys,json,gzip
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import combinations
from math import sqrt
HERE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(HERE.parent/'m4'))
sys.path.insert(0,str(HERE.parent/'m13'))
from resume13 import SOURCE
from anchor import indices,possible,PRIMES
from fastdeck import native
from build import factors
from lowmult import val,mul,deriv
from pairtrace import candidates,systems
from lpscreen import phase_one
from lattice import lat

def compatible(deck,fs):
    full=(1<<len(deck))-1; G=[full]*len(deck)
    for f,k in fs:
        if k!=1:continue
        d=deriv(f)
        for p in PRIMES:
            for a in range(p):
                if val(f,a)%p or not val(d,a)%p:continue
                symbols=[0]+[pow(v,(p-1)//2,p) for v in range(1,p)]
                Y=[symbols[val(q,a)%p] for q in deck]
                minus=sum(1<<i for i,v in enumerate(Y) if v==p-1)
                plus=sum(1<<i for i,v in enumerate(Y) if v==1)
                if minus and plus:
                    G=[m&({p-1:~plus,1:~minus,0:full}[v]) for m,v in zip(G,Y)]
    return G

def unit(row):
    m,idx,h,order,record_rounds,alive=row
    fs=[([1,0],m)]+factors(h)
    g,target,deck=native([([1,8],40)]+fs)
    assert len(deck)==order
    cols=[(1,*q[3:]) for q in deck];b=(58,*target[3:])
    G=compatible(deck,fs);active=(1<<len(G))-1
    for n in record_rounds:
        removed=[i for i in indices(active) if not possible([cols[j] for j in indices(active&G[i])],tuple(x-y for x,y in zip(b,cols[i])))]
        assert len(removed)==n
        active-=sum(1<<i for i in removed)
    assert active.bit_count()==alive if hasattr(int,'bit_count') else bin(active).count('1')==alive
    if any(len(f)>2 and k>1 for f,k in fs):return [idx,'repeated nonlinear factor',alive]
    linear=tuple((-f[1],k) for f,k in fs if len(f)==2)
    nonlinear=[1]
    for f,k in fs:
        if len(f)>2:nonlinear=mul(nonlinear,f)
    # In the all-integral case interpolation over the empty set of nonlinear
    # roots can be tested modulo any prime separating the linear roots.
    if len(nonlinear)==1:
        pars=[]
        for p in (101,103,107,109,113,127,131,137):
            parts=[prodlin(t,linear,p) for t,k in linear]
            pars.append((p,[],[],parts,{}))
    else:pars=systems(tuple(nonlinear),linear)
    gp=deriv(g)
    scale=[2*val(gp,t) for t,k in linear]
    roots=[t for t,k in linear]
    diag={i:tuple(val(deck[i],t) for t in roots) for i in indices(active)}
    pairs={}
    for i in indices(active):
        for j in indices(G[i]&active):
            if i<=j:
                pairs[i,j]=candidates(deck[i],deck[j],nonlinear,linear,pars)
    certs=[]
    for _ in range(alive+1):
        bad=[]
        for i in indices(active):
            ds=diag[i]
            target_row=tuple(x-y for x,y in zip(b,cols[i]))+tuple((s-h)*h for s,h in zip(scale,ds))+tuple((2*t+11)*h for t,h in zip(roots,ds))+tuple(-ds[u]*ds[v] for u,v in combinations(range(len(ds)),2))
            options=set()
            for j in indices(active&G[i]):
                for q in pairs.get((min(i,j),max(i,j)),[]):
                    options.add(cols[j]+tuple(v*v for v in q)+q+tuple(q[u]*q[v] for u,v in combinations(range(len(q)),2)))
            columns=sorted(options)
            if not columns:proof={'kind':'empty'}
            elif not lat(columns,target_row):proof={'kind':'lattice'}
            else:proof=phase_one(columns,target_row)
            if proof['kind']!='primal':bad.append((i,proof))
        if not bad:break
        active-=sum(1<<i for i,_ in bad);certs.append(bad)
    if active and not possible([cols[i] for i in indices(active)],b):
        return [idx,'excluded after full target',[],certs]
    return [idx,'evaluated',list(indices(active)),certs]

def prodlin(t,ls,p):
    z=1
    for a,k in ls:
        if t!=a:z=z*(t-a)%p
    return pow(z,-1,p)

def main():
    args=argparse.ArgumentParser();args.add_argument('--jobs',type=int,default=3);args.add_argument('--end',type=int,default=2965);a=args.parse_args()
    data=list(map(json.loads,gzip.open(SOURCE/'anchor_done.jsonl.gz','rt')))+list(map(json.loads,(HERE/'extra13.jsonl').read_text().splitlines()))
    out=HERE/'rows13.jsonl'
    seen={json.loads(l)[0] for l in out.read_text().splitlines()} if out.exists() else set()
    todo=[r for r in data if r[-1] and r[1] not in seen and r[1]<a.end]
    with ProcessPoolExecutor(a.jobs) as pool,out.open('a',buffering=1) as f:
        for r in pool.map(unit,todo):
            print(json.dumps(r,separators=(',',':')),file=f)
            print(r[:3],flush=True)
if __name__=='__main__':main()

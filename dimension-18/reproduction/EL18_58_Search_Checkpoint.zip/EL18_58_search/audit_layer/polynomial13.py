"""Reconstruct every integral off-diagonal resolvent polynomial for surviving row pairs."""
import json,gzip,sys
from fractions import Fraction as F
from math import isqrt,ceil
from itertools import product,combinations
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from rows13 import native,factors,compatible,indices,possible,HERE,SOURCE,mul,val,deriv,systems,candidates,phase_one,lat
from lowmult import isol

def qr(p,a):
    r=[p[0]]
    for b in p[1:]:
        r.append(b+a*r[-1])
    assert not r[-1]
    return r[:-1]

def bounds(g):
    d=len(g)-1
    limits=[0]*d
    for a,b in isol(g):
        l=u=F(1)
        for k in range(d):
            limits[k]=max(limits[k],ceil(2*max(abs(l),abs(u))))
            z=[l*a,l*b,u*a,u*b]
            l,u=min(z)+g[k+1],max(z)+g[k+1]
    return limits[1:]

def rem(a,b):
    a=a[:]
    while a and len(a)>=len(b):
        if a[0]:
            c=a[0]
            for j,d in enumerate(b):a[j]-=c*d
        a=a[1:]
    return a

def poly_types(H,fs,g,deck,active):
    roots=tuple((-f[1],k) for f,k in fs if len(f)==2)
    f=[1]
    for h,k in fs:
        if len(h)>2:f=mul(f,h)
    cap=bounds(g)
    rad=qr(g,-8)
    assert len(cap)==len(rad)-1
    def largeprime():
        sysdata=systems(tuple(f),roots) if len(f)>1 else []
        if sysdata and sysdata[-1][0]>2*max(cap):return sysdata[-1]
        base=max(2*max(cap)+1,101)|1
        for p in range(base,base+1000000,2):
            if any(p%j==0 for j in range(3,isqrt(p)+1,2)):continue
            ns=[a for a in range(p) if val(f,a)%p==0]
            if len(ns)!=len(f)-1:continue
            allpts=ns+[t for t,k in roots]
            if len({a%p for a in allpts})<len(allpts):continue
            wg=[pow(val(deriv(rad),a)%p,-1,p) for a in allpts]
            return p,ns,wg[:len(ns)],wg[len(ns):],{j*j%p:j for j in range((p+1)//2)}
        raise RuntimeError('split prime absent from prescribed interval')
    if any(k>1 and len(h)>2 for h,k in fs):
        assert fs==[([1,0],13),([1,-1],1),([1,0,-5],2)]
        assert len(cap)==4
        pairs={}
        for i in active:
            for j in active:
                if j<i:continue
                prod0=val(deck[i],0)*val(deck[j],0)
                prod1=val(deck[i],1)*val(deck[j],1)
                neg=val(deck[i],-8)*val(deck[j],-8)
                root=isqrt(prod1)
                if root*root!=prod1:continue
                pool=set()
                for c in range(-isqrt(prod0),isqrt(prod0)+1):
                    if (c*c-prod0)%4:continue
                    for a in range(-cap[1],cap[1]+1):
                        for v in {root,-root}:
                            q=(1,a,v-1-a-c,c);b=q[2]
                            if abs(b)>cap[2]:continue
                            z=val(q,-8)
                            if z*z>neg or (z*z-neg)%4:continue
                            do=mul(deck[i],deck[j]);s=mul(q,q)
                            s=[0]*(len(do)-len(s))+s
                            # At ±sqrt(5), the two-point minor must be
                            # nonnegative and a multiple of four in Z[sqrt(5)].
                            diff=[x-y for x,y in zip(do,s)]
                            if any(z%4 for z in diff):continue
                            t,u=rem(diff,[1,0,-5])
                            if t%4 or u%4 or u<0 or u*u<5*t*t:continue
                            pool.add(q)
                if pool:pairs[i,j]=sorted(pool)
        return 0,cap,pairs
    p,ns,nw,lw,sq=largeprime()
    rp=ns+[t for t,k in roots]
    vand=[]
    for a,w in zip(rp,nw+lw):
        row=[1]
        for z in rad[1:-1]:row.append((row[-1]*a+z)%p)
        vand.append([n*w%p for n in row])
    cand={}
    for i in active:
        for j in active:
            if j<i or not(H[i]>>j&1):continue
            opt=[]
            for t,k in roots:
                uv=val(deck[i],t)*val(deck[j],t)
                assert uv>=0
                n=isqrt(uv)
                opt.append([b for b in range(-n,n+1) if (b*b-uv)%4==0 and (k!=1 or b*b==uv)])
            sqopt=[]
            for t in ns:
                u=val(deck[i],t)*val(deck[j],t)%p
                sqopt.append([] if u not in sq else sorted({sq[u],-sq[u]%p}))
            if any(not x for x in sqopt+opt):continue
            # For a fixed non-linear sign tuple and all integral values except
            # at zero, monicity determines the missing value modulo p.
            assert roots[0][0]==0
            qb=set(); pre={}
            for nsval in product(*sqopt):
                small=(1-sum(a*w for a,w in zip(nsval,nw)))%p
                pre.setdefault(small,[]).append(nsval)
            for vals in product(*opt):
                target=sum(a*w for a,w in zip(vals,lw))%p
                for nsval in pre.get(target,[]):
                    values=nsval+vals
                    q=[sum(x*v[k] for x,v in zip(values,vand))%p for k in range(len(cap))]
                    q=[z-p if z>p//2 else z for z in q]
                    if q[0]!=1 or any(abs(v)>c for v,c in zip(q,cap)):continue
                    if any(val(q,t)!=v for (t,k),v in zip(roots,vals)):continue
                    x=mul(q,q);y=mul(deck[i],deck[j]);x=[0]*(len(y)-len(x))+x
                    diff=[a-b for a,b in zip(x,y)]
                    if any(z%4 for z in diff) or any(rem(diff,f)):continue
                    a,b=val(deck[i],-8),val(deck[j],-8);z=val(q,-8)
                    if z*z>a*b or (z*z-a*b)%4:continue
                    qb.add(tuple(q))
            if qb:cand[i,j]=sorted(qb)
    return p,cap,cand

def unit(row):
    i,_,ids=row[:3]
    h=json.loads((SOURCE/'parents.json').read_text())[i]
    fs=[([1,0],13)]+factors(h)
    g,target,deck=native([([1,8],40)]+fs)
    if isinstance(ids,int):
        H=compatible(deck,fs);cols=[(1,*q[3:]) for q in deck]
        T=(58,*target[3:]); active=(1<<len(deck))-1
        for _ in range(len(deck)+1):
            bad=[j for j in indices(active) if not possible([cols[k] for k in indices(active&H[j])],tuple(a-b for a,b in zip(T,cols[j])))]
            if not bad:break
            active-=sum(1<<j for j in bad)
        assert len(list(indices(active)))==ids
        ids=list(indices(active))
    # Old row pruning supplied an admissible superset. Omit its compatibility
    # filter here: allowing all pairs is conservative.
    graph={v:sum(1<<j for j in ids) for v in ids}
    p,cap,pairs=poly_types(graph,fs,g,deck,ids)
    # Evaluate at small distinct integers. The resulting row identities are
    # kernel identities valid also when an evaluation point is a root.
    zvals=tuple(range(-2,min(len(cap),4)-2))
    di={j:[val(deck[j],z) for z in zvals] for j in ids}
    evals={q:tuple(val(q,z) for z in zvals) for v in pairs.values() for q in v}
    cols={j:(1,*deck[j][3:]) for j in ids};b=(58,*target[3:])
    gp=deriv(g);gpv=[val(gp,z) for z in zvals];gv=[val(g,z) for z in zvals]
    D=len(zvals);duals=[]
    for r in range(len(ids)+1):
        rm=[]
        for j in ids:
            ds=di[j]
            T=tuple(x-y for x,y in zip(b,cols[j]))+tuple((2*z+11)*a-4*c for z,a,c in zip(zvals,ds,gv))
            T+=tuple(2*(gpv[l]*ds[l]-gv[l]*val(deriv(deck[j]),zvals[l]))-ds[l]**2 for l in range(D))
            cross=[]
            for u,v in combinations(range(D),2):
                d=zvals[v]-zvals[u];a=2*(gv[v]*ds[u]-gv[u]*ds[v]);assert a%d==0
                cross.append(a//d-ds[u]*ds[v])
            T+=tuple(cross)
            S=set()
            for k in ids:
                for q in pairs.get((min(j,k),max(j,k)),[]):
                    e=evals[q]
                    S.add(cols[k]+e+tuple(x*x for x in e)+tuple(e[u]*e[v] for u,v in combinations(range(D),2)))
            S=sorted(S)
            if not S:c={'kind':'empty'}
            elif not lat(S,T):c={'kind':'lattice'}
            else:c=phase_one(S,T)
            if c['kind']!='primal':rm.append((j,c))
        if not rm:break
        duals.append(rm)
        ids=[j for j in ids if j not in {x[0] for x in rm}]
    if ids and not possible([cols[j] for j in ids],b):ids=[]
    return [i,p,ids,cap,duals]

if __name__=='__main__':
    src=[a for a in map(json.loads,(HERE/'rows13.jsonl').read_text().splitlines()) if a[2]]
    dest=HERE/'poly13_final.jsonl'
    seen={json.loads(l)[0] for l in dest.read_text().splitlines()} if dest.exists() else set()
    from concurrent.futures import as_completed
    with ProcessPoolExecutor(4) as ex,dest.open('a',buffering=1) as f:
        for future in as_completed([ex.submit(unit,r) for r in src if r[0] not in seen]):
            r=future.result()
            print(json.dumps(r,separators=(',',':')),file=f)
            print(r[:3],flush=True)

"""Exact single-pillar averaged BV including the condition of no all-negative triangle."""
from fractions import Fraction as F
from itertools import permutations,product
from math import comb
from pathlib import Path
import json
from two_axes import run

def kernel(n,k,x,R=F(1)):
    a,b=F(1),x
    if k==0:return a
    for j in range(1,k):a,b=b,((2*j+n-2)*x*b-j*R*a)/(j+n-2)
    return b
ang=(F(-5,13),F(1,13))
def value(k,i,j,t):
    u,v=ang[i],ang[j]
    return kernel(15,k,t-u*v,(1-u*u)*(1-v*v))

def counts(k,j):
    M=[[0]*3 for _ in range(3)]
    for (i,h),v in zip([(0,1),(1,2),(0,2)],[1]*j+[0]*(3-j)):
        M[i][h]=M[h][i]=v
    result=[F(0)]*3
    for v,x,y in permutations(range(3)):
        i,j=M[v][x],M[v][y]
        if i<=j:
            result[i+j]+=value(k,i,j,ang[M[x][y]])
    return result
def bound(n,a):
    moment=F(1);z=F(0)
    for j in range(6):
        if j:moment*=F(2*j-1,n+2*j-3)
        z+=comb(5,j)*a**(10-2*j)*(1-a*a)**j*moment
    return z
coeff=[[counts(k,j) for j in range(4)] for k in range(10)]
def verify(n,e,t):
    E=comb(n,2);T=comb(n,3);P=(n-2)*e
    row=(0,2*T+t-P,P-T-2*t,t)
    assert min(row)>=0
    d,r=divmod(2*e,n)
    assert 2*row[2]+6*t+2*e>=(n-r)*d*d+r*(d+1)**2
    sizes=(2*(E-e),2*e)
    for k in range(10):
        a,b,c=[sum(row[j]*coeff[k][j][l] for j in range(4)) for l in range(3)]
        a+=sizes[0]*value(k,0,0,1)
        c+=sizes[1]*value(k,1,1,1)
        if k==0:
            a-=F(sizes[0]**2,n);b-=F(sizes[0]*sizes[1],n);c-=F(sizes[1]**2,n)
        assert min(a,c,a*c-b*b)>=0,(n,e,t,k)
        assert n+sizes[0]*kernel(16,k,ang[0])+sizes[1]*kernel(16,k,ang[1])>=0
    for u,v,s in product(ang,repeat=3):
        assert (s-u*v)**2<=F(25,64)*(1-u*u)*(1-v*v)
    assert (n-2)*bound(15,F(5,8))<1 and (n-1)*bound(16,F(5,13))<1
root=Path(__file__).resolve().parent
w=json.loads((root/'triangle_free_stats.json').read_text())
data=run()
cases={(r['p'],i) for r in data.values() for i,j,z in r['survivors']}|{(r['q'],j) for r in data.values() for i,j,z in r['survivors']}
assert {(n,e) for n,e,t in w}==cases
for n,e,t in w:verify(n,e,t)
print('PASS',len(cases),'single-pillar three-point tables with zero all-negative triangles')

"""Exact two-pillar feasibility sieve, using integer arithmetic in every decision."""
from fractions import Fraction as F
from math import comb, gcd, lcm
from collections import Counter
import json,sys

def gegen(n,t,k):
    x,y=F(1),t
    if k==0:return x
    for j in range(1,k):x,y=y,((2*j+n-2)*t*y-j*x)/(j+n-2)
    return y
def scaled(k):
    values=[gegen(16,F(a,13),k) for a in (-5,1,3)]
    D=lcm(*[x.denominator for x in values])
    return (D,*[int(D*x) for x in values])
polys=[scaled(k) for k in range(1,6)]

def least_square(n,total,base):
    d,r=divmod(total,n)
    return (n-r)*(base+6*d)**2+r*(base+6*d+6)**2

def run():
    edges=[m for m in range(1654) if all(58+2*m*gegen(17,F(1,7),k)+2*(1653-m)*gegen(17,F(-2,7),k)>=0 for k in (1,2))]
    lo,hi=min(edges),max(edges)
    assert (lo,hi)==(1035,1061)
    results={}
    for p in range(1,30):
        q=58-p
        counts=Counter()
        survivors=[]
        for i in range(comb(p,2)+1):
            u=18*p+12*i-5*p*p
            if u<0:continue
            for j in range(i if p==q else 0,comb(q,2)+1):
                v=18*q+12*j-5*q*q
                delta=3024-4*(2*p-48)**2-4*(2*q-48)**2-49-16*(u+v)
                if v<0 or delta<0:continue
                counts['frame_ij']+=1
                for z in range(max(0,lo-i-j,p*q+i+j-hi),min(p*q//2,hi-i-j,p*q+i+j-lo)+1):
                    counts['one_axis_ijz']+=1
                    for k,(D,l,h,x) in enumerate(polys,1):
                        A=D*p+2*(i*h+(comb(p,2)-i)*l)
                        B=D*q+2*(j*h+(comb(q,2)-j)*l)
                        C=x*(2*z-p*q if k%2 else p*q)
                        if min(A,B,A*B-C*C)<0:break
                    else:
                        counts['two_point_ijz']+=1
                        def ray(a,b):
                            L=least_square(p,2*a*i+b*z,a*(18-5*p)-3*b*q)
                            R=least_square(q,2*b*j+a*z,b*(18-5*q)-3*a*p)
                            s=a*a*u+b*b*v+6*a*b*(2*z-p*q)
                            g=8*(L+R)-377*s
                            return s>=0 and (g<=0 or g*g<=15*delta*s*s)
                        if not all(ray(a,b) for a,b in [(0,1),(1,0)]):continue
                        counts['pure_ray_ijz']+=1
                        if not all(ray(a,b) for a in range(1,5) for b in range(-4,5) if gcd(a,abs(b))==1):continue
                        survivors.append((i,j,z))
        counts['final_ijz']=len(survivors)
        results[p]={'p':p,'q':q,'counts':dict(counts),'survivors':survivors}
    return results
if __name__=='__main__':
    result=run()
    for p,r in result.items():
        print(p,r['q'],*(r['counts'].get(k,0) for k in ['frame_ij','one_axis_ijz','two_point_ijz','pure_ray_ijz','final_ijz']))
    if len(sys.argv)>1:
        with open(sys.argv[1],'w') as f:json.dump(result,f,separators=(',',':'))

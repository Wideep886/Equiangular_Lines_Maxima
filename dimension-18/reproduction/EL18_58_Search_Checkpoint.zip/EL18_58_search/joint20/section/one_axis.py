"""Verify rational feasibility of the 58-point, two-distance three-point relaxation at every degree."""
from fractions import Fraction as F
from itertools import product
from math import comb

N=58
angles=(F(-2,7),F(1,7))
edges=1035
triangles=[1005,9543,12507,7801]
# multiplicity, positive degree, number of positive neighbours of degree 36,
# and positive edges within positive neighbours.
anchors=[(18,35,20,389),(39,36,27,410),(1,36,27,411)]

def kernel(n,k,t,rad=F(1)):
    p,q=F(1),t
    if k==0:
        return p
    for j in range(1,k):
        p,q=q,((2*j+n-2)*t*q-j*rad*p)/(j+n-2)
    return q

def local_kernel(k,i,j,value):
    u,v=angles[i],angles[j]
    return kernel(16,k,value-u*v,(1-u*u)*(1-v*v))

def norm_bound(n,a,k):
    # Absolute Laplace integral bound with k even, also valid for degree >=k.
    m=k//2
    moment=F(1)
    bound=F(0)
    for j in range(m+1):
        if j:
            moment*=F(2*j-1,n+2*j-3)
        bound+=comb(m,j)*a**(2*(m-j))*(1-a*a)**j*moment
    return bound

def audit_one(d,h,g):
    e=N-1-d
    pp=g
    mm=g+edges-35*d-h
    mp=edges-d-pp-mm
    assert 0<=pp<=comb(d,2) and 0<=mm<=comb(e,2) and 0<=mp<=d*e
    assert 2*pp+mp+d==35*d+h
    assert 2*mm+mp==35*e+40-(d==36)-h
    for k in range(6):
        def block(i,j,slots,plus):
            return plus*local_kernel(k,i,j,angles[1])+(slots-plus)*local_kernel(k,i,j,angles[0])
        a=e*local_kernel(k,0,0,1)+2*block(0,0,comb(e,2),mm)
        b=block(0,1,d*e,mp)
        c=d*local_kernel(k,1,1,1)+2*block(1,1,comb(d,2),pp)
        assert a>=0 and c>=0 and a*c>=b*b,(d,h,g,k)
    return [2*(comb(e,2)-mm),2*mm+2*(d*e-mp),2*mp+2*(comb(d,2)-pp),2*pp]

assert sum(m for m,*_ in anchors)==N
assert sum(m*d for m,d,*_ in anchors)==2*edges
assert sum(m*h for m,d,h,g in anchors if d==35)==sum(m*(d-h) for m,d,h,g in anchors if d==36)
assert sum(m*h for m,d,h,g in anchors if d==36)%2==0
assert sum(m*(d-h) for m,d,h,g in anchors if d==35)%2==0
temp=[0]*4
for m,d,h,g in anchors:
    row=audit_one(d,h,g)
    temp=[v+m*r for v,r in zip(temp,row)]
    print('PASS anchor',m,d,h,g)
assert temp==[6*t for t in triangles]
assert sum(triangles)==comb(N,3)
assert sum(i*t for i,t in enumerate(triangles))==(N-2)*edges
for k in range(6):
    assert N+2*edges*kernel(17,k,angles[1])+2*(comb(N,2)-edges)*kernel(17,k,angles[0])>=0
for u,v,s in product(angles,repeat=3):
    assert (s-u*v)**2<=F(4,25)*(1-u*u)*(1-v*v)
B16=norm_bound(16,F(2,5),6)
B17=norm_bound(17,F(2,7),6)
assert B16*56<1 and B17*57<1
print('PASS k>=6',B16,B17)
print('PASS three-point table',edges,triangles)

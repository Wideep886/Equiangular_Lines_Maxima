"""Exact Farkas certificates for a two-colour, three-point distribution."""
from fractions import Fraction as F
from itertools import permutations,product
from math import comb
from functools import lru_cache
from pathlib import Path
import json

pairs=((0,1),(1,2),(2,0))
types=[]
for cells in ((0,0,0),(0,0,1),(1,1,0),(1,1,1)):
    seen=set()
    for bs in product((0,1),repeat=3):
        mp=dict(zip(map(frozenset,pairs),bs))
        keys=[tuple(mp[frozenset((p[i],p[j]))] for i,j in pairs) for p in permutations(range(3)) if tuple(cells[i] for i in p)==cells]
        key=min(sum(a<<i for i,a in enumerate(x)) for x in keys)
        if key not in seen:
            seen.add(key);types.append((cells,mp))

def angles(c,b):return F(((-3,3) if c else (-5,1))[b],13)
@lru_cache(None)
def ker(k,u,v,t):
    a,b=F(1),t-u*v
    if k==0:return a
    for j in range(1,k):
        a,b=b,((2*j+13)*(t-u*v)*b-j*(1-u*u)*(1-v*v)*a)/(j+13)
    return b

def totals(p,q,i,j,z):
    R=[]
    for v,n,m,e in [(0,p,q,i),(1,p,q,i),(2,q,p,j),(3,q,p,j)]:
        R.extend([comb(n,3),(n-2)*e,0] if v in (0,3) else [m*comb(n,2),m*e,(n-1)*z])
    return R

def exact_row(dat,spec):
    p,q,i,j,z=dat
    tag=spec[0]
    a=[F(0)]*len(types)
    if tag=='tri':
        return [int(len(set(c))==1 and sum(m.values())==0) for c,m in types],spec[1]
    if tag=='eq':
        _,index,sgn=spec
        color,offset=divmod(index,3)
        for h,(cells,mp) in enumerate(types):
            if sum(cells)==color:
                a[h]=sgn*(1 if offset==0 else sum(mp[frozenset((s,t))] for s,t in pairs if 1+int(cells[s]!=cells[t])==offset))
        return a,sgn*totals(*dat)[index]
    _,cell,k,ws=spec
    size=([2*(comb(p,2)-i),2*i,p*q-z,z] if cell==0 else [p*q-z,z,2*(comb(q,2)-j),2*j])
    n=(p,q)[cell]
    ang=[angles(cell!=part,sign) for part in range(2) for sign in range(2)]
    b=sum(s*w*w*ker(k,t,t,1) for s,w,t in zip(size,ws,ang))
    if k==0:b-=F(sum(s*w for s,w in zip(size,ws))**2,n)
    for h,(cells,mp) in enumerate(types):
        for v,s,t in permutations(range(3)):
            if cells[v]!=cell:continue
            l=2*cells[s]+mp[frozenset((v,s))]
            m=2*cells[t]+mp[frozenset((v,t))]
            end=angles(cells[s]!=cells[t],mp[frozenset((s,t))])
            a[h]-=ws[l]*ws[m]*ker(k,ang[l],ang[m],end)
    return a,b

def verify(d,proof):
    A=[F(0)]*len(types);B=F(0)
    for spec,ww in proof:
        w=F(ww)
        assert w>=0
        u,b=exact_row(d,spec)
        A=[old+w*x for old,x in zip(A,u)];B+=w*b
    gap=comb(sum(d[:2]),3)*min(A)-B
    assert gap>0,(d,gap)
    return gap
if __name__=='__main__':
    data=json.loads((Path(__file__).resolve().parent/'coloured_certs.json').read_text())
    for case in data:
        g=verify(case['data'],case['cert'])
        print(case['data'], 'cuts',len(case['cert']),'gap>1/10000', g>F(1,10000))

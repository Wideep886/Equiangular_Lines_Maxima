"""Check the source, make an exact LDL input, then scan every half class including rooted neighbours."""
from pathlib import Path
from math import lcm
import json, os,subprocess,sys,tempfile
here=Path(__file__).resolve().parent;tree=Path(sys.argv[1]).resolve();source=int(sys.argv[2]);goal=int(sys.argv[3]) if len(sys.argv)>3 else source+1
sys.path.insert(0,str(tree/'run12/build'));from half import ldl,gram
from grow import verify
paths={48:'run12/build/grown_D1111-1.json',50:'run14/build/source50.json',52:'run12/build/width24/grown_D211-1.json',54:'run14/rank13/rootfree-3-2.json',56:'run12/build/width24/grown_D1111-1.json'}
z=json.loads((tree/paths[source]).read_text())
if source==54:
    B=z['integer_basis'];S=z['shell_coefficients'];G=json.loads((tree/'run14/rank13/rootfree-3-2-gram.json').read_text())
else:
    B=z['basis'];S=z['shell'];G=z['gram']
assert len(S)==source and verify(B,S)==G
audit=bool(os.environ.get('EL_NEIGHBOR_AUDIT'))
if audit:
    p=[1,0,*range(2,len(B))]; signs=[(-1)**i for i in range(len(B))]; B=[[signs[i]*signs[j]*B[p[i]][p[j]] for j in range(len(B))] for i in range(len(B))]; S=[[signs[i]*v[p[i]] for i in range(len(B))] for v in reversed(S)]
L,d=ldl(B);n=len(d);t=[lcm(*(L[j][i].denominator for j in range(i,n))) for i in range(n)];Q=lcm(*((d[i]/t[i]**2).denominator for i in range(n)));a=[int(Q*d[i]/t[i]**2) for i in range(n)];C=[[int(L[j][i]*t[i]) for i in range(n)] for j in range(n)];assert all(sum(a[k]*C[i][k]*C[j][k] for k in range(n))==Q*B[i][j] for i in range(n) for j in range(n));assert 20*Q<2**62
vals=[len(S),Q]+[v for p in zip(t,a) for v in p]+sum(C,[])+sum(B,[])+sum(S,[])
with tempfile.TemporaryDirectory() as tmp:
    exe=Path(tmp)/'neighbors';subprocess.run(['c++','-std=c++17','-O3',*(['-DAUDIT_RUN'] if audit else []),'-I'+str(tree/'run14/rank13'),str(here/'neighbors.cpp'),'-o',str(exe)],check=True)
    mode=sys.argv[4:]
    if mode and int(mode[0]) in (-3,-4,-6):
        gen=json.loads((here/f'autom{source}.json').read_text())['basis_actions_mod2']
        if audit:
            flip=lambda x:(x&~3)|((x&1)<<1)|((x&2)>>1)
            gen=[[flip(M[j]) for j in p] for M in gen]
        vals += [len(gen)]+sum(gen,[])
    s=subprocess.check_output([str(exe),str(goal)]+mode,input=' '.join(map(str,vals)).encode()).decode();(here/(('audit_' if audit else '')+(f'pairs{source}_target{goal}_limit{mode[0]}.out' if mode else f'census{source}_target{goal}.out'))).write_text(s);print(s)

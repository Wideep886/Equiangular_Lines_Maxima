// Exact one-source census over the orbits of the first class under verified lattice isometries.
using W=uint64_t;
struct Signs {W lo=0,hi=0; void put(int j){(j<64?lo:hi)|=W(1)<<(j%64);} int count()const{return __builtin_popcountll(lo)+__builtin_popcountll(hi);} };
struct HalfClass {
    int b0=0,b1=0,f0=0,f1=0;W old=0;Signs whole,by_bit[18];vector<Coeff>duals;
    Signs slice(int form) const {Signs s;while(form){int j=__builtin_ctz(form);form&=form-1;s.lo^=by_bit[j].lo;s.hi^=by_bit[j].hi;}return s;}
};
int bilinear(const HalfClass&a,const HalfClass&b){return (__builtin_popcount(a.b0&b.f0)+2*__builtin_parity((a.b0&b.f1)^(a.b1&b.f0)))&3;}
int small_ip(const Coeff&x,const Coeff&y){int ans=0;for(int k=0;k<n;k++)ans+=x[k]*y[k];return ans;}
#include "rank3_one.h"
void all_halves(int mode){
    int ng;cin>>ng;assert(ng>0);vector<vector<int>>gen(ng,vector<int>(1<<n));for(auto &perm:gen){Vec M;for(auto&v:M)cin>>v;for(int b=1;b<(1<<n);b++)perm[b]=perm[b&(b-1)]^M[__builtin_ctz(b)];}
    vector<HalfClass> tab(1<<n);vector<int>reps,owner(1<<n,-1),length(1<<n),all_keys;
    vector<Coeff>oldP,oldD;for(const auto &s:source){Coeff v{},d{};for(int j=0;j<n;j++){v[j]=2*s[j];for(int k=0;k<n;k++)d[j]+=2*B[j][k]*s[k];}oldP.push_back(v);oldD.push_back(d);}
    for(int b=1;b<(1<<n);b++)if(!lifts[b].empty()){
        all_keys.push_back(b);auto &r=tab[b];auto &vv=lifts[b];assert(vv.size()<=128);const auto &x=vv[0];r.b0=b;
        for(int j=0;j<n;j++){int y=0;for(int z=0;z<n;z++)y+=B[j][z]*x[z];assert(!(y&1));r.b1|=((x[j]&2)>>1)<<j;r.f0|=((y/2)&1)<<j;r.f1|=((y/2&2)>>1)<<j;}
        for(int t=0;t<(int)vv.size();t++){
            r.whole.put(t);Coeff bv{};for(int j=0;j<n;j++){if(((vv[t][j]-x[j])/2)&1)r.by_bit[j].put(t);int d=0;for(int k=0;k<n;k++)d+=B[j][k]*vv[t][k];assert(abs(d)<=10);bv[j]=d;}r.duals.push_back(bv);
        }
        for(int j=0;j<(int)source.size();j++)if(abs(small_ip(oldP[j],r.duals[0]))%8==4)r.old|=W(1)<<j;
        if(owner[b]>=0)continue;reps.push_back(b);vector<int>q{b};owner[b]=b;
        for(size_t h=0;h<q.size();h++)for(auto &p:gen){int v=p[q[h]];assert(!lifts[v].empty()&&lifts[v].size()==vv.size()&&rooted[v]==rooted[b]);if(owner[v]<0){owner[v]=b;q.push_back(v);}}
        length[b]=q.size();
    }
    if(mode==-6){one_root_cube(tab,gen,oldP,oldD);return;}
    I total=0,nonintegral=0,short_mass=0,test_mass=0,node_mass=0,actual=0,search=0,hits=0,old_only=0,raw_max=0,greedy=0,tri=0,empt=0;
    for(int a:reps){const auto &A=tab[a];for(int b:all_keys){if(owner[b]<a||a==b)continue;
        int mass=length[a]*(owner[b]==a?1:2);int c=a^b;total+=mass;
        if(mode==-4&&!tab[c].whole.count()){old_only+=mass;continue;}
        const auto &B_=tab[b],&C_=tab[c];int ab=bilinear(A,B_);if(ab&1){nonintegral+=mass;continue;}
        int ac=0;if(mode==-4){ac=bilinear(A,C_);int bc=bilinear(B_,C_);assert(!(ac&1)&&!(bc&1)&&(((ab+ac+bc)/2)&1));tri+=mass;}
        const int keys[3]={a,b,c},kinds=(mode==-3?2:3);Signs group[3]={A.slice(B_.f0),B_.slice(A.f0),{}};if(kinds==3)group[2]=C_.slice(A.f0);
        W old=A.old&B_.old;if(kinds==3)old&=C_.old;
        for(int f=0;f<2;f++){
            int pick[3]={f,f^(1^(ab/2)),f^(1^(ac/2))};Signs selected[3];int h=__builtin_popcountll(old);bool empty=false;
            for(int i=0;i<kinds;i++){auto &t=tab[keys[i]];selected[i]=group[i];if(!pick[i]){selected[i].lo^=t.whole.lo;selected[i].hi^=t.whole.hi;}int z=selected[i].count();if(!z)empty=true;h+=z;}
            if(empty){empt+=mass;continue;}raw_max=max<I>(raw_max,h);if(h<goal){short_mass+=mass;continue;}test_mass+=mass;actual++;
            vector<const Coeff*>p,d;
            auto append=[&](int key,int j){p.push_back(&lifts[key][j]);d.push_back(&tab[key].duals[j]);};
            for(int i=0;i<kinds;i++){auto s=selected[i];while(s.lo){int j=__builtin_ctzll(s.lo);s.lo&=s.lo-1;append(keys[i],j);}while(s.hi){int j=__builtin_ctzll(s.hi);s.hi&=s.hi-1;append(keys[i],64+j);}}
            W old_rest=old;while(old_rest){int j=__builtin_ctzll(old_rest);old_rest&=old_rest-1;p.push_back(&oldP[j]);d.push_back(&oldD[j]);}
            assert((int)p.size()==h);int matches=0;vector<bool>taken(h);
            for(int i=0;i<h && matches<=h-goal;i++)if(!taken[i])for(int j=h-1;j>i;j--)if(!taken[j]&&abs(small_ip(*d[i],*p[j]))!=4){taken[j]=true;++matches;break;}
            if(matches>h-goal){greedy+=mass;continue;}search++;
            Solver sol;sol.n=h;sol.w=(h+63)/64;sol.limit=1LL<<60;sol.adj.assign(h,Set(sol.w));for(int i=0;i<h;i++)for(int j=0;j<i;j++)if(abs(small_ip(*d[i],*p[j]))==4){sol.adj[i][j/64]|=W(1)<<(j%64);sol.adj[j][i/64]|=W(1)<<(i%64);}
            Set full(sol.w,~W(0));if(h%64)full.back()=(W(1)<<(h%64))-1;
            if(sol.visit(full,goal)){hits+=mass;if(hits==mass){cout<<"witness "<<a<<' '<<b<<' '<<c<<' '<<f<<'\n';for(int j:sol.best){for(auto x:*p[j])cout<<(int)x<<' ';cout<<'\n';}cout.flush();}}
            assert(!sol.blocked);node_mass+=sol.nodes;
        }
    }}
    cout<<"goal "<<goal<<" classes "<<all_keys.size()<<" orbits "<<reps.size()<<" double_pair_mass "<<total<<" empty_third "<<old_only<<" nonintegral "<<nonintegral<<" ternary_integral "<<tri<<" empty_slices "<<empt<<" small_slices "<<short_mass<<" tested_slice_mass "<<test_mass<<" actual_tests "<<actual<<" max_raw "<<raw_max<<" greedy_mass "<<greedy<<" actual_cliques "<<search<<" actual_nodes "<<node_mass<<" hit_mass "<<hits<<'\n';
}

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
#ifdef AUDIT_RUN
#include "audit_clique.h"
#else
#include "bitsolver.h"
#endif
using Vec=array<int,18>;
using Coeff=array<int8_t,18>;
using I=long long;
constexpr int n=18;
I Q,a[n],t[n],C[n][n];
int B[n][n],goal;
Vec x{},bx{};
vector<vector<Coeff>> lifts(1<<n);
vector<bool> rooted(1<<n);
vector<Vec> source;
map<int,int> histogram,rootfree_histogram;
I floor_div(I x,I y){return x/y-(x%y<0);}
void enumerate(int i,I remaining){
    if(i<0){
        if(remaining && remaining!=4*Q)return;
        int mask=0;Coeff v{};bool positive=false;
        for(int j=0;j<n;j++){
            if(!positive && x[j]<0)return; if(x[j])positive=true;
            mask|=(abs(x[j])%2)<<j;assert(abs(x[j])<=127);v[j]=x[j];
        }
        if(!mask)return;
        if(remaining)rooted[mask]=true;else lifts[mask].push_back(v);return;
    }
    I c=0;for(int j=i+1;j<n;j++)c+=C[j][i]*x[j];
    I z=remaining/a[i],w=sqrtl(z);while((w+1)*(w+1)<=z)++w;while(w*w>z)--w;
    for(x[i]=-floor_div(c+w,t[i]);x[i]<=floor_div(w-c,t[i]);++x[i]){
        I v=c+t[i]*x[i];enumerate(i-1,remaining-a[i]*v*v);
    }
}
#include "pairs.h"
#include "all_half.h"
int main(int argc,char**argv){
    goal=stoi(argv[1]);int m;cin>>m>>Q;assert(Q>0&&Q<(1LL<<56));
    for(int i=0;i<n;i++)cin>>t[i]>>a[i];for(auto&r:C)for(auto&v:r)cin>>v;
    for(auto&r:B)for(auto&v:r)cin>>v;
    for(int i=0;i<m;i++){Vec s{};for(auto&v:s)cin>>v;source.push_back(s);}
    enumerate(n-1,20*Q);
    if(argc>=3&&(atoi(argv[2])==-3||atoi(argv[2])==-4||atoi(argv[2])==-6)){all_halves(atoi(argv[2]));return 0;}
    if(argc>=3){pair_survey(atoi(argv[2]));return 0;}
    int cnt=0,calls=0,max_raw=0,largest_bound=0,winner=0,color_reorders=0,uncolored=0;I nodes=0,total_lifts=0;
    for(int mask=1;mask<(1<<n);++mask){
        const auto &added=lifts[mask];if(added.empty())continue;++cnt;total_lifts+=added.size();
        for(int i=0;i<n;++i){bx[i]=0;for(int j=0;j<n;++j)bx[i]+=B[i][j]*added[0][j];}
        vector<int> retained;
        for(int k=0;k<m;k++){int dot=0;for(int i=0;i<n;i++)dot+=source[k][i]*bx[i];if(abs(dot)%4==2)retained.push_back(k);}
        int h=retained.size()+added.size();histogram[h]++;max_raw=max(h,max_raw);if(!rooted[mask])rootfree_histogram[h]++;
        if(h<goal)continue;
        ++calls;vector<Vec> all,dual;
        for(auto k:retained){auto v=source[k];for(auto &c:v)c*=2;all.push_back(v);}
        for(const auto &u:added){Vec v{};copy(u.begin(),u.end(),v.begin());all.push_back(v);}
        for(const auto &v:all){Vec d{};for(int j=0;j<n;j++)for(int k=0;k<n;k++)d[j]+=B[j][k]*v[k];dual.push_back(d);}
        Solver sol;sol.n=h;sol.w=(h+63)/64;sol.limit=1LL<<60;sol.adj.assign(h,Set(sol.w));
        for(int i=0;i<h;i++)for(int j=0;j<=i;j++){
            int d=0;for(int k=0;k<n;k++)d+=dual[i][k]*all[j][k];assert(i==j?d==20:(d%4==0));
            if(abs(d)==4){sol.adj[i][j/64]|=uint64_t(1)<<(j%64);sol.adj[j][i/64]|=uint64_t(1)<<(i%64);}
        }
        Set full(sol.w,~uint64_t(0));if(h%64)full.back()=(uint64_t(1)<<(h%64))-1;
        vector<int>order,caps;sol.color(full,order,caps,0);largest_bound=max(largest_bound,caps.back());
        if(caps.back()>=goal){
            vector<int>vertices(h);for(int i=0;i<h;i++)vertices[i]=i;
            vector<int>degree(h);for(int i=0;i<h;i++)for(auto w:sol.adj[i])degree[i]+=__builtin_popcountll(w);
            bool certified=false;
            for(int k=0;k<5&&!certified;k++){
                if(k==0)reverse(vertices.begin(),vertices.end());
                else stable_sort(vertices.begin(),vertices.end(),[&](int i,int j){return k%2?degree[i]>degree[j]:degree[i]<degree[j];});
                vector<Set> palette;
                for(int i:vertices){int j=0;for(;j<(int)palette.size();j++){
                    bool clash=false;for(int l=0;l<sol.w;l++)if(palette[j][l]&sol.adj[i][l])clash=true;
                    if(!clash)break;
                }if(j==(int)palette.size())palette.emplace_back(sol.w,0);palette[j][i/64]|=uint64_t(1)<<(i%64);}
                if((int)palette.size()<goal){certified=true;++color_reorders;cout<<"recolor "<<mask<<' '<<k<<' '<<palette.size()<<'\n';}
            }
            if(!certified)++uncolored;
        }
        if(sol.visit(full,goal)){
            ++winner;if(winner==1){cout<<"witness "<<mask<<' '<<goal<<'\n';for(auto i:sol.best){for(auto v:all[i])cout<<v<<' ';cout<<'\n';}}
        }
        assert(!sol.blocked);nodes+=sol.nodes;
    }
    cout<<"classes "<<cnt<<" norm20_rays "<<total_lifts<<" raw_max "<<max_raw<<" candidates "<<calls<<" target "<<goal<<" successes "<<winner<<" nodes "<<nodes<<" largest_coloring "<<largest_bound<<" recolored "<<color_reorders<<" no_color_certificate "<<uncolored<<'\n';
    for(auto [h,c]:histogram)cout<<"raw "<<h<<' '<<c<<'\n';for(auto [h,c]:rootfree_histogram)cout<<"rootfree "<<h<<' '<<c<<'\n';
}

"""The five cores and their local lattice shells; pure Python 3.9+."""
from fractions import Fraction as Q
from itertools import combinations,product
from math import isqrt,lcm
from collections import Counter
from pathlib import Path
import json
DIR=Path(__file__).resolve().parent
def ldl(B):
    n=len(B);A=[[Q(0)]*n for _ in B];d=[]
    for i in range(n):
        for j in range(i):
            A[i][j]=(Q(B[i][j])-sum(A[i][k]*A[j][k]*d[k] for k in range(j)))/d[j]
        A[i][i]=Q(1);d.append(Q(B[i][i])-sum(A[i][k]**2*d[k] for k in range(i)))
        assert d[-1]>0
    return A,d
def inv(B):
    n=len(B);A=[list(map(Q,row))+[Q(i==j) for j in range(n)] for i,row in enumerate(B)]
    for i in range(n):
        v=A[i][i];A[i]=[u/v for u in A[i]]
        for j,row in enumerate(A):
            if i!=j and row[i]:A[j]=[a-row[i]*b for a,b in zip(row,A[i])]
    return [row[n:] for row in A]
def sphere(B):
    L,d=ldl(B);n=len(d);coeff=[0]*n;out=[]
    def visit(i,left):
        if i<0:
            if any(coeff) and next(v for v in coeff if v)>0:out.append([int(5-left),coeff.copy()])
            return
        c=sum((L[j][i]*coeff[j] for j in range(i+1,n)),Q(0))
        t=c.denominator;y=left*t**2/d[i];r=isqrt(y.numerator//y.denominator)
        for x in range(-((r+c.numerator)//t),(r-c.numerator)//t+1):
            coeff[i]=x;visit(i-1,left-d[i]*(x+c)**2)
    visit(n-1,Q(5));return out
def gram(cycles):
    p=[];s=0
    for n in cycles:p.extend(list(range(s+1,s+n))+[s]);s+=n
    n=14;M=[[-1]*n for _ in range(n)]
    for i in range(n):M[i][i]=5
    for i,j in combinations(range(12),2):
        neg=(i//4==j//4) or (i%4==j%4 if i<4 else p[i%4]==j%4)
        M[i+2][j+2]=M[j+2][i+2]=-1 if neg else 1
    return M
def enumerate_core(cycles):
    G=gram(cycles);I=[0,1,2,3,4,6,7,8,10,11,12]
    B=[[G[i][j] for j in I] for i in I];S=sphere(B)
    AA=inv(B);D=lcm(*(x.denominator for row in AA for x in row));T=[[int(x*D) for x in row] for row in AA]
    # The fourth line in every tetrahedron is the negative sum of the other three and the anchor pair.
    for k in range(3):
        assert all(sum(G[n][j] for n in [0,1]+list(range(2+4*k,6+4*k)))==0 for j in range(14))
    coeff=[x for n,x in S if n==5]
    assert len(S)==len(coeff)
    dot=lambda a,b:sum(x*y for x,y in zip(a,b))
    sig=[[dot(x,row) for row in B] for x in coeff];SS=[[dot(a,b) for a in coeff] for b in sig]
    assert all(SS[i][i]==5 and all(abs(SS[i][j])==1 for j in range(i)) for i in range(len(SS)))
    real=[]
    for tail in product((-1,1),repeat=10):
        s=(1,)+tail;u=[dot(s,row) for row in T]
        if dot(s,u)==5*D and all(abs(dot(u,[g[i] for i in I]))==D for g in G):
            real.append(s)
    # Rays not already in G cannot have a coordinate +/-5 against the basis.
    shell_real=len(G)+len(real);assert shell_real==len(S)
    return dict(gram=G,basis=I,denominator=D,integral_inverse=T,shell_coefficients=coeff,shell_gram=SS,real_span_lines=shell_real)
def main():
    obj={}
    for c in [(4,),(3,1),(2,2),(2,1,1),(1,1,1,1)]:
        name='D'+''.join(map(str,c));z=enumerate_core(c);obj[name]=z
        print(name,len(z['basis']),z['real_span_lines'],z['denominator'],flush=True)
    (DIR/'cores.json').write_text(json.dumps(obj,separators=(',',':')))
if __name__=='__main__':main()

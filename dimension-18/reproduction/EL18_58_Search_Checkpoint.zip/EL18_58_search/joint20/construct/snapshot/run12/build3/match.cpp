#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
using U=uint64_t;
using V=array<int,18>;
using Mat=vector<vector<int>>;
int n,m;array<U,64> a,b;
int firstbit(U x){return __builtin_ctzll(x);}
int weight(U x){return __builtin_popcountll(x);}
using cell=pair<U,U>;
bool rec(vector<cell> c,vector<int>&p){
 while(true){
  bool split=false;
  for(int t=0;t<(int)c.size()&&!split;t++){
   auto [u,v]=c[t];
   for(int k=0;k<(int)c.size()&&!split;k++){
    auto [x,y]=c[k];if(!(x&(x-1)))continue;
    array<U,65> l{},r{};
    while(x){int j=firstbit(x);x&=x-1;l[weight(a[j]&u)]|=U(1)<<j;}
    while(y){int j=firstbit(y);y&=y-1;r[weight(b[j]&v)]|=U(1)<<j;}
    vector<cell> extra;
    for(int z=0;z<=m;z++){
      if(weight(l[z])!=weight(r[z]))return false;
      if(l[z])extra.push_back({l[z],r[z]});
    }
    if(extra.size()>1){
      c[k]=extra[0];c.insert(c.end(),extra.begin()+1,extra.end());split=true;
    }
   }
  }
  if(!split)break;
 }
 int k=-1,s=100;
 for(int j=0;j<(int)c.size();j++){int v=weight(c[j].first);if(v>1&&v<s){k=j;s=v;}}
 if(k<0){
  for(auto [x,y]:c)p[firstbit(x)]=firstbit(y);
  for(int i=0;i<m;i++)for(int j=0;j<i;j++)if(((a[i]>>j)^(b[p[i]]>>p[j]))&1)return false;
  return true;
 }
 auto [x,y]=c[k];U one=x&-x;
 while(y){
  U two=y&-y;y-=two;auto d=c;d[k].first^=one;d[k].second^=two;d.emplace_back(one,two);
  if(rec(d,p))return true;
 }
 return false;
}
array<U,64> sw(const Mat&G,int r){
 array<U,64> A{};for(int i=0;i<m;i++)for(int j=0;j<i;j++)if(i!=r&&j!=r&&G[i][j]*G[r][i]*G[r][j]<0){
  A[i]|=U(1)<<j;A[j]|=U(1)<<i;
 }
 return A;
}
int main(){
 int nr;cin>>n>>m>>nr;int B[18][18]{};for(int i=0;i<n;i++)for(int j=0;j<n;j++)cin>>B[i][j];
 vector<V>S(m),T(m);for(int i=0;i<m;i++)for(int j=0;j<n;j++)cin>>S[i][j];
 for(int k=0;k<m;k++)for(int i=0;i<n;i++)for(int j=0;j<n;j++)T[k][i]+=B[i][j]*S[k][j];
 Mat G(m,vector<int>(m));for(auto&row:G)for(int&j:row)cin>>j;
 vector<array<U,64>> targets;for(int i=0;i<m;i++)targets.push_back(sw(G,i));
 U vertices=(U(1)<<m)-1;
 for(int c=0;c<nr;c++){
  int key,old,n9,n12,n36,n45;cin>>key>>old>>n9>>n12>>n36>>n45;
  if(n36||n45+old!=m)return 2;
  V r{};for(int i=0,k=key;i<n;i++,k/=3)r[i]=k%3;
  vector<V>L;
  for(int i=0;i<m;i++){
   int ip=0;for(int t=0;t<n;t++)ip+=T[i][t]*r[t];
   if(ip%3==0){L.push_back(S[i]);for(int&t:L.back())t*=3;}
  }
  if(int(L.size())!=old)return 3;
  for(int i=0;i<n45;i++){V v{};for(int j=0;j<n;j++)cin>>v[j];L.push_back(v);}
  Mat E(m,vector<int>(m));
  for(int i=0;i<m;i++){
   V t{};for(int l=0;l<n;l++)for(int h=0;h<n;h++)t[l]+=B[l][h]*L[i][h];
   for(int j=0;j<=i;j++){
    int ip=0;for(int k=0;k<n;k++)ip+=t[k]*L[j][k];
    if(i==j?ip!=45:abs(ip)!=9)return 4;
    E[i][j]=E[j][i]=ip/9;
   }
  }
  a=sw(E,0);vector<int> p(m),s(m);
  bool ok=false;
  for(int j=0;j<m&&!ok;j++){b=targets[j];U two=U(1)<<j;ok=rec({{1,two},{vertices^1,vertices^two}},p);}
  if(!ok){cout<<key<<" -1\n";continue;}
  for(int i=0;i<m;i++)s[i]=i?E[0][i]*G[p[0]][p[i]]:1;
  for(int i=0;i<m;i++)for(int j=0;j<=i;j++)if(E[i][j]!=s[i]*s[j]*G[p[i]][p[j]])return 5;
  cout<<key;for(int j:p)cout<<" "<<j;for(int j:s)cout<<" "<<j;cout<<"\n";
 }
}

"""Produce and check signed automorphisms of each Gram and their exact basis actions."""
import json
from thirds import HERE,sources,gram
from isomorphism import switched,map_graph
from itertools import chain
def autos(G):
    n=len(G);out=[];A=switched(G,0)
    for r in range(1,n):
        b=[0]*n;b[r]=1;a=[1]+[0]*(n-1)
        p=map_graph(A,switched(G,r),a,b)
        if p:
            s=[1]+[G[0][i]*G[r][p[i]] for i in range(1,n)]
            out.append((p,s))
    colors=[0]*n;colors[0]=1
    for v in range(1,n-1):
        for w in range(v+1,n):
            a=colors.copy();b=colors.copy();a[v]=b[w]=v+1
            p=map_graph(A,A,a,b)
            if p:
                s=[1]+[G[0][i]*G[0][p[i]] for i in range(1,n)];out.append((p,s))
        colors[v]=v+1
    return out
def compose(a,b):return tuple(a[i] for i in b)
def perm_group_size(gens,n):
    # Stabilizer chain via Schreier generators; all generators are ordinary ray permutations.
    G=set(map(tuple,gens));identity=tuple(range(n));size=1
    while G:
        G.discard(identity)
        if not G:break
        b=next(i for i in range(n) if any(p[i]!=i for p in G))
        bfs={b:identity};q=[b]
        for t in q:
            for g in G:
                u=g[t]
                if u not in bfs:bfs[u]=compose(g,bfs[t]);q.append(u)
        size*=len(q);stab=set();inv={}
        for t,h in bfs.items():
            qinv=[0]*n
            for i,x in enumerate(h):qinv[x]=i
            inv[t]=tuple(qinv)
        for t,h in bfs.items():
            for p in G:
                spr=compose(inv[p[t]],compose(p,h))
                if spr!=identity:stab.add(spr)
        G=stab
    return size
def main():
    out={}
    for m,p in sources.items():
        data=json.loads(p.read_text());G,S,B=data['gram'],data['shell'],data['basis']
        points=[]
        for i in range(18):
            j=next(j for j,s in enumerate(S) if sum(bool(x) for x in s)==1 and abs(s[i])==1)
            points.append((j,S[j][i]))
        allmaps=autos(G);print(m,'recorded',len(allmaps),flush=True)
        # Reversing the stabilizer chain grows the subgroup by small indices.
        if any(not all(G[i][j]==s[i]*s[j]*G[p[i]][p[j]] for i in range(m) for j in range(m)) for p,s in allmaps):raise ValueError()
        retained=[];g=1
        for p,s in reversed(allmaps):
            if len(retained)>=7:break
            # Keep at most seven verified maps for bounded orbit traversal.
            # Full group generation is not required.
            ng=perm_group_size([a[0] for a in retained]+[p],m)
            if ng>g:retained.append((p,s));g=ng
        # Also select several transitions moving the anchor, if the prefix fixed it.
        if retained and all(p[0]==0 for p,s in retained):
            for p,s in allmaps:
                if p[0]!=0:retained.append((p,s));break
        maps=[]
        for perm,sgn in retained:
            T=[[a*sgn[j]*v for v in S[perm[j]]] for j,a in points]
            assert gram(B,T)==B
            assert all([sum(x*t[i] for x,t in zip(s,T)) for i in range(18)]==[sgn[j]*v for v in S[perm[j]]] for j,s in enumerate(S))
            maps.append(dict(permutation=perm,signs=sgn,basis_images=T))
        print(m,'selected',len(maps),'size lower',g,flush=True)
        out[m]=maps;(HERE/'automorphisms.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':main()

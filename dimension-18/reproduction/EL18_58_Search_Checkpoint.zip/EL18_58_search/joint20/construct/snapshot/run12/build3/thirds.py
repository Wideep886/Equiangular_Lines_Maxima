"""Constrained exact blocks of projective ternary neighbours of the three certified rootless lattices."""
from collections import Counter
from itertools import combinations,product
from math import lcm
from pathlib import Path
import json,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
BUILD=HERE.parent/'build'
sys.path.insert(0,str(BUILD))
from grow import gram,dot
from core import ldl
sources={56:BUILD/'width24/grown_D1111-1.json',52:BUILD/'width24/grown_D211-1.json',48:BUILD/'grown_D1111-1.json'}
def code(x):
    a=sum((v%3)*3**i for i,v in enumerate(x));b=sum((-v%3)*3**i for i,v in enumerate(x))
    return min(a,b)
def triangles(G,S):
    result={9:Counter(),21:Counter()}
    for i,j,k in combinations(range(len(S)),3):
        z=G[i][j]*G[j][k]*G[k][i];p=z*G[i][j];q=z*G[i][k]
        x=[a+p*b+q*c for a,b,c in zip(S[i],S[j],S[k])];key=code(x)
        if key:result[15+6*z][key]+=1
    return result
def engine(B,S,keys,mode,exe):
    n=len(B);L,d=ldl(B);t=[lcm(*(L[j][i].denominator for j in range(i,n))) for i in range(n)]
    Q=lcm(*((d[i]/t[i]**2).denominator for i in range(n)));a=[int(Q*d[i]/t[i]**2) for i in range(n)]
    C=[[int(v*t[i]) for i,v in enumerate(row)] for row in L]
    assert all(sum(a[k]*C[i][k]*C[j][k] for k in range(n))==Q*B[i][j] for i in range(n) for j in range(n))
    factors=[[dot(row,s) for row in B] for s in S]
    args=[n,len(S),len(keys),Q]+[v for z in zip(t,a) for v in z]+sum(C,[])+sum(factors,[])+[v for u in keys for v in (u,mode)]
    raw=subprocess.check_output([exe],input=' '.join(map(str,args)).encode()).decode().splitlines()
    assert len(raw)==len(keys)
    return [list(map(int,row.split())) for row in raw]
def verify_winner(B,S,rows):
    key,keep,n9,n12,n36,n45,*out=rows
    assert not n36
    n=len(B);v=[out[j:j+n] for j in range(0,len(out),n)]
    r=[key//3**i%3 for i in range(n)];short=[[3*a for a in s] for s in S if dot(r,[dot(t,s) for t in B])%3==0]
    assert len(short)==keep and len(v)==n45
    V=short+v;H=gram(B,V)
    assert all(H[i][i]==45 and all(abs(H[i][j])==9 for j in range(i)) for i in range(len(V)))
    return dict(key=key,old=keep,new=n45,coords_times_three=V,gram=[[x//9 for x in t] for t in H])
def main():
    output={}
    with tempfile.TemporaryDirectory() as tmp:
        exe=str(Path(tmp)/'thirds');subprocess.run(['c++','-O3','-std=c++17',str(HERE/'thirds.cpp'),'-o',exe],check=True)
        for m,p in sources.items():
            src=json.loads(p.read_text());B,S,G=src['basis'],src['shell'],src['gram'];D=triangles(G,S)
            keys=sorted(set(D[21])-set(D[9]));rows=engine(B,S,keys,0,exe)
            hist=Counter();winner=[];best=0;kinds=Counter()
            for key,old,n9,n12,n36,n45 in rows:
                if not n45:kinds['no_norm45']+=1;continue
                if n36:kinds['rooted']+=1;continue
                hist[old+n45]+=1;kinds['rootfree']+=1
                if old+n45>best:best=old+n45;winner=[key]
                elif old+n45==best:winner.append(key)
            cert=None
            if winner:cert=verify_winner(B,S,engine(B,S,[winner[0]],1,exe)[0])
            rec=dict(negative_triangles=sum(D[9].values()),positive_triangles=sum(D[21].values()),negative_classes=len(D[9]),positive_classes=len(D[21]),overlap=len(set(D[9])&set(D[21])),covered=len(keys),kinds=kinds,hist=hist,best=best,best_witness=cert)
            output[m]=rec;print(m,{k:v for k,v in rec.items() if k!='best_witness'},flush=True)
            (HERE/'triangles.json').write_text(json.dumps(output,separators=(',',':')))
if __name__=='__main__':main()

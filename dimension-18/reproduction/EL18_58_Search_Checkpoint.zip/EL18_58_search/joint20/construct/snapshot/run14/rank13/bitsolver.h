using Set=vector<uint64_t>;
struct Solver {
 int n,w,goal;long long nodes=0,limit;bool blocked=false;vector<Set>adj;vector<int>cl,best,labels;
 static int shift(uint64_t x){return __builtin_ctzll(x);}
 bool color(Set c,vector<int>&order,vector<int>&caps,int need) {
  int ct=0,left=0;for(auto v:c)left+=__builtin_popcountll(v);if(left<need)return false;
  while(left){++ct;Set available=c;for(int a=0;a<w;++a)while(available[a]){
   int bit=shift(available[a]),u=64*a+bit;uint64_t b=uint64_t(1)<<bit;
   c[a]&=~b;available[a]&=~b;--left;order.push_back(u);caps.push_back(ct);
   for(int j=a;j<w;++j)available[j]&=~adj[u][j];
  }}return ct>=need;
 }
 bool visit(Set c,int need) {
  if(!need){best=cl;return true;}if(++nodes>limit){blocked=true;return false;}
  vector<int>order,cap;if(!color(c,order,cap,need))return false;
  for(int k=(int)order.size()-1;k>=0;--k){if(cap[k]<need)return false;int v=order[k];Set next(w);
   for(int j=0;j<w;++j)next[j]=c[j]&adj[v][j];
   cl.push_back(v);if(visit(next,need-1))return true;cl.pop_back();if(blocked)return false;c[v/64]&=~(uint64_t(1)<<(v%64));
  }return false;
 }
};

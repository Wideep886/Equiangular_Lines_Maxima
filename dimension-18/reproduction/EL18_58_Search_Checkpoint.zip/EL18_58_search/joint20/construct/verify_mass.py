"""Independent finite-quadratic-space counts, using the old norm-20 shell enumerator for holes."""
from itertools import combinations
from pathlib import Path
from math import lcm,comb
import json,sys,subprocess,tempfile
here=Path(__file__).resolve().parent;tree=Path(sys.argv[1]).resolve();sys.path.insert(0,str(tree/'run12/build'));from half import ldl
files={48:'run12/build/grown_D1111-1.json',50:'run14/build/source50.json',52:'run12/build/width24/grown_D211-1.json',54:'run14/rank13/rootfree-3-2.json',56:'run12/build/width24/grown_D1111-1.json'}
def stats(src,cc):
 z=json.loads((tree/files[src]).read_text());B=z.get('basis',z.get('integer_basis'));F,d=ldl(B);n=len(d);L=[lcm(*(F[j][i].denominator for j in range(i,n))) for i in range(n)];Q=lcm(*((d[i]/L[i]**2).denominator for i in range(n)));a=[int(Q*d[i]/L[i]**2) for i in range(n)];C=[[int(x*L[i]) for i,x in enumerate(r)] for r in F];args=[n,0,Q]+[v for e in zip(L,a) for v in e]+sum(C,[])
 holes=list(map(int,subprocess.check_output([str(cc)],input=' '.join(map(str,args)).encode()).split()));assert all(all(x%2==1 for x in r) for r in B)
 def omega(x,y):
  t=sum(B[i][j] for i in range(n) if x>>i&1 for j in range(n) if y>>j&1);assert t%2==0;return (t//2)%2
 basis=[1|(1<<i) for i in range(1,n)];rows=[sum(omega(x,y)<<i for i,y in enumerate(basis)) for x in basis];p={}
 for v in rows:
  while v and v.bit_length() in p:v^=p[v.bit_length()]
  if v:p[v.bit_length()]=v
 rank=len(p);r=n-1;rad=2**(r-rank);N=2**r;full=N-1
 def deg(x):return N//(2 if any(omega(x,y) for y in basis) else 1)-2
 all_orth=((rad-1)*(N-2)+(N-rad)*(N//2-2))//2
 orth_holes=sum(not omega(x,y) for x,y in combinations(holes,2));punched_orth=all_orth-sum(map(deg,holes))+orth_holes
 punched_all=comb(full-len(holes),2)
 all_planes=full*(N-2)//6;hits=sum(1 for x,y,z in combinations(holes,3) if x^y==z);bad_hole_planes=sum(1 for x,y,z in combinations(holes,3) if x^y==z and not omega(x,y))
 punched_planes=all_planes-len(holes)*(N//2-1)+comb(len(holes),2)-hits
 orth_planes=all_orth//3-sum(deg(x)//2 for x in holes)+orth_holes-bad_hole_planes
 data=dict(holes=holes,alternating_rank=rank,unordered_pairs=punched_all,integral_pairs=punched_orth,nonempty_planes=punched_planes,integral_planes=orth_planes)
 for mode in (-3,-4):
  f=here/f'pairs{src}_target58_limit{mode}.out'
  if not f.exists():continue
  v=f.read_text().strip().splitlines()[-1].split();s={k:int(n) for k,n in zip(v[::2],v[1::2])};assert s['double_pair_mass']==2*punched_all
  if mode==-3:assert s['nonintegral']==2*(punched_all-punched_orth)
  else:assert s['ternary_integral']==6*orth_planes and s['empty_third']==2*punched_all-6*punched_planes
 return data
with tempfile.TemporaryDirectory() as tmp:
 # Keep the archived half.cpp sphere engine unchanged, emitting only its missing even masks.
 old=(tree/'run12/build/half.cpp').read_text();line=' sphere(n-1,20*Q);';assert old.count(line)==1
 old=old.replace(line,line+'\n for(int m=1;m<(1<<n);m++)if(!(__builtin_popcount(m)%2)&&!n20[m])cout<<m<<" ";cout<<"\\n";return 0;');cpp=Path(tmp)/'holes.cpp';cpp.write_text(old);cc=Path(tmp)/'holes';subprocess.run(['c++','-O3','-std=c++17',str(cpp),'-o',str(cc)],check=True)
 out={s:stats(s,cc) for s in files};print(json.dumps(out,indent=2));(here/'verify_mass.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

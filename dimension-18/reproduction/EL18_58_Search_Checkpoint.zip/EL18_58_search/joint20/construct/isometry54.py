"""Switching isometry certificates for all rare root-free half classes of the 54 source."""
import gzip,json,subprocess,sys,tempfile
from pathlib import Path
from collections import defaultdict
from math import lcm
base=Path(sys.argv[1]).resolve();here=Path(__file__).resolve().parent
sys.path.insert(0,str(base/'run12/build'));from half import ldl,gram,dot
z=json.loads((base/'run14/rank13/rootfree-3-2.json').read_text());B,S=z['integer_basis'],z['shell_coefficients'];n=len(B);G=gram(B,S);cols=[[dot(b,s) for b in B] for s in S]
F,d=ldl(B);t=[lcm(*(F[j][i].denominator for j in range(i,n))) for i in range(n)];Q=lcm(*((d[i]/t[i]**2).denominator for i in range(n)));a=[int(Q*d[i]/t[i]**2) for i in range(n)];C=[[int(x*t[i]) for i,x in enumerate(r)] for r in F]
arg=[n,len(S),Q]+[v for p in zip(t,a) for v in p]+sum(C,[])+sum(cols,[])
def invoke(exe,x,*flags):return subprocess.check_output([str(exe),*flags],input=' '.join(map(str,x)).encode())
with tempfile.TemporaryDirectory() as tmp:
    h=Path(tmp)/'half';subprocess.run(['c++','-O3','-std=c++17',str(base/'run12/build/half.cpp'),'-o',str(h)],check=True)
    raw=invoke(h,arg,'rare').splitlines();cnt,rooted,maximum,win,keep,reflected=map(int,raw[0].split());rare=defaultdict(list)
    for row in raw[2:]:k,*u=map(int,row.split());rare[k].append(u)
    assert len(rare)==cnt-rooted-reflected==258
    def get(k):
        us=rare[k];chosen=[[2*x for x in s] for s,col in zip(S,cols) if dot(col,us[0])%4==2]+us
        H=gram(B,chosen);assert len(H)==54 and all(H[i][i]==20 and all(abs(H[i][j])==4 for j in range(i)) for i in range(54));return [[x//4 for x in r] for r in H]
    tables={k:get(k) for k in sorted(rare)};args=[54,len(rare)]+sum(G,[])
    for k,H in tables.items():args += [k]+sum(H,[])
    (Path(tmp)/'matcher_prefix.h').write_text((base/'run12/build3/match.cpp').read_text().split('int main(){')[0]);exe=Path(tmp)/'match';subprocess.run(['c++','-O3','-std=c++17','-I'+tmp,str(here/'match54.cpp'),'-o',str(exe)],check=True)
    out=invoke(exe,args);miss=[];checked=0;seen=set()
    for line in out.splitlines():
        k,*w=map(int,line.split());assert k in tables and k not in seen;seen.add(k)
        if w==[-1]:miss.append(k);continue
        p,s=w[:54],w[54:];assert sorted(p)==list(range(54)) and len(s)==54 and all(abs(v)==1 for v in s)
        assert all(tables[k][i][j]==s[i]*s[j]*G[p[i]][p[j]] for i in range(54) for j in range(54));checked+=1
    assert seen==set(tables);print('reflections',reflected,'explicit_isometries',checked,'unmatched',len(miss),miss[:10]);(here/'isometries54.txt.gz').write_bytes(gzip.compress(out,mtime=0))

// Count every three-space whose seven nonzero classes have no norm-16 lift.
// The least two independent masks and the least member of the remaining coset are canonical.
void cube_survey(const vector<PlaneSide>&good,bool){
 vector<int>ids,form(1<<n),marked(1<<n);for(int b=1;b<(1<<n);b++)if(!__builtin_parity(b)&&!rooted[b]){
     ids.push_back(b);marked[b]=1;int v=0;for(int j=0;j<n;j++){int y=0;for(int k=0;k<n;k++)if((b>>k)&1)y+=B[j][k];assert(y%2==0);v|=((y/2)&1)<<j;}form[b]=v;
 }
 I all=0,integral=0,all_lifts=0,integral_lifts=0;I single_incidence=0;for(int a:ids)for(int b:ids){int c=a^b;if(a>=b||b>=c||!marked[c])continue;int ab=__builtin_parity(a&form[b]);
    for(int d:ids){if(d==a||d==b||d==c)continue;int ad=d^a,bd=d^b,cd=d^c;
      if(!ab&&!__builtin_parity(a&form[d])&&!__builtin_parity(b&form[d])){
          int miss=(!marked[ad])+(!marked[bd])+(!marked[cd]);if(miss==1 && (!marked[ad]||d<ad) && (!marked[bd]||d<bd) && (!marked[cd]||d<cd))++single_incidence;
      }
      if(d<=c||ad<d||bd<d||cd<d||!marked[ad]||!marked[bd]||!marked[cd])continue;
      ++all;bool lifted=!lifts[a].empty()&&!lifts[b].empty()&&!lifts[c].empty()&&!lifts[d].empty()&&!lifts[ad].empty()&&!lifts[bd].empty()&&!lifts[cd].empty();all_lifts+=lifted;
      if(ab||__builtin_parity(a&form[d])||__builtin_parity(b&form[d]))continue;++integral;integral_lifts+=lifted;
    }
 }
 assert(single_incidence%4==0);cout<<"one_root_class_integral_cubes "<<single_incidence/4<<" good_lifted "<<good.size()<<" no_norm16 "<<ids.size()<<" binary_cubes "<<all<<" integral "<<integral<<" all_liftable_cubes "<<all_lifts<<" integral_liftable "<<integral_lifts<<'\n';
}

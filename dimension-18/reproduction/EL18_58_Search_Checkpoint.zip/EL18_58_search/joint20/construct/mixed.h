// The third class is rooted while the two summands are individually root-free.
void mixed_planes(const vector<PlaneSide>& good){
    vector<Vec> d(1<<n);vector<uint64_t>keep(1<<n);for(int mask=1;mask<(1<<n);mask++)if(!lifts[mask].empty()){
        auto &dual=d[mask];for(int j=0;j<n;j++)for(int k=0;k<n;k++)dual[j]+=B[j][k]*lifts[mask][0][k];
        for(int i=0;i<(int)source.size();i++){int ip=0;for(int j=0;j<n;j++)ip+=source[i][j]*dual[j];if(abs(ip)%4==2)keep[mask]|=uint64_t(1)<<i;}
    }
    I planes=0,nonintegral=0,inconsistent=0,slices=0,short_slices=0,tests=0,hits=0,nodes=0,qualified=0;int maximum=0;
    for(int i=0;i<(int)good.size();i++)for(int j=0;j<i;j++){
        int u=good[i].mask,v=good[j].mask,w=u^v;if(lifts[w].empty()||!rooted[w])continue;++planes;
        int keys[]={u,v,w};int ab=dot_short(d[u],lifts[v][0]),ac=dot_short(d[u],lifts[w][0]),bc=dot_short(d[v],lifts[w][0]);
        if(ab%4){++nonintegral;continue;}assert(ac%4==0&&bc%4==0);
        int needed[]={1^(abs(ab/4)%2),1^(abs(ac/4)%2),1^(abs(bc/4)%2)};
        if(needed[0]^needed[1]^needed[2]){++inconsistent;continue;}
        int peers[]={v,u,u};vector<int>part[3][2];for(int k=0;k<3;k++)for(int a=0;a<(int)lifts[keys[k]].size();a++){
            int t=dot_short(d[peers[k]],lifts[keys[k]][a])-dot_short(d[peers[k]],lifts[keys[k]][0]);assert(t%4==0);part[k][abs(t/4)%2].push_back(a);
        }
        auto common=keep[u]&keep[v]&keep[w];int old=__builtin_popcountll(common);bool used=false;
        for(int t=0;t<2;t++){
            int choose[]={t,t^needed[0],t^needed[1]};int h=old;bool empty=false;for(int a=0;a<3;a++){h+=part[a][choose[a]].size();if(part[a][choose[a]].empty())empty=true;}
            if(empty)continue;slices++;maximum=max(maximum,h);if(h<goal){short_slices++;continue;}used=true;tests++;
            vector<Vec>P,D;for(int l=0;l<(int)source.size();l++)if((common>>l)&1){auto x=source[l];for(auto &z:x)z*=2;P.push_back(x);}
            for(int a=0;a<3;a++)for(int l:part[a][choose[a]]){Vec x{};copy(lifts[keys[a]][l].begin(),lifts[keys[a]][l].end(),x.begin());P.push_back(x);}
            for(auto &x:P){Vec y{};for(int l=0;l<n;l++)for(int m=0;m<n;m++)y[l]+=B[l][m]*x[m];D.push_back(y);}assert((int)P.size()==h);
            Solver sol;sol.n=h;sol.w=(h+63)/64;sol.limit=1LL<<60;sol.adj.assign(h,Set(sol.w));for(int l=0;l<h;l++)for(int m=0;m<l;m++){
                int ip=0;for(int k=0;k<n;k++)ip+=D[l][k]*P[m][k];if(abs(ip)==4){sol.adj[l][m/64]|=uint64_t(1)<<(m%64);sol.adj[m][l/64]|=uint64_t(1)<<(l%64);}}
            Set full(sol.w,~uint64_t(0));if(h%64)full.back()=(uint64_t(1)<<(h%64))-1;
            if(sol.visit(full,goal)){++hits;if(hits<=3){cout<<"mixed_hit "<<u<<' '<<v<<' '<<w<<' '<<t<<'\n';for(int l:sol.best){for(auto c:P[l])cout<<c<<' ';cout<<'\n';}}}
            assert(!sol.blocked);nodes+=sol.nodes;
        }if(used)qualified++;
    }
    cout<<"good "<<good.size()<<" rooted_sum_planes "<<planes<<" nonintegral "<<nonintegral<<" inconsistent "<<inconsistent<<" nonempty_slices "<<slices<<" short_slices "<<short_slices<<" tested_slices "<<tests<<" tested_planes "<<qualified<<" max_slice "<<maximum<<" nodes "<<nodes<<" hits "<<hits<<" target "<<goal<<'\n';
}

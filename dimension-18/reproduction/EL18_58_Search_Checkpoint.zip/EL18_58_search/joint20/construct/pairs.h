// A pair of separately root-free half-classes has conflicts only between its two new parts.
struct PlaneSide {
    int mask;
    uint64_t kept=0;
    vector<Vec> dual;
};
int dot_short(const Vec& left,const Coeff& right){
    int d=0;for(int i=0;i<n;i++)d+=left[i]*right[i];return d;
}
bool augment(int left, const vector<uint64_t>& conflicts, uint64_t& seen, vector<int>& owners){
    uint64_t next=conflicts[left]&~seen;
    while(next){int j=__builtin_ctzll(next);uint64_t bit=uint64_t(1)<<j;next&=~bit;
        if(seen&bit)continue;seen|=bit;
        if(owners[j]<0||augment(owners[j],conflicts,seen,owners)){owners[j]=left;return true;}
    }return false;
}
void plane_survey(const vector<PlaneSide>& sides){
    vector<int> id(1<<n,-1);for(int i=0;i<(int)sides.size();i++)id[sides[i].mask]=i;
    I triples=0,cross_bad=0,size_bad=0,calls=0,nodes=0,hits=0;int max_raw=0,max_color=0;
    for(int i=0;i<(int)sides.size();i++)for(int j=0;j<i;j++){
        int k=id[sides[i].mask^sides[j].mask];if(k<0||k>=j)continue;triples++;
        const PlaneSide *p[]={&sides[i],&sides[j],&sides[k]};
        if(dot_short(p[0]->dual[0],lifts[p[1]->mask][0])%4){cross_bad++;continue;}
        int old=__builtin_popcountll(p[0]->kept&p[1]->kept&p[2]->kept),h=0;vector<const Vec*> dual;vector<const Coeff*> primal;
        for(auto a:p)for(int l=0;l<(int)a->dual.size();l++){dual.push_back(&a->dual[l]);primal.push_back(&lifts[a->mask][l]);++h;}
        max_raw=max(max_raw,h+old);if(h+old<goal){size_bad++;continue;}
        Solver sol;sol.n=h;sol.w=(h+63)/64;sol.limit=1LL<<60;sol.adj.assign(h,Set(sol.w));
        for(int a=0;a<h;a++)for(int b=0;b<a;b++)if(abs(dot_short(*dual[a],*primal[b]))==4){sol.adj[a][b/64]|=uint64_t(1)<<(b%64);sol.adj[b][a/64]|=uint64_t(1)<<(a%64);}
        Set full(sol.w,~uint64_t(0));if(h%64)full.back()=(uint64_t(1)<<(h%64))-1;vector<int>ord,cap;sol.color(full,ord,cap,0);max_color=max(max_color,old+cap.back());
        calls++;if(sol.visit(full,goal-old)){hits++;if(hits<8){cout<<"plane_hit "<<p[0]->mask<<' '<<p[1]->mask<<' '<<p[2]->mask<<" old "<<old<<" new "<<sol.best.size()<<'\n';for(auto x:sol.best){for(auto c:*primal[x])cout<<(int)c<<' ';cout<<'\n';}}}
        assert(!sol.blocked);nodes+=sol.nodes;
    }
    cout<<"sides "<<sides.size()<<" xor_triples "<<triples<<" cross_nonintegral "<<cross_bad<<" too_small "<<size_bad<<" tested "<<calls<<" nodes "<<nodes<<" max_raw "<<max_raw<<" max_coloring_with_old "<<max_color<<" hits "<<hits<<" target "<<goal<<'\n';
}
#include "mixed.h"
#include "cubes.h"
void pair_survey(int limit){
    assert(source.size()<64);vector<PlaneSide>sides;
    for(int mask=1;mask<(1<<n);mask++){
        if(rooted[mask]||lifts[mask].empty())continue;
        PlaneSide side;side.mask=mask;const auto &a=lifts[mask];assert(a.size()<64);
        for(const auto &v:a){Vec b{};for(int i=0;i<n;i++)for(int j=0;j<n;j++)b[i]+=B[i][j]*v[j];side.dual.push_back(b);}
        for(int k=0;k<(int)source.size();k++){int d=0;for(int j=0;j<n;j++)d+=side.dual[0][j]*source[k][j];if(abs(d)%4==2)side.kept|=uint64_t(1)<<k;}
        assert(__builtin_popcountll(side.kept)+a.size()==source.size());
        for(int i=0;i<(int)a.size();++i)for(int j=0;j<=i;j++)assert(i==j?dot_short(side.dual[i],a[j])==20:abs(dot_short(side.dual[i],a[j]))==4);
        for(int k=0;k<(int)source.size();k++)if((side.kept>>k)&1)for(auto &v:side.dual){int d=0;for(int j=0;j<n;j++)d+=v[j]*source[k][j];assert(abs(d)==2);}
        sides.push_back(std::move(side));if(limit>0&&(int)sides.size()==limit)break;
    }
    if(limit==-5){cube_survey(sides,true);return;}
    if(limit==-2){mixed_planes(sides);return;}
    if(limit==-1){plane_survey(sides);return;}
    I pairs=0,nonintegral=0,too_small=0,greedy=0,exact=0,hits=0;map<int,int>by_raw;
    for(int i=0;i<(int)sides.size();i++)for(int j=0;j<i;j++){
        pairs++;const auto &u=sides[i],&v=sides[j];const auto &a=lifts[u.mask],&b=lifts[v.mask];
        if(dot_short(u.dual[0],b[0])%4){nonintegral++;continue;}
        int old=__builtin_popcountll(u.kept&v.kept),raw=old+a.size()+b.size();by_raw[raw]++;
        if(raw<goal){too_small++;continue;}
        int allowed=raw-goal,matched=0;vector<uint64_t>conflicts(a.size());vector<int>owners(b.size(),-1);vector<bool>assigned(a.size());uint64_t used=0;
        for(int k=0;k<(int)a.size()&&matched<=allowed;k++){
            uint64_t row=0;for(int l=0;l<(int)b.size();l++)if(abs(dot_short(u.dual[k],b[l]))!=4)row|=uint64_t(1)<<l;
            conflicts[k]=row;if((row&~used)!=0){int w=__builtin_ctzll(row&~used);owners[w]=k;assigned[k]=true;used|=uint64_t(1)<<w;++matched;}
        }
        if(matched>allowed){greedy++;continue;}
        exact++;for(int k=0;k<(int)a.size()&&matched<=allowed;k++)if(!assigned[k]){uint64_t seen=0;if(augment(k,conflicts,seen,owners))++matched;}
        if(matched<=allowed){hits++;if(hits<=30)cout<<"hit "<<u.mask<<' '<<v.mask<<" size "<<raw-matched<<'\n';}
    }
    cout<<"sides "<<sides.size()<<" pairs "<<pairs<<" cross_nonintegral "<<nonintegral<<" too_small "<<too_small<<" greedy_matching_excludes "<<greedy<<" exact_matching "<<exact<<" hits "<<hits<<" target "<<goal<<'\n';
    for(auto [r,c]:by_raw)cout<<"integral_raw "<<r<<' '<<c<<'\n';
}

"""Root-free denominator-two and rooted candidate statistics on the rank-13-derived 54 shell."""
from pathlib import Path
import argparse,json,subprocess,sys,tempfile
parser=argparse.ArgumentParser();parser.add_argument('tree',type=Path);parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);args=parser.parse_args()
tree=args.tree.resolve();sys.path.insert(0,str(tree/'run12/build'));import half
from grow import gram,verify
z=json.loads((tree/'run14/rank13/rootfree-3-2.json').read_text());B=z['integer_basis'];S=z['shell_coefficients'];G=verify(B,S);assert G==json.loads((tree/'run14/rank13/rootfree-3-2-gram.json').read_text());assert len(S)==54 and len(B)==18
with tempfile.TemporaryDirectory() as tmp:
    exe=Path(tmp)/'half';subprocess.run(['c++','-std=c++17','-O3',str(tree/'run12/build/half.cpp'),'-o',str(exe)],check=True);r=half.run({'basis':B,'shell':S},str(exe));(args.out/'survey54.json').write_text(json.dumps(r,separators=(',',':'))+'\n');print({k:v for k,v in r.items() if k not in ('gram','half_vectors')})

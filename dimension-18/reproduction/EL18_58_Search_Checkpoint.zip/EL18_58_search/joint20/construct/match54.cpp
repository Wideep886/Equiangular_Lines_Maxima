#include <cassert>

#include "matcher_prefix.h"
int main(){
    int count;cin>>m>>count;assert(m==54);Mat original(m,vector<int>(m));for(auto &r:original)for(auto &x:r)cin>>x;
    vector<array<U,64>>target;for(int j=0;j<m;j++)target.push_back(sw(original,j));U vertices=(U(1)<<m)-1;
    for(int c=0;c<count;c++){
        int mask;cin>>mask;Mat g(m,vector<int>(m));for(auto&r:g)for(auto&x:r)cin>>x;
        a=sw(g,0);vector<int>p(m),sign(m,1);bool ok=false;
        for(int j=0;j<m&&!ok;j++){b=target[j];U column=U(1)<<j;ok=rec({{1,column},{vertices^1,vertices^column}},p);}
        if(!ok){cout<<mask<<" -1\n";continue;}
        for(int i=1;i<m;i++)sign[i]=g[0][i]*original[p[0]][p[i]];
        for(int i=0;i<m;i++)for(int j=0;j<m;j++)assert(g[i][j]==sign[i]*sign[j]*original[p[i]][p[j]]);
        cout<<mask;for(auto x:p)cout<<' '<<x;for(auto x:sign)cout<<' '<<x;cout<<'\n';
    }
}

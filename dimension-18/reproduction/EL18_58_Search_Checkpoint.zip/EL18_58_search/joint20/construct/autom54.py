from pathlib import Path
import tempfile,json,subprocess,sys
here=Path(__file__).resolve().parent;tree=Path(sys.argv[1]).resolve();sys.path.insert(0,str(tree/'run12/build3'));from symmetry import perm_group_size
src=int(sys.argv[2]) if len(sys.argv)>2 else 54
paths={48:'run12/build/grown_D1111-1.json',50:'run14/build/source50.json',52:'run12/build/width24/grown_D211-1.json',54:'run14/rank13/rootfree-3-2.json',56:'run12/build/width24/grown_D1111-1.json'}
z=json.loads((tree/paths[src]).read_text())
if src==54:B,S=z['integer_basis'],z['shell_coefficients'];G=json.loads((tree/'run14/rank13/rootfree-3-2-gram.json').read_text())
else:B,S,G=z['basis'],z['shell'],z['gram']
n=len(B);m=len(G);roots=[]
for i in range(n):roots.append(next((j,row[i]) for j,row in enumerate(S) if sum(abs(x) for x in row)==1 and row[i]))
with tempfile.TemporaryDirectory() as tmp:
 (Path(tmp)/'matcher_prefix.h').write_text((tree/'run12/build3/match.cpp').read_text().split('int main(){')[0]);e=Path(tmp)/'aut';subprocess.run(['c++','-std=c++17','-O3','-I'+tmp,str(here/'autom54.cpp'),'-o',str(e)],check=True)
 lines=subprocess.check_output([str(e)],input=' '.join(map(str,[m]+sum(G,[]))).encode()).splitlines()
 group=1;generators=[];masks=[];mapping=[]
 for line in lines:
  q=list(map(int,line.split()));p,s=q[:m],q[m:];assert sorted(p)==list(range(m)) and all(G[i][j]==s[i]*s[j]*G[p[i]][p[j]] for i in range(m) for j in range(m));new=perm_group_size(generators+[p],m)
  if new>group:
   group=new;generators.append(p);M=[[e*s[j]*x for x in S[p[j]]] for j,e in roots];ms=[sum((x%2)<<k for k,x in enumerate(row)) for row in M];assert all(sum(M[i][v]*B[v][w]*M[j][w] for v in range(n) for w in range(n))==B[i][j] for i in range(n) for j in range(n));masks.append(ms);mapping.append([p,s]);
 print('generated signed isometries',len(lines),'generator_count',len(generators),'ray_group_order',group);(here/f'autom{src}.json').write_text(json.dumps(dict(order=group,basis_actions_mod2=masks,signed_maps=mapping),separators=(',',':'))+'\n')

// Independent include/exclude decision tree. At each node, validate a first-fit partition
// into sets of pairwise incompatible vertices. Include/exclude covers both cases.
using Set=vector<uint64_t>;
struct Solver {
    int n,w;long long nodes=0,limit;bool blocked=false;vector<Set>adj;vector<int>chosen,best;
    bool color(const Set &s,vector<int>&ord,vector<int>&cap,int need){
        vector<Set>groups;vector<vector<int>> ids;
        for(int v=n-1;v>=0;--v)if((s[v/64]>>(v%64))&1){
            int g=0;for(;g<(int)groups.size();g++){
                bool ok=true;for(int i=0;i<w;i++)if(groups[g][i]&adj[v][i]){ok=false;break;}if(ok)break;
            }
            if(g==(int)groups.size()){groups.emplace_back(w,0);ids.emplace_back();}
            groups[g][v/64]|=uint64_t(1)<<(v%64);ids[g].push_back(v);
        }
        for(int g=0;g<(int)ids.size();g++)for(int v:ids[g]){ord.push_back(v);cap.push_back(g+1);}
        return (int)groups.size()>=need;
    }
    bool visit(Set s,int need){
        if(!need){best=chosen;return true;}
        ++nodes;int size=0;for(auto x:s)size+=__builtin_popcountll(x);if(size<need)return false;
        vector<int>o,c;if(!color(s,o,c,need))return false;
        // A member of the last color is tried. Both children get a freshly colored upper bound.
        int v=o.back();s[v/64]&=~(uint64_t(1)<<(v%64));Set child=s;for(int i=0;i<w;i++)child[i]&=adj[v][i];
        chosen.push_back(v);if(visit(child,need-1))return true;chosen.pop_back();return visit(s,need);
    }
};

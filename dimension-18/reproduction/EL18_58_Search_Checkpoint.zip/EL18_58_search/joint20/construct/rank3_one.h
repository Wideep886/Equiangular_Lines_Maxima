#include <unordered_set>
using Cube=array<int,7>;
W key(Cube v){sort(v.begin(),v.end());return (W(v[0])<<36)|(W(v[1])<<18)|v[3];}
int position(const Cube& c,int v){for(int i=0;i<7;i++)if(c[i]==v)return i;abort();}
void one_root_cube(const vector<HalfClass>&tab,const vector<vector<int>>& gen,const vector<Coeff>&oldP,const vector<Coeff>&oldD){
    vector<int>free_ids,form(1<<n);for(int b=1;b<(1<<n);b++)if(!__builtin_parity(b)&&!rooted[b]){
        free_ids.push_back(b);for(int i=0;i<n;i++){int v=0;for(int j=0;j<n;j++)if(b>>j&1)v+=B[i][j];form[b]|=((v/2)&1)<<i;}}
    unordered_set<W>seen;I orbits=0,weight=0,jobs=0,nonempty=0,shorts=0,tries=0,greedy=0,det=0,nodes=0,hits=0;int max_raw=0;
    for(int a:free_ids)for(int b:free_ids){int c=a^b;if(a>=b||b>=c||rooted[c]||__builtin_parity(a&form[b]))continue;
        for(int d:free_ids){if(d==a||d==b||d==c||__builtin_parity(d&form[a])||__builtin_parity(d&form[b]))continue;
            int x=d^a,y=d^b,z=d^c;if((int)rooted[x]+rooted[y]+rooted[z]!=1||(!rooted[x]&&x<d)||(!rooted[y]&&y<d)||(!rooted[z]&&z<d))continue;
            Cube C{a,b,c,d,x,y,z};sort(C.begin(),C.end());W id=key(C);if(!seen.insert(id).second)continue;
            vector<Cube>orbit{C};for(size_t r=0;r<orbit.size();r++)for(auto &p:gen){Cube v{};for(int l=0;l<7;l++)v[l]=p[orbit[r][l]];if(seen.insert(key(v)).second)orbit.push_back(v);}weight+=orbit.size();++orbits;
            int eps[7][7]{};for(int i=0;i<7;i++)for(int j=0;j<7;j++)if(i!=j&&!lifts[C[i]].empty()&&!lifts[C[j]].empty()){
                int q=bilinear(tab[C[i]],tab[C[j]]);assert(!(q&1));eps[i][j]=1^(q>>1);}
            for(int i=0;i<7;i++)for(int j=i+1;j<7;j++)for(int k=j+1;k<7;k++){
                if((C[i]^C[j])==C[k]||lifts[C[i]].empty()||lifts[C[j]].empty()||lifts[C[k]].empty())continue;
                int ix[]={i,j,k},v0=C[i],v1=C[j],v2=C[k];int code[7]{};for(int q=1;q<8;q++)code[position(C,((q&1)?v0:0)^((q&2)?v1:0)^((q&4)?v2:0))]=q;
                bool allowed[7];for(int l=0;l<7;l++)allowed[l]=(l==i||l==j||l>=k||(l>j&&C[l]==(v0^v1)))&&!lifts[C[l]].empty();
                Signs subset[7][8]{};for(int l=0;l<7;l++)if(allowed[l]){
                    const auto &side=tab[C[l]];Signs s[3];for(int t=0;t<3;t++)s[t]=side.slice(tab[C[ix[t]]].f0);
                    for(int q=0;q<8;q++){Signs v=side.whole;for(int t=0;t<3;t++)if((q>>t)&1){v.lo&=s[t].lo;v.hi&=s[t].hi;}else{v.lo&=~s[t].lo;v.hi&=~s[t].hi;}subset[l][q]=v;}
                }
                W old=tab[v0].old&tab[v1].old&tab[v2].old;for(int opt=0;opt<8;opt++){
                    jobs++;int f[3]={};int bidx=0;for(int t=0;t<3;t++)for(int u=t+1;u<3;u++){
                        int s=(opt>>bidx++)&1;f[t]|=s<<u;f[u]|=(s^eps[ix[t]][ix[u]])<<t;}
                    Signs selected[7]{};int h=__builtin_popcountll(old);bool fail=false;
                    for(int l=0;l<7;l++)if(allowed[l]){int q=0;for(int t=0;t<3;t++)if(l!=ix[t])q|=(eps[l][ix[t]]^__builtin_parity(f[t]&code[l]))<<t;
                        selected[l]=subset[l][q];int sz=selected[l].count();h+=sz;if(!sz&&(l==i||l==j||l==k))fail=true;}
                    if(fail)continue;nonempty++;max_raw=max(max_raw,h);if(h<goal){++shorts;continue;}tries++;
                    vector<const Coeff*>p,dual;for(int l=0;l<7;l++){auto s=selected[l];for(int t=0;t<2;t++){W w=t?s.hi:s.lo;while(w){int q=64*t+__builtin_ctzll(w);w&=w-1;p.push_back(&lifts[C[l]][q]);dual.push_back(&tab[C[l]].duals[q]);}}}
                    W o=old;while(o){int j=__builtin_ctzll(o);o&=o-1;p.push_back(&oldP[j]);dual.push_back(&oldD[j]);}assert((int)p.size()==h);
                    int matches=0;vector<bool>taken(h);for(int u=0;u<h&&matches<=h-goal;u++)if(!taken[u])for(int v=h-1;v>u;v--)if(!taken[v]&&abs(small_ip(*dual[u],*p[v]))!=4){taken[v]=true;++matches;break;}
                    if(matches>h-goal){++greedy;continue;}det++;Solver sol;sol.n=h;sol.w=(h+63)/64;sol.limit=1LL<<60;sol.adj.assign(h,Set(sol.w));
                    for(int u=0;u<h;u++)for(int v=0;v<u;v++)if(abs(small_ip(*dual[u],*p[v]))==4){sol.adj[u][v/64]|=W(1)<<(v%64);sol.adj[v][u/64]|=W(1)<<(u%64);}
                    Set full(sol.w,~W(0));if(h%64)full.back()=(W(1)<<(h%64))-1;if(sol.visit(full,goal)){++hits;if(hits==1){cout<<"cube_witness "<<id<<'\n';for(int u:sol.best){for(int x:*p[u])cout<<x<<' ';cout<<'\n';}cout.flush();}}
                    assert(!sol.blocked);nodes+=sol.nodes;
                }
            }
        }
    }
    assert(weight==(I)seen.size());cout<<"one_root_class_integral_cubes "<<weight<<" orbits "<<orbits<<" assignments "<<jobs<<" nonempty "<<nonempty<<" small "<<shorts<<" tested "<<tries<<" max_raw "<<max_raw<<" matched "<<greedy<<" clique_calls "<<det<<" nodes "<<nodes<<" hits "<<hits<<" target "<<goal<<'\n';
}

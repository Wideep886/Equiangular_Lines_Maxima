#include <cassert>
#include "matcher_prefix.h"
int main(){
 cin>>m;Mat G(m,vector<int>(m));for(auto&r:G)for(auto&x:r)cin>>x;a=sw(G,0);U vertices=(U(1)<<m)-1;
 auto transfer=[&](int j, vector<cell> pairs){vector<int>p(m),s(m,1);if(!rec(pairs,p))return;for(int i=1;i<m;i++)s[i]=G[0][i]*G[j][p[i]];for(int i=0;i<m;i++)for(int k=0;k<m;k++)assert(G[i][k]==s[i]*s[k]*G[p[i]][p[k]]);for(int i:p)cout<<i<<' ';for(int i:s)cout<<i<<' ';cout<<'\n';};
 for(int j=1;j<m;j++){b=sw(G,j);U R=U(1)<<j;transfer(j,{{1,R},{vertices^1,vertices^R}});}
 b=a;for(int v=1;v<m-1;v++)for(int j=v+1;j<m;j++){vector<cell>c;U fixed=(U(1)<<v)-1;for(int i=0;i<v;i++)c.emplace_back(U(1)<<i,U(1)<<i);c.emplace_back(U(1)<<v,U(1)<<j);c.emplace_back(vertices^fixed^(U(1)<<v),vertices^fixed^(U(1)<<j));transfer(0,c);}
}

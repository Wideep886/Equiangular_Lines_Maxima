"""Integer Gram audit of the norm-3 even-paired obstruction in symplectic rank 16."""
from itertools import combinations, product
from math import comb


def form(g, c):
    return sum(ci * cj * g[i][j] for i, ci in enumerate(c) for j, cj in enumerate(c))


def main():
    # Gram indexed by y,a_1,...,a_10. All a_i are active, so y.a_i=2.
    base = [[3]+[2]*10] + [[2]+[5 if i==j else 1 for j in range(10)] for i in range(10)]
    assert form([[3,2,2],[2,5,-1],[2,-1,5]],[2,-1,-1]) == 4
    halves = roots = 0
    for m in (2,4,6,8,10):
        for U in combinations(range(10),m):
            # Balanced signs all have the same norm; enumerate all, including global signs.
            for plus in combinations(U,m//2):
                s = [0]+[0 if i not in U else 1 if i in plus else -1 for i in range(10)]
                assert form(base,s)==4*m
                halves += 1
            if m==8:
                # The integer coefficient vector represents twice r.
                assert form(base,[8]+[-1 if i in U else -2 for i in range(10)])==16
                roots += 1
    assert roots==comb(10,8)==45
    # Confirm mask 19 gives a half-sum of squared length 3 with even inner products.
    g = [[5 if i==j else 1 for j in range(6)] for i in range(6)]
    for k,(i,j) in enumerate(combinations(range(1,6),2)):
        if (19>>k)&1: g[i][j]=g[j][i]=-1
    s=(1,-1,-1,-1,1,1)
    assert form(g,s)==12
    outside=[p for p in product((1,-1),repeat=6) if p.count(-1)%2==0]
    assert all(sum(a*b for a,b in zip(row,s))%4==0 for row in g+outside)
    print('high pair forces norm 4; balanced half-sums',halves,'eight-subset root certificates',roots,'mask 19 verified')


if __name__=='__main__':
    main()

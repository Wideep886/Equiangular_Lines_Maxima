"""Rank-14 even norm-three normal. Exact census of its ten high-point code and low signatures."""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations, product


def dot(s, t):
    return sum(a*b for a,b in zip(s,t))


def main():
    # Relative bound in dimension sixteen is 42; the 48 orthogonal lines span dim 17.
    assert 24*16//(25-16)==42
    words = [set(c) for w in (6,10) for c in combinations(range(10),w)]
    triples=set()
    for a,b in combinations(words,2):
        c=a^b
        if len(c) not in (6,10):
            continue
        triples.add(tuple(sorted(tuple(sorted(s)) for s in (a,b,c))))
    shapes=Counter()
    for s in triples:
        a,b,c=map(set,s)
        shapes[len(a),len(b),len(c),len(a&b),len(b&c),len(c&a),len(a|b|c)]+=1
    assert shapes=={(6,6,6,3,3,3,9):2800}
    print('labelled two-dimensional codes, (weights, pair intersections, union):',shapes)
    grams = [[5 if i==j else 1 for j in range(10)] for i in range(10)]
    ys = [2]*10
    B=[tuple(i for i in range(9) if i//3!=k) for k in range(3)]
    for i,b in enumerate(B):
        assert 4*3 == sum(grams[j][k] for j in b for k in b)-8*sum(ys[j] for j in b)+16*3
        for l,c in enumerate(B):
            numerator=sum(grams[j][k] for j in b for k in c)-4*sum(ys[j] for j in b)-4*sum(ys[k] for k in c)+16*3
            assert numerator==(12 if i==l else 0)
        for k in range(10):
            assert sum(grams[j][k] for j in b)//2-2*ys[k] == (1 if k in b else -1)
    signatures={}
    for s in product((-1,1),repeat=10):
        t=tuple(sum(s[3*i:3*i+3]) for i in range(3))
        if not all(abs(t[a]+t[b])==2 for a,b in combinations(range(3),2)): continue
        if sum(t)<0: continue
        key=(tuple(sorted(t)),s[9])
        signatures.setdefault(key,[]).append(s)
    assert len(signatures)==4 and set(map(len,signatures.values()))=={27}
    assert {k[0] for k in signatures}=={(1,1,1),(-1,-1,3)}
    mid = [[Q(4*(i==j))-Q(1,3) for j in range(10)] for i in range(10)]
    inv = [[Q(i==j,4)+Q(1,8) for j in range(10)] for i in range(10)]
    assert all(sum(mid[i][t]*inv[t][j] for t in range(10))==(i==j) for i in range(10) for j in range(10))
    def proj(s,t):
        return Q(dot(s,t),4)+Q(sum(s)*sum(t),8)
    order=[((-1,-1,3),-1),((-1,-1,3),1),((1,1,1),-1),((1,1,1),1)]
    orbits=[signatures[k] for k in order]
    heights=[5-proj(orbit[0],orbit[0]) for orbit in orbits]
    assert heights==[Q(5,2),2,2,Q(1,2)]
    print('patterns per orbit:',[len(v) for v in orbits], 'residual heights:',[str(h) for h in heights])
    # A rational feasibility witness for the three pair-pillar size bounds
    # 24..34 and the single projection-frame inequality. Group counts are
    # integer, and copies within each orbit are averaged fractionally.
    for i in range(4):
        for j in range(4):
            assert len({sum(proj(s,t)**2 for t in orbits[j]) for s in orbits[i]})==1
    h2 = [[sum(proj(orbits[i][0],t)**2 for t in orbits[j])/27 for j in range(4)] for i in range(4)]
    # Three hetero orbits can be equally distributed across which block has sum +3.
    nums = [21,15,12,0]
    low_by_pillar = [12,12,12,12]
    assert sum(nums)==48 and sum(nums[:2])//3==12 and sum(nums[2:])==12
    assert all(24<=low_by_pillar[i]+low_by_pillar[j]+([3,3,3,1][i])+([3,3,3,1][j])<=34 for i,j in combinations(range(4),2))
    energy = sum(nums[i]*nums[j]*h2[i][j] for i,j in product(range(4),repeat=2)) + dot(nums,heights)**2/7
    assert energy < 48*(25+47)
    print('relaxed orbit counts:',nums,'four-pillar total sizes: (15,15,15,13)')
    print('projected second-moment lower witness:',energy,'<=',48*(25+47))

    # Distinct integer signatures passing the pairwise tests and the projection bound.
    # Bit 1 denotes +1, bit 0 denotes -1. Full rank-seven completion is open.
    ids=[79,87,103,122,124,143,167,185,186,221,222,238,243,245,279,295,313,314,
         347,363,365,366,373,411,413,430,438,457,458,460,466,468,481,484,
         599,634,636,655,679,697,783,791,828,969,978,980,993,994]
    assert len(set(ids))==48
    picked=[tuple(2*((m>>i)&1)-1 for i in range(10)) for m in ids]
    assert all(any(s in orb for orb in orbits) for s in picked)
    assert all(5-proj(s,s)>Q(1,2) for s in picked)
    groups=[0,0,0,0]
    for s in picked:
        t=[sum(s[3*i:3*i+3]) for i in range(3)]
        groups[t.index(3) if 3 in t else 3]+=1
    assert groups==[12,10,12,14]
    for s,t in combinations(picked,2):
        assert min((e-proj(s,t))**2 for e in (-1,1)) <= (5-proj(s,s))*(5-proj(t,t))
    low_energy=sum(proj(s,t)**2 for s,t in product(picked,repeat=2))
    low_energy+=sum(5-proj(s,s) for s in picked)**2/7
    assert low_energy==Q(24186,7)<3456
    print('integer 48 distinct signatures, pairwise tests:',len(list(combinations(picked,2))))
    print('low pillars:',groups,'projected energy:',low_energy)
if __name__=='__main__':
    main()

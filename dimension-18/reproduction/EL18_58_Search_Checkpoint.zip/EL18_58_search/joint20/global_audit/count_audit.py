"""Independent exact integer replay for H and Y. Python 3 standard library."""
from fractions import Fraction
from itertools import combinations, product
from math import comb


def spectral(T):
    q = 162680 - 12*T
    # Project the vector of squares onto the span of 1 and the centered t.
    lower4 = Fraction(84**2,18) + Fraction((9*q-84)**2,9*754)
    s4 = 40*625 + 18*11**4 + 8*11**3 + 504*11**2 + 44*q + lower4
    M = (58*57*113 + 24*comb(58,4) - s4)//32
    return 2*M-37*T


def local():
    splits = [frozenset(s) for s in combinations(range(6),3) if 0 in s]
    for v in product((1,-1), repeat=6):
        if sum(v)==0:
            assert sum(abs(sum(v[i] for i in s)) == 3 for s in splits)==1
    for i in range(6):
        # Dot products from the all-negative hexad Gram.
        assert all(abs(sum(5 if i==j else -1 for j in s))==3 for s in splits)
    assert 6*10+52==112
    for t in range(1,6):
        c=comb(t,2)
        for h in range(3*t,19):
            # Multiply the local dual margin by 560.
            margin = -185*t + 18*c - 60*(t==2) + 2*(5*h-56)*c + 5*t*(58-h)-56*c
            assert margin >= 150*(t==5)
    # A line with three coordinates ±1 is high on exactly one of the four
    # directions x1 ± x2 ± x3 (global sign removed).
    for v in product((1,-1), repeat=3):
        assert sum(abs(v[0]+a*v[1]+b*v[2])==3 for a,b in product((1,-1),repeat=2))==1


def lower_Y(T,H,k,budget):
    # e<=618. C3 upper is a floor of the graph degree estimate at this T.
    C=(9*T + 82*3*618 - 58*4096 + 26*(1856*3-9*618))//36
    n5_upper = min(H//10,(budget-112*H)//30)
    assert n5_upper >= 0
    if k:
        extra = 2*min(n5_upper,3) if k==3 else 0
        bottom=6*T+(3*k-14)*H-6*k*C-4*n5_upper-6*extra
    else:
        bottom=6*T-14*H
    return (bottom+11)//12


def main():
    local()
    best={k:None for k in range(6)}
    max_cost=0
    for T in range(13512,13593,2):
        budget=spectral(T)
        max_cost=max(max_cost, budget)
        for H in range(609,budget//112+1):
            for k in range(6):
                row=(lower_Y(T,H,k,budget),T,H)
                if best[k] is None or row<best[k]: best[k]=row
    assert Fraction(max_cost,112)==Fraction(67831,56)
    assert [r[0] for r in best.values()] == [5345,5134,4925,4714,4509,4262]
    print('H maximum:',max_cost//112)
    print('k: (Y lower bound, minimizing T, minimizing H):',best)
    print('f=14:',min(best[k][0] for k in range(4)))
    print('f=16:',min(best[k][0] for k in range(2)))

if __name__=='__main__':
    main()

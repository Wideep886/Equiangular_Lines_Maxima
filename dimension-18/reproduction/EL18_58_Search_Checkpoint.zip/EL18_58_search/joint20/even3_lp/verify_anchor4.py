"""Ungrouped exact dual verification from all 1024 sign rows and both signed edges."""
import json
from pathlib import Path
from fractions import Fraction as Q
from itertools import product,combinations
from collections import Counter
here=Path(__file__).resolve().parent
proof=json.loads((here/'anchor1.json').read_text())[3];anchor=tuple(proof['anchor'][0]);pairs=[]

def inner(x,y):return (Q(sum(a*b for a,b in zip(x,y)),4)+Q(sum(x)*sum(y),8))

def code(A,s,e):
 gs=tuple(sorted(tuple(sorted((A[j],s[j]) for j in range(k,k+3))) for k in (0,3,6)))
 return json.dumps([gs,s[-1],[e]],separators=(',',':'))

h0=5-inner(anchor,anchor);assert h0==Q(1,2)
for s in product((-1,1),repeat=10):
 gs=[sum(s[i:i+3]) for i in (0,3,6)]
 if sum(gs)<0 or any(abs(a+b)!=2 for a,b in combinations(gs,2)):continue
 for e in (-1,1):
  z=e-inner(anchor,s);h=5-inner(s,s)-z*z/h0
  if h>=0:pairs.append((s,z,h,code(anchor,s,e)))
count=Counter(k for _,_,_,k in pairs)
weights={json.dumps(row['key'],separators=(',',':')):Q(row['weight']) for row in proof['rows']}
assert set(count)==set(weights);v=[weights[k]/count[k] for _,_,_,k in pairs];assert all(x>=0 for x in v) and sum(v)==1
mu=[]
for s,z,h,k in pairs:
 mu.append(sum(w*((inner(s,t)+z*y/h0)**2+h*r/6) for w,(t,y,r,_) in zip(v,pairs) if w))
cost=sum(a*b for a,b in zip(v,mu));assert min(mu)==cost and 47**2*cost==Q(6492251,1936);assert 47**2*cost-47*71==Q(31819,1936)>0
old=json.loads((here/'orbit_totals.json').read_text());survivors=[v for v in old['permitted'] if not v[-1]];assert len(survivors)==69
print('raw signatures with edge',len(pairs),'stabilizer classes',len(count),'weighted raw states',sum(bool(x) for x in v),'energy',47**2*cost,'target',47*71,'gap',47**2*cost-47*71,'remaining population tuples',len(survivors));print('class weights',','.join(str(row['weight']) for row in proof['rows']))

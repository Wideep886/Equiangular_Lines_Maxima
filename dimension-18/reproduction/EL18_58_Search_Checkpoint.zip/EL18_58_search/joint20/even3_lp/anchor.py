from frame import orb,solve,F,dot
from collections import defaultdict
from itertools import combinations
from math import gcd
from pathlib import Path
import sys,json

def proj(s,t):return F(2*dot(s,t)+sum(s)*sum(t),8)
def optimize(K):
 n=len(K);floatK=[[float(v) for v in row] for row in K];S=[0];p=[1.];best=100000
 def mv(x):return [sum(r[j]*a for j,a in zip(S,x)) for r in floatK]
 for turn in range(400):
  grad=mv(p);v=sum(grad[j]*a for j,a in zip(S,p));j=min(range(n),key=grad.__getitem__)
  if grad[j]>=v-1.e-9:break
  S.append(j);p.append(0)
  for it in range(300):
   H=[[K[i][j] for j in S]+[-1] for i in S]+[[1]*len(S)+[0]];exact=solve(H,[0]*len(S)+[1]);
   if not exact:
    # Fall back to rationalized pairwise conditional-gradient descent.
    S.pop();p.pop();break
   z=list(map(float,exact[:-1]));
   if min(z)>=-1.e-11:p=z;break
   t=min(p[i]/(p[i]-z[i]) for i in range(len(S)) if z[i]<-1.e-11);p=[(1-t)*x+t*y for x,y in zip(p,z)];sidx=[i for i in range(len(S)) if p[i]>1.e-10];S=[S[i] for i in sidx];p=[p[i] for i in sidx]
 else:pass
 H=[[K[i][j] for j in S]+[-1] for i in S]+[[1]*len(S)+[0]];exact=solve(H,[0]*len(S)+[1]);w=[F(0)]*n
 if exact and min(exact[:-1])>=0:
  for j,r in zip(S,exact):w[j]=r
 else:
  for j,r in zip(S,p):w[j]=F(r).limit_denominator(100000)
  t=sum(w);w=[v/t for v in w]
 g=[dot(row,w) for row in K];v=dot(w,g);return w,v,2*min(g)-v

def anchored(anchors,edges,exclude_D=False):
 vectors=sum(orb[:3] if exclude_D else orb,[]);t=len(anchors);R=[[F(5 if i==j else edges[i][j])-proj(anchors[i],anchors[j]) for j in range(t)] for i in range(t)]
 e=F(1);ri=[solve(R,[int(i==j) for i in range(t)]) for j in range(t)];assert all(v is not None for v in ri)
 from itertools import product
 classes=defaultdict(list)
 for s in vectors:
  for ip in product([-1,1],repeat=t):
   u=[ip[i]-proj(s,anchors[i]) for i in range(t)];co=[dot(r,u) for r in ri];h=5-proj(s,s)-dot(u,co)
   if h<0:continue
   key=(tuple(sorted(tuple(sorted(tuple(v[j] for v in anchors+[s]) for j in range(3*k,3*k+3))) for k in range(3))),s[-1],ip);classes[key].append((s,u,co,h))
 allk=sorted(classes);gg=[classes[k] for k in allk];n=len(gg);K=[]
 for group in gg:
  s,u,co,h=group[0];K.append([sum((proj(s,t_)+dot(co,v))**2 for t_,v,_,_ in other)/len(other)+h*other[0][3]/(7-t) for other in gg]);
 assert all(K[i][j]==K[j][i] for i in range(n) for j in range(n));w,v,lower=optimize(K);m=48-t;target=m*(m+24);print(t,n,len([x for x in w if x]),v*m*m,lower*m*m,target,float(lower*m*m-target),flush=True)
 return dict(anchor=anchors,edges=edges,rows=[dict(key=key,count=len(g),weight=str(w[i])) for i,(key,g) in enumerate(zip(allk,gg))],lower=str(lower*m*m),value=str(v*m*m),target=target)
if __name__=='__main__':
 out=[anchored([x[0]],[[5]]) for x in orb];Path(__file__).resolve().with_name('anchor1.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

"""Necessary dual-weight congruence for the full-rank seven-dimensional residual root lattice."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json
out=Path(__file__).resolve().parent
z=[n for n in json.loads((out/'orbit_totals.json').read_text())['permitted'] if n[3]==0]
assert len(z)==69
print('coordinate ranges',[(min(t[j] for t in z),max(t[j] for t in z)) for j in range(4)],'B+C minimum',min(t[1]+t[2] for t in z))
types=[('A'+str(d),d,sorted(set(Q(k*(d+1-k),d+1) for k in range(d+1)))) for d in range(1,8)]
types += [('D'+str(d),d,[Q(0),Q(1),Q(d,4)]) for d in range(4,8)]+[('E6',6,[Q(0),Q(4,3)]),('E7',7,[Q(0),Q(3,2)])]
checks={}
def visit(rank,idx,labels,cosets):
 if not rank:
  mins=sorted(set(sum(x) for x in product(*cosets)));checks['+'.join(labels)]=[str(x) for x in mins if x in (Q(1,2),Q(5,2))];return
 for j in range(idx,len(types)):
  k,d,vs=types[j];
  if d<=rank:visit(rank-d,j,labels+[k],cosets+[vs])
visit(7,0,[],[])
print('rank seven',len(checks),'excluded',sum(not w for w in checks.values()),'surviving',sum(bool(w) for w in checks.values()));print('excluded types',', '.join(k for k,v in checks.items() if not v))
(out/'residual_roots.json').write_text(json.dumps(checks,separators=(',',':'))+'\n')

"""Exact orbit frame minimum for the 10 high, 48 low branch."""
from fractions import Fraction as F
from itertools import product,combinations
from collections import defaultdict
import json
from pathlib import Path

def dot(a,b):return sum(x*y for x,y in zip(a,b))
rows=defaultdict(list)
for s in product((-1,1),repeat=10):
 u=[sum(s[3*i:3*i+3]) for i in range(3)]
 if not all(abs(x+y)==2 for x,y in combinations(u,2)):continue
 if sum(u)<=0:continue
 rows[(tuple(sorted(u)),s[-1])].append(s)
keys=sorted(rows);orb=[rows[k] for k in keys];h=[F(5,2)-F(sum(g[0])**2,8) for g in orb];M=[]
for i,g in enumerate(orb):
 a=g[0];M.append([sum((2*dot(a,b)+sum(a)*sum(b))**2 for b in v)*F(1,64*len(v))+h[i]*h[j]/7 for j,v in enumerate(orb)])
assert all(M[i][j]==M[j][i] for i in range(4) for j in range(4))
def solve(A,b):
 n=len(A);t=[list(map(F,r))+[F(v)] for r,v in zip(A,b)]
 for i in range(n):
  j=next((j for j in range(i,n) if t[j][i]),None)
  if j==None:return
  t[i],t[j]=t[j],t[i];x=t[i][i];t[i]=[v/x for v in t[i]]
  for j in range(n):
   if j!=i:
    x=t[j][i];t[j]=[a-x*b for a,b in zip(t[j],t[i])]
 return [r[-1] for r in t]
def cost(n):return sum(n[i]*n[j]*M[i][j] for i in range(4) for j in range(4))
def minimum():
 best=None
 for mask in range(1,16):
  I=[i for i in range(4) if mask>>i&1];v=solve([[M[i][j] for j in I]+[-1] for i in I]+[[1]*len(I)+[0]],[0]*len(I)+[48]);
  if not v or min(v[:-1])<0:continue
  x=[F(0)]*4
  for k,i in enumerate(I):x[i]=v[k]
  if min(dot(m,x) for m in M)<v[-1]:continue
  if best is None or cost(x)<best[0]:best=cost(x),x
 return best
if __name__=='__main__':
 print(keys,[(len(v),str(y)) for v,y in zip(orb,h)]);print(M);print('continuous min',minimum());Q=[[int(t*504*9) for t in r] for r in M];assert all(F(Q[i][j],504*9)==M[i][j] for i in range(4) for j in range(4));best=None;feasible=[]
 for a in range(49):
  for b in range(49-a):
   for c in range(49-a-b):
    n=(a,b,c,48-a-b-c);v=sum(n[i]*n[j]*Q[i][j] for i in range(4) for j in range(4));
    if v<=3456*504*9:feasible.append(n)
    if best is None or v<best[0]:best=(v,n)
 print('integer',F(best[0],504*9),best[1], 'through',len(feasible));print('ranges',[(min(n[i] for n in feasible),max(n[i] for n in feasible)) for i in range(4)])
 if feasible:
  out=dict(order=[[list(k[0]),k[1]] for k in keys],matrix_189=[[int(t*189) for t in r] for r in M],target=3456,continuous_min=str(minimum()[0]),continuous_weights=list(map(str,minimum()[1])),integer_min=str(F(best[0],504*9)),integer_argmin=best[1],enumerated=20825,permitted=feasible)
  (Path(__file__).resolve().parent/'orbit_totals.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

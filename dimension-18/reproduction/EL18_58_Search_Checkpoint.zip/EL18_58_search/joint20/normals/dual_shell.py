"""Two-shell LP for the 17-dimensional norm-three layer."""
from fractions import Fraction as F
from math import floor


def harmonics(u):
    # Unit-normalized Gegenbauer polynomials P2 and P4, evaluated at t²=u.
    return [(17*u-1)/16, (21*19*u*u-6*19*u+3)/(16*18)]


m = 58
constant = F(8, 2907)
coeff = [F(418, 7), F(1836, 7)]
# Check the entire degree-two polynomial in u by interpolation.
for u in [F(0), F(1, 9), F(1)]:
    assert u*(u-F(1,9)) == constant*(1+sum(c*y for c,y in zip(coeff, harmonics(u))))
numerator = (1-F(1,9))/constant
assert numerator == 323
# d is the average number of positive-angle neighbours in the 58-point section.
dmin = F(107,3)
dmax = F(1867,51)
assert 1+dmin*F(1,7)+(57-dmin)*F(-2,7)==0
p=harmonics(F(1,49)); q=harmonics(F(4,49))
assert 1+dmax*p[0]+(57-dmax)*q[0]==0
upper=[max(1+d*x+(57-d)*y for d in (dmin,dmax)) for x,y in zip(p,q)]
z=harmonics(F(0))
delta=[x-y for x,y in zip(harmonics(F(1,7)),z)]
w=[m*x/y for x,y in zip(coeff, upper)]
s=-sum(h*x*y for h,x,y in zip(w,z,delta))/sum(h*y*y for h,y in zip(w,delta))
penalty=1+sum(h*(x+s*y)**2 for h,x,y in zip(w,z,delta))
answer=numerator/penalty
assert answer==F(29931424,95135)
print('same-shell bound',numerator,'two-shell bound',answer,'integer bound',floor(answer))

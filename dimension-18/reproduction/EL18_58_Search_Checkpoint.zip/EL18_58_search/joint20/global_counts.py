"""Independent integer checks for H, and a lower bound on distinct negative Walsh syndromes."""
from fractions import Fraction as F
from math import comb, ceil, floor

for t in range(1,6):
    c = comb(t,2)
    for h in range(3*t, 19):
        # A dual row for H; h counts original lines pairing in absolute value 3.
        score = -F(37*t,112) + F(3,28)*(F(3*c,10)-(t==2))
        score += F((5*h-56)*c,280) + F(t*(58-h),112)
        assert score >= F(c,10), (t,h)
    assert (t-3)*(t-4)>=2*(t==2)
    assert t-1>=F(c,2)-(t==5)

fixed = 40*625+18*11**4+4*11**3*2+6*11**2*84
K = 58*57*113+24*comb(58,4)
upper = []
for T in range(13512,13593,2):
    third=162680-12*T
    fourth=F(84**2,18)+(third-F(84,9))**2/F(754,9)
    four_subsets=(K-fixed-44*third-fourth)//32
    upper.append((T,F(2*four_subsets-37*T,112)))
top=max(h for t,h in upper)
assert top==F(67831,56)
print('H upper',top,'floor',floor(top))
# Each active unit normal of squared length three has diagonal frame value 58/3.
assert 6*F(10,3)**2+F(18**2,12)>84
# Same-syndrome ordered collisions use distinct (real nine-axis, norm-three normal) incidences.
# For 4 or 5 normals no real nine-axis can be high for two of them; for 0..3 use Bessel.
def incidence(k,H):
    return k*(1026-F(H,2)) + F((min(k,3) if k<=3 else 1)*H,10)
for name,kmax in [('any',5),('14',3),('16',1)]:
    best=min(ceil((T-F(7*H,3)-max(incidence(k,H) for k in range(kmax+1)))/2)
             for T,h in upper for H in range(609,floor(h)+1))
    print('f',name,'distinct occupied negative-triangle syndromes >=',best)

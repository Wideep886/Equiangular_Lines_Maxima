"""Exact dual for the number of distinct real witness spans, and their nongrid subfamily."""
import json
import sys
from fractions import Fraction as F
from math import ceil, comb
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'run14/deletion'))
from final_anchors import counts, no_triple_rows, rows
from exact_weights import deletion_cap


def link_rows():
    lines = (ROOT / 'run12_recovery/pillar/link10.txt').read_text().splitlines()
    result = [tuple(map(int, row.split())) for row in lines]
    result.extend(tuple(b) + (0,) for b in no_triple_rows())
    assert len(result) == 2697
    return result


def bound(w, alpha, hist, links, n, X, den):
    dot = lambda a: sum(x*y for x, y in zip(a, w))
    scale = max(F(den), F(deletion_cap(w), 10))
    base = max(dot(b) - scale*b[-1] for b in links)
    lam = min((dot(a) - scale*alpha*sum(counts(a))) / a[-1] for a in hist)
    assert lam > 0 and len(hist) == 430
    score = (30*lam*X - comb(n, 2)*base)/scale
    return tuple(map(str, (scale, base, lam, score, ceil(score))))


if __name__ == '__main__':
    h58, h59 = rows(7)
    links = link_rows()
    for cert in json.loads((HERE / 'weights.json').read_text()):
        n = cert['n']
        alpha = F(cert['alpha'])
        values = bound(cert['w'], alpha, h58 if n == 58 else h59, links, n,
                       5780 if n == 58 else 6509, cert['den'])
        assert tuple(cert['values']) == values
        print(n, alpha, *values)

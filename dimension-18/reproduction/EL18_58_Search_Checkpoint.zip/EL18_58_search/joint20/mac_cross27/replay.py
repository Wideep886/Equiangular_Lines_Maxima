"""Reconstruct the Mac rank13 cross27 inputs in a private temporary directory."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

here=Path(__file__).resolve().parent
root=here.parents[1]
files=json.loads((here/'inputs.json').read_text())
expected='6a05f48733fc067e86c5a5101aee342d5070d950d8e2db6c4b397a23a042a274'
with TemporaryDirectory() as temp:
    folder=Path(temp)/'EL18_58_search'
    for rel,(digest,mac) in files.items():
        src=(here/'mac_inputs' if mac else root)/rel
        assert hashlib.sha256(src.read_bytes()).hexdigest()==digest,rel
        out=folder/rel
        out.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,out)
    subprocess.run([sys.executable,'-B',str(folder/'run14/rank13/cross27.py')],check=True)
    actual=hashlib.sha256((folder/'run14/rank13/cross27.json').read_bytes()).hexdigest()
    assert actual==expected,actual
    print('cross27.json SHA-256',actual)

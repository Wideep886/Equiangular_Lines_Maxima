"""Exact switching isomorphisms preserving the two full shells, in order."""
from collections import Counter


def switched(G,r):
    sign=[1 if i==r else G[r][i] for i in range(len(G))]
    return [[sign[i]*sign[j]*v for j,v in enumerate(row)] for i,row in enumerate(G)]


def map_graph(A,B,colA,colB):
    n=len(A)
    def rec(a,b):
        while True:
            patterns=[]
            for M,c in ((A,a),(B,b)):
                pats=[(c[i],tuple(sorted(Counter(c[j] for j in range(n) if M[i][j]==-1).items()))) for i in range(n)]
                patterns.append(pats)
            if Counter(patterns[0])!=Counter(patterns[1]):return
            col={c:k for k,c in enumerate(sorted(set(patterns[0])))}
            aa,bb=([col[c] for c in pats] for pats in patterns)
            if len(set(aa))==len(set(a)):break
            a,b=aa,bb
        cnt=Counter(aa)
        if len(cnt)==n:
            p=[bb.index(c) for c in aa]
            assert all(A[i][j]==B[p[i]][p[j]] for i in range(n) for j in range(n))
            return p
        _,cls=min((k,c) for c,k in cnt.items() if k>1)
        x=aa.index(cls)
        for j in range(n):
            if bb[j]==cls:
                a=aa[:];b=bb[:]
                a[x]=b[j]=len(cnt)
                p=rec(a,b)
                if p:return p
    return rec(colA,colB)


def isometry(A,ca,B,cb):
    # ca encodes which of the two shells contain each axis.
    r=0;n=len(A)
    M=switched(A,r)
    a=ca[:];a[r]=4
    for s,c in enumerate(cb):
        if c!=ca[r]:continue
        b=cb[:];b[s]=4
        p=map_graph(M,switched(B,s),a,b)
        if p:
            sign=[1 if i==r else A[r][i]*B[s][p[i]] for i in range(n)]
            assert all(A[i][j]==sign[i]*sign[j]*B[p[i]][p[j]] for i in range(n) for j in range(n))
            return p,sign

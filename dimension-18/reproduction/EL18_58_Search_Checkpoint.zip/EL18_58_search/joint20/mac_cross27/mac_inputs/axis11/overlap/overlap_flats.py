"""Independent shell enumeration and forced overlaps, Python 3 (no dependencies).
Run from anywhere with the supplied companion coredata directory.
"""
from itertools import combinations
from math import comb
from pathlib import Path
import json


def witnesses(g):
    terms = []
    for i, j in combinations(range(len(g)), 2):
        layer = [x for x in range(len(g)) if x not in {i, j}
                 and g[i][x] == -g[i][j] * g[j][x]]
        tetra = [sum(1 << x for x in t) for t in combinations(layer, 4)
                 if all(g[x][y] * g[i][x] * g[i][y] == -1
                        for x, y in combinations(t, 2))]
        for a, b, c in combinations(tetra, 3):
            if (a & b) == (a & c) == (b & c) == 0:
                terms.append(a | b | c | (1 << i) | (1 << j))
    return terms


def prime_rank(g, p=101):
    rows = [[a % p for a in row] for row in g]
    k = 0
    for j in range(len(rows[0])):
        pos = next((i for i in range(k, len(rows)) if rows[i][j]), None)
        if pos is None:
            continue
        rows[pos], rows[k] = rows[k], rows[pos]
        inv = pow(rows[k][j], -1, p)
        for i in range(k + 1, len(rows)):
            x = rows[i][j] * inv % p
            rows[i] = [(a - x*b) % p for a, b in zip(rows[i], rows[k])]
        k += 1
        if k == len(rows):
            break
    return k


def analyze_shell(name, data):
    g = data['shell_gram']
    n = len(g)
    # All shell vectors are given in the real span of the 11 listed basis
    # vectors by coredata. A nonzero minor modulo a prime certifies rank over Q.
    assert len(data['basis']) == 11
    assert all(prime_rank(g[:i] + g[i+1:]) == 11 for i in range(n))
    # In these orientations the first two normals differ at precisely two
    # shell points. Their difference therefore witnesses the lower bound.
    assert sum(g[0][x] == g[1][x] for x in range(n)) == n - 2
    terms = witnesses(g)
    mins = [0]
    for k in range(1, 1+len(terms)):
        sizes = []
        for family in combinations(terms, k):
            mask = 0
            for w in family:
                mask |= w
            sizes.append(bin(mask).count('1'))
        mins.append(min(sizes))
    print(name, 'shell', n, 'hyperplane capacity', n-2, 'witness count',
          len(terms), 'minimum union sizes', mins[1:])
    return mins


def overlap_bound(costs, total):
    # dp[t]: exact lower-bound relaxation for t selected witnesses in b flats.
    # No intersection consistency imposed in this minimization.
    infinity = 10**6
    dp = [0] + [infinity] * total
    scores = []
    for b in range(1, total+1):
        dp = [min((dp[t-k]+costs[k] for k in range(1, min(t, 8)+1)),
                  default=infinity) for t in range(total+1)]
        if dp[total] >= infinity:
            continue
        incidences = dp[total]
        q, s = divmod(total-b, 7)
        assert incidences == 14*b+4*q+(0 if not s else 3 if s == 1 else 4)
        d, r = divmod(incidences, 58)
        pairs = 58*comb(d, 2) + r*d
        excess = pairs - 3*comb(b, 2)
        scores.append((excess, b))
    print('witnesses', total, 'feasible b values', min(b for _, b in scores),
          'through', max(b for _, b in scores), 'minimum excess, b', min(scores))
    bound = max(0, (min(scores)[0]+12)//13)
    print('at least', bound, 'distinct pairs of flats share at least four lines')
    return bound


if __name__ == '__main__':
    shells = json.loads((Path(__file__).resolve().parents[1] / 'coredata'
                         / 'cores.json').read_text())
    mins = [analyze_shell(name, data) for name, data in shells.items()]
    costs = [min((s[k] for s in mins if k < len(s)), default=10**6)
             for k in range(9)]
    assert costs == [0,14,17,18,18,18,18,18,18]
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('witnesses', nargs='?', type=int, default=384)
    total = parser.parse_args().witnesses
    if total <= 0:
        parser.error('positive witness count required')
    overlap_bound(costs, total)

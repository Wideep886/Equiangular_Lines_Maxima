"""Verify the exact lattice short shells of the three surviving local examples."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import sys, json

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'coredata'))
from core import inv, sphere


def ldl_pivots(G):
    A=[list(map(F,row)) for row in G]
    idx=[]
    for j in range(len(G)):
        if A[j][j]:
            assert A[j][j]>0
            idx.append(j)
            for i in range(j+1,len(G)):
                c=A[i][j]/A[j][j]
                for k in range(i,len(G)):
                    A[i][k]-=c*A[j][k]
                    A[k][i]=A[i][k]
        else:
            assert all(t==0 for t in A[j][j:])
    return idx


def row_hnf(rows):
    a=[row[:] for row in rows]
    rank=len(rows[0])
    for j in range(rank):
        for i in range(j+1,len(a)):
            while a[i][j]:
                z=a[j][j]//a[i][j]
                a[j]=[x-z*y for x,y in zip(a[j],a[i])]
                a[j],a[i]=a[i],a[j]
        assert a[j][j]
        if a[j][j]<0:
            a[j]=[-x for x in a[j]]
        for i in range(j):
            z=a[i][j]//a[j][j]
            a[i]=[x-z*y for x,y in zip(a[i],a[j])]
    assert all(not any(row) for row in a[rank:])
    return a[:rank]


def short_lattice(G):
    I=ldl_pivots(G)
    assert len(I)==12
    Gram=[[G[i][j] for j in I] for i in I]
    invg=inv(Gram)
    H=row_hnf([[row[i] for i in I] for row in G])
    x=[[sum(s*t for s,t in zip(row,col)) for col in invg] for row in H]
    B=[[sum(s*t for s,t in zip(row,col)) for col in H] for row in x]
    assert all(z.denominator==1 for row in B for z in row)
    B=[list(map(int,row)) for row in B]
    # Symmetric integral size reduction and swaps preserve the exact lattice.
    while True:
        perm=sorted(range(len(B)),key=lambda i:B[i][i])
        B=[[B[i][j] for j in perm] for i in perm]
        change=False
        for i in range(1,len(B)):
            for j in range(i):
                coef=round(F(B[i][j],B[j][j]))
                if coef and 2*abs(B[i][j])>B[j][j]:
                    row=[u-coef*v for u,v in zip(B[i],B[j])]
                    diag=B[i][i]-2*coef*B[i][j]+coef**2*B[j][j]
                    for k,v in enumerate(row):
                        B[k][i]=B[i][k]=v
                    B[i][i]=diag
                    change=True
        if not change:break
    return B,dict(Counter(n for n,_ in sphere(B)))


def main():
    res=json.loads((HERE/'census.json').read_text())
    cores=json.loads((HERE.parent/'coredata'/'cores.json').read_text())
    output={}
    for x,data in res.items():
        for y,w in data['rootless_necessary_join'].items():
            cross=w['cross']
            J=[j for j in range(len(cross[0])) if all(abs(row[j])==1 for row in cross)]
            G=[s+[row[j] for j in J] for s,row in zip(cores[x]['shell_gram'],cross)]
            G.extend([row[i] for row in cross]+[cores[y]['shell_gram'][i][j] for j in J] for i in J)
            B,short=short_lattice(G)
            output[x+'/'+y]=dict(gram=G,lattice_basis_gram=B,short_counts=short)
            print(x,y,len(G),short,flush=True)
    (HERE/'lattices.json').write_text(json.dumps(output,sort_keys=True,separators=(',',':')))
if __name__=='__main__': main()

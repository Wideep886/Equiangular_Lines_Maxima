# 33 個必要原核對 27 個格殼的 Mac 重播

兩條歷史工作線採用不同版本的 rank12 及 coredata 模組，原 Mac 釋出 ZIP 本身也有這項差異。此處保留從原 Mac 專案恢復的程式與資料；inputs.json 分別列出此一重播實際讀到的19個輸入、SHA-256及是否取 Mac 檔。執行 python3 replay.py 將這19檔複製到獨立暫存目錄，執行原 cross27.py，並逐位元核對它輸出的 cross27.json。重播僅需 Python 標準庫。其他 Mac 歷史腳本各自有不同依賴。

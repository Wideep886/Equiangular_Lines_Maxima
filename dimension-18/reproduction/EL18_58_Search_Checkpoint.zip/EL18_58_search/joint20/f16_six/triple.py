"""Exact finite arithmetic in the proof of the three-normal restriction."""
from fractions import Fraction as F
from itertools import product
from math import isqrt


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


columns=[s for s in product((-1,1),repeat=3) if s[0]*s[1]*s[2]==1]
assert len(columns)==4
for left in columns:
    for right in columns:
        overlap=dot(left,right)
        assert overlap==(3 if left==right else -1)
        residual={(F(sign)-F(overlap,3))/4 for sign in (-1,1)}
        assert residual==({F(-1,2),F(0)} if left==right else {F(-1,6),F(1,3)})
    assert tuple(3*e-2*e for e in left)==left
assert max(m for m in range(59) if F(58+8*m,9)<26)==21
assert 9+8-12==5 and 5+5-2*3==4
cross={12,-6}
for basis_size in (14,15):
    remainders={j:36-basis_size-3*j for j in range(basis_size+1) if 36-basis_size-3*j>=0}
    print('basis size',basis_size,'nonnegative residuals',remainders)
    if basis_size==15:
        assert [j for j,v in remainders.items() if not v]==[7]
        assert all((basis_size-42+9*i) not in cross for i in range(8))
    else:
        assert set(remainders.values())=={1,4,7,10,13,16,19,22}
        for a,b in product(remainders.values(),repeat=2):
            if isqrt(a*b)**2==a*b and a!=b:
                assert isqrt(a)**2==a and isqrt(b)**2==b
        assert F((58-21)*7,9)>26
        assert all((k-14)%3==1 for k in {0,-18,12,-6})
assert {s for s in range(3) if (15-6*s-36)%9==0}=={1}
assert (15-3*(1+1))%9==0 and all(k%9 for k in cross)
assert 4*14<57 and 4*13+1<58
print('max complete positive subset in a pillar 13; independent three-class branch impossible')

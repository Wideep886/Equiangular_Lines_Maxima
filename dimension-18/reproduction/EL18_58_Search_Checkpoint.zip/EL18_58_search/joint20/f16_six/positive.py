"""Positive Walsh sixes: exact counts, the three-normal quadratic form, and packing."""
from fractions import Fraction as F
from itertools import product
from math import comb


def parity(x):
    return bin(x).count('1') % 2


normal_defects = {}
for a in product((-1, 1), repeat=6):
    s = sum(a)
    norm = 3+s*s//4
    # z is the aligned half-sum minus an odd-paired normal.
    # z.v = (4*a[i]+s)/2 - a[i], since all u_i.u_j=1 off diagonal.
    pair_parity = (a[0]+s//2) % 2
    defect = (norm-pair_parity) % 4
    normal_defects.setdefault(defect, set()).add((abs(s),norm))
assert normal_defects == {0:{(2,4),(6,12)},2:{(0,3),(4,7)}}
print('absolute signature sums and squared norms before excluding 4', normal_defects)

# Exact extremum over the inherited integer triangle strip and edge bounds.
rows = []
for edges in range(592,619):
    for neg in range(13512,13593,2):
        c3 = (neg+F(82,3)*edges-58*F(4096,9)+26*(F(1856,3)-edges))//4
        high = 30856-28*edges+c3-neg//2
        rows.append((high,edges,neg,c3))
assert max(rows)[0]==8521
assert max(rows)[0]//20==426
print('largest positive-triangle upper bound (value,edges,T,C3 upper)', max(rows))

# If three normal classes form a basis, q/2 is 1 on each basis vector
# with all distinct polar products 1. Each q=2 class has one zero incidence.
for c in range(8):
    h=bin(c).count('1')
    if (h+comb(h,2))%2==0:
        continue
    incidence=tuple(parity(c^(c&(1<<i))) for i in range(3))
    assert incidence.count(0)==1
    print('independent three-normal case, class and polar products', c,incidence)

# Mixed shell kernel. Bessel upper matrix on constant and k=p+n.
def harmonic(u):
    return ((17*u-1)/16,(21*19*u*u-6*19*u+3)/(16*18))


degree=(F(107,3),F(1867,51))
c=(F(418,7),F(1836,7))
f0=F(8,2907)
for u in (F(0),F(1,9),F(1)):
    assert f0*(1+sum(a*b for a,b in zip(c,harmonic(u))))==u*(u-F(1,9))
u=[max(1+d*p+(57-d)*q for d in degree) for p,q in zip(harmonic(F(1,49)),harmonic(F(4,49)))]
z=harmonic(F(0)); delta=[(i-j)/58 for i,j in zip(harmonic(F(1,7)),z)]
w=[58*i/j for i,j in zip(c,u)]
h00=1+sum(a*b*b for a,b in zip(w,z));h01=sum(a*b*d for a,b,d in zip(w,z,delta)); h11=sum(a*d*d for a,d in zip(w,delta))
det=h00*h11-h01*h01
bessel=323*(h00+2*h01+h11)/det
assert bessel==F(15713172256,95135)
# t,s are counts of actual triangles on x+a and x-a with a a shell vector.
local=[]
for p,n in product(range(59), repeat=2):
    k=p+n
    if k>58:
        continue
    # 12 times the x and a diagonal deviations are 40 and 8*k-192.
    first,second=40,8*k-192
    if 16*(first**2+second**2+64*(p-n)**2)+(24-first-second)**2>84*16*144:
        continue
    for t,s in product(range(min(5,p//3)+1),range(min(5,n//3)+1)):
        cap=min(p*((p-1)//2)//3-t,n*((n-1)//2)//3-s)
        assert 24*cap+12*(t+s)+1 <= (k-1)**2
        local.append(k)
assert len(local)==5004 and (min(local),max(local))==(12,36)
minimum_all_negative=min((13512-58*e+58*(2*e//58)**2+(2*e%58)*(2*(2*e//58)+1)+3)//4 for e in range(592,619))
assert minimum_all_negative==840
# The shell has at least 84 lines because each a carries at most 10 triangles.
normal_six_cap=(bessel-12*minimum_all_negative-84)//240
assert normal_six_cap==645
print('mixed-shell sum (k-1)^2 upper', bessel, 'local (p,n,t,s) rows', len(local), 'positive-six upper by shell only', normal_six_cap)
# Combine the three e(x) against the unused 15 diagonal coordinates.
edge_sum_lower=1856-F(3,4)*(84-F(100,3)-F(64,15))
assert edge_sum_lower==F(9106,5)
edge_sum_min=-(-edge_sum_lower.numerator//edge_sum_lower.denominator)
# Use all integer frame-compatible e triples, without multiplying the number of configurations.
from itertools import combinations_with_replacement
best=(-1,None)
for t in range(13512,13593,2):
    cap={e:v//20 for v,e,t0,_ in rows if t0==t}
    for es in combinations_with_replacement(cap,3):
        if sum(es)>=edge_sum_min:
            value=sum(cap[e] for e in es)
            if value>best[0]:
                best=(value,(t,es))
assert best[0]==1214, best
print('three-axis joint edge-sum minimum',edge_sum_min,'upper on all distinct positive R-sixes',best)

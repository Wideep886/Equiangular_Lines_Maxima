"""Integer and rational certificate for the f=16, q=1 radical support 220."""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations, product

n = 6
G = [[4 * (i == j) + 1 for j in range(n)] for i in range(n)]
for bit, (i, j) in enumerate(combinations(range(1, n), 2)):
    if (220 >> bit) & 1:
        G[i][j] = G[j][i] = -1

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def apply(mat, u):
    return tuple(dot(row, u) for row in mat)

signs = list((1,)+s for s in product((-1, 1), repeat=5))
S = [[G[i][j] - 5*(i == j) for j in range(n)] for i in range(n)]
assert all(dot(S[i], S[j]) == 5*(i == j) for i in range(n) for j in range(n))
Z = [[5*(i == j) - S[i][j] for j in range(n)] for i in range(n)]
assert all(dot(Z[i], G[j]) == 20*(i == j) for i in range(n) for j in range(n))

# A half signed sum has norm s^T G s/4; its inner products with the six core rays are Gs/2.
half = []
for s in signs:
    gs = apply(G, s)
    assert dot(s,gs) >= 20
    if dot(s,gs) == 20:
        assert all(x % 4 == 0 for x in gs)
        i, = [j for j,x in enumerate(gs) if x == 0]
        assert sum(abs(x)==4 for x in gs)==5
        half.append((i,s,gs))
half.sort()
assert [i for i,_,_ in half] == list(range(6))
for i,s,g in half:
    edges=[(a,b) for a,b in combinations(range(n),2) if g[a]*g[b]*G[a][b]<0]
    assert len(edges)==5 and all(sum(j in e for e in edges)==2 for j in range(n) if j!=i)
print('six shortest half axes; each has a different zero, and active core graph C5')

single=[];triple=[]
for v in signs:
    paired = [dot(v,s) for _,s,_ in half]  # twice the external pairings
    if any(x%4 for x in paired):
        continue
    m=sum(bool(x) for x in paired)
    assert set(map(abs,paired)) <= {0,4}
    proj20 = dot(v,apply(Z,v))
    if m == 1:
        assert proj20 == 20
        single.append(v)
    else:
        assert m == 3 and proj20 == 36
        assert dot(v,apply(G,v)) == 24
        assert all(x%4==2 for x in apply(G,v))
        triple.append(v)
assert (len(single),len(triple)) == (6,10)
# All 16 legal external signatures pair oddly with every unscaled-square-six t_s.
assert all(dot(v,s)%4 == 2 for v in single+triple for s in triple)
assert all(sum(apply(G,s)[i]*apply(G,s)[j] for s in triple)==40*G[i][j]
           for i in range(n) for j in range(n))
print('projected signatures (count, active axes, projection norm): (6,1,1), (10,3,9/5)')
print('square-six companion frame: 10 axes, frame operator 10 I on the six-dimensional span')

corr=lambda s,t: Q(dot(s,apply(G,t)),4) - dot(s,t)
E=[(i,j,corr(s,t)) for (i,s),(j,t) in combinations(enumerate(triple),2) if corr(s,t)]
assert len(E)==15 and all(abs(c)==2 for _,_,c in E)
assert all(sum(k==i or k==j for i,j,_ in E)==3 for k in range(10))
assert all(corr(s,s)==0 for s in triple)
valid=[]
for k in range(53):
    excess=(82+Q(4,5)*k-Q(290,3))**2/4+Q((82-4*k)**2,30)
    if excess<=Q(754,9):
        valid.append(k)
assert valid == list(range(10,31))
print('forced sign pairs among triple-signature types',len(E),'out of 45; degree 3')
print('two trace constraints: N_three =', valid[0], '..',valid[-1],'; even-pair square-five axes >=',6+valid[0])

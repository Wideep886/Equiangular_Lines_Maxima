"""Replay with Python's standard library. Run from any working directory."""
from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations, product
from math import ceil, comb

points = tuple(range(6))
edges = tuple(combinations(points[1:], 2))
triples = tuple(combinations(points, 3))

def gram(mask):
    matrix = [[5 if i == j else 1 for j in points] for i in points]
    for index, (i,j) in enumerate(edges):
        if mask & (1 << index):
            matrix[i][j] = matrix[j][i] = -1
    return matrix

def canonical(matrix):
    def moved(p):
        return sum((matrix[p[0]][p[i]]*matrix[p[0]][p[j]]*matrix[p[i]][p[j]] < 0) << k
                   for k, (i,j) in enumerate(edges))
    return min(moved(p) for p in permutations(points))

def axes_data(matrix):
    partial = []
    for signs in product((1,-1), repeat=5):
        signs=(1,)+signs
        pair=tuple(sum(x*y for x,y in zip(row,signs)) for row in matrix)
        form=sum(x*y for x,y in zip(pair,signs))
        assert form%4 == 0 and all(x%2 == 0 for x in pair)
        parity = (sum(s < 0 for s in signs)+1)%2
        assert all((v//2)%2 == parity for v in pair)
        partial.append((form//4,parity))
    def triangle_sign(t):
        i,j,k=t
        return matrix[i][j]*matrix[i][k]*matrix[j][k]
    splits=Counter()
    for a in triples:
        if 0 in a:
            b=tuple(i for i in points if i not in a)
            splits[triangle_sign(a)+triangle_sign(b)] += 1
    return min(partial), (4,0) in partial, [splits[k] for k in (-2,0,2)]

def min_pairs(total, slots):
    average,remainder=divmod(total,slots)
    return slots*comb(average,2)+remainder*average

orbits=Counter()
for mask in range(1<<len(edges)):
    matrix=gram(mask)
    if all(sum(a < 0 for a in row)%2 == 0 for row in matrix):
        orbits[canonical(matrix)] += 1
assert sorted(orbits.items()) == [(0,1),(19,20),(54,15),(207,15),(220,12),(1023,1)]
for k in sorted(orbits):
    print(k, orbits[k], *axes_data(gram(k)))
assert axes_data(gram(54)) == ((3,1),False,[4,0,6])
assert axes_data(gram(207))[1]
assert all(axes_data(gram(i))[2][0]==0 for i in [0,19,220])
slots=2**12-58
allpairs=min_pairs(comb(58,3),slots)
negpairs=min_pairs(13512,slots)
maxhex=2*13592//21
min54=ceil(Fraction(negpairs-10*maxhex,4))
print('triple bins, all and negative collisions:',slots,allpairs,negpairs)
print('R6 lower, C6 upper, non-C6 lower, type54 lower:',
      ceil(Fraction(allpairs,10)),maxhex,ceil(Fraction(allpairs,10))-maxhex,min54)
assert (allpairs,negpairs,maxhex,min54)==(102928,16308,1294,842)
six_cost=6*Fraction(10,3)**2+Fraction(18**2,12)
print('six orthogonal axes energy, largest family lower:',six_cost,ceil(Fraction(min54,5)))
assert six_cost==Fraction(281,3)>84
upper4=Fraction(13592)+Fraction(82,3)*618-Fraction(58*4096,9)+26*(Fraction(1856,3)-618)
upper_tri=(upper4/4).__floor__()
cap=(Fraction(maxhex,4)+Fraction(upper_tri,8)).__floor__()
print('all-negative oriented triangles, single-axis capacity, minimum axes, hexads if two:',
      upper_tri, cap,ceil(Fraction(min54,cap)),ceil(Fraction(16308-upper_tri,12)))
assert (upper4,upper_tri,cap)==(Fraction(36944,9),1026,451)
assert all(t-1>=Fraction(comb(t,2),2)-int(t==5) for t in range(1,6))
assert all((t-3)*(t-4)==6*int(t==1)+2*int(t in (2,5)) for t in range(1,6))
cost5=5*upper_tri
slope=Fraction(7,3)-Fraction(5,2)+Fraction(3,10)
needH=Fraction(13512-2*slots-cost5,slope)
assert slope==Fraction(2,15) and needH==2295 and needH>maxhex
print('f=12 excluded: H >=',needH,'versus H <=',maxhex)

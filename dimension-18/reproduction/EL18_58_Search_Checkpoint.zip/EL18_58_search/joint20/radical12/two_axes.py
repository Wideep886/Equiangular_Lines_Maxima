"""Exact two-axis class census. a,b,c count negative edges in the classes and across them."""
from itertools import product

def moments(m):
    for a in range(m*(m+12)//12+1):
        first=m*(m+12)-12*a
        second=m*(2688-153*m)+768*a
        if second>=0:
            yield a,first,second

for m in range(1,30):
    n=58-m
    ahist=[]
    for (a,p,q),(b,r,s) in product(moments(m),moments(n)):
        if q*s<(25*m*n)**2:continue
        for e in range(592,619):
            c=e-a-b
            if 0<=c<=m*n and p*r >= 9*(m*n-2*c)**2:
                ahist.append((a,b,c,e))
    if ahist:
        print(m,n,len(ahist),min(row[3] for row in ahist),max(row[3] for row in ahist))
    assert bool(ahist)==(m>=24)

import json,sys
from pathlib import Path
from itertools import product, combinations_with_replacement
from fractions import Fraction as F
from math import lcm

def independ(g):
    a=[list(map(F,r)) for r in g];ix=[];n=len(g)
    for i in range(n):
        d=a[i][i]
        if not d:
            assert not any(a[i][i:])
            continue
        ix.append(i)
        for j in range(i+1,n):
            c=a[j][i]/d
            if c:
                a[j][i+1:]=[x-c*y for x,y in zip(a[j][i+1:],a[i][i+1:])]
    return ix
def inv(g):
    m=len(g)
    a=[list(map(F,r))+[int(i==j) for j in range(m)] for i,r in enumerate(g)]
    for i in range(m):
        d=a[i][i];a[i]=[v/d for v in a[i]]
        for j in range(m):
            if i!=j:
                c=a[j][i]
                if c:a[j]=[x-c*y for x,y in zip(a[j],a[i])]
    return [r[m:] for r in a]
def dot(a,b):
    return sum(i*j for i,j in zip(a,b))
def check(g):
    ix=independ(g);r=len(ix);n=len(g);b=[[g[i][j] for j in ix] for i in ix];bi=inv(b)
    d=lcm(*[v.denominator for row in bi for v in row]);z=[[int(d*v) for v in row] for row in bi]
    other=[[g[i][j] for j in ix] for i in range(n) if i not in ix]
    hits=[]
    for s in product((1,-1),repeat=r-1):
        s=(1,)+s
        col=tuple(dot(a,s) for a in z)
        q=dot(col,s)
        if q<=3*d and all(abs(dot(a,col))==d for a in other):
            hits.append((q,s,col))
    h2=sum(dot(s,v)**2 <= (3*d-q)*(3*d-p) for (q,s,u),(p,t,v) in combinations_with_replacement(hits,2))
    return len(hits),h2
src=Path(sys.argv[1]);short=json.loads((src/'run14/shared_pair/shortlist.json').read_text())
ids=json.loads((src/'run14/rank13/cross27.json').read_text());shells=json.loads((src/'run14/rank13/shell-classes.json').read_text())['reps']
processed=set()
for z in ids:
    i=z['matches'][0][0];r=z['rank']
    if (r,i) in processed:continue
    processed.add((r,i))
    if r==13:
        masks=shells[i]['negative'];g=[[5 if j==k else 1-2*((m>>k)&1) for k in range(len(masks))] for j,m in enumerate(masks)]
    else:
        g=short[z['source']]['gram']
        assert len(g)==18
    print(r,i,len(g),*check(g),flush=True)

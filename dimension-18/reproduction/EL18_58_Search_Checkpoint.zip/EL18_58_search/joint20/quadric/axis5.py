"""Necessary moment bounds for the norm-five even-paired half-coset shell."""
from fractions import Fraction as F
from math import comb, isqrt


def local(q):
    bounds={}
    for t in range(59):
        e=F(4*t,5)-16
        for k in range(min(comb(t,2),q-1)+1):
            col=F(4,5)*(t*t-28*t+320-4*k)
            if col>=e*e and 2*col-e*e+(2-e)**2/17<=84:
                bounds[t]=k
                break
    return bounds

def main():
    # q <= 61 by the equiangular relative bound. Each k <= q-1.
    viable=[]
    for q in range(1,62):
        tminmax=local(q)
        if not tminmax:
            continue
        for total in range(q*min(tminmax),q*max(tminmax)+1):
            # Same-dimensional centered Frobenius inner product of F and F_Y.
            if (36*total-725*q)**2>377*q*(432-7*q):
                continue
            t,r=divmod(total,q)
            # Sum of squares of integral t_i at fixed sum.
            tt=q*t*t+(2*t+1)*r
            lhs=4*(tt-28*total+320*q-4*q*(q-1))
            # 5 sum_y ||(F-16I)(y/sqrt(5))||^2 <= 84 largest_eig(F_Y).
            h=18*lhs-420*q
            if h>0 and h*h>84**2*17*q*(432-7*q):
                continue
            c=F(5*q*1000+isqrt(1000**2*17*q*(432-7*q))+1,18000)
            if lhs>84*c-(2*c-4*total+80*q)**2/(18*c-5*q):
                continue
            vb=F(q*(432-7*q),18)
            vd=F(754,9)
            z0=4*total-F(725*q,9)
            residual=vb-z0*z0/vd
            valid=False
            for ntri in range(13512,13593,2):
                skew=162680-12*ntri-F(84,9)
                center=F(5*q*84,18)+z0*skew/vd
                four=F(84**3+(162680-12*ntri)**2,168)
                margin=four-F(84**2,18)-skew*skew/vd
                if lhs<=center or (lhs-center)**2<=residual*margin:
                    valid=True
                    break
            if not valid:
                continue
            viable.append((q,total))
    assert sorted({q for q,total in viable})==list(range(35,62))
    assert [v for v in viable if v[0]==35]==[(35,i) for i in range(662,671)]
    print('q survivors',sorted({q for q,total in viable}))
    print('minimum size and total activity range',min(viable),max((q,t) for q,t in viable if q==viable[0][0]))

if __name__=='__main__':
    main()

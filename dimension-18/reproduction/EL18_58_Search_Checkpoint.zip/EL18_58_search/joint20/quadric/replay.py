"""Exact quadratic-refinement and six-support calculations. Standard Python 3."""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, ceil


def six_profile(mask):
    g = [[5 if i == j else 1 for j in range(6)] for i in range(6)]
    for bit, (i, j) in enumerate(combinations(range(1, 6), 2)):
        if mask >> bit & 1:
            g[i][j] = g[j][i] = -1
    if any(row.count(-1) % 2 for row in g):
        return None
    signs = set()
    shortest = 1000
    min_active = set()
    for a in product((1,-1), repeat=6):
        twice_ip = [sum(x*y for x,y in zip(row, a)) for row in g]
        assert len({z % 4 for z in twice_ip}) == 1 and twice_ip[0] % 2 == 0
        parity = twice_ip[0] // 2 % 2
        scaled = sum(x*z for x,z in zip(a, twice_ip))
        assert scaled % 4 == 0
        norm = scaled // 4
        signs.add((norm + parity) % 2)
        if norm < shortest:
            shortest, paired, min_active = norm, parity, {tuple(sorted(abs(z//2) for z in twice_ip))}
        if norm == shortest:
            assert parity == paired
            min_active.add(tuple(sorted(abs(z//2) for z in twice_ip)))
    assert len(signs) == 1
    def negative(triple):
        i,j,k = triple
        return int(g[i][j]*g[j][k]*g[k][i] < 0)
    counts = [0,0,0]
    for pair in combinations(range(1,6),2):
        triple = (0,) + pair
        other = tuple(i for i in range(6) if i not in triple)
        counts[negative(triple) + negative(other)] += 1
    q = signs.pop()
    assert (counts[1] == 10) == bool(q)
    assert len(min_active) == 1
    return (shortest, paired, q, *reversed(counts)), min_active.pop()


def balanced(m,s):
    q,r=divmod(m,s)
    return s*comb(q,2)+r*q


def cap_h(t):
    fixed=40*625+18*11**4+4*11**3*2+6*11**2*84
    k=58*57*113+24*comb(58,4)
    third=162680-12*t
    fourth=F(84**2,18)+(third-F(84,9))**2/F(754,9)
    four=(k-fixed-44*third-fourth)//32
    return (2*four-37*t)//112


def main():
    classes = {}
    for mask in range(1024):
        profile = six_profile(mask)
        if profile is not None:
            classes.setdefault(profile, []).append(mask)
    expected = {0:1,19:20,54:15,207:15,220:12,1023:1}
    assert {min(m):len(m) for m in classes.values()} == expected
    for (key,active),masks in classes.items():
        print('six',min(masks),len(masks),'norm/pair/p/--/-+/++',key,'absolute pairings',active)
    ts=range(13512,13593,2)
    assert comb(58,3)==30856
    for sign in (1,-1):
        # Q_+(u,v)=u.v and Q_-=u.v+u_0+v_0.
        s0=sum(((bin(u&v).count("1")+int(sign<0)*((u%2)+(v%2)))%2)==0
               for u in range(128) for v in range(128))
        assert s0 == 2**13+64*sign
        s=s0-58
        mpp=min(balanced(30856-t,s) for t in ts)
        mm=min(balanced(t,16384-s0) for t in ts)
        cut=ceil(F(mpp,10))
        h_cuts=[ceil(F(balanced(30856-t,s)-18*((cap_h(t)+513)//4),10)) for t in ts]
        n0=min(h_cuts)
        exp=(8198,9934,5384,994,220) if sign==1 else (8070,10318,5256,1032,258)
        assert (s,mpp,mm,cut,n0)==exp
        print('f14 Arf sign',sign,'positive/negative buckets',s,16384-s0,'M++',mpp,'M--',mm,'N0+N54',cut,'N0',n0)
    sy=min(ceil((F(t)-F(7*cap_h(t),3))/2) for t in ts)
    assert sy>=5344
    print('f16 p nonorthogonal: distinct positive syndromes >=',30856-max(ts),
          'distinct negative syndromes >=',sy)
    # Nonzero even-length vector in L has squared length at least 8.
    feasible=[s for s in range(-3,4) if s%2 and min(8+2*s,8-2*s)>=8]
    assert not feasible
    print('squared 3 and 5 even-paired axes in one half-lattice coset:',feasible)


if __name__=='__main__':
    main()

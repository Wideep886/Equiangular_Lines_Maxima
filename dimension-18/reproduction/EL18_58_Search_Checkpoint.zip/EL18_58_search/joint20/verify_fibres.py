"""Six-point signed dot products for every ordered choice of the first negative triangle.
Independent of the canonical orbit numbers and of the plane-incidence programs.
"""
from itertools import combinations, product
from math import comb
from collections import Counter
from fractions import Fraction as F

N = 6
points = tuple(range(N))
edge = tuple(combinations(points[1:], 2))
outs = tuple(p for p in product((1,-1), repeat=N) if p.count(-1)%2==0)
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
counts=Counter()
for mask in range(1<<len(edge)):
    g=[[5 if i==j else 1 for j in points] for i in points]
    for b,(i,j) in enumerate(edge):
        if mask>>b&1: g[i][j]=g[j][i]=-1
    if any(row.count(-1)%2 for row in g): continue
    counts['rooted Euler sign patterns']+=1
    def axis(s):
        gs=[dot(row,s) for row in g]
        return dot(gs,s),gs
    root=False
    for ss in product((-1,1),repeat=5):
        s=(1,)+ss
        value,gs=axis(s)
        if value==16 and all(dot(s,row)%4==0 for row in (*g,*outs)):
            root=True;break
    if root:
        counts['even-paired norm-four exclusion']+=1
        continue
    def oriented(triple):
        i,j,k=triple
        if g[i][j]*g[j][k]*g[k][i]!=-1:return None
        v=[0]*6;v[i]=1;v[j]=-g[i][j];v[k]=-g[i][k]
        assert axis(v)[0]==9
        return v
    for t in combinations(points,3):
        if 0 not in t:continue
        a=oriented(t); b=oriented(tuple(x for x in points if x not in t))
        if not a or not b:continue
        d=dot(axis(a)[1],b)
        if abs(d)==9:
            counts['identical real axis partitions']+=1
            continue
        s=[i-(1 if d>0 else -1)*j for i,j in zip(a,b)]
        assert abs(d)==3 and axis(s)[0]==12
        assert all(dot(s,row)%4==2 for row in (*g,*outs))
        counts['different axes yield odd-paired norm-three half-sum']+=1
print(dict(counts))
assert tuple(counts[k] for k in ('rooted Euler sign patterns','even-paired norm-four exclusion',
    'identical real axis partitions','different axes yield odd-paired norm-three half-sum'))==(64,15,10,60)
# Frame bound for all-negative cliques in the orientation x.v=1.
e=618
triangle_bound=(F(13592)+F(82,3)*e-F(58*4096,9)+26*(F(1856,3)-e))/4
assert triangle_bound//1==1026
# Check the worst possible multiplicity inequality for every integer H,T
# without using the strengthened trace-four estimate on H.
for H in range(1295):
    assert F(13512)-F(7*H,3) > 2*(2**12-58)+5*(1026-F(H,2))+F(3*H,10)
print('rank 12 contradictions for every H between 0 and 1294')

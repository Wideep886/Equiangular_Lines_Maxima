#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <vector>
using namespace std;
using Row=vector<double>;
class Tableau {
  int m,n;
  vector<int> basic, nonbasic;
  vector<Row> d;
  const double eps=1e-8;
  void pivot(int i,int j){
    double inv=1/d[i][j];
    for(int p=0;p<m+2;p++)if(p!=i){
      double t=d[p][j]*inv;
      if(abs(t)>1e-12)for(int q=0;q<n+2;q++)if(q!=j)d[p][q]-=d[i][q]*t;
      d[p][j]=-t;
    }
    for(int q=0;q<n+2;q++)if(q!=j)d[i][q]*=inv;
    d[i][j]=inv; swap(basic[i],nonbasic[j]);
  }
  bool maximize(int phase){
    int row=phase==1?m+1:m;
    for(int iter=0;iter<15000;iter++){
      int j=-1;
      for(int q=0;q<=n;q++)if(!(phase==2&&nonbasic[q]==-1))
        if(j==-1||d[row][q]<d[row][j]-eps||(abs(d[row][q]-d[row][j])<eps && nonbasic[q]<nonbasic[j]))j=q;
      if(d[row][j]>=-eps)return true;
      int i=-1;double best=0;
      for(int p=0;p<m;p++)if(d[p][j]>eps){
        double r=d[p][n+1]/d[p][j];
        if(i==-1||r<best-eps||(abs(r-best)<eps&&basic[p]<basic[i])){i=p;best=r;}
      }
      if(i==-1)return false;
      pivot(i,j);
    }
    return false;
  }
public:
  void solve(){
    cin>>m>>n; d.assign(m+2, Row(n+2));basic.resize(m);nonbasic.resize(n+1);
    for(int j=0;j<n;j++){cin>>d[m][j];d[m][j]*=-1;nonbasic[j]=j;}
    for(int i=0;i<m;i++){for(int j=0;j<n;j++)cin>>d[i][j];cin>>d[i][n+1];d[i][n]=-1;basic[i]=n+i;}
    nonbasic[n]=-1;d[m+1][n]=1;int r=0;
    for(int i=1;i<m;i++)if(d[i][n+1]<d[r][n+1])r=i;
    if(d[r][n+1]<-eps){
      pivot(r,n); if(!maximize(1)||d[m+1][n+1]<-1e-6)exit(2);
      for(int i=0;i<m;i++)if(basic[i]==-1){
        int s=int(max_element(d[i].begin(),d[i].begin()+n+1,[](double a,double b){return abs(a)<abs(b);})-d[i].begin());
        if(abs(d[i][s])>eps)pivot(i,s);
      }
    }
    if(!maximize(2))exit(3);
    Row x(n);for(int i=0;i<m;i++)if(basic[i]<n&&basic[i]>=0)x[basic[i]]=d[i][n+1];
    for(auto v:x)cout<<setprecision(14)<<v<<" ";cout<<"\n";
  }
};
int main(){Tableau t;t.solve();}

import sys, os, json, subprocess
from pathlib import Path
from fractions import Fraction as F
from math import comb,ceil
here=Path(__file__).resolve().parent
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here.parents[1]
sys.path.insert(0,str(ROOT/'run14/deletion'))
from final_anchors import WORDS,rows,no_triple_rows,counts
from exact_weights import deletion_cap
from itertools import combinations
A58,A59=rows(7)
B=[(tuple(map(int,l.split()[:-1])),int(l.split()[-1])) for l in (here/'link12.txt').read_text().splitlines()]
B+= [(b,0) for b in no_triple_rows()]
assert len(B)==6410
grid=tuple(8*int(w==(1,1,1,1)) for w in WORDS)
def delta(b,d,t):
    if d==1:return 1
    if b==grid and d==8:return t
    return 0
def cf(a):
    return sum(counts(a))
def build(A,B,X,alpha,t,n):
    # 35 word weights, 3 monotone increments, g, lambda.
    nv=40; M=[]
    def row(data,b):
        v=[0]*nv
        for j,a in data:v[j]+=a
        M.append((v,b))
    for a in A:
        row([(j,-x) for j,x in enumerate(a[:35])]+[(39,a[-1])],-alpha*cf(a))
    for b,d in B:
        row(list(enumerate(b))+[(38,-1)],d-delta(b,d,t))
    for j,w in enumerate(WORDS):
        row([(j,1)]+[(34+x,x) for x in w if x],12)
        for x in set(w)-{0}:
            u=list(w);u.remove(x);u.append(x-1);i=WORDS.index(tuple(sorted(u)))
            row([(j,1),(i,-1),(34+x,-1)],0)
    c=[0]*nv;c[39]=30*X/comb(n,2);c[38]=-1
    inp='\n'.join(['%d %d'%(len(M),nv),' '.join(map(str,c))]+[' '.join(str(float(i)) for i in v+[b]) for v,b in M])+'\n'
    proc=subprocess.run([os.environ.get('EL18_SIMPLEX','/tmp/el17-matching-simplex')],input=inp,text=True,capture_output=True,timeout=60)
    if proc.returncode:return None
    return [round(float(x)*1_000_000) for x in proc.stdout.split()[:35]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))

for label,n,X,A,alpha in [('chosen58',58,5780,A58,F(1,9)),('full58',58,5780,A58,F(5,48)),('full59',59,6509,A59,F(5,48))]:
    t=8-48*alpha
    weight=build(A,B,X,alpha,t,n)
    if weight is None:
        raise ArithmeticError('floating discovery simplex did not finish')
    gamma=max(F(1000000),F(deletion_cap(weight),12))
    g=max(dot(b,weight)-gamma*(d-delta(b,d,t)) for b,d in B)
    lam=min((dot(a,weight)-gamma*alpha*cf(a))/a[-1] for a in A)
    value=(30*lam*X-comb(n,2)*g)/(4*gamma)
    print(label,alpha,value,ceil(value))

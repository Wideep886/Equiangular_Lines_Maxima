"""Enumerate same-baseline grid pairs with k=3,4 common cells and no common petal."""
from itertools import product, permutations
from collections import Counter
from pathlib import Path
import json
here=Path(__file__).resolve().parent
cells=list(product(range(4),repeat=2))
perms=list(permutations(range(4)))
def within(x,y):return 5 if x==y else (-1 if x[0]==y[0] or x[1]==y[1] else 1)
def psd(g):
    a=[list(row) for row in g];r=0;divisor=1
    for i in range(len(a)):
        p=a[i][i]
        if p<0 or (p==0 and any(a[i][i+1:])):return -1
        if not p:continue
        for j in range(i+1,len(a)):
            for k in range(j,len(a)):
                num=p*a[j][k]-a[i][j]*a[i][k]
                assert num%divisor==0
                a[j][k]=num//divisor
        divisor=p;r+=1
    return r
def census(k):
    diagonal=[(i,i) for i in range(k)]
    extra=[x for x in cells if x not in diagonal]
    candidates={}
    for x in extra:
        allowed=[p for p in perms if all((p[i]==i)==(i in x) for i in range(k))]
        candidates[x]=[[(-1 if p[a]==b else 1) for a,b in cells] for p in allowed]
    sides=[[x for x in cells if x[j]==i] for j in (0,1) for i in range(4)]
    fixed={x:list(map(lambda y:within(x,y),cells)) for x in diagonal}
    data=[]; counts=Counter()
    for values in product(*(candidates[x] for x in extra)):
        cross=dict(fixed);cross.update(zip(extra,values));counts['raw']+=1
        if any(sum(cross[x][j] for x in side)!=2 for side in sides for j in range(16)):continue
        counts['reciprocal']+=1
        grid=cells+extra;g=[[5,-1]+[-1]*len(grid),[-1,5]+[-1]*len(grid)]
        for i,x in enumerate(cells):
            g.append([-1,-1]+[within(x,y) for y in cells]+[cross[y][i] for y in extra])
        for x in extra:
            g.append([-1,-1]+cross[x]+[within(x,y) for y in extra])
        r=psd(g);counts['inertia'+str(r)]+=1
        if 0<=r<=18:data.append({'rank':r,'gram':g})
    print(k,sorted(counts.items()),'sizes',sorted(map(len,candidates.values())),flush=True)
    return data
if __name__=='__main__':
    data={str(k):census(k) for k in (3,4)}
    (here/'rooks.json').write_text(json.dumps(data,separators=(',',':'))+'\n')

// Independent enumeration of the link histograms. C++17, no dependencies.
// c++ -std=c++17 -O2 link_base.cpp -o /tmp/link_base
// /tmp/link_base 4 > /tmp/link_base_cpp
// python3 audit_incidence.py --dump-base 4 > /tmp/link_base_py
// cmp /tmp/link_base_cpp /tmp/link_base_py
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <set>
#include <vector>

using Signature = std::array<int,3>;
using Row = std::array<int,36>;
using Word = std::array<int,4>;
using Bits = std::uint32_t;

struct Enumerator {
    int threshold;
    std::vector<Word> words;
    std::set<Row> rows;
    std::vector<Signature> strong, weak, selected;
    std::vector<Bits> edge{0,0,0};

    explicit Enumerator(int cut) : threshold(cut) {
        for (int a=0; a<=3; ++a)
            for (int b=a; b<=3; ++b)
                for (int c=b; c<=3; ++c)
                    for (int d=c; d<=3; ++d)
                        words.push_back({a,b,c,d});
    }

    bool inspect(Row &row) const {
        const int n = edge.size();
        assert(n < 32);
        const Bits full = (Bits{1} << n) - 1;
        for (int i=0; i<n; ++i) {
            // The nonedges among nonneighbors of i count its empty triples.
            Bits tail = full & ~(edge[i] | (Bits{1} << i));
            int empty = 0;
            while (tail) {
                const int j = __builtin_ctz(tail);
                tail &= tail-1;
                empty += __builtin_popcount(tail & ~edge[j]);
            }
            if (empty >= threshold) return false;
            row[35] += empty;
            // Check all neighborhood components are cliques by traversing
            // whole components, then compare component sizes and degrees.
            Bits unexplored = edge[i];
            Word word{};
            int index = 0;
            while (unexplored) {
                Bits seen = unexplored & -unexplored;
                Bits todo = seen;
                while (todo) {
                    const int j = __builtin_ctz(todo);
                    todo &= todo-1;
                    const Bits fresh = edge[j] & edge[i] & ~seen;
                    todo |= fresh;
                    seen |= fresh;
                }
                const int size = __builtin_popcount(seen);
                if (index == 4 || size > 3) return false;
                Bits verts = seen;
                while (verts) {
                    const int j = __builtin_ctz(verts);
                    verts &= verts-1;
                    if (__builtin_popcount(edge[j] & seen) != size-1) return false;
                }
                word[index++] = size;
                unexplored &= ~seen;
            }
            std::sort(word.begin(),word.end());
            ++row[std::lower_bound(words.begin(),words.end(),word)-words.begin()];
        }
        assert(row[35] % 3 == 0);
        row[35] /= 3;
        return true;
    }

    void search(int first, int depth) {
        Row row{};
        if (!inspect(row)) return;
        const bool compulsory = depth < static_cast<int>(weak.size());
        if (!compulsory) rows.insert(row);
        const int options = compulsory ? 1 : static_cast<int>(strong.size())-first;
        for (int offset=0; offset<options; ++offset) {
            const auto &candidate = compulsory ? weak[depth] : strong[first+offset];
            Bits include=0, uncertain=0;
            for (int i=0;i<3;++i)
                if (candidate[i]>=0) include |= Bits{1} << i;
            bool compatible=true;
            for (int j=0;j<static_cast<int>(selected.size());++j) {
                int equal=0, different=0;
                for (int i=0;i<3;++i) {
                    const int x=candidate[i], y=selected[j][i];
                    if (x<0 || y<0) continue;
                    if (x==y) ++equal; else ++different;
                }
                if (equal>=2 || (equal && different)) {
                    compatible=false;
                    break;
                }
                const Bits bit=Bits{1} << (3+j);
                if (equal) include |= bit;
                if (!equal && !different) uncertain |= bit;
            }
            if (!compatible) continue;
            const int n=edge.size();
            for (Bits sub=uncertain; ; sub=(sub-1)&uncertain) {
                const Bits nb=include|sub;
                for (int j=0;j<n;++j)
                    if ((nb>>j)&1) edge[j] |= Bits{1}<<n;
                edge.push_back(nb);
                selected.push_back(candidate);
                search(compulsory?0:first+offset+1, depth+int(compulsory));
                selected.pop_back();
                edge.pop_back();
                for (int j=0;j<n;++j) edge[j]&=~(Bits{1}<<n);
                if (!sub) break;
            }
        }
    }

    void place_weak(const std::vector<int> &anchors, int pos) {
        if (pos==static_cast<int>(anchors.size())) {
            search(0,0);
            return;
        }
        const int anchor=anchors[pos];
        const int minimum=(pos && anchor>=0 && anchor==anchors[pos-1]) ? weak.back()[anchor] : 0;
        for (int x=minimum;x<(anchor<0?1:4);++x) {
            Signature s{-1,-1,-1};
            if (anchor>=0) s[anchor]=x;
            weak.push_back(s);
            place_weak(anchors,pos+1);
            weak.pop_back();
        }
    }

    void run() {
        const std::vector<std::array<int,4>> representatives{
            {0,1,2,3},{1,0,2,3},{1,0,3,2},{1,2,0,3},{1,2,3,0}};
        for (const auto &p : representatives) {
            strong.clear();
            for (int a=-1;a<4;++a)
                for (int b=-1;b<4;++b)
                    for (int c=-1;c<4;++c) {
                        if (int(a>=0)+int(b>=0)+int(c>=0)<2) continue;
                        if (a>=0 && b>=0 && a!=b) continue;
                        if (a>=0 && c>=0 && a!=c) continue;
                        if (b>=0 && c>=0 && p[b]!=c) continue;
                        strong.push_back({a,b,c});
                    }
            for (int z=0;2*z<=threshold-2;++z)
                for (int a=0;2*z+a<=threshold-2;++a)
                    for (int b=0;b<=a && 2*z+a+b<=threshold-2;++b)
                        for (int c=0;c<=b;++c) {
                            std::vector<int> anchors(z,-1);
                            anchors.insert(anchors.end(),a,0);
                            anchors.insert(anchors.end(),b,1);
                            anchors.insert(anchors.end(),c,2);
                            place_weak(anchors,0);
                        }
        }
    }
};

int main(int argc, char **argv) {
    int cut=argc==2 ? std::atoi(argv[1]) : 4;
    if (cut<3 || cut>12) return 2;
    Enumerator engine(cut);
    engine.run();
    for (const Row &row : engine.rows) {
        for (std::size_t i=0;i<row.size();++i)
            std::cout << (i?" ":"") << row[i];
        std::cout << '\n';
    }
}

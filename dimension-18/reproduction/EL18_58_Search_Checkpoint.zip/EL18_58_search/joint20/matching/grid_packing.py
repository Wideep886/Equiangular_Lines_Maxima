"""Pairwise overlap packing and the archived frame-variance bounds on its baselines."""
from fractions import Fraction as F
from pathlib import Path
from math import comb
import sys
here=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here.parents[1]
sys.path.insert(0,str(root/'run14/deletion'))
from bad_anchors import variances
def union_lower(g):
    return 16*g-4*comb(g,2)
assert [union_lower(g) for g in (1,2,3,4)]==[16,28,36,40]
for n in (58,59):
    for g in (2,3):
        minimum=union_lower(g)
        value,c,V,s=min((V/(minimum-c)**2,c,V,s) for c,V,s in variances(n) if c<minimum)
        bound=value.numerator//value.denominator
        print(n,g,minimum,'centering',c,'s',s,'exact',value,'at most',bound)
        assert bound=={(58,2):375,(58,3):43,(59,2):364,(59,3):33}[n,g]

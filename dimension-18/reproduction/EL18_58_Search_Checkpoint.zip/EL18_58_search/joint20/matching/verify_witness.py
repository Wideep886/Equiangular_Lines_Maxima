"""Verify the archived 54-ray witness without regenerating its clique."""
import json
from fractions import Fraction as F
from pathlib import Path
from rooks import psd
here=Path(__file__).resolve().parent
g=json.loads((here/'rook54.json').read_text())
core=json.loads((here/'rooks.json').read_text())['4'][0]['gram']
assert len(g)==54 and all(len(r)==54 for r in g)
assert all(g[i][j]==g[j][i] and (g[i][j]==5 if i==j else abs(g[i][j])==1) for i in range(54) for j in range(54))
assert [r[:30] for r in g[:30]]==core and psd(g)==18
# Rational Gram--Schmidt using actual basis rows and a sum-of-outer-products identity.
columns=[]
for j in range(54):
    z=[F(g[i][j])-sum(c[i]*c[j]/q for c,q in columns) for i in range(54)]
    if z[j]:
        assert z[j]>0
        columns.append((z,z[j]))
    else:
        assert not any(z)
assert len(columns)==18 and all(sum(c[i]*c[j]/q for c,q in columns)==g[i][j] for i in range(54) for j in range(54))
print('54 rays, anchored core matches; PSD rank 18 by integral elimination and rational rank-one decomposition')

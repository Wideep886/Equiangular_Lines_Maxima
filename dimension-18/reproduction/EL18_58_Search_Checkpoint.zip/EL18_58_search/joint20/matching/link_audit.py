"""Verify triple counts independently and strict nesting of the retained rows."""
import sys
from itertools import combinations_with_replacement
from math import comb
from pathlib import Path
here=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here.parents[1]
words=list(combinations_with_replacement(range(4),4))
def read(path):
    rows=[tuple(map(int,line.split())) for line in path.read_text().splitlines()]
    assert len(rows)==len(set(rows))
    return set(rows)
a=read(root/'run12_recovery/pillar/link10.txt')
b=read(here/'link12.txt')
assert a < b and len(b-a)==3713
for row in b:
    *counts,triples=row
    assert len(counts)==35
    n=sum(counts)
    degrees=[sum(w) for w in words]
    twice_edges=sum(m*k for m,k in zip(counts,degrees))
    assert twice_edges%2==0
    wedges=sum(t*comb(k,2) for t,k in zip(counts,degrees))
    three_triangles=sum(t*sum(comb(j,2) for j in w) for t,w in zip(counts,words))
    assert 3*(comb(n,3)-(n-2)*(twice_edges//2)+wedges-triples)==three_triangles
print(len(a),len(b),len(b-a),'added distinct local rows; triple identities verified')

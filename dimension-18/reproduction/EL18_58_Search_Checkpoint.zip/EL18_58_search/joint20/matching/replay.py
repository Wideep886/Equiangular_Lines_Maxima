"""Exact rational matching certificates. Run inside EL18_58_search/run17/matching."""
import json
import sys
from fractions import Fraction as F
from pathlib import Path
from math import ceil, comb
here=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here.parents[1]
sys.path.insert(0,str(root/'run14/deletion'))
from final_anchors import rows, counts, no_triple_rows
from exact_weights import deletion_cap
A58,A59=rows(7)
path=here/'link12.txt'
links=[list(map(int,line.split())) for line in path.read_text().splitlines()]
pair_rows=[(r[:-1],r[-1]) for r in links]+[(r,0) for r in no_triple_rows()]
assert len(pair_rows)==6410
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
for cert in json.loads((here/'certificates.json').read_text()):
    A=A59 if cert["n"]==59 else A58
    alpha=F(cert["alpha"])
    n,X,w=cert['n'],cert['X'],cert['w']
    gamma=max(F(cert['scale']),F(deletion_cap(w),12))
    from exact_weights import WORDS
    grid=[8*int(word==(1,1,1,1)) for word in WORDS]
    def discount(h,d):
        if d==1: return 1
        return (8-48*alpha) if d==8 and list(h)==grid else 0
    g=max(dot(h,w)-gamma*(d-discount(h,d)) for h,d in pair_rows)
    lam=min((dot(h,w)-gamma*alpha*sum(counts(h)))/h[-1] for h in A)
    val=(30*X*lam-comb(n,2)*g)/(4*gamma)
    result=[str(f) for f in [gamma,g,lam,val]]+[ceil(val)]
    assert lam>0 and result==cert['expected']
    print(cert['label'],'gamma, g, lambda, matching fraction, ceiling',*result)

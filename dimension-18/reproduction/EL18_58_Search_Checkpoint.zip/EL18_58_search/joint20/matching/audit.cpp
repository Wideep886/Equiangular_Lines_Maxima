#include <algorithm>
#include <array>
#include <cassert>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
using Word=array<int,4>;
// Data are passed as already scaled integers. The proof uses no floating point.
int main(int argc,char** argv){
    assert(argc==4);ifstream in(argv[1]);
    int n,expected; long long gamma,g,lambda,flag_price,grid_discount;
    in>>n>>expected>>gamma>>g>>lambda>>flag_price>>grid_discount;
    array<long long,35> weight;for(auto& x:weight)in>>x;
    vector<Word> words;map<Word,int> index;
    for(int a=0;a<4;a++)for(int b=a;b<4;b++)for(int c=b;c<4;c++)for(int d=c;d<4;d++){
        Word word={a,b,c,d};index[word]=words.size();words.push_back(word);
    }
    array<long long,4> loss={0,-1000000000,-1000000000,-1000000000};
    for(auto word:words)for(int i=0;i<4;i++)if(word[i]){
        Word reduced=word;reduced[i]--;sort(reduced.begin(),reduced.end());
        loss[word[i]]=max(loss[word[i]],weight[index.at(word)]-weight[index.at(reduced)]);
    }
    for(auto w:words){
        long long upper=weight[index.at(w)];for(int v:w)upper+=v*loss[v];
        assert(upper<=12*gamma);
    }
    int nr=0;
    for(int f=2;f<=3;f++){
        ifstream stream(argv[f]);long long v;
        while(stream>>v){
            long long score=v*weight[0];int d=0,vertices=v,marks=0;
            for(int i=1;i<35;i++){stream>>v;score+=v*weight[i];vertices+=v; if(words[i]==Word{1,1,1,1})marks=v;}
            if(f==2)stream>>d;
            long long discount=d==1?gamma:((d==8 && vertices==8 && marks==8)?grid_discount:0);
            assert(score<=g+gamma*d-discount);nr++;
        }
    }
    assert(nr==6410);
    vector<int> splits;vector<Word> pairs;
    for(int i=0;i<64;i++)if((i&1)&&__builtin_popcount(i)==3)splits.push_back(i);
    for(int u=0;u<6;u++)for(int v=0;v<u;v++){
        int j=0;Word cols;
        for(int k=0;k<10;k++)if((((splits[k]>>u)^(splits[k]>>v))&1)==0)cols[j++]=k;
        assert(j==4);pairs.push_back(cols);
    }
    long long minimum=1LL<<60;int retained=0;
    set<array<int,36>> distinct;
    for(int code=0;code<(1<<20);code++){
        array<int,10> e,sizes;int E=0,cost=0;
        for(int j=0;j<10;j++){
            int k=(code>>(2*j))&3;e[j]=k;sizes[j]=3*k;E+=k;cost+=60/(k+2);
        }
        if(count(e.begin(),e.end(),0)<3||count(e.begin(),e.end(),3)>1||3*E>n-6)continue;
        for(int s=3*E;s<n-6;s++)++*min_element(sizes.begin(),sizes.end());
        int variance=(n-56)*(n-56);
        for(int size:sizes)variance+=8*(size-5)*(size-5);
        if(variance>(n==58?756:585))continue;
        array<int,36> h{};h[35]=cost;long long score=0;
        for(Word w:pairs){
            for(int& v:w)v=e[v];sort(w.begin(),w.end());
            int i=index.at(w);score+=weight[i];h[i]++;
        }
        long long slack=score-lambda*cost-flag_price*E;
        assert(slack>=0);minimum=min(minimum,slack);distinct.insert(h);retained++;
    }
    assert(distinct.size()==430&&minimum==0);
    int X=n==58?5780:6509;
    long long numerator=30LL*X*lambda-1LL*n*(n-1)/2*g;
    long long k=(numerator+4*gamma-1)/(4*gamma);
    assert(k==expected);
    cout<<n<<" lines, "<<retained<<" labelled, "<<distinct.size()<<" distinct, minimum integer slack "<<minimum<<", matching "<<k<<"\n";
}

"""Independent two-dimensional residual completion of the 30-ray aligned rook pair."""
from pathlib import Path
from itertools import product
from collections import Counter,defaultdict
from math import isqrt
import json,sys
here=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here.parents[1]
sys.path.insert(0,str(root/'run14/joins'))
from grid_glue import basis
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def color(graph,P):
    order=[];upper=[];i=0
    while P:
        q=P;i+=1
        while q:
            b=q&-q;v=b.bit_length()-1;order.append(v);upper.append(i);P^=b;q=(q^b)&~graph[v]
    return order,upper
def clique(graph):
    best=[];calls=0
    def go(P,R):
        nonlocal calls,best
        calls+=1
        if len(R)>len(best):best=R
        order,bound=color(graph,P)
        for v,b in zip(reversed(order),reversed(bound)):
            if len(R)+b<=len(best):return
            go(P&graph[v],R+[v]);P^=1<<v
    go((1<<len(graph))-1,[])
    assert all(graph[i]>>j&1 for k,i in enumerate(best) for j in best[k+1:])
    return len(best),calls
def squareclass(h):
    t=1;p=2
    while p*p<=h:
        while h%(p*p)==0:h//=p*p;t*=p
        p+=1
    return h,t
def main():
    G=json.loads((here/'rooks.json').read_text())['4'][0]['gram']
    J,T,D=basis(G,range(len(G)));assert len(J)==16
    sig=[];dots=[];height=[];n=len(G)
    cols=[[sum(G[i][j]*a for j,a in zip(J,row)) for row in T] for i in range(n) if i not in J]
    for tail in product((-1,1),repeat=15):
        s=(1,)+tail
        if any(abs(dot(r,s))!=D for r in cols):continue
        y=[dot(r,s) for r in T]
        h=5*D-dot(y,s)
        if h>=0:sig.append(s);dots.append(y);height.append(h)
    M=[[dot(y,t) for t in sig] for y in dots]
    print('core',n,'rank',len(J),'D',D,'outer height distribution',sorted(Counter(height).items()),flush=True)
    zero=[i for i,h in enumerate(height) if h==0]
    cells=list(product(range(4),repeat=2))
    outer=[x for x in cells if x[0]!=x[1]]
    # Mark a cell of each grid with a grid index, sharing both diagonal copies.
    keys=['p','q']+[(0,a,b) for a,b in cells]+[(1,a,b) for a,b in outer]
    def norm(z):
        return (0,z[1],z[2]) if isinstance(z,tuple) and z[1]==z[2] else z
    maps=[]
    for p in ((1,0,2,3),(0,2,1,3),(0,1,3,2)):
        maps.append([keys.index(norm((g,p[a],p[b]))) for g,a,b in keys[2:]])
    maps=[[0,1]+row for row in maps]
    maps+=[[1,0]+list(range(2,n))]
    for transform in (lambda g,a,b:(1-g,a,b),lambda g,a,b:(g,b,a) if g==0 else (g,a,b),lambda g,a,b:(g,b,a) if g==1 else (g,a,b)):
        maps.append([0,1]+[keys.index(norm(transform(g,a,b))) for g,a,b in keys[2:]])
    assert all(all(G[i][j]==G[p[i]][p[j]] for i in range(n) for j in range(n)) for p in maps)
    lookup={s:i for i,s in enumerate(sig)};full=[[dot(y,[G[i][j] for j in J])//D for i in range(n)] for y in dots]
    actions=[]
    for p in maps:
        act=[]
        for v in full:
            t=[v[p[j]] for j in J];t=tuple(z*t[0] for z in t);act.append(lookup[t])
        assert sorted(act)==list(range(len(sig)));actions.append(act)
    orbits={};seen=set()
    for i in range(len(sig)):
        if i in seen:continue
        orb=[i];seen.add(i)
        for j in orb:
            for action in actions:
                k=action[j]
                if k not in seen:seen.add(k);orb.append(k)
        orbits[i]=len(orb)
    print('actual signed-automorphism orbits',len(orbits),sorted(Counter(orbits.values()).items()),flush=True)
    counts=Counter();calls=0
    for i,norb in orbits.items():
        a=height[i]
        if not a:continue
        families=defaultdict(list);fixed=[]
        for j,b in enumerate(height):
            for sign in (-1,1):
                z=sign*D-M[i][j];q=a*b-z*z
                if q<0:continue
                if q==0:
                    fixed.append((j,z,0));continue
                p,t=squareclass(q);families[p].extend([(j,z,t),(j,z,-t)])
        best=0
        for p,more in list(families.items()) or [(1,[])]:
            vertices=more+fixed;graph=[0]*len(vertices)
            for v,(j,z,t) in enumerate(vertices):
                for u in range(v):
                    k,y,s=vertices[u]
                    if abs(a*M[j][k]+z*y+p*t*s)==a*D:
                        graph[v]|=1<<u;graph[u]|=1<<v
            sol,steps=clique(graph);best=max(best,sol);calls+=steps
        counts[n+1+best]+=norb
    print('anchored exact maxima',sorted(counts.items()),'clique nodes',calls,'no-anchor upper',n+len(zero),flush=True)
if __name__=='__main__':main()

"""Rebuild original HNF charts and inspect supports directly, independent of triple buckets."""
from collections import Counter
from itertools import combinations,permutations
from pathlib import Path
import json,sys
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
from radical_audit import kernel_images
from higher_walsh import embeddings
from walsh import independent
from sympy import Matrix

def min_type(G,S):
    # exact switching classification via triangle-product signature under permutations
    bits=[(i,j) for i in range(1,6) for j in range(i+1,6)]
    return min(sum((G[p[0]][p[i]]*G[p[0]][p[j]]*G[p[i]][p[j]]<0)<<h for h,(i,j) in enumerate(bits)) for p in permutations(S))
def canonical(i):
    W=[[5 if a==b else 1 for b in range(6)] for a in range(6)]
    for k,(a,b) in enumerate(combinations(range(1,6),2)):
        if i>>k&1:W[a][b]=W[b][a]=-1
    return min_type(W,tuple(range(6)))
assert [canonical(i) for i in [0,19,54,207,220,1023]]==[0,19,54,207,220,1023]
cases=json.load(open(sys.argv[2]));S=json.loads((root/'short.json').read_text());D=json.loads((root/'pair_cases.json').read_text())
idx={(z['ambient'],z['k'],z['index']):z for z in cases};checked=set()
for k,d in enumerate(S):
 if '4' in d['shell']:continue
 g=D[d['rep']]['gram'];n=len(g);ss=[1]+g[0][1:]
 G=[[a*ss[i]*ss[j] for j,a in enumerate(row)] for i,row in enumerate(g)]
 f,homs=kernel_images(g)
 N=[sum((x<0)<<j for j,x in enumerate(row)) for row in G];I=independent(N)
 base=[sum(int(row[j]<0)<<i for i,j in enumerate(I)) for row in G]
 # All lifts retain the base labels, so these lists are necessary for any ambient relation.
 b4=[(a,b,c,d) for a,b,c,d in combinations(range(n),4) if base[a]^base[b]^base[c]^base[d]==0]
 b6=[(a,b,c,d,e,v) for a,b,c,d,e,v in combinations(range(n),6) if base[a]^base[b]^base[c]^base[d]^base[e]^base[v]==0]
 types={T:min_type(G,T) for T in b6}
 for f1 in [14,16]:
  for num,axes in enumerate(embeddings(homs,(f1-f)//2)):
   key=(f1,k,num);z=idx[key];checked.add(key)
   assert tuple(z['basis'])==axes
   lifts=[sum(((a>>j)&1)<<i for i,a in enumerate(axes)) for j in range(n)]
   fours=[T for T in b4 if not (lifts[T[0]]^lifts[T[1]]^lifts[T[2]]^lifts[T[3]])]
   if fours:
    assert tuple(z['witness']) in fours and z['reason']=='four';continue
   H=Counter(c for (a,b,d,e,i,j),c in types.items() if not (lifts[a]^lifts[b]^lifts[d]^lifts[e]^lifts[i]^lifts[j]))
   assert {str(c):v for c,v in H.items()}==z['six']
   q={0:2,19:3,54:2,220:1}
   assert z['reason']==('207' if H[207] else ('mixed' if f1==16 and len({q[c] for c in H if c in q})>1 else 'retained'))
assert checked==set(idx)
print('PASS',len(checked),'original HNF charts; all local 4- and 6-subsets checked directly')

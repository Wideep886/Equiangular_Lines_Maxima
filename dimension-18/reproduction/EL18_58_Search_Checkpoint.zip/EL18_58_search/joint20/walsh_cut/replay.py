"""Audit lifted symplectic labels on the 41 fixed transversal join cores."""
from itertools import combinations,permutations
from collections import Counter,defaultdict
from fractions import Fraction as Q
from pathlib import Path
import json,sys,math

def bin_piv(rows):
    piv={};I=[]
    for i,z in enumerate(rows):
        while z and z.bit_length() in piv:z^=piv[z.bit_length()]
        if z:piv[z.bit_length()]=z;I.append(i)
    return I

def invert(A):
    n=len(A);Z=[[Q(x) for x in row]+[Q(i==j) for j in range(n)] for i,row in enumerate(A)]
    for j in range(n):
        k=next(i for i in range(j,n) if Z[i][j]);Z[j],Z[k]=Z[k],Z[j]
        t=Z[j][j];Z[j]=[x/t for x in Z[j]]
        for i in range(n):
            if i==j:continue
            t=Z[i][j];Z[i]=[a-t*b for a,b in zip(Z[i],Z[j])]
    return [r[n:] for r in Z]

def real_piv(G):
    R=[list(map(Q,row)) for row in G]
    I=[]
    for j in range(len(R)):
        if R[j][j]==0:
            assert not any(R[j][j:]);continue
        assert R[j][j]>0
        I.append(j)
        for k in range(j+1,len(R)):
            t=R[k][j]/R[j][j]
            for h in range(k,len(R)):
                R[k][h]-=t*R[j][h];R[h][k]=R[k][h]
    return I

def integer_rows(A):
    B=[row[:] for row in A];r=len(B[0])
    for j in range(r):
        for i in range(j+1,len(B)):
            while B[i][j]:
                m=B[j][j]//B[i][j];B[j]=[a-m*b for a,b in zip(B[j],B[i])];B[i],B[j]=B[j],B[i]
        assert B[j][j]!=0
        if B[j][j]<0:B[j]=[-v for v in B[j]]
    assert all(not any(row) for row in B[r:])
    return B[:r]

def homs(G,I):
    J=real_piv(G);A=[[r[j] for j in J] for r in G];H=integer_rows(A);Hinv=invert(H)
    A0=[[sum(x*y for x,y in zip(row,col)) for col in zip(*Hinv)] for row in A]
    assert all(v.denominator==1 for row in A0 for v in row)
    forms=[sum((int(v)%2)<<i for i,v in enumerate(col)) for col in zip(*A0)]
    bits={0}
    for v in forms:bits|={x^v for x in bits}
    assert len(bits)==2**len(J)
    restrict=sum(1<<i for i in [0]+I)
    return sorted(x for x in bits if not x&restrict)

def embed(images,t):
    seen={frozenset([0]):()}
    for _ in range(t):
        new={}
        for sub,basis in seen.items():
            for x in images:
                if x in sub:continue
                H=sub|{x^z for z in sub}
                if H not in seen and H not in new:new[H]=(*basis,x)
        seen.update(new)
    return sorted(seen.values(),key=lambda x:(len(x),x))

sixpairs=list(combinations(range(1,6),2))
def word(G,S):
    i=S[0]
    return sum((G[i][S[a]]*G[i][S[b]]*G[S[a]][S[b]]<0)<<k for k,(a,b) in enumerate(sixpairs))
CODES={}
for code in (0,19,54,207,220,1023):
    F=[[5 if i==j else 1 for j in range(6)] for i in range(6)]
    for k,(i,j) in enumerate(sixpairs):
        if code>>k&1:F[i][j]=F[j][i]=-1
    for W in permutations(range(6)):
        key=word(F,W);assert CODES.get(key,code)==code;CODES[key]=code
assert len(CODES)==64

def screen(G,L,amb):
    unique={}
    for a,b in combinations(range(len(L)),2):
        v=L[a]^L[b]
        if v in unique:return {'reason':'four','witness':sorted((*unique[v],a,b))}
        unique[v]=(a,b)
    assert len(set(L))==len(L)
    seen=defaultdict(list);hist=Counter();why={}
    for t in combinations(range(len(L)),3):
        v=L[t[0]]^L[t[1]]^L[t[2]]
        for prev in seen[v]:
            assert not set(prev)&set(t)
            S=tuple(sorted(t+prev))
            if t!=S[3:]:continue
            c=CODES[word(G,S)];hist[c]+=1;why.setdefault(c,S)
        seen[v].append(t)
    # Each six support contributes exactly its unique lexicographic first/last triple split.
    if 207 in why:return {'reason':'207','witness':why[207],'six':dict(hist)}
    if amb==16:
        keys=[c for c in (19,220,0,54) if c in why]
        q={19:3,220:1,0:2,54:2}
        for a,b in combinations(keys,2):
            if q[a]!=q[b]:return {'reason':'mixed','witness':[why[a],why[b]],'six':dict(hist)}
    return {'reason':'retained','six':dict(hist)}

def glue(G,labels):
    n=len(labels);width=max(labels).bit_length()
    piv={};words=[]
    for j,lab in enumerate(labels):
        x=lab|(1<<width);r=1<<j
        while x and x.bit_length() in piv:
            y,s=piv[x.bit_length()];x^=y;r^=s
        if x:piv[x.bit_length()]=(x,r)
        else:words.append(r)
    H=[]
    for r in words:
        a=[(r>>j)&1 for j in range(n)]
        w=sum(x*y for x,y in zip(a,G[0]))
        assert w%2==0
        a[0]-=2*((w//2)%2)
        col=[sum(x*y for x,y in zip(a,row)) for row in G]
        assert all(y%4==0 for y in col)
        H.append((a,col))
    def gram(r,s):
        t=sum(x*y for x,y in zip(H[r][0],H[s][1]));assert t%4==0
        return t//4
    m=len(words);q=[gram(i,i)%4 for i in range(m)]
    B=[sum((gram(i,j)%2)<<j for j in range(m)) for i in range(m)]
    rank=len(bin_piv(B));extra=0
    for v in range(1,1<<m):
        if any((v&row).bit_count()%2 for row in B):continue
        z=sum(q[i] for i in range(m) if v>>i&1)
        z+=2*sum((B[i]>>j)&1 for i,j in combinations(range(m),2) if v>>i&1 and v>>j&1)
        if z%4:
            assert z%4==2;extra=1;break
    return {'r':m,'b':rank,'extra':extra,'min':rank+extra,'words':words,'Q':q,'B':B}

def main(path,out):
    roots=json.loads((path/'short.json').read_text());data=json.loads((path/'pair_cases.json').read_text())
    logs=[]
    for k,case in enumerate(roots):
        if '4' in case['shell']:continue
        g=data[case['rep']]['gram'];o=[1,*g[0][1:]]
        G=[[v*o[i]*o[j] for j,v in enumerate(row)] for i,row in enumerate(g)]
        n=len(G);edges=[sum((v<0)<<j for j,v in enumerate(row)) for row in G]
        I=bin_piv(edges);f=len(I)
        ids=[sum(((r>>j)&1)<<i for i,j in enumerate(I)) for r in edges]
        images=homs(G,I)
        for ambient in [14,16]:
            if f>ambient:continue
            forms=embed(images,(ambient-f)//2)
            for index,basis in enumerate(forms):
                labels=[lab|sum(((v>>i)&1)<<(f+2*j) for j,v in enumerate(basis)) for i,lab in enumerate(ids)]
                if len(set(labels))<n:
                    dup=next((i,j) for i,j in combinations(range(n),2) if labels[i]==labels[j])
                    res={'reason':'two','witness':dup}
                else:res=screen(G,labels,ambient)
                res['glue']=glue(G,labels)
                logs.append(dict(k=k,f=f,ambient=ambient,index=index,basis=list(basis),**res))
    out.write_text(json.dumps(logs,separators=(',',':')))
    print(Counter((z['ambient'],z['reason']) for z in logs))
    for f in [14,16]:
        print('core ids with survivors',f,sorted(set(z['k'] for z in logs if z['ambient']==f and z['reason']=='retained')))
    print([[z['k'],z['index'],z['reason']] for z in logs if z['ambient']==14 and z['k'] in (6,26,29,32)])
if __name__=='__main__':main(Path(sys.argv[1]),Path(sys.argv[2]))

"""Recompute the rank-16 no-type-19 cut directly from the 20-point Gram charts."""
from collections import Counter
from itertools import combinations
from pathlib import Path
import json,sys

here=Path(__file__).resolve().parent
src=here.parent.parent/'run16'
cases=json.loads((here/'cases.json').read_text())
data=json.loads((src/'pair_cases.json').read_text())
cores=json.loads((src/'short.json').read_text())
charts=[r for r in cases if r['ambient']==16 and r['reason']=='retained']
assert len(charts)==84

def triangle_degrees(G,S):
    d={i:0 for i in S}
    for i,j,k in combinations(S,3):
        if G[i][j]*G[j][k]*G[k][i]<0:
            for v in (i,j,k):d[v]+=1
    return tuple(sorted(d.values()))

def root_gram(code):
    G=[[5 if i==j else 1 for j in range(6)] for i in range(6)]
    for n,(i,j) in enumerate(combinations(range(1,6),2)):
        if code>>n&1:G[i][j]=G[j][i]=-1
    return G

# Independent classification of all 64 root-normalized, locally radical sextets.
# The graph on the five nonroot vertices is Eulerian.
pool=Counter()
for code in range(1024):
    G=root_gram(code)
    if all(sum(x<0 for x in row)%2==0 for row in G):
        pool[triangle_degrees(G,range(6))]+=1
target=triangle_degrees(root_gram(19),range(6))
assert len(pool)==6 and pool[target]==20
assert all(triangle_degrees(root_gram(i),range(6))!=target for i in (0,54,207,220,1023))

def enum_core(k):
    G=data[cores[k]['rep']]['gram']
    orient=[1,*G[0][1:]]
    rows=[sum((x*orient[i]*orient[j]<0)<<j for j,x in enumerate(r)) for i,r in enumerate(G)]
    words=[]
    for a,b,c,d,e,f in combinations(range(len(rows)),6):
        if rows[a]^rows[b]^rows[c]^rows[d]^rows[e]^rows[f]:continue
        S=(a,b,c,d,e,f)
        if triangle_degrees(G,S)==target:words.append((S,sum(1<<v for v in S)))
    return words

cache={k:enum_core(k) for k in sorted({r['k'] for r in charts})}
new=[];live=[]
for r in charts:
    w=[s for s,mask in cache[r['k']] if all(bin(mask&t).count('1')%2==0 for t in r['basis'])]
    assert len(w)==r['six'].get('19',0)
    if w:new.append(dict(k=r['k'],index=r['index'],supports=w))
    else:live.append([r['k'],r['index']])
assert len(live)==80 and {k for k,i in live}=={r['k'] for r in charts}
out=dict(eligible=len(charts),removed=new,survivors=live,removed_complete_core_types=0)
s=json.dumps(out,separators=(',',':'))
if '--write' in sys.argv:(here/'no19.json').write_text(s)
else:assert (here/'no19.json').read_text()==s
print('PASS',len(new),[len(z['supports']) for z in new],len(live),'retained, all 41 core types represented')

from petal_payments import *
import numpy as np
from grid_glue import basis
G=json.loads(Path(sys.argv[3]).read_text())['4'][0]['gram']
assert psd(G)==16 and len(G)==30
I,T,d=basis(G,range(len(G)));r=len(I);G=np.array(G);S=np.ones((2**(r-1),r),dtype=np.int64);S[:,1:]=1-2*((np.arange(len(S))[:,None]>>np.arange(r-1))&1)
Y=S@T;h=5*d-(S*Y).sum(axis=1);C=Y@G[I];b=(h>=0)&(abs(C)==d).all(axis=1);S,Y,C,h=S[b],Y[b],C[b]//d,h[b]

H=Y@S.T
assert 0<=min(h)<=max(h)<4*d

p=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).with_name('petal25.in')
with p.open('w') as w:
 print(len(h),18-r,58-len(G),d,file=w)
 for row in -H:print(*row,file=w)
 for _ in h:print('3'*len(h),file=w)
print('bounds',len(h),r,d,h.min(),h.max(), Counter(h))

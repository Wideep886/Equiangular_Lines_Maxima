from shared_gridrow import *
from grid_flag24 import iso
classes=[];maps=[]
for g in sorted(census()[1]):
 for j,h in enumerate(classes):
  try:
   p,s=iso(g,h);break
  except ValueError:pass
 else:
  j=len(classes);classes.append(g);p=list(range(30));s=[1]*30
 maps.append((j,p,s))
print('classes',Counter(x[0] for x in maps))
Path(__file__).with_name('row_classes.json').write_text(json.dumps(dict(grams=classes,maps=maps),separators=(',',':')))

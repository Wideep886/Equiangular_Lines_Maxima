from petal_payments import *
import numpy as np
from grid_glue import basis
sys.path.insert(0,str(Path(sys.argv[1])/'run16'))
from root_cut import allowed,pair_cuts
shape=int(sys.argv[3]) if len(sys.argv)>3 else 0
cores=[G for centers in ((0,5,10),(0,4,9)) for G in build(centers)[1] if len(G)==25 and chart(G)[0]>=3]
assert len(cores)==3
G=cores[shape]
assert psd(G)==15
I,T,d=basis(G,range(len(G)));r=len(I);G=np.array(G);S=np.ones((2**(r-1),r),dtype=np.int64);S[:,1:]=1-2*((np.arange(len(S))[:,None]>>np.arange(r-1))&1)
Y=S@T;h=5*d-(S*Y).sum(axis=1);C=Y@G[I];b=(h>=0)&(abs(C)==d).all(axis=1);S,Y,C,h=S[b],Y[b],C[b]//d,h[b]
b,_=allowed(G,C);S,Y,C,h=S[b],Y[b],C[b],h[b]
B=pair_cuts(G,C);H=Y@S.T
assert 0<=min(h)<=max(h)<4*d
if shape==0: assert len(h)==466 and d==132
p=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).with_name('petal25.in')
with p.open('w') as w:
 print(len(h),18-r,58-len(G),d,file=w)
 for row in -H:print(*row,file=w)
 for row in (~B[0]).astype(int)+2*(~B[1]).astype(int):print(''.join(map(str,row)),file=w)
print('bounds',len(h),r,d,h.min(),h.max(), Counter(h))

"""All cross blocks of grids on common base and row, after the no-shared-flag theorem."""
from petal_triangle import *
def census():
 A=base();rows=range(3);cols=range(4);stats=Counter();grams=set()
 menus=[permutations_at(j) for j in cols]
 for selections in product(*menus):
  # Permute the three lines in each column to form the three right rows.
  # Simultaneous row permutation fixes the first column.
  for rest in product(permutations(range(3)),repeat=3):
   order=((0,1,2),)+rest
   points=[selections[j][order[j][i]] for i in rows for j in cols]
   if any(sum(points[4*i+j][k] for j in cols)!=-A[0][k]-A[1][k] for i in rows for k in range(18)):continue
   G=[z+[s[k] for s in points] for k,z in enumerate(A)]
   G += [s+A[6+i][6:] for i,s in enumerate(points)]
   r=psd(G);stats[r]+=1
   if 0<=r<=18:
    grams.add(tuple(tuple(row) for row in G))
 return stats,grams
if __name__=='__main__':
 s,g=census();print(s,len(g))

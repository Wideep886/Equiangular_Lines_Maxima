"""Glue three single-intersection external petals at distinct rows and columns of a grid."""
from itertools import permutations,combinations,product
from collections import Counter
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
# grid_flag24 expects project root in argv
from grid_flag24 import psd
def base():
 G=[[5,-1]+[-1]*16,[-1,5]+[-1]*16]
 for a,b in product(range(4), repeat=2):
  G.append([-1,-1]+[5 if (a,b)==(i,j) else (-1 if a==i or b==j else 1) for i,j in product(range(4),repeat=2)])
 return G
def permutations_at(cell):
 h,k=divmod(cell,4)
 # Each exterior point is negative at a 4x4 permutation containing (h,h).
 opts=[p for p in permutations(range(4)) if p[h]==k]
 return [[[-1,-1]+[-1 if p[i]==j else 1 for i,j in product(range(4),repeat=2)] for p in ps] for ps in combinations(opts,3) if all(len({p[i] for p in ps})==3 for i in range(4) if i!=h)]
def across(a,sa,b,sb):
 # Each petal has sum -(v0+v1); its three exterior points sum -(v0+v1)-g_aa.
 col=[2-x[2+a] for x in sb];row=[2-x[2+b] for x in sa]
 rv=[[(i,j,k) for i,j,k in product((-1,1,5),repeat=3) if i+j+k==t and all(v!=5 or sa[u]==sb[m] for m,v in enumerate((i,j,k)))] for u,t in enumerate(row)]
 return [z for z in product(*rv) if list(map(sum,zip(*z)))==col]
def build(centers=(0,5,10)):
 G=base();stats=Counter();records=[]
 for choices in product(*(permutations_at(i) for i in centers)):
  blocks=[across(centers[i],choices[i],centers[j],choices[j]) for i,j in combinations(range(3),2)]
  for cross in product(*blocks):
   K=[v.copy() for v in G];rays=sum(choices,[]);pairs={(0,1):cross[0],(0,2):cross[1],(1,2):cross[2]}
   for row in K:row.extend([0]*9)
   for u,s in enumerate(rays):
    a,i=divmod(u,3);d=s[:]
    for k,x in enumerate(s):K[k][18+u]=x
    for v in range(9):
     b,j=divmod(v,3)
     d.append((5 if i==j else -1) if a==b else pairs[a,b][i][j] if a<b else pairs[b,a][j][i])
    K.append(d)
   if any(K[i]!=K[j] for i,j in combinations(range(27),2) if K[i][j]==5):continue
   I=sorted({K.index(r) for r in K});K=[[K[i][j] for j in I] for i in I]
   r=psd(K)
   if not 0<=r<=18:continue
   stats[len(K),r]+=1;records.append(K)
 return stats,records
if __name__=='__main__':
 stats,c=build();print(stats,'total',len(c))
 Path(__file__).with_name('petal_census.json').write_text(json.dumps(c,separators=(',',':')))

from petal_payments import *
from grid_flag24 import iso
c=[g for centers in ((0,5,10),(0,4,9)) for g in build(centers)[1] if len(g)==25 and chart(g)[0]>=3]
for i,j in combinations(range(len(c)),2):
 try:
  p,s=iso(c[i],c[j]);print(i,j,'equal',p,s)
 except ValueError:
  print(i,j,'inequivalent')

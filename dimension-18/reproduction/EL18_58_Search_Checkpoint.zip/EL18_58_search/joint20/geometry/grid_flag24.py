"""Independent all-column gluing of two grids sharing a nine-ray flag, and signed equivalence lookup."""
from collections import Counter,defaultdict
from itertools import combinations,permutations,product
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import json,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'run14/joins'))
from grid_glue import basis

def flags(G):
 hs=[set(s) for s in combinations(range(18),6) if all(G[s[0]][i]*G[s[0]][j]*G[i][j]<0 for i,j in combinations(s[1:],2))]
 return sorted({tuple(sorted(tuple(sorted(t)) for t in [a&b,a-b,b-a])) for a,b in combinations(hs,2) if len(a&b)==3})

def charts(G,flag):
 outer=sorted(set(range(18))-set(sum(flag,())))
 keys={}
 for order in permutations(flag):
  for t in product(*(permutations(s) for s in order)):
   J=sum(t,());o=[1]+[-G[J[0]][j] for j in J[1:3]]+[G[J[0]][j] for j in J[3:]]
   groups=defaultdict(list)
   for x in outer:groups[tuple(G[x][J[0]]*G[x][j]*s for j,s in zip(J,o))].append(x)
   X=tuple(z for v in sorted(groups) for z in [v]*len(groups[v]))
   def key(R):return tuple(G[x][y]*G[x][J[0]]*G[y][J[0]] for x,y in combinations(R,2))
   R=min((sum(p,()) for p in product(*(permutations(groups[k]) for k in sorted(groups)))),key=key)
   k=(X,key(R))
   if k in keys:continue
   p=J+R;w=o+[G[x][J[0]] for x in R]
   M=tuple(tuple(G[x][y]*a*b for y,b in zip(p,w)) for x,a in zip(p,w))
   assert all(M[i][j]==(-1 if i//3==j//3 else 1) for i,j in combinations(range(9),2))
   keys[k]=M
 return keys

def allcols(G):
 I,T,d=basis(G,range(18));assert len(I)==11
 cols=defaultdict(list)
 for s in product((-1,1),repeat=len(I)-1):
  v=(1,)+s;y=[sum(a*b for a,b in zip(row,v)) for row in T]
  t=[sum(row[i]*a for i,a in zip(I,y)) for row in G]
  if all(abs(x)==d for x in t):
   c=tuple(x//d for x in t);cols[c[:9]].append(c)
 for j in range(9,18):
  c=G[j];assert c[0]==1;cols[c[:9]].append(c)
 return cols

def psd(G):
 a=[list(row) for row in G];r=0;old=1
 for i in range(len(a)):
  p=a[i][i]
  if p<0 or (p==0 and any(a[i][i+1:])):return -1
  if not p:continue
  for j in range(i+1,len(a)):
   for k in range(j,len(a)):
    t=p*a[j][k]-a[i][j]*a[i][k];assert t%old==0;a[j][k]=t//old
  old=p;r+=1
 return r

def glue(A,B,cols):
 I,T,d=basis(B,range(18));J=[i for i in I if i>=9];assert len(J)==4
 coeff=[[sum(B[i][v]*a for a,v in zip(row,I)) for row in T] for i in range(9,18)]
 result=[]
 for col in product(*(cols[B[i][:9]] for i in J)):
  fixed={v:A[v] for v in I if v<9};fixed.update(zip(J,col))
  rest=[[sum(a*fixed[v][i] for v,a in zip(I,row)) for i in range(18)] for row in coeff]
  if any(x not in (-d,d,5*d) for r in rest for x in r):continue
  C=[[x//d for x in r] for r in rest]
  whole=[list(A[i])+[r[i] for r in C] for i in range(18)]+[r+list(row[9:]) for r,row in zip(C,B[9:])]
  if any(whole[i]!=whole[j] for i,j in combinations(range(27),2) if whole[i][j]==5):continue
  M=list(dict.fromkeys(tuple(r) for r in whole))
  ind=[whole.index(list(r)) for r in M];g=[[whole[i][j] for j in ind] for i in ind]
  r=psd(g)
  if r>=0:result.append((r,g))
 return result

def iso(G,H):
 n=len(G);p=[0]*n
 def orient(g,u):
  sw=[1 if i==u else g[u][i] for i in range(n)]
  return [[v*sw[i]*sw[j] for j,v in enumerate(row)] for i,row in enumerate(g)],sw
 A,s=orient(G,0)
 for u in range(n):
  B,t=orient(H,u)
  def visit(c,d):
   while True:
    sa=[(c[i],tuple(sorted(c[j] for j in range(n) if A[i][j]<0))) for i in range(n)]
    sb=[(d[i],tuple(sorted(d[j] for j in range(n) if B[i][j]<0))) for i in range(n)]
    if Counter(sa)!=Counter(sb):return
    dic={v:j for j,v in enumerate(sorted(set(sa)))};cc=[dic[x] for x in sa];dd=[dic[x] for x in sb]
    if len(set(cc))==len(set(c)):c,d=cc,dd;break
    c,d=cc,dd
   if len(set(c))==n:
    p=[d.index(i) for i in c]
    return p if all(A[i][j]==B[p[i]][p[j]] for i,j in combinations(range(n),2)) else None
   i=min((i for i in range(n) if c.count(c[i])>1),key=lambda j:c.count(c[j]))
   for j in range(n):
    if d[j]!=c[i]:continue
    v=c[:];w=d[:];v[i]=w[j]=max(c)+1
    p=visit(v,w)
    if p:return p
  p=visit([int(i==0) for i in range(n)],[int(j==u) for j in range(n)])
  if p is not None:
   sw=[s[i]*t[j] for i,j in enumerate(p)]
   assert all(G[i][j]==sw[i]*sw[j]*H[p[i]][p[j]] for i in range(n) for j in range(n))
   return p,sw
 raise ValueError('inequivalent')

if __name__=='__main__':
 G=json.loads((root/'axis11/coredata/cores.json').read_text())['D1111']['shell_gram']
 target=json.loads((root/'run14/joins/grid_glue.json').read_text())[0]['gram']
 f=flags(G);marks=charts(G,f[0]);assert len(f)==16 and len(marks)==9 and all(set(charts(G,q))==set(marks) for q in f[1:])
 A=marks[min(marks)];cols=allcols(A);stat=Counter();maps=[]
 for j,key in enumerate(sorted(marks)):
  for r,g in glue(A,marks[key],cols):
   stat[len(g),r]+=1
   if len(g)==24:
    p,s=iso(g,target);maps.append(dict(chart=j,gram=g,permutation=p,signs=s))
 assert stat=={(27,15):78,(24,13):6,(18,11):1}
 print('flag supports',len(f),'ordered boundary charts',len(marks),'PSD (distinct rays, rank)',stat,'signed maps',len(maps))
 (Path(__file__).with_name('grid_flag24_maps.json')).write_text(json.dumps(maps,separators=(',',':')))

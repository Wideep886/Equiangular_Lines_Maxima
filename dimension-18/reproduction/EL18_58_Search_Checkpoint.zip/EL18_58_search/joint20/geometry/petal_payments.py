from petal_triangle import *
def chart(G):
 delpoint=2+5*3
 pool=set(range(2,len(G)))-{delpoint}
 H=[p for p in combinations(sorted(pool),4) if all(G[i][j]==-1 for i,j in combinations(p,2))]
 M=[frozenset(tr) for tr in combinations(range(len(H)),3) if all(set(H[i]).isdisjoint(H[j]) for i,j in combinations(tr,2))]
 def grid(tr):
  x,y,z=(H[j] for j in tr)
  mat=lambda a,b:[next(j for j,v in enumerate(b) if G[u][v]==-1) for u in a]
  xy,xz,yz=mat(x,y),mat(x,z),mat(y,z)
  return all(xz[i]==yz[xy[i]] for i in range(4))
 board=[frozenset(2+4*i+j for j in range(4)) for i in range(3)]+[frozenset(2+4*i+j for i in range(4)) for j in range(3)]
 bset={H.index(tuple(sorted(p))) for p in board}
 nongrid=[tr for tr in M if not grid(tr)]
 paid=[tr for tr in nongrid if len(tr & bset)==2 and all(tr==s or len(tr&s)<2 for s in nongrid)]
 slots={frozenset(tr&bset) for tr in paid}
 return len(slots),paid
if __name__=='__main__':
 s,c=build();h=Counter();print('input',s)
 for G in c:
  p,m=chart(G);h[len(G),psd(G),p]+=1
 print(h)

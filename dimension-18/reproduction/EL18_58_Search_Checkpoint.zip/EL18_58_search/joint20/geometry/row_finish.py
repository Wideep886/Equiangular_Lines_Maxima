"""Complete arbitrary 18-dimensional real extension of a codimension-one core."""
import json,sys
from pathlib import Path
from math import isqrt
from collections import Counter,defaultdict
import numpy as np
sys.path.insert(0,str(Path(sys.argv[1])/'run14/joins'))
from grid_glue import basis
def squarefree(x):
 p=2
 while p*p<=x:
  while x%(p*p)==0:x//=p*p
  p+=1
 return x
def max_clique(adj):
 best=[];nodes=0
 def go(chosen,mask):
  nonlocal best,nodes
  nodes+=1
  if len(chosen)>len(best):best=chosen[:]
  order=[];bound=[];rest=mask;num=0
  while rest:
   group=rest;num+=1
   while group:
    bit=group&-group;v=bit.bit_length()-1
    rest^=bit;group&=~(bit|adj[v]);order.append(v);bound.append(num)
  for v,b in reversed(list(zip(order,bound))):
   if len(chosen)+b<=len(best):break
   go(chosen+[v],mask&adj[v]);mask^=1<<v
 go([],(1<<len(adj))-1)
 return best,nodes
def test(g):
 I,T,d=basis(g,range(len(g)));r=len(I);assert r==17
 G=np.asarray(g,dtype=np.int64);S=np.ones((2**16,17),dtype=np.int64)
 S[:,1:]=1-2*((np.arange(2**16)[:,None]>>np.arange(16))&1)
 Y=S@T;h=5*d-(S*Y).sum(axis=1);C=Y@G[I]
 keep=(h>=0)&(abs(C)==d).all(axis=1);S,Y,h=S[keep],Y[keep],h[keep]
 H=Y@S.T;h=list(map(int,h))
 groups=defaultdict(list)
 for i,x in enumerate(h):
  if x:groups[squarefree(x)].extend([(i,1),(i,-1)])
 z=[(i,0) for i,x in enumerate(h) if not x]
 record=[]
 for sf in sorted(groups or {1:[]}):
  v=z+groups[sf];adj=[0]*len(v)
  for i,(a,eps) in enumerate(v):
   for j in range(i):
    b,eta=v[j];p=isqrt(h[a]*h[b]);assert p*p==h[a]*h[b]
    if abs(int(H[a,b])+eps*eta*p)==d:
     adj[i]|=1<<j;adj[j]|=1<<i
  m,n=max_clique(adj)
  record.append((sf,len(v),len(m),n))
 print('den',d,'heights',sorted(Counter(h).items()),'squareclasses (class,rays,clique,nodes)',record,'max total',len(g)+max([len(z) if not groups else 0]+[a[2] for a in record]))
 return max(a[2] for a in record)
if __name__=='__main__':
 c=json.loads(Path(__file__).with_name('row_classes.json').read_text())
 for g in c['grams']:
  assert test(g)<28

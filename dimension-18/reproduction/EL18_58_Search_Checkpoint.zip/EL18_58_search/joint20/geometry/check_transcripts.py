"""Verify complete old ternary logs against archived signatures without modifying them."""
import sys, json
from pathlib import Path
root=Path(sys.argv[1]).resolve()
logs=Path(sys.argv[2])
sys.path.insert(0,str(root/'run14/joins'))
from grid_ternary import read_case, marked_cases, input_data
old=json.loads((root/'run14/joins/grid_ternary.json').read_text())
for k,markinfo in enumerate(marked_cases()):
    mark,size,ok,steps,core=markinfo
    if not ok:continue
    data=input_data(core).encode()
    p=logs/f'case_{k:02}'
    assert p.with_suffix('.in').read_bytes()==data
    record=read_case(data,p.with_suffix('.out'),p.with_suffix('.err').read_text())
    record.update(orbit=size,core_size=len(core),mark=list(mark))
    assert record==old[0 if k==0 else 1]
    print(k,record['forms'],record['templates'],record['nodes'],record['output_sha256'])

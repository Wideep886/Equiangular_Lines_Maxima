from petal_payments import *
for centers in ((0,5,10),(0,4,9)):
 stats,grams=build(centers);h=Counter()
 for G in grams:
  n,marks=chart(G);h[len(G),psd(G),n]+=1
 print(centers,stats,h)

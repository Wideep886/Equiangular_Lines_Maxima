"""Evaluate the existing 35 integer weights at a different flag price exactly."""
import sys
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'run16'))
from certificate import *
z=json.loads((local/'weights.json').read_text())
w=z['w'];gamma=max(F(z['den']),F(deletion_cap(w),10))
A=rows();B=no_triple_rows()
E=[list(map(int,v.split())) for v in (here/'link10.txt').read_text().splitlines()]
for alpha in (F(1,12),F(17,192),F(3,32),F(5,48),F(1,8)):
    c=8-48*alpha
    def delta(row):
        if row[-1]==1:return 1
        if row[-1]==8 and sum(row[:-1])==8 and row[INDEX[(1,1,1,1)]]==8:return c
        return 0
    g=max([dot(v,w) for v in B]+[dot(v[:-1],w)-gamma*(v[-1]-delta(v)) for v in E])
    lam=min((dot(a,w)-alpha*gamma*cost(a))/a[-1] for a in A)
    cap=max(F(6),1+4*c/3)
    print(alpha, g,lam, (30*lam*5780-1653*g)/gamma, 'cap',cap, 'k>=',-(-((30*lam*5780-1653*g)/gamma)//cap))

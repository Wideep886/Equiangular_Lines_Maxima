"""Replay the geometry of the released checkpoint. Requires Python 3.10+, NumPy, C++17."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import os
import subprocess
import sys

here = Path(__file__).resolve().parent
root = here.parents[1]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")

def run(command):
    return subprocess.check_output(list(map(str, command)), cwd=here, env=env, text=True).strip()

def script(name, *args):
    return run([sys.executable, '-B', here/name, *args])

def verify_file(name, output):
    assert output == (here/name).read_text().strip(), name

def digest(file):
    return hashlib.sha256((here/file).read_bytes()).hexdigest()

with TemporaryDirectory() as temporary:
    temp = Path(temporary)
    h = digest('grid_flag24_maps.json')
    print(script('grid_flag24.py', root), flush=True)
    assert digest('grid_flag24_maps.json') == h
    for name, args in [('petal_placements', ()), ('petal_payments', (root,)), ('petal_partial', (root,)), ('petal_gram_equiv', (root,))]:
        verify_file(name+'.out', script(name+'.py', *args))
    print('付款四與五槽的全部安排、三外瓣321個標記與兩個末核已核對。', flush=True)
    before = digest('row_classes.json')
    print(script('row_classify.py', root), flush=True)
    assert digest('row_classes.json') == before
    verify_file('row_finish.out', script('row_finish.py', root))
    print('同基線共一瓣兩個30線實核最大54、41。', flush=True)
    exe = temp/'real_search'
    run([os.environ.get('CXX','c++'), '-O3', '-std=c++17', root/'run16/real_search.cpp', '-o', exe])
    rooks = root/'joint20/matching/rooks.json'
    for name, builder, arg in [
        ('petal25','petal25_input.py','0'),
        ('petal25_1','petal25_input.py','1'),
        ('petal25_2','petal25_input.py','2'),
        ('rook30','rook30_input.py',rooks),
        ('rook30_free','rook30_unconditional.py',rooks),
    ]:
        path = temp/(name+'.in')
        script(builder, root, path, arg)
        out = run([exe, path, 0, 10000000, 0])
        suffix = out[out.index(' first-positive '):]
        verify_file(name+'.out', path.name + suffix)
        print(name + suffix, flush=True)
    print('三個25線標記與兩種30線輸入全部完成。')

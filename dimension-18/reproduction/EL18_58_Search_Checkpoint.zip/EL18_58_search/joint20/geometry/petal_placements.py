"""Whole labelled six-slot coverage by three external petals, before any Gram search."""
from itertools import combinations,product
from collections import Counter

def partitions(n):
    labels=[0]
    def visit():
        if len(labels)==n:
            yield tuple(labels)
            return
        for t in range(2+max(labels)):
            labels.append(t)
            yield from visit()
            labels.pop()
    yield from visit()

# An active grid has complete rows/columns 0,1,2. The fourth row and column meet at its missing cell.
positions=[(i,j) for i,j in product(range(4),repeat=2) if (i,j)!=(3,3)]+[(-1,-1)]
def related(slot,p):
    axis,rest=divmod(slot,3)
    return p[axis] in set(range(3))-{rest}

def check():
    count=Counter()
    for k in (4,5):
        for paid in combinations(range(6),k):
            for mate in sorted(set(range(6))-set(paid)):
                appointments=paid+(mate,)
                for L in partitions(len(appointments)):
                    lab=range(max(L)+1);opts=[]
                    for t in lab:
                        allowed=[]
                        for p in positions:
                            if any(related(s,p) for s,label in zip(appointments,L) if label==t):continue
                            # A paying petal hits the sole remaining complete row/column.
                            if any(p[s//3]!=s%3 for i,s in enumerate(paid) if L[i]==t):continue
                            # Every other external petal must meet the payer's pair.
                            if any(not related(s,p) for i,s in enumerate(paid) if L[i]!=t):continue
                            allowed.append(p)
                        opts.append(allowed)
                    for points in product(*opts):
                        shapes=set()
                        for tri in combinations(lab,3):
                            if sum(t in tri for t in L[:-1])<3:continue
                            pos=[points[i] for i in tri]
                            if not all(x in range(3) for p in pos for x in p):continue
                            r,c=(len(set(v)) for v in zip(*pos))
                            if max(r,c)==3 and min(r,c)>=2:
                                shapes.add((max(r,c),min(r,c)))
                        assert shapes, (paid,mate,L,points)
                        count[k,tuple(sorted(shapes))]+=1
    return count
if __name__=='__main__':
    print(check())

"""Exact edge-charge caps and grid reconstructions over every single missing position."""
from fractions import Fraction as Q
from itertools import combinations
from math import ceil

rows = [frozenset(range(4*i, 4*i+4)) for i in range(4)]
cols = [frozenset(range(i, 16, 4)) for i in range(4)]
minimum = {}
for missing in [None, *range(16)]:
    for hit in [None, *range(16)]:
        pairs = set()
        for family in (rows, cols):
            usable = [p for p in family if missing not in p and hit not in p]
            pairs.update(frozenset(pair) for pair in combinations(usable, 2))
        key = missing is None
        minimum[key] = min(minimum.get(key, 12), len(pairs))
assert minimum == {True: 6, False: 2}
from_full = Q(4, minimum[True])
caps = {
    'full + ordinary': 4 + 1 + max(from_full, 2 * from_full),
    'incomplete + ordinary': 1 + max(5, 3, 2 * from_full),
    'ordinary + ordinary': 2 + max(3, 2 * from_full),
}
bound = Q(326613, 115) / max(caps.values())
assert max(caps.values()) == Q(19, 3) and ceil(bound) == 449
print('avoided petal pairs', minimum, 'charge caps', caps, 'k >=', bound, 'ceiling', ceil(bound))

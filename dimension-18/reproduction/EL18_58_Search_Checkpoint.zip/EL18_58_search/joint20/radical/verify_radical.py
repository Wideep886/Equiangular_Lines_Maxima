"""Exact checks for radical tetrads and Sidon bounds. No external libraries."""
from collections import Counter
from itertools import combinations, product
from math import comb


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def image(matrix, v):
    return [dot(row, v) for row in matrix]


def tetrads():
    pairs = list(combinations(range(4), 2))
    counts = Counter()
    for bits in product((0, 1), repeat=6):
        a = [[0]*4 for _ in range(4)]
        for (i, j), value in zip(pairs, bits):
            a[i][j] = a[j][i] = value
        if any(sum(row) % 2 for row in a):
            continue
        # Row zero switching normalizes while preserving the even word.
        first = a[0]
        assert sum(first) % 2 == 0
        a = [[a[i][j] ^ first[i] ^ first[j] for j in range(4)]
             for i in range(4)]
        minus = sum(map(sum, a)) == 6
        assert sum(map(sum, a)) in (0, 6)
        oriented = [-1, 1, 1, 1] if minus else [1]*4
        g = [[5 if i == j else oriented[i]*oriented[j]*(1-2*a[i][j])
              for j in range(4)] for i in range(4)]
        assert all(g[i][j] == (-1 if minus else 1)
                   for i, j in pairs)
        s = [1, 1, 1, 1] if minus else [1, 1, -1, -1]
        vals = image(g, s)
        outside = [x for x in product((-1, 1), repeat=4)
                   if (x.count(-1) % 2) == int(minus)]
        ip2 = vals + [dot(s, x) for x in outside]  # pairings of 2z
        assert dot(s, vals) == (8 if minus else 16)
        if minus:
            assert set(map(abs, ip2)) == {2}
        else:
            assert all(k % 4 == 0 for k in ip2)
        counts['negative' if minus else 'positive'] += 1
    assert counts == {'positive': 4, 'negative': 4}
    return dict(sorted(counts.items()))


def sidon():
    assert comb(58, 2) == 1653 > 2**10-1
    triples = comb(58, 3)
    rows = []
    for f in (12, 14, 16):
        bins = 2**f - 58
        q, r = divmod(triples, bins)
        collisions = (bins-r)*comb(q, 2) + r*comb(q+1, 2)
        rows.append((f, bins, q, r, collisions, (collisions+9)//10))
    assert [row[-1] for row in rows] == [10293, 1453, 0]
    return rows


def trace_bound():
    # Every eigenvalue of F-16I has absolute value <= sqrt(84)<37/4.
    # tr(S^3) = 22456 + sum t^3 > 22456-84*(37/4).
    lower = 22456 - 84*37//4
    assert lower == 21679
    # T=(6*C(58,3)-tr(S^3))/12 is an integer.
    max_triangles = (6*comb(58, 3)-lower-1)//12
    max_hexads = max_triangles//5
    assert (max_triangles,max_hexads) == (13621,2724)
    return max_triangles,max_hexads,10293-max_hexads


if __name__ == '__main__':
    print('Eulerian labelled tetrads:', tetrads())
    print('(f, bins, q, r, equal-sum triples, six-supports):', sidon())
    print('T_upper, H_upper, non-simplex_lower(f=12):', trace_bound())

def six_orbits():
    """Relabel each row-zero representative and normalize its first row."""
    from itertools import permutations
    pairs = list(combinations(range(6), 2))
    group = list(permutations(range(6)))
    six = Counter()
    for b in product((0, 1), repeat=6):
        a = [[0]*6 for _ in range(6)]
        for (i,j), bit in zip(combinations(range(1,5), 2), b):
            a[j][i] = a[i][j] = bit
        for i in range(1,5):
            a[i][5] = a[5][i] = sum(a[i]) % 2
        masks = []
        for p in group:
            r = p[0]
            masks.append(sum((a[p[i]][p[j]]^a[r][p[i]]^a[r][p[j]])<<k
                             for k,(i,j) in enumerate(pairs)))
        root = False
        for s in product((-1,1), repeat=6):
            g = [[5 if i==j else 1-2*a[i][j] for j in range(6)] for i in range(6)]
            # All outside patterns have an even number of minus signs.
            p = (3 + s.count(-1)) % 2
            if p == 0 and dot(s, image(g, s)) == 16:
                root = True
                break
        nneg = sum(((a[i][j]+a[i][k]+a[j][k])%2)
                   for i,j,k in combinations(range(6),3))
        six[min(masks),nneg,root] += 1
    assert dict(six) == {(0,0,False):1,(608,10,False):20,
                          (1728,8,False):15,(6624,12,True):15,
                          (7040,10,False):12,(32736,20,False):1}
    return sorted(six.items())

if __name__ == '__main__':
    print('(six-mask, negative triangles, new root), class size:', six_orbits())

def plane_types():
    from itertools import permutations
    v = (1,2,3,4,8,12)
    pairs = list(combinations(range(6),2))
    answer = {}
    for a,b in ((0,0),(0,1),(1,1)):
        masks = []
        for cross_rank in range(3):
            # First two coordinates span P, last two span P'.
            form = [(0,1,a), (2,3,b), (0,2,int(cross_rank>=1)),
                    (1,3,int(cross_rank==2))]
            def pairing(x,y):
                return sum(z*(((x>>i)&1)*((y>>j)&1)+((x>>j)&1)*((y>>i)&1))
                           for i,j,z in form)%2
            h = [[pairing(x,y) for y in v] for x in v]
            masks.append(min(sum((h[p[i]][p[j]]^h[p[0]][p[i]]^h[p[0]][p[j]])<<k
                                 for k,(i,j) in enumerate(pairs))
                             for p in permutations(range(6))))
        answer[a,b] = masks
    assert answer == {(0,0):[0,1728,6624],(0,1):[608,608,7040],
                      (1,1):[32736,6624,1728]}
    return answer

if __name__ == '__main__':
    print('symplectic plane types, cross-rank 0/1/2:', plane_types())

def tetrahedral_sizes():
    from itertools import combinations_with_replacement
    live = []
    for sizes in combinations_with_replacement(range(59),4):
        if sum(sizes) != 58:
            continue
        tr2_times9 = 58**2 + 8*sum(h*h for h in sizes)
        lower_times135 = 15*(tr2_times9 - 9*(32*58-768)) + 9*64
        if lower_times135 <= 135*84:
            live.append(sizes)
    assert len(live)==50 and min(t[0] for t in live)==9 and max(t[-1] for t in live)==20
    return len(live),min(t[0] for t in live),max(t[-1] for t in live)

if __name__ == '__main__':
    print('tetrahedral occupancy multisets, min, max:', tetrahedral_sizes())

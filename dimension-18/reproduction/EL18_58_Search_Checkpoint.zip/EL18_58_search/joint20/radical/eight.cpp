#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    constexpr int n = 8;
    std::array<int, 256> pop{};
    for (int s=1; s<256; ++s) pop[s]=1+pop[s&(s-1)];
    std::array<int,4> count{};
    std::array<int,15> index_i{}, index_j{};
    int k=0;
    for (int i=1; i<7; ++i) for (int j=i+1; j<7; ++j) {
        index_i[k]=i;
        index_j[k++]=j;
    }
    assert(k==15);
    for (int seed=0;seed<(1<<15);++seed) {
        std::array<int,n> adj{};
        for (int e=0;e<15;++e) if ((seed>>e)&1) {
            adj[index_i[e]] |= 1<<index_j[e];
            adj[index_j[e]] |= 1<<index_i[e];
        }
        for (int i=1;i<7;++i) if (pop[adj[i]]%2) {
            adj[i]|=128; adj[7]|=1<<i;
        }
        int flag=0;
        for (int s=0;s<256;s+=2) {
            const int p=(4+pop[s])%2;
            int twice_edges=0, core_sum=0;
            for (int i=0;i<n;++i) {
                int switched=adj[i]^s^(((s>>i)&1)?255:0);
                int d=pop[switched];
                twice_edges+=d;
                int k=(n+4-2*d)/2;
                core_sum+=k*k;
            }
            int norm=24-twice_edges/2;
            if (!p && norm==4) flag|=1;
            if (norm<0 || (norm==0 && core_sum+50*p>0) ||
                (norm>0 && core_sum+50*p>=26*norm)) flag|=2;
        }
        ++count[flag];
    }
    std::cout<<"Neither, root only, frame only, both: ";
    for (int v:count) std::cout<<v<<" ";
    std::cout<<"\n";
}

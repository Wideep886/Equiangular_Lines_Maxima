"""Replay the 462 cases using alternative label enumeration and row-separation checks."""
from fractions import Fraction
from itertools import combinations_with_replacement
import squareclasses as s

def evaluate(p,t):
    return sum(a*t**i for i,a in enumerate(reversed(p)))
def alg(p):
    a,b=0,0
    for c in p: a,b=b,5*a+c
    return a,b
def mul(p,q):
    ans=[0]*(len(p)+len(q)-1)
    for i,x in enumerate(p):
        for j,y in enumerate(q):ans[i+j]+=x*y
    return ans
def direct(i,j):
    h1,h2=s.deck[i],s.deck[j]
    h=mul(h1,h2)
    v=evaluate(h,1);r=s.isqrt(v)
    if r*r!=v:return set()
    out=set()
    # Coefficient of t² in p is 7−11+(S²)_ij/(2S_ij).
    for a in range(-32,25):
        for c in range(-s.isqrt(h[-1]),s.isqrt(h[-1])+1):
            for q1 in {r,-r}:
                p=(1,a,q1-1-a-c,c)
                diff=[u-v for u,v in zip(h,[0,0]+mul(p,p))]
                if any(z%4 for z in diff) or any(evaluate(diff,t)<0 for t in (-8,0)):continue
                u,v=alg(diff)
                if v>=0 and v*v>=5*u*u:out.add(p)
    return out
def checksquare(z):
    # Enumerate the two roots of the monic quadratic satisfied by k²,
    # for z=(h+k√5)². Work entirely with fractions.
    a,b=z
    n=b*b-5*a*a
    if b<0 or n<0 or s.isqrt(n)**2!=n:return False
    for sign in [1,-1]:
        k2=Fraction(b+sign*s.isqrt(n),10)
        h2=b-5*k2
        if k2<0 or h2<0:continue
        if all(s.isqrt(w.numerator)**2==w.numerator and s.isqrt(w.denominator)**2==w.denominator for w in (h2,k2)):
            return True
    return False

def span_mod(C,t,p):
    piv={}
    for v in [*C,t]:
        v=[x%p for x in v]
        for k,w in sorted(piv.items()):
            if v[k]:
                c=v[k];v=[(x-c*y)%p for x,y in zip(v,w)]
        k=next((i for i,x in enumerate(v) if x),None)
        if k is not None:
            c=pow(v[k],-1,p)
            piv[k]=[x*c%p for x in v]
    return k is None

def span_prime_power(C,T,p,e):
    from math import gcd
    mod=p**e
    A=[[x%mod for x in r] for r in zip(*C)]
    t=[x%mod for x in T]
    while A:
        d,i,j=min(((gcd(x,mod),i,j) for i,r in enumerate(A) for j,x in enumerate(r) if x),default=(mod,None,None))
        if i is None:return not any(t)
        A[0],A[i]=A[i],A[0];t[0],t[i]=t[i],t[0]
        if t[0]%d:return False
        c=pow(A[0][j]//d,-1,mod//d)
        for i in range(1,len(A)):
            h=(A[i][j]//d*c)%(mod//d)
            A[i]=[(x-h*y)%mod for k,(x,y) in enumerate(zip(A[i],A[0])) if k!=j]
            t[i]=(t[i]-h*t[0])%mod
        A=A[1:];t=t[1:]
    return True

def row(i,active,k):
    from itertools import combinations
    loc=(-2,-1,0,1)
    def column(j,p):
        w=[evaluate(p,t) for t in loc]
        return [1,*s.deck[j][3:],*w,*(x*x for x in w),*(w[a]*w[b] for a,b in combinations(range(4),2))]
    def prime(p,t):return evaluate([a*j for a,j in zip(p,range(len(p)-1,-1,-1))][:-1],t)
    d=s.deck[i]
    T=[57,*(x-y for x,y in zip(s.target[3:],d[3:]))]
    T += [(2*t+11)*evaluate(d,t)-4*evaluate(s.g,t) for t in loc]
    T += [2*(prime(s.g,t)*evaluate(d,t)-evaluate(s.g,t)*prime(d,t))-evaluate(d,t)**2 for t in loc]
    for a,b in combinations(loc,2):
        num=2*(evaluate(s.g,b)*evaluate(d,a)-evaluate(s.g,a)*evaluate(d,b))
        assert num%(b-a)==0
        T.append(num//(b-a)-evaluate(d,a)*evaluate(d,b))
    C=[column(j,p) for j in active for p in s.pairs.get(s.pair(i,j),[]) if s.types[s.pair(i,j),p] in (-1,k)]
    return C,T
def main():
    for i,j in combinations_with_replacement(s.ids,2):
        assert direct(i,j)==set(s.pairs.get((i,j),[]))
    for i,z in enumerate(s.reps):
        assert not any(checksquare(s.product(z,w)) for w in s.reps[:i])
    for (ij,p),k in s.types.items():
        z=s.minor(*ij,p)
        if k>=0:assert checksquare(s.product(z,s.reps[k]))
        else:assert z==(0,0)
    stats={}
    results=s.json.loads((s.HERE/'results.json').read_text())
    assert len(results)==len(s.reps)==462
    for k,rec in enumerate(results):
        active=s.ids[:]
        assert rec['label']==k and rec['rep']==list(s.reps[k])
        for removals in rec['rounds']:
            for i,c in removals:
                assert i in active
                C,T=row(i,active,k)
                if c=='empty':assert not C
                elif c=='lattice':
                    prime=next((p for p in (1009,3,5,7,11,13,17,19,23,29,31,41,2) if not span_mod(C,T,p)),None)
                    if prime is None:
                        assert not span_prime_power(C,T,2,32)
                    c='prime-power' if prime is None else 'modular'
                else:
                    y=c['y']
                    dot=lambda x:sum(v*w for v,w in zip(x,y))
                    assert c['kind']=='farkas' and len(y)==len(T) and dot(T)<0 and all(dot(col)>=0 for col in C)
                    c='Farkas'
                stats[c]=stats.get(c,0)+1
            active=[j for j in active if all(j!=i for i,_ in removals)]
        assert not active and not rec['types']
    print('Direct enumeration, square classes and row certificates agree:',stats)
if __name__=='__main__':main()

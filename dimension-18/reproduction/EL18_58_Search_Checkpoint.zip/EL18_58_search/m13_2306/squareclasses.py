"""Two-dimensional determinant square classes over Q(sqrt(5)) for m13 #2306."""
from pathlib import Path
from itertools import combinations
import sys,json
from math import isqrt
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'audit_layer'))
from polynomial13 import poly_types,rem,val,mul,lat,deriv,phase_one,possible
from lowmult import allowed_deck
fs=[([1,0],13),([1,-1],1),([1,0,-5],2)]
g,target,deck=allowed_deck([([1,8],40)]+fs)
ids=list(range(len(deck)))
assert len(deck)==18
_,_,pairs=poly_types({},fs,g,deck,ids)
def product(a,b):
    x,y=a;v,w=b
    return x*w+y*v,5*x*v+y*w
def square(a):
    x,y=a
    norm=y*y-5*x*x
    if norm<0 or y<0: return False
    n=isqrt(norm)
    if n*n!=norm:return False
    # Write x√5+y=(h+k√5)^2. Then 4h²=2(y±sqrt(norm)).
    # If h=0 the square is 5 times a rational square.
    if x==0:return isqrt(y)**2==y or isqrt(5*y)**2==5*y
    return any(d>0 and isqrt(d)**2==d for d in [2*(y+n),2*(y-n)])
def minor(i,j,q):
    x=product(rem(deck[i],[1,0,-5]),rem(deck[j],[1,0,-5]))
    r=rem(list(q),[1,0,-5]);y=product(r,r)
    return tuple(a-b for a,b in zip(x,y))
def pair(i,j):return (min(i,j),max(i,j))

types={}
reps=[]
for ij,pool in pairs.items():
    for q in pool:
        z=minor(*ij,q)
        if z==(0,0): k=-1
        else:
            k=next((c for c,h in enumerate(reps) if square(product(z,h))),None)
            if k is None:
                reps.append(z);k=len(reps)-1
        types[ij,q]=k
print('classes',len(reps),'labels',len(types),flush=True)
def chk(k):
    active=ids[:];zvals=(-2,-1,0,1)
    cols={j:(1,*deck[j][3:]) for j in ids}; b=(58,*target[3:])
    gv=[val(g,x) for x in zvals]
    gp=[val(deriv(g),x) for x in zvals]
    def checks(i):
        ds=[val(deck[i],x) for x in zvals]
        T=tuple(x-y for x,y in zip(b,cols[i]))+tuple((2*z+11)*a-4*c for z,a,c in zip(zvals,ds,gv))
        T+=tuple(2*(gp[l]*ds[l]-gv[l]*val(deriv(deck[i]),zvals[l]))-ds[l]**2 for l in range(4))
        T+=tuple(2*(gv[v]*ds[u]-gv[u]*ds[v])//(zvals[v]-zvals[u])-ds[u]*ds[v] for u,v in combinations(range(4),2))
        C=set()
        for j in active:
            ij=pair(i,j)
            for q in pairs.get(ij,[]):
                if types[ij,q] not in (-1,k):continue
                e=tuple(val(q,z) for z in zvals)
                C.add(cols[j]+e+tuple(s*s for s in e)+tuple(e[u]*e[v] for u,v in combinations(range(4),2)))
        return sorted(C),T
    rounds=[]
    while active:
        removed=[]
        reasons=[]
        for i in active:
            C,T=checks(i)
            if not C: reason='empty'
            elif not lat(C,T): reason='lattice'
            else:
                cert=phase_one(C,T)
                reason=None if cert['kind']=='primal' else cert
            if reason is not None:
                removed.append(i);reasons.append([i,reason])
        if not removed:break
        active=[i for i in active if i not in removed];rounds.append(reasons)
    if active and not possible([cols[j] for j in active],b):
        rounds.append([['global',sorted(active)]]);active=[]
    return dict(label=k,rep=reps[k],types=active,rounds=rounds)

if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(2) as ex:results=list(ex.map(chk,range(len(reps))))
    print([(row['rep'],row['types']) for row in results if row['types']])
    (HERE/'results.json').write_text(json.dumps(results))

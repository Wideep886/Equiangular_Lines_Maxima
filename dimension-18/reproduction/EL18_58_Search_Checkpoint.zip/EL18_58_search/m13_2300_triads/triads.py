"""Ternary sign support refinement for surviving vertex pair states of #2300."""
import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'m13_decorations'))
import triangles as tr
from triangles import load,red,gpoly,pol,inv,trace,times
def main():
 k=2300
 f,_,d,_,op,_=load(k);g=gpoly(f)
 info,=json.load(open(tr.HERE/'triangles_2300.json'))
 raw=next(x for x in json.load(open(tr.HERE/'patterns_2300.json')) if x['deck']==info['deck'])
 ps=[[tuple(raw['patterns'][a][u]) for u in ids] for a,ids in enumerate(info['surviving_indices'])]
 I,ns=zip(*info['deck']);N=len(I);ref=I[0]
 h=red(d[ref],f);c=times(times([2,16,0],inv(pol.deriv(g),f),f),inv(h,f),f)
 R=[h]+[red(op[ref,j][0],f) for j in I[1:]]
 H=[[int(trace(times(c,times(x,y,f),f),f)) for y in R] for x in R]
 # Global state index for a vertex's type and row pattern.
 states=[(a,p) for a,rows in enumerate(ps) for p in rows]
 V=len(states); live=(1<<V)-1
 typem=[sum(1<<v for v,(t,_) in enumerate(states) if t==a) for a in range(N)]
 third_capacity={(a,i,j):sum(1<<u for u,(t,p) in enumerate(states) if p[a]>=i+j and ns[a]-(a==t)-p[a]>=2-i-j) for a in range(N) for i in (0,1) for j in (0,1)}
 data={}
 for u,(a,p) in enumerate(states):
    for v,(b,q) in enumerate(states[:u+1]):
        if a==b and ns[a]<2:continue
        for e in (0,1):
            s=2*e-1
            if not(0<=p[b]-e<=ns[b]-1-(a==b) and 0<=q[a]-e<=ns[a]-1-(a==b)):continue
            nh=tuple(n-(t==a)-(t==b) for t,n in enumerate(ns))
            ph=tuple(x-e*(t==b) for t,x in enumerate(p));qh=tuple(x-e*(t==a) for t,x in enumerate(q))
            num=H[a][b]+6*s-56+2*(sum(ph)+sum(qh))
            if num%4:continue
            goal=num//4
            base=[(max(0,x+y-n),min(x,y)) for x,y,n in zip(ph,qh,nh)]
            if sum(x for x,y in base)<=goal<=sum(y for x,y in base):
                data[u,v,e]=(goal,nh,ph,qh,base)
 def count():return [bin(live&m).count('1') for m in typem]
 rounds=[(len(data),count())]
 while True:
    adj=[[0,0] for _ in states]
    for u,v,e in data:
        adj[u][e]|=1<<v;adj[v][e]|=1<<u
    nxt=live
    for u,(a,p) in enumerate(states):
        if not (live>>u&1):continue
        if any(needs and not (adj[u][e]&typem[t]&live) for t in range(N) for e,needs in ((1,p[t]),(0,ns[t]-(t==a)-p[t]))):
            nxt^=1<<u
    changed=(nxt!=live);live=nxt
    failed=[]
    for key,(goal,ns2,ph,qh,base) in data.items():
        u,v,e=key
        if not ((live>>u)&(live>>v)&1):failed.append(key);continue
        # Which third states simultaneously permit both incident signs?
        common=[(adj[u][i]&adj[v][j]&live) for i,j in ((0,0),(0,1),(1,0),(1,1))]
        if states[u][0]==states[v][0]:
            a0=states[u][0];common=[m&third_capacity[a0,i,j] for m,(i,j) in zip(common,((0,0),(0,1),(1,0),(1,1)))]
        lo=hi=0
        for t,((a,b),n,x,y) in enumerate(zip(base,ns2,ph,qh)):
            # Intersection g determines counts of each of --,-+,+-,++ in this type.
            # If an incident sign pair has no common compatible state, its count is zero.
            for M,w in zip(common,(x+y-n,y,x,0)):
                if not M&typem[t]:a=max(a,w);b=min(b,w)
            if a>b:break
            lo+=a;hi+=b
        else:
            if lo<=goal<=hi:continue
        failed.append(key)
    for key in failed:del data[key]
    if not changed and not failed:break
    rounds.append((len(data),count()))
 result=dict(profile=k,deck=info['deck'],initial_pattern_ids=info['surviving_indices'],states=len(states),rounds=rounds,
             retained_state_ids=[u for u in range(V) if live>>u&1],
             retained_pairs=list(data))
 (HERE/'triads2300.json').write_text(json.dumps(result,separators=(',',':')))
 print(rounds)
if __name__=='__main__':main()

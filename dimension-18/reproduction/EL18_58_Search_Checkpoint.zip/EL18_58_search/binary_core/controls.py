"""Integer 2-saturation and complete small-weight codeword distribution for a given Gram."""
import sys,json,math
from itertools import combinations
from collections import defaultdict,Counter
def paritycheck(G):
 n=len(G);A=[r[:] for r in G];p=1;I=[]
 for i in range(n):
  d=A[i][i]
  if not d:continue
  assert d>0;I.append(i)
  for j in range(i+1,n):
   for k in range(j,n):
    q,r=divmod(d*A[j][k]-A[j][i]*A[i][k],p);assert not r;A[j][k]=A[k][j]=q
  p=d
 M=[G[i][:] for i in I];r=len(M);divisions=0
 while True:
  row=0
  for col in range(n):
   j=next((j for j in range(row,r) if M[j][col]%2),None)
   if j is None:continue
   M[j],M[row]=M[row],M[j]
   for j in range(row+1,r):
    if M[j][col]%2:M[j]=[x-y for x,y in zip(M[j],M[row])]
   row+=1
  if row==r:break
  for j in range(row,r):
   assert all(x%2==0 for x in M[j])
   M[j]=[x//2 for x in M[j]];divisions+=1
 return [sum((x%2)<<i for i,x in enumerate(c)) for c in zip(*M)],divisions
def inspect(G):
 n=len(G);cols,divisions=paritycheck(G)
 W=defaultdict(list);counts=Counter();masks=[1<<i for i in range(n)]
 for a,b,c,d in combinations(range(n),4):
  key=cols[a]^cols[b]^cols[c]^cols[d]
  low=masks[a]|masks[b]|masks[c]|masks[d]
  for prev in W[key]:counts[prev^low]+=1
  W[key].append(low)
 tally=Counter()
 for code,num in counts.items():
  h=bin(code).count('1')
  assert h in (4,6,8) and num==math.comb(h,h//2)//2*math.comb(n-h,4-h//2)
  tally[h]+=1
 print(n,divisions,tally,flush=True)
 for h in sorted(tally):
  code=next(code for code in counts if bin(code).count('1')==h)
  I=[i for i in range(n) if code>>i&1]
  p=I[0]
  assert all(sum(G[p][i]*G[p][j]*G[i][j]==-1 for i in I if i!=p)%2==0 for j in range(n) if j not in I)
  print(h,I,flush=True)
if __name__=='__main__':
 from pathlib import Path
 here=Path(__file__).resolve().parent
 for fn in (sys.argv[1:] or [here/'control_other_57.json',here.parent/'control_57.json']):
  print(Path(fn).name,flush=True);inspect(json.load(open(fn)))

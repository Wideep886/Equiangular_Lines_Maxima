// Independent exhaustive verification of local binary circuit support templates.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;
using M=array<array<int,8>,8>;
struct Template {int h,code,rank,orbit; bool rootless;};
const Template reps[]={
    {4,0,4,1,false}, {6,860,6,15,false},{6,1023,5,1,true},
    {8,0,8,1,true},{8,17411,8,210,false},{8,671853,8,2520,false},
    {8,1722641,8,3360,false},{8,679311,7,105,true},{8,1202677,8,1260,false}
};
int unpack_position[8][8];
M matrix_from_bits(int h,int bits){
    M G{};
    for(int i=0;i<h;i++)for(int j=0;j<h;j++){
        int pos=unpack_position[i][j];
        G[i][j]=i==j?5:(pos<0||!(bits&(1<<pos))?1:-1);
    }
    return G;
}
// Fraction-free elimination, with a PSD zero-pivot test.
int psd_rank(const M& G,int h){
    long long q[8][8]={};for(int i=0;i<h;i++)for(int j=0;j<h;j++)q[i][j]=G[i][j];
    long long last=1; int r=0;
    for(int i=0;i<h;i++){
        long long v=q[i][i];
        if(v<0)return -1;
        if(v==0){
            for(int j=i+1;j<h;j++)if(q[i][j]!=0)return -1;
        }else{
            r++;
            for(int j=i+1;j<h;j++)for(int k=j;k<h;k++){
                __int128 d=(__int128)v*q[j][k]-(__int128)q[j][i]*q[i][k];
                assert(d%last==0 && abs((long long)(d/last))<10000000);
                q[k][j]=q[j][k]=(long long)(d/last);
            }
            last=v;
        }
    }
    return r;
}
void verify(int h){
    int edges=0;for(auto & row:unpack_position)fill(row,row+8,-1);
    for(int i=1;i<h;i++)for(int j=i+1;j<h;j++)unpack_position[i][j]=unpack_position[j][i]=edges++;
    vector<int> labels(1<<edges,-1);
    for(int id=0;id<9;id++)if(reps[id].h==h){
        auto T=matrix_from_bits(h,reps[id].code);assert(psd_rank(T,h)==reps[id].rank);
        vector<int> pi(h);iota(pi.begin(),pi.end(),0);
        do{
            int bits=0;
            for(int i=1;i<h;i++)for(int j=i+1;j<h;j++)
                if(T[pi[0]][pi[i]]*T[pi[0]][pi[j]]*T[pi[i]][pi[j]]<0)bits|=1<<unpack_position[i][j];
            assert(labels[bits]<0||labels[bits]==id);labels[bits]=id;
        }while(next_permutation(pi.begin(),pi.end()));
    }
    int counted[9]={};int rootless_count=0;
    for(int g=0;g<1<<edges;g++){
        auto T=matrix_from_bits(h,g);
        int row0=h+4,total=0;bool discard=false;
        for(int i=0;i<h;i++){
            int sum=accumulate(T[i].begin(),T[i].begin()+h,0);
            if((sum-row0)%4!=0){discard=true;break;}
            total+=sum;
        }
        if(discard||total%4||((total/4)%4)!=(row0/2%2)){assert(labels[g]<0);continue;}
        bool norm4=false;
        for(int bits=0;bits<(1<<(h-1));bits++){
            int s[8]={1};
            for(int i=1;i<h;i++)s[i]=(bits&(1<<(i-1)))?-1:1;
            int sq=0;
            for(int i=0;i<h;i++)for(int j=0;j<h;j++)sq+=s[i]*s[j]*T[i][j];
            assert(sq%4==0 && (sq%16==0||sq%16==4));
            if(sq==4){discard=true;break;}
            if(sq==16)norm4=true;
        }
        if(discard){assert(labels[g]<0);continue;}
        int r=psd_rank(T,h);
        if(r<0){assert(labels[g]<0);continue;}
        int id=labels[g];assert(id>=0 && reps[id].rank==r && reps[id].rootless==!norm4);
        counted[id]++;
    }
    for(int id=0;id<9;id++)if(reps[id].h==h){
        assert(counted[id]==reps[id].orbit);
        rootless_count+=int(reps[id].rootless);
        cout<<h<<" "<<reps[id].code<<" "<<reps[id].rank<<" "<<counted[id]<<" "<<int(reps[id].rootless)<<"\n";
    }
    assert(rootless_count==(h-4)/2);
}
int main(){for(int h:{4,6,8})verify(h);}

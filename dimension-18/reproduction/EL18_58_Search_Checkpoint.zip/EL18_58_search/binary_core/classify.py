from pathlib import Path
import itertools,math,collections,json
from fractions import Fraction
def go(k):
 edges=list(itertools.combinations(range(1,k),2)); ep={p:i for i,p in enumerate(edges)}
 def edge(i,j):
  if i==0 or j==0 or i==j:return 0
  return 1<<ep[tuple(sorted((i,j)))]
 transforms=[]
 for x in range(k-1):
  pi=list(range(k));pi[x],pi[x+1]=pi[x+1],pi[x]
  transforms.append([edge(pi[i],pi[j])^edge(pi[0],pi[i])^edge(pi[0],pi[j]) for i,j in edges])
 def move(c,a):return sum((bin(c&x).count("1")%2)<<i for i,x in enumerate(a))
 def canon_orbit(c):
  seen={c};q=[c]
  while q:
   i=q.pop()
   for t in transforms:
    j=move(i,t)
    if j not in seen:seen.add(j);q.append(j)
  return seen
 def gram(c):
  return [[5 if i==j else 1-2*bool(c&edge(i,j)) for j in range(k)] for i in range(k)]
 def rank(K):
  V=[[Fraction(x) for x in s] for s in K];r=0
  for i in range(k):
   d=V[i][i]
   if d<0 or (d==0 and any(V[i][i:])):return -1
   if d==0:continue
   r+=1
   for j in range(i+1,k):
    for l in range(j,k):V[j][l]=V[l][j]=V[j][l]-V[i][j]*V[i][l]/d
  return r
 visited=set();recs=[]
 for bits in range(1<<math.comb(k-2,2)):
  c=0;deg=[0]*k
  for ix,(i,j) in enumerate(itertools.combinations(range(1,k-1),2)):
   if bits>>ix&1:c|=edge(i,j);deg[i]+=1;deg[j]+=1
  for i in range(1,k-1):
   if deg[i]%2:c|=edge(i,k-1)
  if c in visited:continue
  E=bin(c).count("1");norm=k*(k+4)//4-E
  if norm%4!=(k//2)%2:continue
  T=canon_orbit(c);visited.update(T)
  K=gram(c);r=rank(K)
  if r<0:continue
  rootless=True;extra=set();found4=False;short={}
  for tail in itertools.product([1,-1],repeat=k-1):
   ss=(1,)+tail;w=tuple(sum(x*y for x,y in zip(row,ss)) for row in K)
   assert sum(x*y for x,y in zip(w,ss))%4==0
   n=sum(x*y for x,y in zip(w,ss))//4
   assert n%4 in (0,1)
   if n==1:break
   found4|=n==4
   if n==5 and all(abs(z)!=10 for z in w):extra.add(min(w,tuple(-x for x in w)))
   short[n]=short.get(n,0)+1
  else:
   recs.append(dict(k=k,code=c,rank=r,hist=short,orbit=len(T),extra=len(extra),rootless=not found4 and len(extra)<=1))
 print(k,len(recs),sum(r['orbit'] for r in recs),sum(r['rootless'] for r in recs),collections.Counter((r['rank'],r['rootless']) for r in recs),flush=True)
 return recs
if __name__=='__main__':
 data=sum([go(k) for k in [4,6,8]],[]);open(Path(__file__).with_name('templates.json'),'w').write(json.dumps(data))

from pathlib import Path
import json
from fractions import Fraction
from itertools import combinations,product
g=json.load(open(Path(__file__).with_name('templates.json')))
for a in g:
 h=a['k'];c=a['code'];es=list(combinations(range(1,h),2));ix={e:j for j,e in enumerate(es)}
 def val(i,j):
  if i==j:return 5
  if min(i,j)==0:return 1
  return 1-2*((c>>ix[tuple(sorted((i,j)))])&1)
 K=[[val(i,j) for j in range(h)] for i in range(h)]
 counts=0;qs={}
 for v in product((-1,1),repeat=h-1):
  s=(1,)+v
  if sum(t==-1 for t in s)%2:continue
  B=[[Fraction(t) for t in row]+[Fraction(z)] for row,z in zip(K,s)]
  piv=[]
  for col in range(h):
   i=len(piv);j=next((j for j in range(i,h) if B[j][col]!=0),None)
   if j is None:continue
   B[i],B[j]=B[j],B[i];q=B[i][col];B[i]=[x/q for x in B[i]]
   for j in range(h):
    if j!=i:
     q=B[j][col];B[j]=[x-q*y for x,y in zip(B[j],B[i])]
   piv.append(col)
  if any(row[-1] for row in B[len(piv):]):continue
  z=sum(s[j]*B[i][-1] for i,j in enumerate(piv))
  if z<=5:counts+=1;qs[str(z)]=1+qs.get(str(z),0)
 print(h,c,counts,qs)

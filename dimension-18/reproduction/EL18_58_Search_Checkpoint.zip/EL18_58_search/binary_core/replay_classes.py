from pathlib import Path
"""Exhaust the rooted Euler graphs by shifting the root and traversing permutations independently."""
from itertools import combinations,permutations
import json,math
from functools import reduce
from operator import xor
rows=json.load(open(Path(__file__).with_name('templates.json')))
rows.append({'k':8,'code':1759697,'orbit':None})
for n in (4,6,8):
 edges=list(combinations(range(1,n),2));lab={p:i for i,p in enumerate(edges)}
 def at(c,u,v):return c>>lab[tuple(sorted((u,v)))]&1 if u and v and u!=v else 0
 tables=[]
 for row in (r for r in rows if r['k']==n):
  c=row['code']; orbit=set();G=[[at(c,i,j) for j in range(n)] for i in range(n)]
  for pi in permutations(range(n)):
   rt=G[pi[0]]
   orbit.add(sum((G[pi[i]][pi[j]]^rt[pi[i]]^rt[pi[j]])<<k for k,(i,j) in enumerate(edges)))
  assert all(orbit.isdisjoint(o) for o in tables) and (not row['orbit'] or len(orbit)==row['orbit'])
  if not row['orbit']:
   e=(1,1,-1,-1,-1,-1,1,-1)
   assert 5*n+2*sum((1-2*G[i][j])*e[i]*e[j] for i,j in combinations(range(n),2))==4
   print('rejected by squared norm 1:',len(orbit),flush=True)
  tables.append(orbit)
 seen=set().union(*tables);labcount=0
 masks=[sum(1<<k for k,e in enumerate(edges) if i in e) for i in range(1,n)]
 for c in range(1<<len(edges)):
  if (n*(n+4)//4-bin(c).count('1'))%4!=n//2%2:continue
  if any(bin(c&mask).count('1')%2 for mask in masks):continue
  labcount+=1
  assert c in seen
 assert labcount==len(seen)
 print(n,len(tables),len(seen),flush=True)

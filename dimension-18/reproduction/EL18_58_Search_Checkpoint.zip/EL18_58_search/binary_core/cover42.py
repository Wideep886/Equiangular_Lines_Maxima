"""Exact MacWilliams obstruction and syndrome-collision bound. Standard Python only."""
from math import comb
def choose(n,k):
    return comb(n,k) if 0<=k<=n else 0
def krawtchouk(n,j,h):
    return sum((-1)**i*choose(h,i)*choose(n-h,j-i) for i in range(j+1))
def dot(a,b):
    assert len(a)==len(b)
    return sum(x*y for x,y in zip(a,b))
def main():
    n=42
    y=(-363825,-252252,-150150,-100100,-54600,-34650,-16632,-9900,-3850,-2100,-525,-252,0,0,0,0,-7,0,0,0,0,-1)
    rhs=(2**24-1,*(-comb(n,j) for j in range(1,22)))
    residue=[dot(y,tuple(krawtchouk(n,j,h) for j in range(22))) for h in range(10,n+1,2)]
    assert min(residue)>=0 and max(y[1:])<=0 and dot(y,rhs)<0
    print('parent weights 10,12,...,42:',residue,'target',dot(y,rhs))
    y58=(-29343600,-21902400,-16110900,-11738925,-8401536,-5948800,-4118400,-2816775,
         -1871100,-1226016,-772200,-479050,-280800,-162000,-85536,-44550,-19800,-8800,
         -2700,-891,0,0,0,-25,-36,0,0,0,0,-8)
    values=[dot(y58,tuple(krawtchouk(58,j,h) for j in range(30))) for h in range(0,59,2)]
    d=52776558133248
    rhs58=(2**40-1,*(-comb(58,j) for j in range(1,30)))
    assert max(y58[1:])<=0 and min(values[5:])>=0
    assert [-v for v in values[2:5]]==[d*t for t in (4664,510,30)]
    assert dot(y58,rhs58)==-432745*d
    print('length-58 cut verified: 4664 A4 + 510 A6 + 30 A8 >= 432745')
    N=comb(58,4)
    for b in [2**17,2**17-1-comb(58,2)]:
        q,r=divmod(N,b)
        print('buckets',b,'pair bound',b*comb(q,2)+r*q)
if __name__=='__main__':main()

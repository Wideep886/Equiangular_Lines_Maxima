"""Even row/column cross blocks with weight divisible by 4; classify the (4,4) blocks."""
from itertools import permutations,product
from collections import defaultdict
from math import comb
from pathlib import Path
import json
def cross_count(a,b):
    even=[x for x in range(1<<b) if bin(x).count('1')%2==0]
    states={(0,0):1}
    for _ in range(a):
        nxt=defaultdict(int)
        for (xor,w),c in states.items():
            for x in even:nxt[xor^x,(w+bin(x).count('1'))%4]+=c
        states=nxt
    assert states[0,0]+states.get((0,2),0)==2**((a-1)*(b-1))
    return states[0,0]
def four_four():
    even=[i for i in range(16) if bin(i).count('1')%2==0]
    pool=set()
    for a,b,c in product(even,repeat=3):
        r=(a,b,c,a^b^c)
        if sum(bin(v).count('1') for v in r)%4==0:pool.add(tuple(sorted(r)))
    def move(x,p):return sum(((x>>i)&1)<<j for j,i in enumerate(p))
    def trans(rows):return tuple(sum(((u>>j)&1)<<i for i,u in enumerate(rows)) for j in range(4))
    reps=set()
    for rows in pool:
        reps.add(min(tuple(sorted(move(x,p)^s for x in R)) for p in permutations(range(4)) for R in (rows,trans(rows)) for s in (0,15)))
    return sorted(reps)
if __name__=='__main__':
    r={f'{a}x{b}':cross_count(a,b) for a in (4,6,8) for b in (4,6,8) if a<=b}
    r['4x4_representatives']=four_four()
    out=json.dumps(r,indent=1)+'\n';p=Path(__file__).with_name('four_cores.json')
    if p.exists():assert json.loads(p.read_text())==json.loads(out)
    else:p.write_text(out)
    print(out)

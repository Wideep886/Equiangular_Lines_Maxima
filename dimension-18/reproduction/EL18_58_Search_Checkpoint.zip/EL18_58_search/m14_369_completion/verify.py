"""Independent frame calculation for the ten forced anchors of spectrum 369."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json,sys
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'m14_369_next'))
# cells.py imports upstream verify.py by name; this module runs as __main__.
import cells
def transpose(A):return list(map(list,zip(*A)))
def dot(u,v):return sum(a*b for a,b in zip(u,v))
def mul(A,B):return [[dot(x,y) for y in transpose(B)] for x in A]
def diag(n,z):return [[z*(i==j) for j in range(n)] for i in range(n)]
decorated,=[c for item in json.loads((here.parent/'m14_369_next'/'cells.json').read_text()) for c in item['survivors']]
decorated=[(i,tuple(z),k) for i,z,k in decorated]
rows=[(i,z) for i,z,k in decorated for _ in range(k)]
R=[cells.R[i] for i,z in rows]
Z=[z for i,z in rows]
RT=transpose(R)
RTR=mul(RT,R)
assert RTR==[[242,-116],[-116,136]]
a,b=RTR[0];_,c=RTR[1]
inv=[[Q(c,a*c-b*b),Q(-b,a*c-b*b)],[Q(-b,a*c-b*b),Q(a,a*c-b*b)]]
# S R=R [[5,4],[2,11]], thus the physical Gram contribution (5I+S)P_R is
# R([[10,4],[2,16]]) (R'R)^(-1) R'. Similarly Z'Z=40I and S Z=15Z.
Rlow=mul(mul(mul(R,[[10,4],[2,16]]),inv),RT)
assert mul(transpose(Z),Z)==diag(2,40)
assert mul(RT,Z)==diag(2,0)
low=[[Rlow[i][j]+Q(dot(Z[i],Z[j]),2) for j in range(58)] for i in range(58)]
anchors=[k for k,(i,z) in enumerate(rows) if i in (0,3)]
large=[k for k,(i,z) in enumerate(rows) if i in (1,4)]
small=[rows[k] for k in anchors]
A=diag(10,2)
for i in range(0,10,2):
    assert small[i]==small[i+1]
    assert cells.signs(*small[i],*small[i+1])=={1}
    assert low[anchors[i]][anchors[i+1]]==3
    A[i][i+1]=A[i+1][i]=-2
for i,j in product(range(10),repeat=2):
    x,y=anchors[i],anchors[j]
    if i//2==j//2:continue
    v=low[x][y]
    assert abs(v)==1
    assert {t for t in (-2,0,2) if abs(v+t)==abs(v-t)==1}=={0}
S=[[int(A[i][j]+low[x][y]-5*(i==j)) for j,y in enumerate(anchors)] for i,x in enumerate(anchors)]
assert S==transpose(S) and all(S[i][i]==0 and all(abs(S[i][j])==1 for j in range(i)) for i in range(10))
# Core low components in physical coordinates are coords/sqrt(2).
coords=[(1,z[0],0) if i==1 else (0,0,1) for k in large for i,z in [rows[k]]]
assert all(Q(dot(v,w),2)==low[x][y] for x,v in zip(large,coords) for y,w in zip(large,coords))
assert mul(transpose(coords),coords)==diag(3,24)
for k in large:
    allowable=[]
    for j in anchors[::2]:
        v=low[k][j]
        # The two anchor residuals are antipodal.
        allowable.append(sorted(t for t in (-2,-1,0,1,2) if abs(v+t)==abs(v-t)==1))
    expected=[[-1,1] if low[k][j]==0 else [0] for j in anchors[::2]]
    assert allowable==expected
    assert sum(len(x)>1 for x in allowable)==(2 if rows[k][0]==1 else 3)
anchors_json=dict(rows=[[i,list(z)] for i,z in small],Seidel=S,residual_gram=A,low_core_frame=diag(3,12))
(here/'certificate.json').write_text(json.dumps(anchors_json))
print('Unique ten-point Gram. Remaining core frame: 12 I_8 plus 16 I_9.')

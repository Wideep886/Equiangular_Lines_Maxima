from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import sys,json,gzip
P=Path(__file__).resolve().parent
D=P.parent/'proof_next_2593'
sys.path.insert(0,str(D))
from input import data,matinv
from functools import lru_cache
@lru_cache(None)
def model(k):return data(k)
def load(k,j):
    n,L,ps=model(k)
    _,_,lab,t,A,I,opts,sz,adj=json.load(gzip.open(D/f'graphs{k}'/f'{j:03}.json.gz','rt'))
    den=F(A[0][0],5-L[t[0]][t[0]])
    inv=matinv([[F(A[i][j],den) for j in I] for i in I])
    H=[];cache={}
    for u,s,e in opts:
        key=u,tuple(s)
        if key not in cache:
            x=[s[i]-L[u][t[i]] for i in I]
            val=(5-L[u][u])-sum(a*b*c for a,r in zip(x,inv) for b,c in zip(x,r))
            cache[key]=val
        H.append(cache[key])
    return t,A,I,opts,sz,list(map(lambda v:int(v,16),adj)),H
if __name__=='__main__':
 from collections import Counter
 t,A,I,ops,sz,G,H=load(2300,5)
 print(Counter(H))
 for v in set(H):
    i=H.index(v)
    print(v,i,Counter(H[j] for j in range(len(G)) if (G[i]>>j)&1))

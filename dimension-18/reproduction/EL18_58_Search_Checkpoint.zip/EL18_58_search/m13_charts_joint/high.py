"""Integer graph checks of the branches with at least one squared-height-two point."""
from height_charts import *
def has_clique(G,S,k):
    if not k:return True
    while bin(S).count('1')>=k:
        b=S&-S;v=b.bit_length()-1;S-=b
        if has_clique(G,S&G[v],k-1):return True
    return False
def one(k,j):
    _,_,_,opts,_,G,H=load(k,j)
    masks={v:sum(1<<i for i,h in enumerate(H) if h==v) for v in set(H)}
    large=[i for i,h in enumerate(H) if h==2];assert not has_clique(G,masks[2],3)
    for i in large:
        u,s,e=opts[i];other=opts.index([u,s,-e])
        # Exactly the same in-core projection, opposite normal coordinate.
        assert G[i]&masks[F(1,2)]==G[other]&masks[F(1,2)]
        for t in range(len(H)):
            if G[i]>>t&1:assert H[t] in (0,2,F(1,2))
        for v in large:
            if G[i]>>v&1:assert not has_clique(G,G[i]&G[v]&masks[0],6)
    return j
if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    for k in (2300,2689):
        jobs=[j for j,status,_ in json.loads((D/f'clique{k}.json').read_text()) if status<0]
        with ProcessPoolExecutor(2) as pool:print(k,list(pool.map(one,[k]*len(jobs),jobs)),flush=True)

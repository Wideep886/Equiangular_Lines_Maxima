"""Fix all exceptional coordinates relative to a switched anchor and enforce pair rows."""
from joint_axes import *
import joint_axes
old=joint_axes.check_dec
def paired(i,H,P,f,h,d,dec,G):
    if not old(i,H,P,f,h,d,dec,G):return False
    n=[r[-1] for r in dec];v=[r[0] for r in dec];A=len(n)
    gm=lru_cache(None)(lambda p:tuple(gram_column(p)))
    rows={j:coefficient_gram(G,H[j],H[j],H[j],True) for j in set(v)}
    live=set()
    for a,(j,p,R,u,w,nj) in enumerate(dec):
        for b in range(a,A):
            k,q,T,x,y,nk=dec[b]
            if a==b and nj==1:continue
            target=rem(mul(p,q),f);bilin=u*x+d*w*y
            for g in P[j][k]:
                if a==0 and tuple(g)!=tuple(q):continue
                yz=rem(mul(H[i],g),f)
                for s in ([1] if a==0 else [-1,1]):
                    if s*h*val(g,2)==bilin and all(t==s*z for t,z in zip(target,yz)):
                        live.add((a,b,s,g))
    while True:
        op={(a,b):[] for a in range(A) for b in range(A)}
        for a,b,s,g in sorted(live):
            op[a,b].append((s,g))
            if a!=b:op[b,a].append((s,g))
        gone=[]
        for a in range(A):
            for b in range(a,A):
                if n[b]-(a==b)>0 and not op[a,b]:return False
        for a,b,s,g in sorted(live):
            na,nb=v[a],v[b];z=gm(g)
            goal=[x-y for x,y in zip(rows[na],z)]+[x-y for x,y in zip(rows[nb],z)]+coefficient_gram(G,g,H[na],H[nb],False)
            counts=[];cols=[]
            for k in range(A):
                c=n[k]-(k==a)-(k==b)
                counts.append(c);C=set()
                for t,p in op[a,k] if c else []:
                    for u,q in op[b,k]:
                        sign=s*t*u
                        if any(x!=sign*y for x,y in zip(rem(mul(H[v[k]],g),f),rem(mul(p,q),f))):continue
                        C.add(gm(p)+gm(q)+tuple(sign*x*y for x in reversed(p) for y in reversed(q)))
                cols.append(sorted(C))
            if not test(cols,counts,goal):gone.append((a,b,s,g))
        if not gone:return True
        live.difference_update(gone)
if __name__=='__main__':
    # Reuse only decks surviving the previous phase; no dependency on optional timeouts.
    joint_axes.check_dec=paired
    import tempfile
    originals={k:json.load(open(HERE/f'survive_{k}.json')) for k in map(int,sys.argv[1:])}
    for k,rows in originals.items():
        counts=[r['counts'] for r in json.load(open(HERE/f'axes_{k}.json')) if r['survives']]
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            (out/f'survive_{k}.json').write_text(json.dumps([r for r in rows if r['counts'] in counts]))
            joint_axes.HERE=out
            joint_axes.run_axes(k)
            (HERE/f'decorated_pairs_{k}.json').write_bytes((out/f'joint_axes_{k}.json').read_bytes())

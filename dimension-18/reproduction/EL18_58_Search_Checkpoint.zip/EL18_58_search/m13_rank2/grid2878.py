"""Enumerate every low Gram at a type-5 anchor and identify the three-table obstruction."""
from fractions import Fraction as F
from joint_axes import *
def inverse(G):
    m=len(G)
    A=[[F(t) for t in r]+[int(i==j) for j in range(m)] for i,r in enumerate(G)]
    for j in range(m):
        i=next(i for i in range(j,m) if A[i][j])
        A[i],A[j]=A[j],A[i]
        c=A[j][j];A[j]=[v/c for v in A[j]]
        for i in range(m):
            if i!=j:
                z=A[i][j];A[i]=[x-z*y for x,y in zip(A[i],A[j])]
    return [r[m:] for r in A]
def classify(dec,f):
    n=len(dec)
    U=[[*z[2],z[3],z[4]] for z in dec]
    V=[[*rem(mul([2,16],z[2]),f),20*z[3],20*z[4]] for z in dec]
    Q=inverse([[sum(c[-1]*u[i]*u[j] for c,u in zip(dec,U)) for j in range(5)] for i in range(5)])
    L=[[sum(V[i][a]*Q[a][b]*U[j][b] for a,b in product(range(5),repeat=2)) for j in range(n)] for i in range(n)]
    assert all(L[i][j]==L[j][i] for i,j in product(range(n),repeat=2))
    null=[i for i in range(n) if L[i][i]==5]; small=[i for i in range(n) if L[i][i]==3];big=[i for i in range(n) if L[i][i]==1]
    # Rows with the same exceptional vector may arise in different anchor cells.
    # Switch by sign and aggregate collinear with equal norm.
    def equivalence(S):
        groups=[]
        for i in S:
            cl=next((h for h in groups if abs(L[h[0]][i])==L[i][i]),None)
            if cl is None:groups.append([i])
            else:cl.append(i)
        return [(s[0],sum(dec[k][-1] for k in s)) for s in groups]
    small=equivalence(small);big=equivalence(big)
    if not(sum(dec[k][-1] for k in null)==2 and len(small)==4 and all(m==2 for _,m in small) and len(big)==4 and all(m==12 for _,m in big)):return False
    J=[i for i,m in small];I=[i for i,m in big]
    if not all(abs(L[i][j])==1 for i,j in combinations(J,2)):return False
    if not all(L[i][j]==0 for i,j in combinations(I,2)):return False
    if not all(L[i][j] in (-1,0,1) for i,j in product(I,J)):return False
    axes=[tuple(j for j in J if L[i][j]==0) for i in I]
    return all(len(x)==2 and axes.count(x)==2 for x in axes) and len(set(sum((list(x) for x in axes),[])))==4
def main():
    idx=2878
    r,=[r for r in json.load(open(HERE/'decorated_pairs_2878.json')) if r['survives']]
    rec,=[z for z in json.load(open(HERE/'survive_2878.json')) if z['counts']==r['counts']]
    dat=json.load(open(ROOT/'m13_joint'/'input_2878.json'));H,G=dat['deck'],dat['minimal']
    f=[1]
    for a,e in dat['factors']:
        if e==1:f=mul(f,a)
    n=rec['counts'];i=5;h=val(H[i],2);delta=rec['squareclass']
    assert all(any(rem(H[i],q)) for q,k in dat['factors'] if k==1)
    P=[[[] for _ in n] for _ in n]
    for j,k,p in rec['edges']:
        P[j][k].append(tuple(p))
        if j!=k:P[k][j].append(tuple(p))
    record=[]
    for cells in row_options(G,H,i,n,P):
        opts=[];upper=[];goal=[0]*5;data=[]
        for j,p,m in cells:
            u=val(p,2);b=h*val(H[j],2)-u*u;v=isqrt(b//delta);assert b==delta*v*v
            R=rem(p,f);data.append((j,p,m,R,u,v));col=[v*a for a in (*R,u,1)]
            if v:opts.append(col);upper.append(m);goal=[t+m*x for t,x in zip(goal,col)]
        splits=[] if any(t%2 for t in goal) else feasible_counts(opts,[t//2 for t in goal],upper)
        for split in splits:
            dec=[];sol=iter(split)
            for j,p,m,R,u,v in data:
                z=next(sol) if v else m
                if z:dec.append((j,p,R,u,v,z))
                if z<m:dec.append((j,p,R,u,-v,m-z))
            valid=check_dec(i,H,P,f,h,delta,dec,G)
            grid=classify(dec,f) if valid else None
            record.append(dict(cells=dec,pass_rows=valid,grid=grid))
    assert n==[0,36,4,0,0,2,12,0,0,0,0,4] and len(record)==1 and record[0]['pass_rows'] and record[0]['grid']
    print('histogram',Counter((r['pass_rows'],r['grid']) for r in record),flush=True)
    (HERE/'grid_2878.json').write_text(json.dumps(record))
if __name__=='__main__':main()

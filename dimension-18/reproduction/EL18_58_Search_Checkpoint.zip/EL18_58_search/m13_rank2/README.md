# m=13, square classes of the t=2 spectral plane

Use the pair cofactor inputs input_2593.json and input_2878.json in ../m13_joint. The integral eigenvalue t=2 has multiplicity two for both. Local type indices in the result files start at zero and refer to rows of those inputs. Earlier catalog IDs for these spectra are n58_d2_0103 and n58_d2_0113 respectively; both polynomials are present in the combined remaining list in EL18_58_Research_20261121.zip.

Let M be the minimal polynomial of Y=(S−11I)/2. Write H_i for the diagonal cofactor and S_ij p_ij for its off-diagonal, so U(t)=2M(t)(tI−Y)⁻¹. The rank-two plane at 2 has Gram entries proportional to H_i(2), S_ij p_ij(2), with common scale 2M′(2). Therefore all nonzero integers H_i(2)H_j(2)−p_ij(2)² have the same squarefree part d. For a triangle with Seidel sign product s, the 3×3 plane Gram determinant must vanish. At every simple-root factor f it also satisfies H_k p_ij ≡ s p_ik p_jk (mod f).

1. sieve.py uses these constraints and linear row/edge cofactor Gram moments modulo 101. Remove failed types and edges until stable. The rational rank-two squareclasses from the previous pair pool are 1,2,3,5,6,10,11,15 for 2593; 1,3,6,15,30,39,42,51,87 for 2878. Only classes 1,2,6 for 2593 and 3 for 2878 survive this step. The modular_*.json files record the rounds.
2. counts.py enumerates supports and positive type counts. For each anchor type i and neighboring type j subtract a representative label from all admissible label moments; their differences span the correction space. Quotient the row equations by that space modulo 101. Impose all resulting equations on the type counts simultaneously with the exact total diagonal cofactor. A pair with no same-type label forces its type to occur at most once. Since all counts are below 101, ordinary modular row reduction and enumerating free counts covers all integers. For 2593, classes 1,2,6 leave 3,147,0 decks; for 2878 class 3 leaves 47.
3. exact_decks.py fixes a deck, repeats the row and pair Gram equations counting third vertices of each type, and removes infeasible labels iteratively. Every removed row or pair failed the finite constraints in m13_joint/screen.py. Eight decks of 2593 remain (2+6); seven of 2878 remain.
4. anchors.py takes an existing vertex of each tested type i with h=H_i(2)>0, switching its incident edges to +. Enumerate its complete label histogram from all coefficient-Gram equations. For a cell (j,p) in this histogram let u=p(2); choose the signed integer v with d v²=hH_j(2)−u². The scaled plane coordinates can be taken as (u,√d v)/√h. The first coordinates are fixed, and only the split between v and −v in each cell is unknown. The split must have zero sum of v times (p mod f,u,1) across the whole configuration, where f is the product of all simple-root factors. The first three entries are from orthogonality to the three simple eigenlines, u from tightness of the plane, and the last entry 1 from the plane eigenvector equation at the switched anchor (its own v coordinate is zero). With this split fixed, the same Seidel sign must attain all simple-root and plane inner products. Each cell’s row must obey the three simple eigenvector equations (mod f) and the two plane eigenvector equations. Failure for any one occupied anchor type excludes the whole deck. An anchor timed out is marked “deferred” and does not exclude. The surviving lists can be determined exactly by replaying only the recorded fully checked excluding anchor for each rejected deck, irrespective of machine speed. joint_axes.py optionally adds the full single-row coefficient Gram equations with the same label and sign choices.

Run python3 -B NAME.py 2593 2878 in order, replacing NAME by sieve, counts, exact_decks, anchors. The optional ANCHOR_SECONDS limit applies separately to each anchor. Increase it on faster or longer runs; its expiry only relaxes a test. Passing the first four tests gives necessary conditions. The additional finite checks below exclude the entire spectrum 2878.

## Counts after the anchored single-row tests

* 2593, squareclass 1: (0:14,1:20,9:4,10:20) and (0:16,1:16,2:2,10:24).
* 2593, squareclass 2: (0:8,1:12,2:2,3:8,5:4,8:24).
* 2878, squareclass 3: (1:36,2:4,5:2,6:12,11:4) and (0:12,1:12,5:2,7:20,9:4,10:4,11:4).

Each pair i:n lists its local type index and multiplicity. All omitted types have count zero.


## 第 2878 號譜的完整排除

在前一階段的兩組數量解上，把一個定向錨點的全部例外座標固定後，再對每一對細胞檢查帶號係數 Gram 方程。decorated_pairs.py 排除了第二組數量解；其中取第 10 型為錨點時，五種可能的錨點行次數全部失敗。check_cuts.py 只重播每次真正造成排除的錨點，完全取消時間截斷；前面標成 deferred 的探索不參與結論。剩下的第 1,2,5,6,11 型數量依序為 36,4,2,12,4。

在此數量解固定第 5 型為錨點，所有單根的錨點譜權重都非零。grid2878.py 完整列舉其行及平面第二座標的正負拆分，得到恰好一份例外座標配置（grid_2878.json）。取簡單因子乘積 f，以每個細胞 p mod f 的三個係數和先前 u,v 兩座標作矩陣 U 的行，按細胞數量重複。令 V 的對應行取 (2t+16)p mod f 的三個係數以及 20u,20v。這五個列向量張成兩個 t=2 方向及三個單根方向，且 V=(5I+S)U。因此例外 Gram 為 L=V(UᵀU)⁻¹Uᵀ。程式以有理數運算重建 L。其餘 Gram 為 16P₁₁，秩 13。

* 兩個第 5 型頂點的 L 對角均為 5，故剩餘向量為零。
* 八個點分成四組，每組兩點的例外向量相同（必要時同時切換整個代表向量），範數平方 3，剩餘範數平方 2。內積 1 或 −1 扣掉 3 只能為 −2，因而各組剩餘向量是反向對。四對之間的例外內積為 ±1，由反向性知剩餘向量互相正交。記其四根單位軸為 r₁,…,r₄。
* 其餘 48 點的例外部分，切換後恰為四個互相正交的單位向量 e₁,…,e₄，各有十二點。若它同某反向對的例外內積為 ±1，對應根座標為零；若例外內積為零，根座標為 ±1/√2。四個十二點類各用恰好兩根軸。前兩類共用一對軸，後兩類共用另兩根。

在四根軸的每一對上作 2×2 的正交 Hadamard 變換。每條線的兩個 ±1/√2 座標成為一個 ±1 和一個零。故其八維投影具有 e_i±f_j 形狀，且四乘四佔用表支撐於兩個互不相交的二乘二對角塊。在原 11-特徵空間，刪除十點使四根軸的 frame 特徵值由 16 降到 12（每反向對貢獻 4），正交九維仍為 16。原來例外空間和 11-空間的交叉 frame 項為零，刪掉十點的交叉項也為零：每對的小類例外向量相同，餘向量相反。四條 e 軸各有十二個相同的單位投影，因此其 frame 亦為 12I。這就得到與 ../m14_369_geometry 相同的已排除核心，三個可能佔用表為 0、1、83，無任何可行延拓。這一步不需任何新的浮點測試。

依序可執行 python3 -B check_cuts.py 2593 2878，python3 -B grid2878.py，以及 ../m14_369_geometry/recheck.py 對既有三表排除的重播。第 2593 號仍餘上述三個數量解。starts_2593.json 記錄各解的一組局部錨點座標作下次搜尋起點；各個錨點只需滿足局部條件，未有完整 Gram。

也可直接換線得到已排除的 m=15 譜。取 E=span(e₁,…,e₄) 及 F 為上述四根經 Hadamard 變換後的空間，另取垂直於 17 維核心的單位向量 w。於 E 和 F 各取四個「恰一個負號」及一個「全負號」的四維符號字，每字加 w。每個新向量平方長度 5；核心在 E、F 各只有一個 ±1 座標，所以新舊內積均為 ±1。同組兩字 Hamming 距離為 2 或 3，附加共同的 w 後內積為 1 或 −1，異組的內積均為 1。對於每個四維空間，五字的二次矩是 4I+J，字向量總和為全一向量。加入十線後，兩個三維零和空間及原九維的 frame 值均為 16；在兩個正規化的全一方向與 w 上的 frame 塊為 [[20,0,2],[0,20,2],[2,2,10]]。故所得 Seidel 矩陣為譜 (−5)^40, 11^15, 15, 10±√33，與 m15_upstream/single_row 的已驗證排除矛盾。這是一條與三表直接排除不同的重用方式。

後續的四圈檢驗已排除第 2593 號第二組型數（16,16,2,24），只餘平方類 1 和 2 各一組。請以 ../m13_2593_geometry 及 ../m13_2593_core 為接續起點。

另一個平方類 1 的型數其後亦由兩條路徑的閉合延拓排除。只有平方類 2 的型數尚餘，請見 ../m13_2593_geometry/README.md。

最後的平方類 2 情形現已透過兩線替換歸約至第 369 號，見 ../m13_2593_core/README.md。因此第 2593 與 2878 號均已排除。

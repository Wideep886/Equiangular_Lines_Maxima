"""Fix support, then impose all exact row equations modulo 101 on the type counts."""
from sieve import *
from itertools import combinations
def pivots(rows,p=101):
    piv={}
    for r in rows:
        a=[x%p for x in r]
        for j,v in sorted(piv.items()):
            if a[j]:
                z=a[j];a=[(u-z*w)%p for u,w in zip(a,v)]
        j=next((i for i,x in enumerate(a) if x),None)
        if j is not None:
            z=pow(a[j],-1,p);piv[j]=[x*z%p for x in a]
    return piv
def project(x,A):
    x=list(x)
    for j,v in sorted(A.items()):
        z=x[j]%101
        if z:x=[(u-z*w)%101 for u,w in zip(x,v)]
    return x
def solve_mod(A,b,upper):
    dim=len(A[0])-1
    R=pivots(A)
    if dim in R:return
    free=[j for j in range(dim) if j not in R]
    # Early prune n>=1; pivot variables determined uniquely in 1..58.
    for values in product(*[range(1,upper[j]+1) for j in free]):
        n=[0]*dim
        for j,z in zip(free,values):n[j]=z
        if sum(n)>58:continue
        for j in sorted(R,reverse=True):
            v=R[j];n[j]=(v[-1]-sum(t*z for t,z in zip(v[:-1],n)))%101
            if not 1<=n[j]<=upper[j]:break
        else:
            if sum(n)==58:yield tuple(n)
def run_decks(idx):
    d=json.load(open(ROOT/'m13_joint'/f'input_{idx}.json'));G,H,target=d['minimal'],d['deck'],d['cofactor_sum'];N=len(H)
    rlist=json.load(open(HERE/f'modular_{idx}.json'));res=[]
    for rec in rlist:
        if not rec['survivors']:continue
        ids=rec['survivors'];pairs={(i,j):[] for i in ids for j in ids}
        for i,j,q in rec['edges']:
            pairs[i,j].append(tuple(q))
            if i!=j:pairs[j,i].append(tuple(q))
        D={i:coefficient_gram(G,H[i],H[i],H[i],True) for i in ids};gm=lru_cache(None)(lambda p:tuple(gram_column(p)))
        count=0;found=set()
        for s in range(1,len(ids)+1):
            for F in combinations(ids,s):
                if any(not pairs[i,j] for i,j in combinations(F,2)):continue
                rows=[[*r,b] for r,b in zip(zip(*(H[i] for i in F)),target)]
                for i in F:
                    cols=[list(set(gm(q) for q in pairs[i,j])) for j in F]
                    # No self edge makes this type singleton.
                    if not pairs[i,i]:rows.append([*[int(j==i) for j in F],1]);cols[F.index(i)]=[[0]*len(D[i])]
                    delta=[tuple(u-v for u,v in zip(a,cl[0])) for cl in cols for a in cl[1:]]
                    A=pivots(delta)
                    c=[project(cl[0],A) for cl in cols]
                    t=project([u+v for u,v in zip(D[i],cols[F.index(i)][0])],A)
                    rows.extend([*r,y] for r,y in zip(zip(*c),t) if y%101 or any(x%101 for x in r))
                count+=1
                for n in solve_mod(rows,None,[59-s]*s):
                    if any(sum(nj*H[j][k] for j,nj in zip(F,n))!=y for k,y in enumerate(target)):continue
                    found.add(tuple(dict(zip(F,n)).get(i,0) for i in range(N)))
        print(idx,rec['squareclass'],'supports',count,'decks',len(found),flush=True)
        res.append(dict(squareclass=rec['squareclass'],counts=sorted(found)))
    (HERE/f'counts_{idx}.json').write_text(json.dumps(res,separators=(',',':')))
if __name__=='__main__':
    for k in map(int,sys.argv[1:]):run_decks(k)

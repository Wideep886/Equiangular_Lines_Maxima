"""Rank-two determinant squareclass and signed triple row sieve."""
from pathlib import Path
from collections import Counter
from itertools import product,combinations_with_replacement
import sys,json
from math import isqrt
from functools import lru_cache
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'m13_joint'))
from screen import coefficient_gram,gram_column,lat,span_mod,reduced_product,mul,feasible_counts
from lowmult import val
from lpscreen import phase_one
def sf(v):
    assert v>=0
    if not v:return 0
    d=2
    while d*d<=v:
        while v%(d*d)==0:v//=d*d
        d+=1
    return v
def why(C,T):
    if not C:return 'empty'
    if not span_mod(C,T):return 'mod101'
    return None
def run(idx):
    dat=json.loads((ROOT/'m13_joint'/f'input_{idx}.json').read_text())
    G,H,tar=dat['minimal'],dat['deck'],dat['cofactor_sum']
    N=len(H);Q=dat['pairs'];I=range(N)
    H=[tuple(h) for h in H];gm=lru_cache(None)(lambda p:tuple(gram_column(p)))
    at2=lru_cache(None)(lambda p:val(p,2))
    h2=[at2(p) for p in H]
    M=[coefficient_gram(G,h,h,h,True) for h in H]
    classes=set();opts={}
    for i,j in combinations_with_replacement(I,2):
        for p in map(tuple,Q[i][j]):
            c=sf(h2[i]*h2[j]-at2(p)**2);classes.add(c)
            opts[i,j,p]=c
    f=[1]
    for h,r in dat['factors']:
        if r==1:f=mul(f,h)
    prod=lru_cache(None)(lambda a,b:reduced_product(a,b,f))
    out=[]
    for cls in sorted(classes-{0}):
        active=set(I);edges={(i,j,p) for (i,j,p),v in opts.items() if v in (0,cls)}
        rec=dict(squareclass=cls,rounds=[])
        def pair(i,j):return (min(i,j),max(i,j))
        def row(i):
            return [*(x-y for x,y in zip(tar,H[i])),*M[i]]
        while active:
            lookup={(i,j):[] for i in I for j in I}
            for i,j,p in sorted(edges):
                lookup[i,j].append(p)
                if i!=j:lookup[j,i].append(p)
            drop={}
            for i in sorted(active):
                C=[H[j]+gm(p) for j in active for p in lookup[i,j]]
                h=why(C,row(i))
                if h:drop[i]=h
            if drop:
                rec['rounds'].append(dict(rows=drop));active.difference_update(drop)
                edges={e for e in edges if e[0] in active and e[1] in active}
                continue
            h=why([H[i] for i in active],tar)
            if h:rec['rounds'].append(dict(deck=h));active.clear();break
            gone=[]
            for i,j,p in sorted(edges):
                C=set()
                for k in sorted(active):
                    for a in lookup[i,k]:
                        for b in lookup[j,k]:
                            for s in [-1,1]:
                                if any(x!=s*y for x,y in zip(prod(H[k],p),prod(a,b))):continue
                                x,y,z=at2(p),at2(a),s*at2(b)
                                if h2[i]*h2[j]*h2[k]+2*x*y*z != h2[i]*z*z+h2[j]*y*y+h2[k]*x*x:continue
                                mixed=tuple(s*u*v for u in reversed(a) for v in reversed(b))
                                C.add(H[k]+gm(a)+gm(b)+mixed)
                T=[x-y-z for x,y,z in zip(tar,H[i],H[j])]
                T += [x-y for x,y in zip(M[i],gm(p))]+[x-y for x,y in zip(M[j],gm(p))]
                T+=coefficient_gram(G,p,H[i],H[j],False)
                h=why(sorted(C),T)
                if h:gone.append((i,j,p,h))
            if not gone:break
            rec['rounds'].append(dict(edges=gone))
            edges.difference_update((i,j,p) for i,j,p,h in gone)
        rec['survivors']=sorted(active)
        rec['edges']=sorted(edges) if active else []
        out.append(rec);print(idx,cls,len(active),len(rec['edges']),flush=True)
    (HERE/f'modular_{idx}.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':
    for i in map(int,sys.argv[1:]):run(i)

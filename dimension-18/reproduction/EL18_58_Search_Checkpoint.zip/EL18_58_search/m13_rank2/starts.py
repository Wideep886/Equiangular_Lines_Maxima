"""Retain one compatible exceptional-coordinate record per surviving cofactor deck."""
from decorated_pairs import *
import tempfile
class Found(Exception): pass
def collect(idx):
    wanted=json.load(open(HERE/f'decorated_pairs_{idx}.json'))
    data=json.load(open(HERE/f'survive_{idx}.json'))
    out=[]
    for r in data:
        if not any(z['survives'] and z['counts']==r['counts'] for z in wanted):continue
        rec=dict(squareclass=r['squareclass'],counts=r['counts'])
        def see(i,H,P,f,h,d,cells,G):
            if paired(i,H,P,f,h,d,cells,G):
                rec.update(anchor=i,h=h,field_modulus=f,cells=cells)
                raise Found()
            return False
        with tempfile.TemporaryDirectory() as tmp:
            scratch=Path(tmp);joint_axes.HERE=scratch;joint_axes.check_dec=see
            (scratch/f'survive_{idx}.json').write_text(json.dumps([r]))
            try:joint_axes.run_axes(idx)
            except Found:pass
        assert 'cells' in rec
        out.append(rec)
    (HERE/f'starts_{idx}.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':
    for k in map(int,sys.argv[1:]):collect(k)

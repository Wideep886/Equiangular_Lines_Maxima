from counts import *
from screen import test
def refine(idx):
    dat=json.load(open(ROOT/'m13_joint'/f'input_{idx}.json'));G,H=dat['minimal'],[tuple(x) for x in dat['deck']];h=[val(x,2) for x in H]
    L={r['squareclass']:r for r in json.load(open(HERE/f'modular_{idx}.json'))}
    f=[1]
    for p,m in dat['factors']:
        if m==1:f=mul(f,p)
    prod=lru_cache(None)(lambda a,b:reduced_product(a,b,f))
    gm=lru_cache(None)(lambda q:tuple(gram_column(q)))
    at2=lru_cache(None)(lambda q:val(q,2))
    M={i:coefficient_gram(G,x,x,x,True) for i,x in enumerate(H)}
    results=[]
    def triangle(i,j,k,p,a,b):
        R=prod(H[k],p);Q=prod(a,b);x,y,z=map(at2,(p,a,b))
        return [s for s in (1,-1) if all(t==s*u for t,u in zip(R,Q)) and h[i]*h[j]*h[k]+2*s*x*y*z==h[i]*z*z+h[j]*y*y+h[k]*x*x]
    for rec in json.load(open(HERE/f'counts_{idx}.json')):
        cls=rec['squareclass'];raw=L[cls]['edges']
        for n in rec['counts']:
            active=[i for i,c in enumerate(n) if c]
            live={(i,j,tuple(p)) for i,j,p in raw if n[i] and n[j] and (i!=j or n[i]>1)}
            while True:
                pools={(i,j):[] for i in active for j in active}
                for i,j,p in sorted(live):
                    pools[i,j].append(p)
                    if i!=j:pools[j,i].append(p)
                badrow=next((i for i in active if not test([[gm(q) for q in pools[i,j]] for j in active],[n[j]-(i==j) for j in active],M[i])),None)
                if badrow is not None:ok=False;break
                gone=set()
                for i,j,p in sorted(live):
                    counts=[n[k]-(k==i)-(k==j) for k in active]
                    target=[x-y for x,y in zip(M[i],gm(p))]+[x-y for x,y in zip(M[j],gm(p))]+coefficient_gram(G,p,H[i],H[j],False)
                    groups=[]
                    for k,c in zip(active,counts):
                        choices=set()
                        for a in pools[i,k] if c else []:
                            for b in pools[j,k]:
                                for s in triangle(i,j,k,p,a,b):choices.add(gm(a)+gm(b)+tuple(s*u*v for u in reversed(a) for v in reversed(b)))
                        groups.append(sorted(choices))
                    if not test(groups,counts,target):gone.add((i,j,p))
                if not gone:ok=True;break
                live-=gone
            if ok:results.append(dict(squareclass=cls,counts=n,edges=list(sorted(live))))
        print(idx,cls,'cumulative',len(results),flush=True)
    (HERE/f'survive_{idx}.json').write_text(json.dumps(results,separators=(',',':')))
if __name__=='__main__':
    for i in map(int,sys.argv[1:]):refine(i)

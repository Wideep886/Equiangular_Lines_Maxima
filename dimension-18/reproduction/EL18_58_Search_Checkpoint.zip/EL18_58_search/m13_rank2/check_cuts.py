"""Replay every actual rejection without timeout and without exploring inactive candidates."""
import tempfile,os
import anchors, joint_axes
from decorated_pairs import paired
from sieve import HERE,json,Path
def verify(idx):
    data=json.load(open(HERE/f'survive_{idx}.json')); cuts=0
    for kind in ['axes','decorated_pairs']:
        records=json.load(open(HERE/f'{kind}_{idx}.json'))
        module=anchors if kind=='axes' else joint_axes
        if kind=='decorated_pairs':module.check_dec=paired
        original=module.HERE
        for r in records:
            if r['survives']:continue
            n=r['counts']
            bad=next(a for a,num,s in r['rows'] if s==0)
            os.environ['ONLY_ANCHOR']=str(bad);os.environ['ANCHOR_SECONDS']='0'
            case,=[z for z in data if z['counts']==n]
            with tempfile.TemporaryDirectory() as tmp:
                module.HERE=Path(tmp)
                (module.HERE/f'survive_{idx}.json').write_text(json.dumps([case]))
                module.run_axes(idx)
                name='axes' if kind=='axes' else 'joint_axes'
                ver,=json.loads((module.HERE/f'{name}_{idx}.json').read_text())
                assert not ver['survives'] and ver['rows']==[r['rows'][-1]]
            module.HERE=original;cuts+=1
    print(idx,'replayed',cuts,'complete deck rejections')
if __name__=='__main__':
    import sys
    for k in map(int,sys.argv[1:]):verify(k)

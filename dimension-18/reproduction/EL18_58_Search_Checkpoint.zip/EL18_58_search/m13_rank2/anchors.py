from exact_decks import *
from decorate import row_options,rem
import signal, os
def on_timeout(*_): raise TimeoutError()
signal.signal(signal.SIGALRM, on_timeout)

def run_axes(idx):
    d=json.load(open(ROOT/'m13_joint'/f'input_{idx}.json'));H=d['deck'];G=d['minimal']
    f=[1]
    for h,m in d['factors']:
        if m==1:f=mul(f,h)
    results=[]
    for rec in json.load(open(HERE/f'survive_{idx}.json')):
        n=rec['counts'];delta=rec['squareclass'];N=len(n)
        P=[[[] for j in n] for i in n]
        for i,j,p in rec['edges']:
            P[i][j].append(tuple(p))
            if i!=j:P[j][i].append(tuple(p))
        anchors=sorted((i for i in range(N) if n[i] and val(H[i],2)>0),
                       key=lambda i:sum(len(P[i][j]) for j in range(N) if n[j]))
        if os.environ.get("ONLY_ANCHOR"):
            anchors=[a for a in anchors if a==int(os.environ["ONLY_ANCHOR"])]
        keep=True;info=[]
        for i in anchors:
            total=0;survive=0;h=val(H[i],2)
            signal.setitimer(signal.ITIMER_REAL,float(os.environ.get('ANCHOR_SECONDS','3')))
            try:
                for cells in row_options(G,H,i,n,P):
                    total+=1
                    # orthogonality of second plane coordinate to the fixed anchor row's
                    # spectral coefficients, including its own horizontal plane coordinate.
                    opts=[];upper=[];rhs=[0]*5
                    data=[]
                    for j,p,m in cells:
                        u=val(p,2);b=h*val(H[j],2)-u*u
                        assert b%delta==0 and isqrt(b//delta)**2==b//delta
                        v=isqrt(b//delta)
                        R=rem(p,f)
                        data.append((j,p,m,R,u,v))
                        vec=(*R,u,1)
                        if v:
                            opts.append(tuple(v*x for x in vec));upper.append(m)
                            rhs=[a+m*v*x for a,x in zip(rhs,vec)]
                    # The last equation must not use sum of entries of the vertical axis:
                    # anchor eigenvector at i is zero vertically, all anchor Seidel signs +,
                    # so 15 times that zero equals its neighbor sum, hence valid.
                    if any(z%2 for z in rhs):continue
                    splits=feasible_counts(opts,[z//2 for z in rhs],upper) if opts else [()]
                    valid=False
                    for sol in splits:
                        dec=[];pos=iter(sol)
                        for j,p,m,R,u,v in data:
                            w=next(pos) if v else m
                            if w:dec.append((j,p,R,u,v,w))
                            if m-w:dec.append((j,p,R,u,-v,m-w))
                        if check_dec(i,H,P,f,h,delta,dec):
                            valid=True;break
                    if valid:survive+=1;break
            except TimeoutError:
                survive='deferred'
            finally:
                signal.setitimer(signal.ITIMER_REAL,0)
            info.append([i,total,survive])
            if not survive:keep=False;break
        results.append(dict(counts=n,squareclass=delta,rows=info,survives=keep))
        print(idx,delta,len(results),keep,info,flush=True)
    (HERE/f'axes_{idx}.json').write_text(json.dumps(results))
def check_dec(i,H,P,f,h,d,dec):
    def poly(p):return tuple(rem(p,f))
    for a,(j,p,R,u,v,n) in enumerate(dec):
        goal=[*rem(mul([2,11],R),f),15*u,15*v]
        coeff=[];bound=[]
        for b,(k,q,T,x,y,m) in enumerate(dec):
            m-=a==b
            if not m:continue
            want=rem(mul(p,q),f);prod=u*x+d*v*y
            opts=set()
            for s in ((1,) if a==0 or b==0 else (-1,1)):
                for g in P[j][k]:
                    if s*val(g,2)*h!=prod:continue
                    yz=rem(mul(H[i],g),f)
                    if all(t==s*z for t,z in zip(want,yz)):opts.add(s);break
            if not opts:return False
            vec=[*T,x,y];s=min(opts)
            goal=[c-s*m*z for c,z in zip(goal,vec)]
            if len(opts)==2:coeff.append([2*z for z in vec]);bound.append(m)
        if coeff:
            if not feasible_counts(coeff,goal,bound,first_only=True):return False
        elif any(goal):return False
    return True
if __name__=='__main__':
    for k in map(int,sys.argv[1:]):run_axes(k)

"""Check the type-0 row identities simultaneously on all three original decks."""
import json
from fractions import Fraction as Q
from pathlib import Path

root=Path(__file__).resolve().parents[1]
inp=json.loads((root/'m13_joint/input_2593.json').read_text())
classes=json.loads((root/'m13_rank2/survive_2593.json').read_text())
dec=json.loads((root/'m13_rank2/decorated_pairs_2593.json').read_text())
gprime=inp['minimal'][-2]
for row in dec:
    if not row['survives']:
        continue
    n=row['counts']
    rec,=[r for r in classes if r['counts']==n and r['squareclass']==row['squareclass']]
    h0=inp['deck'][0][-1]
    assert 5-Q(8*h0,gprime)==1
    exterior=[]; interior=[]
    for i,m in enumerate(n):
        if not m:continue
        projections={abs(1-Q(8*q[-1],gprime)) for a,b,q in rec['edges'] if (a,b)==(0,i)}
        if projections=={0}:exterior.append(i)
        elif projections=={1}:interior.append(i)
        else:raise AssertionError(projections)
    assert sum(n[i] for i in exterior)==40 and sum(n[i] for i in interior)==18
    assert 16*4-4**2-40 == 2*(2**2)
    print('core',[(i,n[i]) for i in interior],'exterior',[(i,n[i]) for i in exterior])

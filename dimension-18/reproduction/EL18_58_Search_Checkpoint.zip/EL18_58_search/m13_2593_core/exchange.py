"""Verify the third-deck exchange in rational coordinates, including its exact spectrum."""
from itertools import product, permutations
from fractions import Fraction as F
# Order: u, sqrt(2)e', g, b, a/sqrt(2), sqrt(2)n for one removed pair.
metric=[1,2,1,1,F(1,2),2]
signs=(-1,1)

def dot(x,y):
    return sum(a*b*d for a,b,d in zip(x,y,metric))

def determinant(m):
    if len(m)==0:return 1
    return sum((-1)**i*x*determinant([row[:i]+row[i+1:] for row in m[1:]])
               for i,x in enumerate(m[0]) if x)

def check():
    new=[[1,-1,0,0,0,z] for z in signs]
    assert [dot(v,v) for v in new]==[5,5] and dot(*new)==1
    others=[[1,0,0,0,0,0],[1,1,0,0,0,0]]
    for s,t in product(signs,repeat=2):
        others.extend([[1,0,s,t,0,0],[0,F(s,2),0,t,0,0],[0,0,0,0,s,F(t,2)]])
        for a in signs:others.append([0,F(s,2),t,0,2*a,0])
    assert all(abs(dot(x,y))==1 for x in new for y in others)
    core=[[18,4,0,0,0,0],[2,12,0,0,0,0],[0,0,12,0,0,0],
          [0,0,0,20,0,0],[0,0,0,0,20,0],[0,0,0,0,0,16]]
    for s,t in product(signs,repeat=2):
        removed=[[1,0,s,t,0,z] for z in signs]
        C=[[core[i][j]+metric[j]*(sum(v[i]*v[j] for v in new)-sum(v[i]*v[j] for v in removed))
            for j in range(6)] for i in range(6)]
        # tI-C is monic of degree 6. Seven integer values suffice.
        for x in range(7):
            got=determinant([[x*(i==j)-a for j,a in enumerate(row)] for i,row in enumerate(C)])
            assert got==(x-16)**2*(x-20)**2*(x*x-26*x+152)
    print('All signed products; four rational frame updates; spectra 16^14,20^2,13±sqrt(17).')
if __name__=='__main__':check()

"""Verify the small residual cells of 369 and the forced grid obstruction."""
import json
import sys
from fractions import Fraction as F
from itertools import product
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root / "m14_369_next"))
from cells import R, signs

saved = json.loads((root / "m14_369_next/cells.json").read_text())
survivor, = [s for row in saved for s in row["survivors"]]
cells = [(i, tuple(z), n) for i,z,n in survivor]
assert [n for i,z,n in cells] == [2,12,12,2,2,2,2,24]
G = [[sum(n*R[i][a]*R[i][b] for i,z,n in cells)
      for a in range(2)] for b in range(2)]
assert G == [[242,-116],[-116,136]]
a,b = G[0]
_,c = G[1]
h = F(1, a*c-b*b)
E = [[h*c,-h*b],[-h*b,h*a]]
T = [[10,4],[2,16]]   # S+5I action on the two quadratic coordinate columns
def low(i,x,j,y):
    return (sum(R[i][p]*T[p][q]*E[q][k]*R[j][k]
                for p,q,k in product(range(2),repeat=3))
            + F(sum(a*b for a,b in zip(x,y)),2))
def residual(u,v):
    i,x,_ = cells[u]
    j,y,_ = cells[v]
    return {s-low(i,x,j,y) for s in signs(i,x,j,y)}
small = [0,3,4,5,6]
for i in small:
    t,x,_ = cells[i]
    assert 5-low(t,x,t,x) == 2 and residual(i,i)=={-2}
    for j in small:
        if i<j:
            assert 0 in residual(i,j)
            assert not any(-v in residual(i,j) for v in residual(i,j) if v)
for a, needed in [(1,{5,6}), (2,{5,6}), (7,{0,3,4})]:
    for b in small:
        opts = residual(a,b)
        assert {v for v in opts if -v in opts} == ({-1,1} if b in needed else {0})
# Each big cell has one quadratic constant axis, or no quadratic component.
assert low(1,(0,0),1,(0,0))==F(1,2) and R[4]==(0,0)
sys.path.insert(0, str(root/'core_search'))
from reproduce import transpose_key
sys.path.insert(0, str(root/'core_transversal'))
import transversal
troot=root/'core_transversal'
rows=json.loads((troot/'results_col8.json').read_text())
base=transversal.occupation.profile_states(troot/'words_col8.txt')
for q,r,expected in [(2,2,0),(2,3,1),(3,3,83)]:
    mat=[[q,6-q,0,0],[6-q,q,0,0],[0,0,r,6-r],[0,0,6-r,r]]
    matches=[j for j,h in enumerate(rows) if transpose_key(h['table'])==transpose_key(mat)]
    assert matches==[expected]
    t=tuple(map(tuple,rows[expected]['table']))
    answer,stats=transversal.solve(t,base)
    assert answer is None and not stats['open'] and not stats['centered']
    if expected==0: assert stats['matching']==16
    print(expected,dict(stats))
print("Five orthogonal antipodal pairs; all three forced occupancy classes excluded.")

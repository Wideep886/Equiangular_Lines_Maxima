"""Identify quartic 169 among the earlier integral spectrum certificates and replay it."""
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import gzip
import json
import subprocess
import sys

here = Path(__file__).resolve().parent
rows = json.loads((here.parent / "m14/quartic_results.json").read_text())
spectrum = Counter({-5: 40})
for factor, mult in rows[169]["factors"]:
    leading, constant = factor
    assert leading == 1
    spectrum[11 - 2*constant] += mult
archive = here.parent.parent / "EL18_58_Research_20261121.zip"
profile_dir = here.parents[2] / "EL16維度分類專案/research_d18/output"
assert spectrum == {-5: 40, 7: 2, 11: 14, 15: 1, 17: 1}
with ZipFile(archive) as z, TemporaryDirectory() as temp:
    for name in ("verify_signed_projectors.py", "signed_projector_certificates.json.gz"):
        path = Path(temp) / name
        path.write_bytes(z.read("EL18_58/integral/" + name))
    bundle = json.loads(gzip.decompress(path.read_bytes()))
    matches = [i for i, item in bundle.items() if
        dict(zip(item["inputs"]["eigenvalues"], item["inputs"]["ranks"])) == spectrum]
    assert matches == ["14"], matches
    args = [sys.executable, str(Path(temp)/"verify_signed_projectors.py"), "14"]
    if profile_dir.exists():
        args.extend(["--compare-inputs", str(profile_dir)])
    subprocess.run(args, check=True)

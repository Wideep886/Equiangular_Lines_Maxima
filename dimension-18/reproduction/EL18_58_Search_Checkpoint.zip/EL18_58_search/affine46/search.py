"""Exact 46-core search over unordered marked pairs in all affine parity lifts."""
import itertools as it
import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from functools import reduce
from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
import multiprocessing as mp

here=Path(__file__).resolve().parent
def load(path):
    spec=spec_from_file_location(path.stem,path)
    mod=module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
common=load(here.parent/'affine47'/'search.py')
solver=common.solver
def orbit_records():
    switch={reduce(int.__xor__,[solver.masks[i] for i in range(9) if mask>>i&1],0):mask
            for mask in range(512)}
    assert len(switch)==512
    reductions={r^v:(r,t) for r in solver.reps for v,t in switch.items()}
    pts=solver.pts
    maps=[]
    for a,b,c,d in it.product(range(3),repeat=4):
        if (a*d-b*c)%3:
            for tx,ty in pts:
                pi=[pts.index(((a*x+b*y+tx)%3,(c*x+d*y+ty)%3)) for x,y in pts]
                lm=[solver.lines.index(tuple(sorted(pi[i] for i in t))) for t in solver.lines]
                maps.append((pi,lm))
    designs={r:solver.triples(r) for r in solver.reps}
    indices={r:{tuple(sorted(t)):i for i,t in enumerate(bl)} for r,bl in designs.items()}
    groups={}
    for r,blocks in designs.items():
        images=[]
        for pi,lm in maps:
            label=sum(((r>>i)&1)<<p for i,p in enumerate(lm))
            representative,flip=reductions[label]
            point_map=[2*pi[u//2]+((u%2)^((flip>>pi[u//2])&1)) for u in range(18)]
            block_map=[indices[representative][tuple(sorted(point_map[u] for u in t))] for t in blocks]
            images.append((representative,block_map))
        for a,b in it.combinations(range(48),2):
            key=min((c,min(p[a],p[b]),max(p[a],p[b])) for c,p in images)
            groups[key]=groups.get(key,0)+1
    assert sum(groups.values())==8*1128
    return sorted(groups.items())

def run(record):
    (r,a,b),mult=record
    blocks=solver.triples(r)
    C=[t for i,t in enumerate(blocks) if i not in (a,b)]
    D,opts,B=solver.coords(C)
    adj=[0]*len(opts)
    inner={}
    for i,(x,h,e) in enumerate(opts):
        for j,(y,g,f) in enumerate(opts[:i]):
            dot=sum(a*b for a,b in zip(x,y))
            for z in (-1,1):
                delta=2*D*D*z-dot
                if delta**2==h*g and delta*e*f>=0:
                    adj[i]|=1<<j;adj[j]|=1<<i
                    inner[i,j]=inner[j,i]=z
                    break
    best=common.max_clique(adj)
    witness=None
    if len(best)>=12 or (r,a,b)==(0,0,1):
        best_used=best[:12]
        gram=[[2*len(set(x)&set(y))-1 for y in C] for x in C]
        n=len(C)
        for row,t in zip(gram,C):
            for i in best_used:
                u=sum(opts[i][0][p] for p in t)
                assert abs(u)==D
                row.append(u//D)
        for j,i in enumerate(best_used):
            gram.append([row[n+j] for row in gram[:n]]+
                        [5 if i==l else inner[i,l] for l in best_used])
        witness='gram_%d_%d_%d_%d.json'%(r,a,b,len(gram))
        common.certify(gram,len(gram),18)
        (here/witness).write_text(json.dumps(gram))
    result=dict(code=r,deletions=[a,b],multiplicity=mult,basis=B,den=D,
                directions=len(opts),edges=len(inner)//2,
                maximum=len(best),witness=witness,clique_indices=best)
    return result

if __name__=='__main__':
    classes=orbit_records()
    (here/'orbits.json').write_text(json.dumps(classes))
    print('classes',len(classes),flush=True)
    resultfile=here/'results.json'
    prior=json.loads(resultfile.read_text()) if resultfile.exists() else []
    done={(x['code'],*x['deletions']) for x in prior}
    todo=[z for z in classes if z[0] not in done]
    with ProcessPoolExecutor(max_workers=min(5,os.cpu_count() or 1),
                             mp_context=mp.get_context('fork')) as pool:
        for result in pool.map(run,todo):
            prior.append(result)
            tmp=resultfile.with_suffix('.tmp')
            tmp.write_text(json.dumps(prior));tmp.replace(resultfile)
            print(len(prior),result['code'],result['deletions'],result['directions'],result['maximum'],flush=True)

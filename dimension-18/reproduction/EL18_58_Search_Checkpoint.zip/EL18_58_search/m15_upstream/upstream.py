"""Read-only replay of original project order-58 0021 pruning; no external dependencies."""
from pathlib import Path
import json,sys,types
from hashlib import sha256
here=Path(__file__).resolve().parent
src=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here/'source'
pkg=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else src/'output'
sys.path[:0]=[str(pkg),str(src)]
from verify_quadratic_0020 import coefficient_gram
import nonintegral_deck_attack as deck
import base64,subprocess
from verify_quadratic_0021_core import check
out=src/'output';pid='n58_d2_0021'
d=json.load(open(out/f'nonintegral_deck_{pid}.json'))
rr=json.load(open(out/'residues_n57_mod128.json'))
inputs=b''.join(base64.b64decode(r['witness_upper_triangle_base64']) for r in rr['classes'])
rpath=Path(__file__).resolve().parent/'residue'
import tempfile
with tempfile.TemporaryDirectory() as tmp:
 rpath=Path(tmp)/'residue'
 subprocess.run(['c++','-O3','-std=c++17',str(here/'residue.cpp'),'-o',str(rpath)],check=True)
 actual=subprocess.check_output([str(rpath)],input=inputs).decode().splitlines()
res={tuple(map(int,l.split())) for l in actual}
assert len(res)==len(actual)==2048 and all(tuple(map(int,l.split()))==tuple(row['coefficients']) for l,row in zip(actual,rr['classes']))
print('2048 odd order-57 residues checked',flush=True)
deck.lp_check=lambda polys,target:d['metadata']['lp']
new=deck.spectrum_deck(d['metadata']['source_profile'],res)
assert new['H_deck']==d['H_deck'];deck.verify_lp(new)
print('complete one-vertex deck',len(new['H_deck']),flush=True)
def load(n,transform):
 p=src/(n+'.py');m=types.ModuleType(n);m.__file__=str(p);sys.modules[n]=m
 s=transform(p.read_text());m.coefficient_gram=coefficient_gram
 exec(compile(s,str(p),'exec'),m.__dict__);return m
def pair_source(s):
 s=s.replace('import sympy as sp','').replace("t,u = sp.symbols('t u')","")
 return s[:s.index('def independent_gram')]+'''def independent_gram(M,H):
    return coefficient_gram(M,H,H,H,True)
'''+s[s.index('def check_certificate'):]
p=load('verify_nonintegral_pair',pair_source);r=p.verify_profile(pid)
print('independent pair',r['complete_independent_pair_coverage'],len(r['pair_checks']),flush=True)
# Run the original verifier with its inputs copied into a temporary output directory.
import tempfile,shutil
t=load('verify_nonintegral_triangle',lambda s:s)
with tempfile.TemporaryDirectory() as tmp:
 t.OUT=Path(tmp)
 for name in [f'nonintegral_triangle_{pid}.json',f'nonintegral_pair_{pid}.json',f'nonintegral_deck_{pid}.json', ]:
  shutil.copyfile(out/name,t.OUT/name)
 (t.OUT/'nonintegral_pair_independent_verification.json').write_text(json.dumps({'results':[r]}))
 v=t.verify_profile(pid)
print('independent triangle',v.keys(),flush=True)
for typ in ('pair','triangle'):
 fn=f'nonintegral_{typ}_{pid}.json';assert (out/fn).read_bytes()==(pkg/fn).read_bytes()
check(pkg/f'nonintegral_triangle_{pid}.json')

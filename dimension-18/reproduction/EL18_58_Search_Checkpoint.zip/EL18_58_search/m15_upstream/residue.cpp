#include <cstdio>
#include <cstdint>
using I=int64_t;
int main(){
 const int n=57;unsigned char bytes[200];
 while(fread(bytes,1,200,stdin)==200){
  I m[n][n],m2[n][n],m3[n][n],m4[n][n];
  int q=0;
  for(int i=0;i<n;i++){m[i][i]=1;for(int j=i+1;j<n;j++,q++)m[i][j]=m[j][i]=2*((bytes[q/8]>>(7-q%8))&1)-1;}
  auto mul=[&](I a[][n],I b[][n],I c[][n]){for(int i=0;i<n;i++)for(int j=0;j<=i;j++){I z=0;for(int k=0;k<n;k++)z+=a[i][k]*b[j][k];c[i][j]=c[j][i]=z;}};
  auto dot=[&](I a[][n],I b[][n]){I v=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++)v+=a[i][j]*b[i][j];return v;};
  mul(m,m,m2);mul(m2,m,m3);mul(m2,m2,m4);
  I traces[]={0,n,dot(m,m),dot(m,m2),dot(m2,m2),dot(m2,m3),dot(m3,m3),dot(m3,m4)},s[8]={1};
  for(int i=1;i<=7;i++){I v=0;for(int j=1;j<=i;j++)v-=s[i-j]*traces[j];if(v%i)return 1;s[i]=v/i;}
  for(auto a:s)printf("%d ",int((a%128+128)%128));puts("");
 }
}

# Why spectrum 0021 necessarily produces the signed 4 by 4 core

This supplement covers the implication from the full 58-line spectrum to the occupation search. The reverse construction in the previous report is independent.

Let \(R\) be the rank-15 spectral projector for 11, \(X=256R\). The 11-coordinate physical Gram contribution to \(5I+S\) is \(X/16\). The simple eigenvalue 15 can be switched with coordinates \(1,0,1,2\) on \(A,B,C,D\), respectively, up to a common factor. Their squared sum is 40; the corresponding physical Gram contribution is \(aa^\top/2\).

For \(t^2+t-8=0\), use a simple-eigenvector coordinate on one vertex of \(B\) as the unit. The \(A\) coordinates vanish. On \(B\) the remaining switching freedom gives coordinate 1 everywhere. On \(C,D\) the ratios are \(\pm(1-t),\pm(4-t)\), respectively, since the anchor deletion polynomial at the quadratic root equals \(t\), and its pair polynomials give \(\pm(2t-8)=\pm t(1-t)\) and \(\pm(5t-8)=\pm t(4-t)\). Although each choice is obtained up to sign, each real coordinate ratio is a polynomial value in the same field using the same orientation of both vertices; conjugation consequently preserves that chosen sign. Orthogonality to \(a\) forces
\[
c(1-t)+2d(4-t)=0,\qquad c=|C_+|-|C_-|,\ d=|D_+|-|D_-|.
\]
Since \(t\) is irrational, \(c=d=0\). Thus there are two four-point \(C\)-groups. Both \(D\) points have zero 11-projection by the diagonal of \(X\).

On each \(C\) row, exactly three \(C\)-neighbors use the pair polynomial with \(Q(0)=-16,Q(2)=-2\), four use \(Q(0)=0,Q(2)=2\), and none uses the third polynomial. The eigenvalue-15 switching fixes the signs so that the nonzero entries of \(X_{CC}\) are \(-16\). The rank-one quadratic pair products identify the first three as the vertices of the same \(C\)-group: the first polynomial is congruent to \(12(t-2)\); the second is \(-12(t-2)\) after multiplying by the sign fixed at 15. Thus the \(X_{CC}/16\) Gram is a direct sum of \(4I-J\) blocks. Let \(u_{+,i},u_{-,j}\) denote the resulting tetrahedron vertices. Each tetrahedron has vertex sum zero.

On \(A\), the two within-cell values of \(X\), after eigenvalue-15 switching, are \(8,-24\). On \(B\) one obtains the same two values by the quadratic-root switching, since the corresponding polynomials reduce to \(t,-t\) there. Both mean counts of the latter value are 8, and the diagonal is 72. Hence for either cell \(F=A,B\),
\[
 {\bf1}_F^\top X{\bf1}_F
 =24\bigl(72+15\cdot8-8\cdot24\bigr)=0.
\]
Positive semidefiniteness gives \(X{\bf1}_F=0\). After restricting to \(A\cup B\), the other three eigendirections give two orthogonal constant directions \(g_A/\sqrt2,g_B/\sqrt2\) on their respective cells. Indeed the 15-eigenvector contributes only on \(A\), and both conjugate quadratic eigenvectors are constant on \(B\) and zero on \(A\). The squared lengths of these constant contributions are \(5-72/16=1/2\). Vanishing of \(X{\bf1}_F\) makes the mixed terms of the restricted frame operator zero.

On both \(C\)-tetrahedra, each \(A\) row has physical products \(1/2\) or \(-3/2\). Their sum is zero, so there is exactly one exceptional \(-3/2\) entry. The orthogonal projection onto the tetrahedron span therefore equals \(v_{\pm,i}:=-u_{\pm,i}/2\). For \(B\) rows, reduce the two \(B,C\) pair polynomials modulo the quadratic: the possibilities before applying the edge sign are \(2t-8\) with constant 24 and \(-(2t-8)\) with constant 8. For \(C_+\) the physical products are \(3/2,-1/2\); for \(C_-\) these signs reverse. Consequently the two projections of a \(B\) row are \(-v_{+,i},v_{-,j}\).

The 11-coordinate full frame operator is \(16I_{15}\). Deleting \(C,D\) subtracts \(4I\) on each tetrahedron span, since the nonzero eigenvalues of \(4I-J\) are 4; the orthogonal nine-space retains frame eigenvalue 16. Each constant direction on \(A\) or \(B\) separately has frame eigenvalue \(24/2=12\). The resulting core has frame eigenvalues \(12^{(8)},16^{(9)}\). Put
\[
 E_j=v_{-,j}+\frac{g_A+g_B}{2\sqrt2},\qquad
 F_i=v_{+,i}+\frac{g_A-g_B}{2\sqrt2}.
\]
The \(E_j,F_i\) are eight orthonormal vectors, since the Gram of the \(v\)'s is \(I-J/4\) on each block and the blocks are orthogonal. The projection of an \(A\) row is \(E_j+F_i\), that of a \(B\) row is \(E_j-F_i\). The core is therefore necessarily of the signed grid form. Its projection frame is \(12I_8\); off-diagonal cross entries give equality of the two sign populations in each cell and the diagonal entries give margins 6 per sign. Thus deleting the two forced small classes and applying the exhaustive grid obstruction would exclude this entire parent spectrum.

# Parent-to-core audit for the remaining multiplicity-15 spectrum

Run `python3 upstream.py` using standard Python 3.9+ and a C++17 compiler named `c++`. All source files and certificates are included. This regenerates the order-57 residue classes from 2,048 explicit Seidel matrices using Newton identities, reconstructs the 42 one-point candidates for profile 0021, checks all 528 two-point tables after the rank-one filter, rechecks exact separator certificates for the triangle stage, and enumerates every remaining integral deck and all its feasible row counts. Input files are copied into a temporary directory when the original triangle checker writes its diagnostic output.

The geometry needed to pass from this verified data to the signed grid of 48 lines is given in `geometry.md`. This package proves the grid condition is necessary for this spectrum. It does not itself test the 4 by 4 grids.

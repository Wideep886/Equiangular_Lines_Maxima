#!/usr/bin/env python3
"""Exact one-vertex deletion decks for the 28 integral n=58 moment profiles.

Enumeration and all pruning use integers. SciPy only proposes LP results;
every reported LP result is checked using exact fractions. No Seidel matrix
realizability is claimed for a surviving deck.

For distinct eigenvalues r_0<...<r_d, remove one copy of each eigenvalue
from the parent polynomial to obtain F. Every deletion polynomial is F*h,
where h has degree d and interlaces the r_i. Its first three coefficients
are fixed by tr(S[i])=0 and tr(S[i]^2)=57*56. Write
H(y)=h(2*y-1)/2**(d-1). The weak type-2 condition for odd order 57 is
exactly H in Z[y], with leading coefficient 2, since the corresponding
transformed F is monic over Z. Thus H has d-2 unknown integer coefficients.

Alternating signs H((r_i+1)/2) give an exact bounded rational polytope.
Fourier-Motzkin projections give complete integer point enumeration.
We then impose the three Eulerian-graph congruences in Lemma 1 of
integral_spectra_algebraic_eliminations.pdf (valid for every odd order).
The LP asks if 58 nonnegative real vertex-type multiplicities can sum to
the derivative polynomial. Feasibility is only a necessary condition.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
from functools import reduce
from itertools import product
import json
from math import comb, gcd, isqrt
from pathlib import Path
import random
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"


def mul(a, b, limit=None):
    length = len(a) + len(b) - 1
    if limit is not None:
        length = min(length, limit)
    result = [0] * length
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            if i + j < length:
                result[i + j] += x * y
    return result


def evalpoly(a, x):
    value = 0
    for c in a:
        value = value * x + c
    return value


def normalize(rows):
    """Rows encode a*x <= b; divide positive gcd and retain tight duplicates."""
    best = {}
    for coefficients, rhs in rows:
        coefficients = tuple(coefficients)
        factor = reduce(gcd, (abs(v) for v in (*coefficients, rhs)), 0)
        if factor:
            coefficients = tuple(v // factor for v in coefficients)
            rhs //= factor
        if not any(coefficients):
            if rhs < 0:
                return [(coefficients, rhs)]
            continue
        if coefficients not in best or rhs < best[coefficients]:
            best[coefficients] = rhs
    return [(a, b) for a, b in sorted(best.items())]


def eliminate_last(rows):
    positive = [(a, b) for a, b in rows if a[-1] > 0]
    negative = [(a, b) for a, b in rows if a[-1] < 0]
    result = [(a[:-1], b) for a, b in rows if not a[-1]]
    for a, b in positive:
        for c, e in negative:
            result.append((tuple((-c[-1]) * x + a[-1] * y
                                 for x, y in zip(a[:-1], c[:-1])),
                           (-c[-1]) * b + a[-1] * e))
    return normalize(result)


def integer_points(rows, dimension, counters):
    projections = {dimension: normalize(rows)}
    for size in range(dimension, 0, -1):
        projections[size - 1] = eliminate_last(projections[size])
    counters["projection_inequalities"] = {
        str(size): len(values) for size, values in projections.items()}
    counters["prefix_nodes"] = [0] * (dimension + 1)
    if any(rhs < 0 for a, rhs in projections[0]):
        return

    def recurse(prefix):
        size = len(prefix)
        counters["prefix_nodes"][size] += 1
        if size == dimension:
            yield prefix
            return
        lower, upper = None, None
        for a, rhs in projections[size + 1]:
            rhs -= sum(x * y for x, y in zip(a, prefix))
            coefficient = a[-1]
            if coefficient > 0:
                bound = rhs // coefficient
                upper = bound if upper is None else min(upper, bound)
            elif coefficient < 0:
                bound = -((-rhs) // coefficient)
                lower = bound if lower is None else max(lower, bound)
            elif rhs < 0:
                return
        if lower is None or upper is None:
            raise AssertionError("interlacing coefficient polytope is not bounded")
        for value in range(lower, upper + 1):
            yield from recurse(prefix + [value])

    yield from recurse([])


def exact_solve(matrix, rhs):
    """RREF over Q; set free variables to zero; return None if inconsistent."""
    n = len(matrix[0])
    rows = [[Fraction(x) for x in row] + [Fraction(b)]
            for row, b in zip(matrix, rhs)]
    pivot_columns = []
    index = 0
    for column in range(n):
        pivot = next((i for i in range(index, len(rows)) if rows[i][column]), None)
        if pivot is None:
            continue
        rows[index], rows[pivot] = rows[pivot], rows[index]
        scale = rows[index][column]
        rows[index] = [x / scale for x in rows[index]]
        for i in range(len(rows)):
            if i != index and rows[i][column]:
                scale = rows[i][column]
                rows[i] = [x - scale * y for x, y in zip(rows[i], rows[index])]
        pivot_columns.append(column)
        index += 1
    if any(not any(row[:n]) and row[n] for row in rows):
        return None
    answer = [Fraction(0)] * n
    for i, column in enumerate(pivot_columns):
        answer[column] = rows[i][n]
    return answer


def check_farkas(columns, target, y):
    return (y is not None
            and all(sum(a * b for a, b in zip(column, y)) >= 0
                    for column in columns)
            and sum(a * b for a, b in zip(target, y)) < 0)


def lp_check(deck, target):
    if not deck:
        return {"status": "infeasible", "certificate": {"kind": "empty_deck"}}
    columns = [[1] + h[3:] for h in deck]
    target = [58] + target[3:]
    # Coordinate bounds provide especially transparent exact certificates.
    for j in range(1, len(target)):
        lo, hi = min(c[j] for c in columns), max(c[j] for c in columns)
        y = [0] * len(target)
        if target[j] < 58 * lo:
            y[0], y[j] = -lo, 1
        elif target[j] > 58 * hi:
            y[0], y[j] = hi, -1
        else:
            continue
        assert check_farkas(columns, target, y)
        return {"status": "infeasible", "certificate": {
            "kind": "farkas", "coordinates": "[1,H coefficients after first three]",
            "y": list(map(str, y)),
            "target_dot_y": str(sum(a * b for a, b in zip(target, y)))}}

    import numpy as np
    from scipy.optimize import linprog
    A = np.array(columns, dtype=float).T
    b = np.array(target, dtype=float)
    scale = np.maximum(1.0, np.max(np.abs(A), axis=1))
    proposal = linprog(np.zeros(len(columns)), A_eq=A / scale[:, None],
                       b_eq=b / scale, bounds=(0, None), method="highs")
    if proposal.success:
        support = [i for i, x in enumerate(proposal.x) if x > 1e-8]
        exact = exact_solve([[columns[i][j] for i in support]
                             for j in range(len(target))], target)
        if exact is None or any(x < 0 for x in exact):
            raise AssertionError("LP primal proposal did not verify exactly")
        assert all(sum(columns[i][j] * x for i, x in zip(support, exact)) == target[j]
                   for j in range(len(target)))
        return {"status": "feasible_relaxation", "certificate": {
            "kind": "rational_vertex_type_counts",
            "support": [{"deck_index": i, "count": str(x)}
                        for i, x in zip(support, exact)]}}

    # Obtain an explicit separating functional; do not trust numerical status.
    dual = linprog(np.zeros(len(target)), A_ub=-A.T, b_ub=np.zeros(len(columns)),
                   A_eq=b[None, :], b_eq=[-1.0],
                   bounds=[(None, None)] * len(target), method="highs")
    if not dual.success:
        raise AssertionError("no LP result has an exact certificate yet")
    for denominator in [100, 10000, 1000000, 1000000000]:
        y = [Fraction(float(x)).limit_denominator(denominator) for x in dual.x]
        if check_farkas(columns, target, y):
            break
    else:
        active = [column for column in columns
                  if abs(sum(a * b for a, b in zip(column, dual.x))) < 1e-7]
        y = exact_solve([target] + active, [-1] + [0] * len(active))
        if not check_farkas(columns, target, y):
            raise AssertionError("LP dual proposal did not verify exactly")
    return {"status": "infeasible", "certificate": {
        "kind": "farkas", "coordinates": "[1,H coefficients after first three]",
        "y": list(map(str, y)),
        "target_dot_y": str(sum(a * b for a, b in zip(target, y)))}}


def spectrum_deck(profile, index):
    start = time.monotonic()
    multiplicities = dict(sorted(Counter([-5] * 40 + profile).items()))
    roots = list(multiplicities)
    knots = [(r + 1) // 2 for r in roots]
    d = len(roots) - 1
    sum_h_roots = sum(roots)
    square_h_roots = 57 * 56 - (58 * 57 - sum(r * r for r in roots))
    h1 = -sum_h_roots
    h2 = (sum_h_roots ** 2 - square_h_roots) // 2
    numerator = comb(d, 2) - (d - 1) * h1 + h2
    assert numerator % 2 == 0
    fixed = [2, h1 - d, numerator // 2]
    rows = []
    for i, t in enumerate(knots):
        sign = (-1) ** (d - i)
        constant = evalpoly(fixed, t) * t ** (d - 2)
        a = [-sign * t ** power for power in range(d - 3, -1, -1)]
        # Strict at the smallest root follows from N(17)=48 <57.
        rows.append((a, sign * constant - (1 if i == 0 else 0)))
    F = [1]
    for r, m in multiplicities.items():
        for _ in range(m - 1):
            F = mul(F, [1, -(r + 1) // 2], 8)
    target = [0] * (d + 1)
    for i, r in enumerate(roots):
        term = [1]
        for j, t in enumerate(knots):
            if i != j:
                term = mul(term, [1, -t])
        for j, value in enumerate(term):
            target[j] += 2 * multiplicities[r] * value
    assert target[:3] == [58 * c for c in fixed]
    residue_file = OUT / "residues_n57_mod128.json"
    residue_data = json.loads(residue_file.read_text())
    assert residue_data["complete"] and residue_data["n"] == 57 and residue_data["modulus"] == 128
    residue_classes = {tuple(item["coefficients"]) for item in residue_data["classes"]}
    assert len(residue_classes) == residue_data["upper_bound"] == 2048
    counters = {"interlacing_weak_type2": 0, "eulerian_survivors": 0,
                "complete_mod128_survivors": 0}
    deck = []
    for unknown in integer_points(rows, d - 2, counters):
        H = fixed + unknown
        assert all(sum(a * b for a, b in zip(row, unknown)) <= rhs
                   for row, rhs in rows)
        counters["interlacing_weak_type2"] += 1
        top = mul(F, H, 8)
        # a3=4*top[3], a4=8*top[4], a5=16*top[5].
        b2 = -top[3] % 4  # 57 == 1 mod 4.
        if top[4] % 2 or (2 * top[5] - b2 * (b2 - 1)) % 4:
            continue
        counters["eulerian_survivors"] += 1
        residue = (1,) + tuple((top[j] * 2 ** (j - 1)) % 128 for j in range(1, 8))
        if residue not in residue_classes:
            continue
        deck.append(H)
    counters["complete_mod128_survivors"] = len(deck)
    result = {
        "profile_id": index, "spectrum": {str(k): v for k, v in multiplicities.items()},
        "distinct_eigenvalues": len(roots), "transformed_knots": knots,
        "H_fixed_coefficients": fixed, "target_H_sum": target,
        "complete_enumeration": True, "constraints": [
            "one-vertex interlacing", "trace=0", "trace_square=57*56",
            "odd-order weak type-2", "odd-order Eulerian Lemma 1",
            "complete P_57,7 residue classes from residues_n57_mod128.json",
            "rank18: deletion multiplicity at -5 is 39"],
        "counts": counters,
    }
    result["lp"] = lp_check(deck, target)
    result["elapsed_seconds"] = round(time.monotonic() - start, 4)
    path = OUT / ("decks_%02d.json" % index)
    path.write_text(json.dumps({"metadata": result, "H_deck": deck}, indent=2) + "\n")
    return result


def rank1_attack():
    """Exhaust the possible primitive integer lines of each simple eigenspace.

For r simple, X=sign(m'(r))*prod_(s!=r)(S-sI)/2^(e-2)=c*P_r
is an integral rank-one PSD matrix. Hence X=k*u*u^T with u primitive
integral and k a positive divisor of c. Its norm c/k is even (S+I=J mod2)
and at least r+1 (an eigenvector support has >=r+1 entries). Each diagonal
is k times a square. Branch jointly over all simple eigenvalues. A branch
is pruned only by an exact LP certificate; a survivor is only a relaxation.
"""
    results = []
    for index in range(1, 29):
        start = time.monotonic()
        saved = json.loads((OUT / ("decks_%02d.json" % index)).read_text())
        metadata, deck = saved["metadata"], saved["H_deck"]
        knots = metadata["transformed_knots"]
        mult = {int(r): m for r, m in metadata["spectrum"].items()}
        projections = []
        for r, multiplicity in mult.items():
            if multiplicity != 1:
                continue
            t = (r + 1) // 2
            delta = reduce(lambda a, b: a * b, (t - u for u in knots if t != u), 1)
            c = 2 * abs(delta)
            diagonals = [(1 if delta > 0 else -1) * evalpoly(H, t) for H in deck]
            assert all(0 <= v <= c for v in diagonals)
            options = []
            for k in range(1, c + 1):
                if c % k:
                    continue
                norm = c // k
                if norm % 2 or norm < r + 1:
                    continue
                # A support of size p >= r+1 uses at least p-1 other
                # nonzero integer coordinates. Also the eigenvector row
                # equation and Cauchy give r^2*u_i^2 <= 57*(norm-u_i^2).
                max_square = min(norm - r, 57 * norm // (r * r + 57))
                allowed = [i for i, v in enumerate(diagonals)
                           if v % k == 0 and v // k <= max_square
                           and isqrt(v // k) ** 2 == v // k]
                amplitudes = {isqrt(diagonals[i] // k) for i in allowed if diagonals[i]}
                # If all available nonzero coordinates have a common divisor,
                # no primitive generator exists for this k.
                if not amplitudes or reduce(gcd, amplitudes, 0) != 1:
                    continue
                options.append({"k": k, "norm": norm, "max_coordinate_square": max_square,
                                "allowed": allowed})
            projections.append({"eigenvalue": r, "c": c, "options": options})
        projections.sort(key=lambda p: len(p["options"]))
        nodes = []

        def search(level, allowed, prefix):
            subset = [deck[i] for i in allowed]
            lp = lp_check(subset, metadata["target_H_sum"])
            if lp["certificate"]["kind"] == "rational_vertex_type_counts":
                for item in lp["certificate"]["support"]:
                    item["deck_index"] = allowed[item["deck_index"]]
            node = {"prefix": prefix, "allowed_deck_count": len(allowed), "lp": lp}
            nodes.append(node)
            if lp["status"] == "infeasible":
                return False
            if level == len(projections):
                return True
            projection = projections[level]
            for option in projection["options"]:
                allowed_set = set(option["allowed"])
                reduced = [i for i in allowed if i in allowed_set]
                if search(level + 1, reduced,
                          prefix + [{"eigenvalue": projection["eigenvalue"], "k": option["k"]}]):
                    return True
            return False

        survives = search(0, list(range(len(deck))), [])
        serialized = [{"eigenvalue": p["eigenvalue"], "c": p["c"],
                       "options": [{"k": o["k"], "norm": o["norm"],
                                    "max_coordinate_square": o["max_coordinate_square"],
                                    "allowed_deck_count": len(o["allowed"])} for o in p["options"]]}
                      for p in projections]
        result = {"profile_id": index, "spectrum": metadata["spectrum"],
                  "status": "survives_rank1_relaxation" if survives else "eliminated",
                  "projections": serialized, "nodes": nodes,
                  "elapsed_seconds": round(time.monotonic() - start, 4)}
        (OUT / ("decks_rank1_%02d.json" % index)).write_text(json.dumps(result, indent=2) + "\n")
        results.append({k: v for k, v in result.items() if k != "nodes"})
        (OUT / "deck_rank1_results.json").write_text(json.dumps(results, indent=2) + "\n")
        print(json.dumps({"id": index, "status": result["status"], "lp_nodes": len(nodes),
                          "simple_eigenvalues": len(projections),
                          "seconds": result["elapsed_seconds"]}), flush=True)
    print("rank1 summary", dict(Counter(r["status"] for r in results)), flush=True)


def verify_outputs():
    """Independent coefficient checks and exact verification of every LP witness."""
    verified = 0
    profiles = json.loads((OUT / "deck_input_profiles.json").read_text())
    for index, profile in enumerate(profiles, 1):
        saved = json.loads((OUT / ("decks_%02d.json" % index)).read_text())
        metadata, deck = saved["metadata"], saved["H_deck"]
        assert len(deck) == len(set(map(tuple, deck)))
        mult = dict(sorted(Counter([-5] * 40 + profile).items()))
        F = [1]
        for r, multiplicity in mult.items():
            for _ in range(multiplicity - 1):
                F = mul(F, [1, -r], 8)
        knots = metadata["transformed_knots"]
        for H in deck:
            d = len(H) - 1
            # Expand h(x)=2^(d-1)*H((x+1)/2), independently of
            # the direct transformed-coefficient congruences used above.
            h = [sum((H[j] // 2 if j == 0 else H[j] * 2 ** (j - 1))
                     * comb(d - j, k - j) for j in range(k + 1))
                 for k in range(d + 1)]
            f = mul(F, h, 8)
            assert f[:3] == [1, 0, -57 * 56 // 2]
            shifted = [sum(f[j] * comb(57 - j, k - j) * (-1) ** (k - j)
                           for j in range(k + 1)) for k in range(8)]
            assert shifted[3] % 4 == 0 and shifted[4] % 16 == 0
            graph_b2 = (-shifted[3] // 4) % 4
            assert (shifted[5] - 8 * graph_b2 * (graph_b2 - 1)) % 32 == 0
            residues_file = json.loads((OUT / "residues_n57_mod128.json").read_text()) if verified == 0 else None
            if residues_file is not None:
                residue_classes = {tuple(item["coefficients"]) for item in residues_file["classes"]}
            assert tuple(a % 128 for a in shifted) in residue_classes
            # Positive residues characterize weak interlacing; their sum is 2.
            residues = [Fraction(evalpoly(H, t),
                                 reduce(lambda a, b: a * b,
                                        (t - u for u in knots if u != t), 1))
                        for t in knots]
            assert all(r >= 0 for r in residues) and sum(residues) == 2
            assert residues[0] > 0
            verified += 1
        columns = [[1] + h[3:] for h in deck]
        target = [58] + metadata["target_H_sum"][3:]
        certificate = metadata["lp"]["certificate"]
        if certificate["kind"] == "farkas":
            assert check_farkas(columns, target, list(map(Fraction, certificate["y"])))
        elif certificate["kind"] == "rational_vertex_type_counts":
            support = certificate["support"]
            assert all(Fraction(item["count"]) >= 0 for item in support)
            assert all(sum(columns[item["deck_index"]][j] * Fraction(item["count"])
                           for item in support) == target[j] for j in range(len(target)))
        else:
            assert certificate["kind"] == "empty_deck" and not deck

    # Independently brute-force bounded random polytopes in all relevant
    # dimensions; this also exercises fractional and negative bound rounding.
    rng = random.Random(58018)
    tests = 0
    for dimension in range(1, 5):
        for trial in range(10):
            rows = []
            for j in range(dimension):
                unit = [int(i == j) for i in range(dimension)]
                rows += [(unit, 2), ([-a for a in unit], 2)]
            for _ in range(4):
                rows.append(([rng.randint(-4, 4) for _ in range(dimension)],
                             rng.randint(-5, 10)))
            brute = {v for v in product(range(-2, 3), repeat=dimension)
                     if all(sum(a * b for a, b in zip(row, v)) <= rhs
                            for row, rhs in rows)}
            projected = set(map(tuple, integer_points(rows, dimension, {})))
            assert brute == projected
            tests += 1
    result = {"verified_profiles": len(profiles), "verified_deck_polynomials": verified,
              "verified_lp_certificates": len(profiles),
              "independent_bounded_polytope_checks": tests,
              "all_checks_passed": True}
    (OUT / "deck_verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


def verify_rank1_outputs():
    node_count = 0
    eliminated = []
    for index in range(1, 29):
        base = json.loads((OUT / ("decks_%02d.json" % index)).read_text())
        saved = json.loads((OUT / ("decks_rank1_%02d.json" % index)).read_text())
        deck, metadata = base["H_deck"], base["metadata"]
        roots = list(map(int, metadata["spectrum"]))
        d = len(roots) - 1
        content = 2 ** (d - 1)
        # Reconstruct h in the original x variable and calculate actual
        # m'(r)/content instead of reusing the transformed formulas.
        original_deck = [[sum((H[j] // 2 if j == 0 else H[j] * 2 ** (j - 1))
                              * comb(d - j, k - j) for j in range(k + 1))
                          for k in range(d + 1)] for H in deck]
        allowed_by_choice = {}
        for projection in saved["projections"]:
            r = projection["eigenvalue"]
            delta = reduce(lambda a, b: a * b, (r - s for s in roots if s != r), 1)
            assert delta % content == 0
            c = abs(delta) // content
            assert c == projection["c"]
            diagonal = []
            for h in original_deck:
                value = (1 if delta > 0 else -1) * evalpoly(h, r)
                assert value % content == 0
                diagonal.append(value // content)
            expected = []
            for k in range(1, c + 1):
                if c % k or (c // k) % 2 or c // k < r + 1:
                    continue
                norm = c // k
                max_square = min(norm - r, 57 * norm // (r * r + 57))
                allowed = {i for i, v in enumerate(diagonal)
                           if v % k == 0 and v // k <= max_square
                           and isqrt(v // k) ** 2 == v // k}
                amplitudes = {isqrt(diagonal[i] // k) for i in allowed if diagonal[i]}
                if not amplitudes or reduce(gcd, amplitudes, 0) != 1:
                    continue
                expected.append({"k": k, "norm": norm,
                                 "max_coordinate_square": max_square,
                                 "allowed_deck_count": len(allowed)})
                allowed_by_choice[r, k] = allowed
            assert projection["options"] == expected

        columns = [[1] + H[3:] for H in deck]
        target = [58] + metadata["target_H_sum"][3:]
        nodes = {}
        full_witness = False
        for node in saved["nodes"]:
            key = tuple((item["eigenvalue"], item["k"]) for item in node["prefix"])
            assert key not in nodes
            nodes[key] = node
            allowed = set(range(len(deck)))
            for choice in key:
                allowed.intersection_update(allowed_by_choice[choice])
            assert len(allowed) == node["allowed_deck_count"]
            certificate = node["lp"]["certificate"]
            if certificate["kind"] == "farkas":
                y = list(map(Fraction, certificate["y"]))
                assert check_farkas([columns[i] for i in allowed], target, y)
                assert node["lp"]["status"] == "infeasible"
            elif certificate["kind"] == "empty_deck":
                assert not allowed and node["lp"]["status"] == "infeasible"
            else:
                assert certificate["kind"] == "rational_vertex_type_counts"
                support = certificate["support"]
                assert all(item["deck_index"] in allowed and Fraction(item["count"]) >= 0
                           for item in support)
                assert all(sum(columns[item["deck_index"]][j] * Fraction(item["count"])
                               for item in support) == target[j] for j in range(len(target)))
                if len(key) == len(saved["projections"]):
                    full_witness = True
            node_count += 1

        def covered(prefix):
            node = nodes[prefix]
            if node["lp"]["status"] == "infeasible":
                return True
            level = len(prefix)
            if level == len(saved["projections"]):
                return False
            projection = saved["projections"][level]
            return all(covered(prefix + ((projection["eigenvalue"], option["k"]),))
                       for option in projection["options"])

        if saved["status"] == "eliminated":
            assert covered(()) and not full_witness
            eliminated.append(index)
        else:
            assert full_witness
    result = {"verified_profiles": 28, "verified_lp_nodes": node_count,
              "eliminated_profiles": eliminated, "complete_branch_cover_verified": True,
              "all_checks_passed": True}
    (OUT / "deck_rank1_verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--profiles", default=str(OUT / "deck_input_profiles.json"))
    parser.add_argument("--only", type=int, nargs="*")
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--rank1", action="store_true")
    parser.add_argument("--verify-rank1", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.verify:
        verify_outputs()
        return
    if args.rank1:
        rank1_attack()
        return
    if args.verify_rank1:
        verify_rank1_outputs()
        return
    profiles = json.loads(Path(args.profiles).read_text())
    assert len(profiles) == 28
    assert all(len(p) == 18 and sum(p) == 200 and sum(x * x for x in p) == 2306
               and all(x > -5 and x % 2 for x in p) for p in profiles)
    (OUT / "deck_input_profiles.json").write_text(json.dumps(profiles, indent=2) + "\n")
    results = []
    for i, profile in enumerate(profiles, 1):
        if args.only and i not in args.only:
            continue
        print("starting profile %02d: %s" % (i, dict(sorted(Counter(profile).items()))), flush=True)
        result = spectrum_deck(profile, i)
        results.append(result)
        (OUT / "deck_results.json").write_text(json.dumps(results, indent=2) + "\n")
        print(json.dumps({"id": i, "counts": result["counts"],
                          "lp": result["lp"]["status"], "seconds": result["elapsed_seconds"]}), flush=True)
    print("summary", dict(Counter(r["lp"]["status"] for r in results)), flush=True)


if __name__ == "__main__":
    main()

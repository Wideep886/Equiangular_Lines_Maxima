#!/usr/bin/env python3
"""Complete one-deletion decks for an explicitly bounded nonintegral subclass.

Input: n=58 profiles whose normalized t=(x-11)/2 factors are linear or
quadratic and contain exactly one distinct irreducible quadratic. Its
multiplicity is unrestricted. All interlacing and Fourier--Motzkin steps
use exact Q(sqrt(discriminant)) arithmetic. No float is used to prune.
SciPy LP proposals are checked by deck_attack.lp_check using exact Q
primal/Farkas certificates; a numerical result alone cannot exclude a case.

This enumerates complete deletion decks for each selected input profile.
It does NOT assert that the selected profiles exhaust all n=58 spectra.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction as F
import json
from math import comb, isqrt, lcm
from pathlib import Path
import re
import time

from deck_attack import mul, lp_check, check_farkas


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"


@dataclass(frozen=True)
class Q:
    """a+b*sqrt(D), with exact rational coefficients and nonsquare D>0."""
    a: F
    b: F
    D: int

    def __post_init__(self):
        object.__setattr__(self, "a", F(self.a))
        object.__setattr__(self, "b", F(self.b))

    def coerce(self, v):
        if isinstance(v, Q):
            if self.D != v.D:
                raise ValueError("Different quadratic fields")
            return v
        return Q(v, 0, self.D)

    def __add__(self, v):
        v = self.coerce(v)
        return Q(self.a + v.a, self.b + v.b, self.D)

    __radd__ = __add__

    def __neg__(self):
        return Q(-self.a, -self.b, self.D)

    def __sub__(self, v):
        return self + (-self.coerce(v))

    def __rsub__(self, v):
        return self.coerce(v) - self

    def __mul__(self, v):
        v = self.coerce(v)
        return Q(self.a * v.a + self.b * v.b * self.D,
                 self.a * v.b + self.b * v.a, self.D)

    __rmul__ = __mul__

    def __truediv__(self, v):
        v = self.coerce(v)
        denominator = v.a*v.a - self.D*v.b*v.b
        if not denominator:
            raise ZeroDivisionError
        return Q((self.a*v.a-self.D*self.b*v.b)/denominator,
                 (self.b*v.a-self.a*v.b)/denominator, self.D)

    def __pow__(self, exponent):
        if exponent < 0:
            return self.coerce(1) / self**(-exponent)
        result, base = self.coerce(1), self
        while exponent:
            if exponent & 1:
                result = result * base
            exponent >>= 1
            base = base * base
        return result

    def sign(self):
        if not self.b:
            return (self.a > 0) - (self.a < 0)
        if not self.a:
            return (self.b > 0) - (self.b < 0)
        if self.a > 0 and self.b > 0:
            return 1
        if self.a < 0 and self.b < 0:
            return -1
        difference = self.a*self.a - self.D*self.b*self.b
        if not difference:
            raise AssertionError("D must be nonsquare")
        return ((difference > 0) - (difference < 0)) * (1 if self.a > 0 else -1)

    def __bool__(self):
        return bool(self.a or self.b)

    def __lt__(self, v):
        return (self-v).sign() < 0

    def __le__(self, v):
        return (self-v).sign() <= 0

    def __gt__(self, v):
        return (self-v).sign() > 0

    def __ge__(self, v):
        return (self-v).sign() >= 0

    def floor(self):
        # Integer sqrt bounds and binary search; no floating approximation.
        s = isqrt(self.D)
        ends = [self.a + self.b*s, self.a + self.b*(s+1)]
        lo = min(ends).numerator // min(ends).denominator
        hi = max(ends).numerator // max(ends).denominator + 1
        while hi-lo > 1:
            mid = (lo+hi)//2
            if self >= mid:
                lo = mid
            else:
                hi = mid
        assert self >= lo and self < lo+1
        return lo

    def ceil(self):
        return -(-self).floor()

    def encoded(self):
        return [str(self.a), str(self.b)]


def normalize(rows):
    """Positive rescaling and exact duplicate-inequality elimination."""
    best = {}
    for a, b in rows:
        first = next((v for v in a if v), None)
        if first is None:
            if b < 0:
                return [(a, b.coerce(-1))]
            continue
        scale = first if first > 0 else -first
        a = tuple(v/scale for v in a)
        b = b/scale
        if a not in best or b < best[a]:
            best[a] = b
    return list(best.items())


def eliminate_last(rows):
    positive = [(a, b) for a, b in rows if a[-1] > 0]
    negative = [(a, b) for a, b in rows if a[-1] < 0]
    result = [(a[:-1], b) for a, b in rows if not a[-1]]
    for a, b in positive:
        for c, e in negative:
            result.append((tuple((-c[-1])*x+a[-1]*y for x, y in zip(a[:-1], c[:-1])),
                           (-c[-1])*b+a[-1]*e))
    return normalize(result)


def integer_affine(values):
    """Common-denominator encoding of an affine quadratic-field expression."""
    denominator = lcm(*(v.a.denominator for v in values),
                      *(v.b.denominator for v in values))
    return ([(int(v.a*denominator), int(v.b*denominator)) for v in values],
            denominator, values[0].D)


def floor_affine(encoded, prefix, negate=False):
    pairs, denominator, discriminant = encoded
    a = pairs[0][0] + sum(c[0]*v for c, v in zip(pairs[1:], prefix))
    b = pairs[0][1] + sum(c[1]*v for c, v in zip(pairs[1:], prefix))
    if negate:
        a, b = -a, -b
    # D is nonsquare; for nonzero b, b*sqrt(D) is never an integer.
    radical_floor = (isqrt(b*b*discriminant) if b > 0
                     else -isqrt(b*b*discriminant)-1 if b < 0 else 0)
    return (a+radical_floor)//denominator


def integer_points(rows, dimension, counters):
    projections = {dimension: normalize(rows)}
    for size in range(dimension, 0, -1):
        projections[size-1] = eliminate_last(projections[size])
    counters["projection_inequalities"] = {str(k): len(v) for k, v in projections.items()}
    counters["prefix_nodes"] = [0]*(dimension+1)
    if any(b < 0 for a, b in projections[0]):
        return
    # Divide each bounding row once, then evaluate integer affine functions.
    # floor((a+b*sqrt(D))/L)=(a+floor(b*sqrt(D)))//L exactly.
    bounds = {}
    for size in range(1, dimension+1):
        bounds[size] = []
        for a, b in projections[size]:
            coefficient = a[-1]
            direction = coefficient.sign()
            values = ([b/coefficient]+[-v/coefficient for v in a[:-1]]
                      if direction else [b]+[-v for v in a[:-1]])
            bounds[size].append((direction, integer_affine(values)))

    def recurse(prefix):
        size = len(prefix)
        counters["prefix_nodes"][size] += 1
        if size == dimension:
            yield prefix
            return
        lower, upper = None, None
        for direction, encoded in bounds[size+1]:
            if direction > 0:
                bound = floor_affine(encoded, prefix)
                upper = bound if upper is None else min(upper, bound)
            elif direction < 0:
                bound = -floor_affine(encoded, prefix, negate=True)
                lower = bound if lower is None else max(lower, bound)
            elif floor_affine(encoded, prefix) < 0:
                return
        if lower is None or upper is None:
            raise AssertionError("Unbounded coefficient polytope")
        for value in range(lower, upper+1):
            yield from recurse(prefix+[value])
    yield from recurse([])


def evaluate(coefficients, t):
    answer = t.coerce(0)
    for c in coefficients:
        answer = answer*t+c
    return answer


def translate(coefficients, shift):
    degree = len(coefficients)-1
    return [sum(coefficients[j]*comb(degree-j, k-j)*shift**(k-j)
                for j in range(k+1)) for k in range(degree+1)]


def addpolys(polynomials):
    length = max(map(len, polynomials))
    result = [0]*length
    for polynomial in polynomials:
        offset = length-len(polynomial)
        for i, value in enumerate(polynomial):
            result[offset+i] += value
    return result


def factors_from_profile(profile):
    factors = [(list(f["t_coefficients_descending"]), int(f["multiplicity"]))
               for f in profile["factors"]]
    degree = sum((len(f)-1)*m for f, m in factors)
    if degree == 18:
        factors.append(([1, 8], 40))
    elif degree != 58:
        raise ValueError("Expected degree18 residual or degree58 full factors")
    assert all(f[0] == 1 and all(isinstance(a, int) for a in f) for f, m in factors)
    assert len({tuple(f) for f, m in factors}) == len(factors)
    assert sum((len(f)-1)*m for f, m in factors) == 58
    assert sum(-f[1]*m for f, m in factors) == -319
    assert sum((f[1]**2-(2*f[2] if len(f)==3 else 0))*m for f, m in factors) == 2581
    return factors


def spectrum_deck(profile, residue_classes):
    start = time.monotonic()
    factors = factors_from_profile(profile)
    quadratics = [f for f, m in factors if len(f)==3]
    if len(quadratics) != 1 or any(len(f) not in (2, 3) for f, m in factors):
        raise ValueError("This exact field implementation requires one distinct quadratic")
    f = quadratics[0]
    discriminant = f[1]**2-4*f[2]
    assert discriminant > 0 and isqrt(discriminant)**2 != discriminant
    q = lambda a=0, b=0: Q(a, b, discriminant)
    knots = []
    for f, m in factors:
        if len(f)==2:
            knots.append(q(-f[1]))
        else:
            knots.extend([q(F(-f[1], 2), F(-1, 2)), q(F(-f[1], 2), F(1, 2))])
    knots.sort()
    assert knots[0] == q(-8) and all(t > -8 for t in knots[1:])
    e, degree = len(knots), len(knots)-1
    sumroots, squares = sum(knots), sum(t*t for t in knots)
    assert not sumroots.b and not squares.b
    U, V = int(sumroots.a), int(squares.a)
    assert sumroots.a == U and squares.a == V
    fixed = [2, -2*U-11, U*U+11*U-V+89]
    assert degree >= 2
    rows = []
    for i, t in enumerate(knots):
        sign = (-1)**(degree-i)
        constant = evaluate(fixed, t)*t**(degree-2)
        coefficients = tuple(-sign*t**power for power in range(degree-3, -1, -1))
        # H(-8) is an integer; rank<=17 would violate the relative bound.
        rows.append((coefficients, sign*constant-(1 if i==0 else 0)))
    # chi_S'(x)/forced_factor, after normalizing H: 2*sum m*f'*M/f.
    terms = []
    for i, (f, m) in enumerate(factors):
        degree_f = len(f)-1
        term = [2*m*(degree_f-j)*a for j, a in enumerate(f[:-1])]
        for j, (g, _) in enumerate(factors):
            if i != j:
                term = mul(term, g)
        terms.append(term)
    target = addpolys(terms)
    assert target[:3] == [58*c for c in fixed]
    # Convert t to w=(x+1)/2=t+6 for the established residue-class tables.
    forced_shifted = [1]
    for f, m in factors:
        translated = translate(f, -6)
        for _ in range(m-1):
            forced_shifted = mul(forced_shifted, translated, 8)
    counters = {"interlacing_weak_type2": 0, "eulerian_survivors": 0,
                "complete_mod128_survivors": 0}
    exact_rows = [integer_affine([rhs]+[-v for v in coefficients])
                  for coefficients, rhs in rows]
    base_H = fixed+[0]*(degree-2)
    top_base = mul(forced_shifted, translate(base_H, -6), 8)
    top_columns = []
    for j in range(degree-2):
        unit = [0]*(degree+1)
        unit[j+3] = 1
        top_columns.append(mul(forced_shifted, translate(unit, -6), 8))
    deck = []
    for unknown in integer_points(rows, degree-2, counters):
        H = fixed+unknown
        assert all(floor_affine(row, unknown) >= 0 for row in exact_rows)
        counters["interlacing_weak_type2"] += 1
        top = [top_base[j]+sum(v*column[j] for v, column in zip(unknown, top_columns))
               for j in range(8)]
        b2 = -top[3] % 4
        if top[4] % 2 or (2*top[5]-b2*(b2-1)) % 4:
            continue
        counters["eulerian_survivors"] += 1
        residue = (1,)+tuple((top[j]*2**(j-1)) % 128 for j in range(1, 8))
        if residue not in residue_classes:
            continue
        deck.append(H)
    counters["complete_mod128_survivors"] = len(deck)
    lp = lp_check(deck, target)
    metadata = {
        "profile_id": profile["id"], "n": 58,
        "profile_source": "quadratic_profiles.json",
        "source_profile": profile,
        "normalized_variable": "t=(x-11)/2",
        "full_normalized_factors": [{"coefficients_descending": f, "multiplicity": m}
                                    for f, m in factors],
        "quadratic_discriminant": discriminant,
        "knots_as_a_plus_b_sqrt_discriminant": [t.encoded() for t in knots],
        "distinct_eigenvalue_count": e,
        "H_definition": "H(t)=h(2t+11)/2^(e-2)",
        "H_fixed_coefficients": fixed, "target_H_sum": target,
        "complete_enumeration": True,
        "complete_branch_scope": "Complete enumeration of one-deletion polynomials passing the listed necessary conditions for this supplied full characteristic polynomial. A deck member is not asserted realizable. Input profile family is not all possible n=58 spectra.",
        "enumeration_arithmetic": "Exact rational pairs in Q(sqrt(D)); exact Fourier-Motzkin projection and exact integer floor/ceil; no floating-point pruning",
        "constraints": ["one-vertex interlacing", "trace=0", "trace_square=57*56",
                        "odd-order weak type-2", "Eulerian coefficient congruences",
                        "complete P_57,7 residue classes modulo128", "strict interlacing sign at -5 from rank18 relative bound"],
        "counts": counters, "lp": lp,
        "status": "ELIMINATED" if lp["status"]=="infeasible" else "SURVIVES_ONE_DELETION_RELAXATION",
        "elapsed_seconds": round(time.monotonic()-start, 4),
    }
    return {"metadata": metadata, "H_deck": deck}


def verify_lp(saved):
    metadata, deck = saved["metadata"], saved["H_deck"]
    columns = [[1]+h[3:] for h in deck]
    target = [58]+metadata["target_H_sum"][3:]
    cert = metadata["lp"]["certificate"]
    if cert["kind"] == "empty_deck":
        assert not deck
    elif cert["kind"] == "farkas":
        assert check_farkas(columns, target, list(map(F, cert["y"])))
    elif cert["kind"] == "rational_vertex_type_counts":
        assert all(F(item["count"]) >= 0 for item in cert["support"])
        assert all(sum(columns[item["deck_index"]][j]*F(item["count"])
                       for item in cert["support"]) == value
                   for j, value in enumerate(target))
    else:
        raise ValueError(cert["kind"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=OUT/"quadratic_profiles.json")
    parser.add_argument("--max-distinct", type=int, default=6)
    parser.add_argument("--min-distinct", type=int, default=0)
    parser.add_argument("--summary-name", default="nonintegral_deck_results.json")
    parser.add_argument("--max-profiles", type=int)
    parser.add_argument("--profile-id", action="append")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    profiles = data["profiles"] if isinstance(data, dict) else data
    candidates = []
    for profile in profiles:
        factors = factors_from_profile(profile)
        e = sum(len(f)-1 for f, _ in factors)
        if sum(len(f)==3 for f, _ in factors)!=1 or not args.min_distinct <= e <= args.max_distinct:
            continue
        if args.profile_id and profile["id"] not in args.profile_id:
            continue
        candidates.append((e, str(profile["id"]), profile))
    candidates.sort()
    if args.max_profiles is not None:
        candidates = candidates[:args.max_profiles]
    residues = json.loads((OUT/"residues_n57_mod128.json").read_text())
    assert residues["complete"] and residues["n"]==57 and residues["modulus"]==128
    residue_classes = {tuple(item["coefficients"]) for item in residues["classes"]}
    assert len(residue_classes)==residues["upper_bound"]==2048
    results = []
    for e, name, profile in candidates:
        safe_name = re.sub(r"[^A-Za-z0-9_-]", "_", name)
        path = OUT/f"nonintegral_deck_{safe_name}.json"
        if path.exists() and not args.force:
            saved = json.loads(path.read_text())
            assert saved["metadata"]["source_profile"] == profile, "Cached profile changed; rerun with --force"
            assert saved["metadata"]["distinct_eigenvalue_count"] == e
        else:
            saved = spectrum_deck(profile, residue_classes)
            verify_lp(saved)
            path.write_text(json.dumps(saved, indent=2)+"\n")
        verify_lp(saved)
        results.append(saved["metadata"])
        counts_by_e = {}
        for result in results:
            counts = counts_by_e.setdefault(str(result["distinct_eigenvalue_count"]),
                                            {"completed": 0, "eliminated": 0, "surviving_relaxation": 0})
            counts["completed"] += 1
            counts["eliminated" if result["status"]=="ELIMINATED" else "surviving_relaxation"] += 1
        summary_path = OUT/args.summary_name
        assert summary_path.parent == OUT and summary_path.name.startswith("nonintegral_deck_")
        summary_path.write_text(json.dumps({
            "selected_profiles_count": len(candidates), "completed_profiles_count": len(results),
            "selection_complete": len(results)==len(candidates),
            "counts_by_distinct_eigenvalues": counts_by_e,
            "eliminated_profile_ids": [r["profile_id"] for r in results if r["status"]=="ELIMINATED"],
            "total_admissible_deletion_polynomials": sum(r["counts"]["complete_mod128_survivors"] for r in results),
            "selection": {"one_distinct_quadratic": True, "min_distinct": args.min_distinct,
                          "max_distinct": args.max_distinct,
                          "max_profiles": args.max_profiles, "profile_ids": args.profile_id},
            "results": results}, indent=2)+"\n")
        print(json.dumps({"id": name, "e": e, "status": saved["metadata"]["status"],
                          "counts": saved["metadata"]["counts"],
                          "seconds": saved["metadata"]["elapsed_seconds"]}), flush=True)


if __name__ == "__main__":
    main()

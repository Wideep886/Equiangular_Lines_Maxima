"""Check the input to the exploratory 48-line-core reduction for profile 0021.

Run with the project file nonintegral_triangle_n58_d2_0021.json as argument.
The original nonintegral_pair_n58_d2_0021.json must be in the same directory.
Uses only the standard library and the neighboring verify_quadratic_0020.py.
"""
import argparse
import json
from pathlib import Path

from verify_quadratic_0020 import coefficient_gram, feasible_counts, gram_column, evaluate


def quadratic_remainder(q):
    a, b = 0, 0
    for c in q:
        a, b = b-a, 8*a+c
    return a, b


def check(path):
    triangle = json.loads(path.read_text())
    data = json.loads(path.with_name(triangle['source']).read_text())
    assert data['profile_id'] == 'n58_d2_0021'
    H, M = data['H_deck'], data['M']
    types = triangle['remaining_types']
    assert types == [0, 1, 7, 27] and data['remaining_types'] == types
    table = triangle['remaining_pair_tables']
    def pair(i,j):
        return table[f'{min(i,j)},{max(i,j)}']
    grams = {i: coefficient_gram(M,H[i],H[i],H[i],True) for i in types}
    decks = feasible_counts([[1]+H[i][3:] for i in types],[58]+data['target_H_sum'][3:],[58]*4)
    assert len(decks) == 5
    viable = {}
    for deck in decks:
        rows = {}
        for i,n in zip(types,deck):
            if not n:
                continue
            counts = dict(zip(types,deck))
            counts[i] -= 1
            labels = [(j,tuple(q)) for j in types if counts[j] for q in pair(i,j)]
            col = [[int(k==j) for k in types]+gram_column(q) for j,q in labels]
            solutions = feasible_counts(col,list(counts.values())+grams[i],[counts[j] for j,q in labels])
            if not solutions:
                break
            rows[i] = [dict(zip(labels,values)) for values in solutions]
        else:
            viable[deck] = rows
    assert list(viable) == [(24,24,8,2)]
    rows = viable[(24,24,8,2)]
    assert [len(rows[t]) for t in types] == [9,1,1,1]
    assert [H[t][-1] for t in types] == [72,72,48,0]
    assert [evaluate(H[t],2) for t in types] == [-2,0,-2,-8]
    assert [quadratic_remainder(H[t]) for t in types] == [(0,0),(1,0),(12,-24),(33,-72)]

    def count(row,j,q):
        return row.get((j,tuple(q)),0)
    q0,q1 = [1,0,-9,8],[1,-2,-11,24]
    assert all(count(row,0,q1) == 2 + count(row,7,q0) for row in rows[0])
    assert count(rows[7][0],0,q0) == 18
    # Thus the aggregate count of the second A-A label per A row is 2+18*8/24=8.
    assert count(rows[1][0],1,[1,-2,-12,24]) == 8
    assert count(rows[7][0],7,[1,0,3,-16]) == 3
    assert count(rows[7][0],7,[1,-2,1,0]) == 4
    assert {(evaluate(q,2),q[-1]) for q in pair(0,7)} == {(-2,8),(2,24)}
    assert {(quadratic_remainder(q),q[-1]) for q in pair(1,7)} == {((2,-8),24),((-2,8),8)}
    assert {quadratic_remainder(q) for q in pair(1,27)} == {(5,-8)}
    print('5 decks tested; unique deck (24,24,8,2). Row-option counts 9,1,1,1.')
    print('Verified both average within-cell degrees 8 and tetrahedral 3/4 split.')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('triangle_table',type=Path)
    check(p.parse_args().triangle_table)

"""Exact order-58 exclusion for n58_d2_0020, using the project's pair table.

Usage: python3 verify_quadratic_0020.py path/to/nonintegral_pair_n58_d2_0020.json
No external Python packages are required. Input rows and labels are the outputs
of the project's earlier necessary-condition computation for this spectrum.
"""

import argparse
import json
from fractions import Fraction
from math import lcm
from pathlib import Path


def feasible_counts(columns, target, bounds, first_only=False):
    """Enumerate bounded nonnegative integer solutions using exact elimination."""
    count = len(columns)
    assert count == len(bounds) and all(len(column) == len(target) for column in columns)
    matrix = [[Fraction(v) for v in row] for row in zip(*columns, target)]
    pivots = []
    for j in range(count):
        i = len(pivots)
        k = next((k for k in range(i, len(matrix)) if matrix[k][j]), None)
        if k is None:
            continue
        matrix[i], matrix[k] = matrix[k], matrix[i]
        coefficient = matrix[i][j]
        matrix[i] = [x / coefficient for x in matrix[i]]
        for k, row in enumerate(matrix):
            if k != i and row[j]:
                matrix[k] = [x - row[j] * y for x, y in zip(row, matrix[i])]
        pivots.append(j)
    if any(row[-1] for row in matrix[len(pivots):]):
        return []

    free = sorted(set(range(count)).difference(pivots), key=bounds.__getitem__)
    coefficients, targets, divisors, intervals = [], [], [], []
    for j, row in zip(pivots, matrix):
        denominator = lcm(*(v.denominator for v in row))
        coeff = [int(row[k] * denominator) for k in free]
        coefficients.append(coeff)
        targets.append(int(row[-1] * denominator))
        divisors.append(denominator)
        # Remaining contributions include the bounded pivot variable.
        ranges = [(0, bounds[j] * denominator)]
        for k, c in reversed(list(zip(free, coeff))):
            lo, hi = ranges[-1]
            ranges.append((lo + min(0, c * bounds[k]), hi + max(0, c * bounds[k])))
        intervals.append(ranges[::-1])

    solutions = []
    x = [0] * count

    def visit(depth, residual):
        if any(value < intervals[i][depth][0] or value > intervals[i][depth][1]
               for i, value in enumerate(residual)):
            return
        if depth == len(free):
            if any(value % d for value, d in zip(residual, divisors)):
                return
            for j, v, d in zip(pivots, residual, divisors):
                x[j] = v // d
            assert all(0 <= value <= upper for value, upper in zip(x, bounds))
            assert all(sum(x[k] * columns[k][i] for k in range(count)) == v
                       for i, v in enumerate(target))
            solutions.append(tuple(x))
            return
        k = free[depth]
        for value in range(bounds[k] + 1):
            x[k] = value
            visit(depth + 1, [v - value * coeff[depth] for v, coeff in zip(residual, coefficients)])
            if first_only and solutions:
                return

    visit(0, targets)
    return solutions


def coefficient_gram(M, q, H_i, H_j, diagonal):
    """Off-diagonal resolvent-product target or diagonal Gram target.

    Coefficients in input polynomials descend; returned monomials ascend.
    """
    degree = len(M) - 1
    m = M[::-1]
    v = list(q[::-1]) + [0] * (len(M) - len(q))
    left = list(H_i[::-1]) + [0]
    right = list(H_j[::-1]) + [0]
    K = [[0] * (degree + 1) for _ in m]
    # (t^i u^j - t^j u^i)/(u-t), with i<j, is an explicit finite sum.
    for i in range(degree + 1):
        for j in range(i + 1, degree + 1):
            weight = 2 * (v[i] * m[j] - v[j] * m[i])
            for k in range(j - i):
                K[i+k][j-1-k] += weight
    for i in range(degree + 1):
        for j in range(degree + 1):
            K[i][j] -= left[i] * right[j] if diagonal else left[i] * v[j] + v[i] * right[j]
    assert all(K[i][j] == 0 for i in range(degree + 1) for j in range(degree + 1)
               if max(i, j) > degree - 2)
    if diagonal:
        assert all(K[i][j] == K[j][i] for i in range(degree) for j in range(degree))
    return [K[i][j] for i in range(degree - 1)
            for j in range(i if diagonal else 0, degree - 1)]


def gram_column(q):
    a = q[::-1]
    return [x * y for i, x in enumerate(a) for y in a[i:]]


def evaluate(q, x):
    value = 0
    for c in q:
        value = value * x + c
    return value


def quadratic_remainder(q):
    """Return (a,b) for a T + b modulo T² + 2T - 4."""
    a, b = 0, 0
    for coefficient in q:
        a, b = b - 2 * a, 4 * a + coefficient
    return a, b


def quadratic_product(x, y):
    a, b = x
    c, d = y
    return a*d + b*c - 2*a*c, b*d + 4*a*c


def admissible_signs(H, Q):
    """Rank-one Gram determinants must vanish at 3 and both quadratic roots."""
    A, B, C = [evaluate(h, 3) for h in H]
    x, y, z = [evaluate(q, 3) for q in Q]
    constant = A*B*C - A*z*z - B*y*y - C*x*x
    signs = [e for e in (-1, 1) if constant + 2*e*x*y*z == 0]

    def triple(a, b, c):
        return quadratic_product(quadratic_product(a, b), c)

    A, B, C = map(quadratic_remainder, H)
    x, y, z = map(quadratic_remainder, Q)
    abc, xyz = triple(A, B, C), triple(x, y, z)
    subtracted = [triple(A, z, z), triple(B, y, y), triple(C, x, x)]
    return [e for e in signs
            if all(abc[i] + 2*e*xyz[i] == sum(a[i] for a in subtracted) for i in (0, 1))]


def verify(data):
    assert data['profile_id'] == 'n58_d2_0020' and data['complete_pair_enumeration']
    M = data['M']
    assert M == [1, 7, -18, -68, 96, 0]
    H = data['H_deck']
    types = data['remaining_types']
    assert types == [0, 3, 15, 34]

    def pair(i, j):
        return data['pair_tables'][f'{min(i,j)},{max(i,j)}']

    grams = {i: coefficient_gram(M, H[i], H[i], H[i], True) for i in types}
    decks = feasible_counts([[1] + H[i][3:] for i in types],
                            [58] + data['target_H_sum'][3:], [58]*len(types))
    viable = []
    for deck in decks:
        for i, n in zip(types, deck):
            if n == 0:
                continue
            counts = [v - int(i == j) for j, v in zip(types, deck)]
            columns, limits = [], []
            for j, limit in zip(types, counts):
                if limit == 0:
                    continue
                for q in pair(i,j):
                    columns.append([int(k == j) for k in types] + gram_column(q))
                    limits.append(limit)
            if not feasible_counts(columns, counts + grams[i], limits, first_only=True):
                break
        else:
            viable.append(deck)
    assert len(decks) == 7 and viable == [(16, 32, 2, 8)]
    print('Integer decks: 7. Decks passing every single-vertex row: (16,32,2,8).')

    # Both types below must occur. Each of their four possible labels must fail.
    i, j = 15, 34
    remaining = [n - int(k == i) - int(k == j) for k, n in zip(types, viable[0])]
    assert len(pair(i,j)) == 4
    for q in pair(i,j):
        columns, limits = [], []
        for k, limit in zip(types, remaining):
            for r in pair(i,k):
                for s in pair(j,k):
                    for e in admissible_signs([H[i], H[j], H[k]], [q, r, s]):
                        columns.append([int(v == k) for v in types] + gram_column(r) + gram_column(s)
                                       + [e*x*y for x in r[::-1] for y in s[::-1]])
                        limits.append(limit)
        target = list(remaining)
        for k in (i,j):
            target.extend(x-y for x,y in zip(grams[k], gram_column(q)))
        target.extend(coefficient_gram(M, q, H[i], H[j], False))
        assert len(columns) == 20
        assert not feasible_counts(columns, target, limits, first_only=True)
        print(f'Pair polynomial {q}: {len(columns)} possible signed third labels, zero solutions.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pair_table', type=Path)
    args = parser.parse_args()
    verify(json.loads(args.pair_table.read_text()))

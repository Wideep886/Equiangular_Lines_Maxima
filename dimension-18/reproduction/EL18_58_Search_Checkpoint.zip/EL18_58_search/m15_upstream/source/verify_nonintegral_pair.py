#!/usr/bin/env python3
"""Independent exact verification of nonintegral pair/Gram exclusions.

Coverage never calls enum_pair, make_weights, or field_sqrt from the attack.
For a simple quadratic factor, integer remainder squares are solved by a
signed-divisor equation. Other cases use integer-knot bounds. All Gram
targets are derived independently as bivariate SymPy polynomials.
"""
from fractions import Fraction as F
from itertools import combinations
from math import isqrt
from pathlib import Path
import argparse
import hashlib
import json
import time

import sympy as sp
from nonintegral_deck_attack import Q

OUT = Path(__file__).resolve().parent/'output'
t,u = sp.symbols('t u')


def mul(a,b):
    result=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):result[i+j]+=x*y
    return result


def sub(a,b):
    n=max(len(a),len(b));a=[0]*(n-len(a))+a;b=[0]*(n-len(b))+b
    return [x-y for x,y in zip(a,b)]


def div(a,b):
    assert b[0]==1
    a=a[:];result=[]
    for i in range(max(0,len(a)-len(b)+1)):
        c=a[i];result.append(c)
        for j,v in enumerate(b):a[i+j]-=c*v
    return result,a[len(result):]


def evaluate(p,x):
    value=0
    for a in p:value=value*x+a
    return value


def divisors(n):
    assert n>0
    answer=set()
    for k in range(1,isqrt(n)+1):
        if n%k==0:answer.update([k,n//k])
    return sorted(answer)


def rational_integer_square(v):
    v=F(v)
    if v.denominator!=1 or v<0:return None
    root=isqrt(v.numerator)
    return root if root*root==v else None


def quadratic_remainder_squares(P1,P0,b,c):
    """All integer A,B with (A*t+B)^2 = P1*t+P0 modulo t^2+b*t+c.

    Put Z=2B-bA, D=b^2-4c. Then ZA=P1 and
    Z^2+D*A^2=4P0-2bP1. This is a complete signed-divisor problem;
    P1=0 is split into A=0 or Z=0 explicitly.
    """
    D=b*b-4*c;answers=set()
    if P1:
        for positive in divisors(abs(P1)):
            for A in [positive,-positive]:
                Z=P1//A
                if Z*Z+D*A*A!=4*P0-2*b*P1 or (Z+b*A)%2:continue
                answers.add((A,(Z+b*A)//2))
    else:
        B=rational_integer_square(P0)
        if B is not None:answers.update([(0,B),(0,-B)])
        A=rational_integer_square(F(4*P0,D))
        if A is not None:
            for v in [A,-A]:
                if b*v%2==0:answers.add((v,b*v//2))
    for A,B in answers:
        assert -b*A*A+2*A*B==P1 and B*B-c*A*A==P0
    return sorted(answers)


def independent_pairs(Hi,Hj,knots,multiplicities,factors,R):
    degree=len(knots)-2
    assert degree==3,'This independent verifier currently covers e=5 only.'
    products=[evaluate(Hi,r)*evaluate(Hj,r) for r in knots]
    assert all(v>=0 for v in products)
    parent_product=mul(Hi,Hj)
    offset=11+sum(r.a for r in knots)
    assert offset.denominator==1;offset=int(offset)
    a_range=range(-28-offset,29-offset)
    simple_quadratic=[f['coefficients_descending'] for f in factors
                      if len(f['coefficients_descending'])==3 and f['multiplicity']==1]
    candidates=[]
    if simple_quadratic:
        f=simple_quadratic[0];_,rem=div(parent_product,f)
        rem=[0]*(2-len(rem))+rem;P1,P0=rem;b,c=f[1:]
        for A,B in quadratic_remainder_squares(P1,P0,b,c):
            for a in a_range:
                # t^3 = (b^2-c)t+bc modulo f.
                candidates.append([1,a,A-b*b+c+a*b,B-b*c+a*c])
        method='complete integer quadratic remainder squares via signed divisors'
    else:
        integer_nodes=[]
        for r,p,m in zip(knots,products,multiplicities):
            if r.b:continue
            assert r.a.denominator==p.a.denominator==1 and not p.b
            bound=isqrt(int(p.a))
            if m==1 and bound*bound!=p.a:return [],{'method':'integer simple-root nonsquare','outer_candidates':0}
            integer_nodes.append((int(r.a),bound,m))
        assert len(integer_nodes)>=3
        simple=[(r,B) for r,B,m in integer_nodes if m==1]
        for a in a_range:
            blo,bhi=None,None
            for (r,Br,_),(s,Bs,_) in combinations(integer_nodes,2):
                center=r*r+r*s+s*s+a*(r+s)
                radius=(Br+Bs)//abs(r-s)
                lo,hi=-radius-center,radius-center
                blo=lo if blo is None else max(blo,lo)
                bhi=hi if bhi is None else min(bhi,hi)
            for b in range(blo,bhi+1):
                if simple:
                    r,B=simple[0];base=r**3+a*r*r+b*r
                    values=sorted({-B-base,B-base})
                else:
                    lo=max(-B-r**3-a*r*r-b*r for r,B,m in integer_nodes)
                    hi=min(B-r**3-a*r*r-b*r for r,B,m in integer_nodes)
                    values=range(lo,hi+1)
                candidates.extend([1,a,b,c] for c in values)
        method='complete 57-value leading coefficient and three integer-knot bounds'
    answers=[]
    for polynomial in candidates:
        if (polynomial[1]+offset-Hi[3]+Hj[3])%2:continue
        quotient,remainder=div(sub(parent_product,mul(polynomial,polynomial)),R)
        if any(remainder) or any(v%4 for v in quotient):continue
        values=[evaluate(polynomial,r) for r in knots]
        if any(v*v>p for v,p in zip(values,products)):continue
        if any(v*v!=p for v,p,m in zip(values,products,multiplicities) if m==1):continue
        answers.append(polynomial)
    assert len(answers)==len({tuple(a) for a in answers})
    return answers,{'method':method,'outer_candidates':len(candidates)}


def check_prefilter(data,source,knots,multiplicities,M):
    original=source['H_deck'];retained=set(range(len(original)));records=[]
    derivative=[a*(len(M)-1-i) for i,a in enumerate(M[:-1])]
    for t0,m in zip(knots,multiplicities):
        if t0.b or m!=1:continue
        r=int(2*t0.a+11);delta=evaluate(derivative,t0)
        assert not delta.b and delta.a.denominator==1
        sign=1 if delta>0 else -1;scale=2*abs(int(delta.a));options=[];allowed=set()
        for k in divisors(scale):
            norm=scale//k
            if norm%2 or norm<r+1:continue
            bound=min(norm-r,57*norm//(r*r+57));indices=[]
            for i,H in enumerate(original):
                z=sign*evaluate(H,t0)
                assert not z.b and z.a.denominator==1 and z>=0
                z=int(z.a)
                if z%k==0 and rational_integer_square(z//k) is not None and z//k<=bound:indices.append(i)
            options.append({'k':k,'norm':norm,'max_square':bound,'allowed_types':indices});allowed.update(indices)
        records.append({'eigenvalue':r,'scale':scale,'options':options});retained.intersection_update(allowed)
    assert records==data['rank1_prefilter']
    assert sorted(retained)==data['original_deck_indices']
    assert [original[i] for i in sorted(retained)]==data['H_deck']


def independent_gram(M,H):
    m=sp.Poly.from_list(M,t).as_expr();h=sp.Poly.from_list(H,t).as_expr()
    numerator=2*(m.subs(t,u)*h-m*h.subs(t,u))
    quotient,remainder=sp.div(sp.Poly(numerator,t,u),sp.Poly(u-t,t,u))
    assert remainder.is_zero
    polynomial=quotient-sp.Poly(h*h.subs(t,u),t,u)
    degree=len(M)-3
    assert polynomial.degree(t)<=degree and polynomial.degree(u)<=degree
    assert all(c.is_Integer for c in polynomial.coeffs())
    assert all(polynomial.coeff_monomial(t**i*u**j)==polynomial.coeff_monomial(t**j*u**i)
               for i in range(degree+1) for j in range(degree+1))
    return [int(polynomial.coeff_monomial(t**i*u**j)) for i in range(degree+1) for j in range(i,degree+1)]


def check_certificate(columns,target,cert):
    kind=cert['kind']
    if kind=='empty_columns':assert not columns and any(target)
    elif kind=='farkas':
        y=list(map(F,cert['y']))
        assert len(y)==len(target)
        assert all(sum(a*b for a,b in zip(c,y))>=0 for c in columns)
        assert sum(a*b for a,b in zip(target,y))<0
    elif kind=='modular_column_lattice':
        m=cert['modulus'];y=cert['y'];assert m>1
        assert all(sum(a*b for a,b in zip(c,y))%m==0 for c in columns)
        assert sum(a*b for a,b in zip(target,y))%m==cert['target_residue']!=0
    elif kind=='rational_primal':
        support=[(i,F(w)) for i,w in cert['support']]
        assert all(w>=0 for i,w in support)
        assert all(sum(columns[i][j]*w for i,w in support)==v for j,v in enumerate(target))
    else:raise AssertionError(kind)
    assert (cert['status']=='excluded')==(kind!='rational_primal')


def verify_profile(pid):
    start=time.monotonic();path=OUT/f'nonintegral_pair_{pid}.json';raw=path.read_bytes();data=json.loads(raw)
    assert data['complete_pair_enumeration']
    source=json.loads((OUT/data['source']).read_text());md=source['metadata'];D=md['quadratic_discriminant']
    assert md['complete_enumeration']
    knots=[Q(F(a),F(b),D) for a,b in md['knots_as_a_plus_b_sqrt_discriminant']]
    factors=md['full_normalized_factors'];M=[1];R=[1]
    for f in factors:
        M=mul(M,f['coefficients_descending'])
        if f['multiplicity']==1:R=mul(R,f['coefficients_descending'])
    assert M==data['M'] and R==data['simple_root_factor']
    mult=[]
    for r in knots:
        matches=[f['multiplicity'] for f in factors if not evaluate(f['coefficients_descending'],r)]
        assert len(matches)==1;mult+=matches
    check_prefilter(data,source,knots,mult,M)
    deck=data['H_deck'];table=data['pair_tables'];pair_checks=[]
    assert set(table)=={f'{i},{j}' for i in range(len(deck)) for j in range(i,len(deck))}
    for i,Hi in enumerate(deck):
        for j in range(i,len(deck)):
            labels,info=independent_pairs(Hi,deck[j],knots,mult,factors,R)
            assert sorted(labels)==sorted(table[f'{i},{j}']),(pid,i,j,labels,table[f'{i},{j}'])
            pair_checks.append({'i':i,'j':j,'label_count':len(labels),**info})
    gram={i:independent_gram(M,H) for i,H in enumerate(deck)}
    column_cache={}
    for key,polynomials in table.items():
        column_cache[key]=[]
        for q in polynomials:
            v=q[::-1]
            column_cache[key].append([v[i]*v[j] for i in range(len(v)) for j in range(i,len(v))])
    active=set(range(len(deck)));certificate_count=0
    assert data['target_H_sum']==md['target_H_sum']
    for round_ in data['rounds']:
        assert round_['active_before']==sorted(active)
        assert [row['anchor_type'] for row in round_['results']]==sorted(active)
        killed=[]
        for row in round_['results']:
            i=row['anchor_type'];columns=[]
            for j in sorted(active):
                columns.extend([1]+deck[j][3:]+g for g in column_cache[f'{min(i,j)},{max(i,j)}'])
            target=[57]+[a-b for a,b in zip(md['target_H_sum'][3:],deck[i][3:])]+gram[i]
            check_certificate(columns,target,row['certificate']);certificate_count+=1
            if row['certificate']['status']=='excluded':killed.append(i)
        assert killed==round_['excluded_types'];active.difference_update(killed)
    assert sorted(active)==data['remaining_types']
    check_certificate([[1]+deck[i][3:] for i in sorted(active)],
                      [58]+md['target_H_sum'][3:],data['final_certificate'])
    assert data['excluded']==(data['final_certificate']['status']=='excluded')
    return {'profile_id':pid,'source_sha256':hashlib.sha256(raw).hexdigest(),
            'excluded':data['excluded'],'all_checks_passed':True,
            'rank1_prefilter_verified':True,'complete_independent_pair_coverage':True,
            'pair_count':len(pair_checks),'label_count':sum(r['label_count'] for r in pair_checks),
            'full_Gram_independent_bivariate_SymPy':True,'exact_certificates_verified':certificate_count+1,
            'pair_checks':pair_checks,'seconds':round(time.monotonic()-start,4)}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',nargs='+');parser.add_argument('--all',action='store_true')
    args=parser.parse_args();summary=json.loads((OUT/'nonintegral_pair_results.json').read_text())
    ids=args.profiles or [r['profile_id'] for r in summary if r['excluded'] or args.all]
    results=[]
    for pid in ids:
        result=verify_profile(pid);results.append(result)
        (OUT/'nonintegral_pair_independent_verification.json').write_text(json.dumps({
            'all_selected_passed':True,'selected_profile_ids':ids,
            'completed_profiles':len(results),'selection_complete':len(results)==len(ids),
            'results':results},indent=2)+'\n')
        print(json.dumps({k:v for k,v in result.items() if k!='pair_checks'}),flush=True)


if __name__=='__main__':main()

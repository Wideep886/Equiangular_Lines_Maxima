#!/usr/bin/env python3
"""Exact independent audit of triangle-based pair removals.

For each excluded pair, only third types violating the saved separating
functional need testing: all other possible types automatically satisfy it.
Compatibility is recomputed in Z[t]/(t^2+b*t+c), without importing the
production triangle routine or its scaled sqrt(D) encoding.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
import time

from verify_nonintegral_pair import div,evaluate,independent_gram,check_certificate

OUT=Path(__file__).resolve().parent/'output'


def verify_profile(pid):
    start=time.monotonic();path=OUT/f'nonintegral_triangle_{pid}.json';raw=path.read_bytes();data=json.loads(raw)
    basepath=OUT/data['source'];base_raw=basepath.read_bytes();base=json.loads(base_raw)
    prior=json.loads((OUT/'nonintegral_pair_independent_verification.json').read_text())
    audit=next(r for r in prior['results'] if r['profile_id']==pid)
    assert audit['complete_independent_pair_coverage'] and audit['source_sha256']==hashlib.sha256(base_raw).hexdigest()
    md=json.loads((OUT/base['source']).read_text())['metadata']
    factors=md['full_normalized_factors'];quad=next(f for f in factors if len(f['coefficients_descending'])==3)
    f=quad['coefficients_descending'];b,c=f[1:];D=b*b-4*c
    linear=sorted((-g['coefficients_descending'][1],g['multiplicity']) for g in factors if len(g['coefficients_descending'])==2)
    M=base['M'];derivative=[a*(len(M)-1-i) for i,a in enumerate(M[:-1])]
    signs=[1 if evaluate(derivative,r)>0 else -1 for r,m in linear]
    quad_signs=[]
    for i,(a0,b0) in enumerate(md['knots_as_a_plus_b_sqrt_discriminant']):
        if F(b0):quad_signs.append((1 if F(b0)>0 else -1,(-1)**(len(md['knots_as_a_plus_b_sqrt_discriminant'])-1-i)))
    deck=base['H_deck'];active=set(base['remaining_types'])
    def key(i,j):return f'{min(i,j)},{max(i,j)}'
    table={key(i,j):[tuple(q) for q in base['pair_tables'][key(i,j)]] for i in active for j in active if i<=j}
    def remainder(poly):
        _,r=div(poly,f);return tuple([0]*(2-len(r))+r)
    Hring=[remainder(H) for H in deck]
    Hlinear=[[evaluate(H,r) for r,m in linear] for H in deck]
    polynomials={q for labels in table.values() for q in labels}
    Qring={q:remainder(list(q)) for q in polynomials}
    Qlinear={q:[evaluate(q,r) for r,m in linear] for q in polynomials}
    # Ring coordinates are (coefficient of t, constant); t^2=-b*t-c.
    def multiply(v,w):
        A,B=v;C,E=w
        return (-b*A*C+A*E+B*C,B*E-c*A*C)
    def subtract(v,w):return (v[0]-w[0],v[1]-w[1])
    Qsquares={q:multiply(v,v) for q,v in Qring.items()}
    def radical_sign(A,B):
        # Sign of A+B*sqrt(D), using only integer comparisons.
        if B==0:return (A>0)-(A<0)
        if A==0:return (B>0)-(B<0)
        if A>0 and B>0:return 1
        if A<0 and B<0:return -1
        difference=A*A-D*B*B
        assert difference!=0
        return ((difference>0)-(difference<0))*(1 if A>0 else -1)
    compatibility_calls=0
    def compatible(i,j,k,q,r,s):
        nonlocal compatibility_calls
        compatibility_calls+=1
        hi,hj,hk=Hring[i],Hring[j],Hring[k]
        constant=multiply(multiply(hi,hj),hk)
        for h,square in [(hi,Qsquares[s]),(hj,Qsquares[r]),(hk,Qsquares[q])]:constant=subtract(constant,multiply(h,square))
        cross=multiply(multiply(Qring[q],Qring[r]),Qring[s]);cross=(2*cross[0],2*cross[1])
        epsilons=[]
        for epsilon in [-1,1]:
            det=(constant[0]+epsilon*cross[0],constant[1]+epsilon*cross[1])
            if quad['multiplicity']<=2:
                if det!=(0,0):continue
            elif any(derivative_sign*radical_sign(2*det[1]-b*det[0],embedding_sign*det[0])<0
                     for embedding_sign,derivative_sign in quad_signs):continue
            epsilons.append(epsilon)
        if not epsilons:return False
        for index,(root,multiplicity) in enumerate(linear):
            A,B,C=Hlinear[i][index],Hlinear[j][index],Hlinear[k][index]
            v,w,z=Qlinear[q][index],Qlinear[r][index],Qlinear[s][index]
            constant=A*B*C-A*z*z-B*w*w-C*v*v
            cross=2*v*w*z
            epsilons=[epsilon for epsilon in epsilons
                      if (constant+epsilon*cross==0 if multiplicity<=2
                          else signs[index]*(constant+epsilon*cross)>=0)]
            if not epsilons:return False
        return True
    gram={i:independent_gram(M,H) for i,H in enumerate(deck)}
    gramcolumns={q:[q[::-1][i]*q[::-1][j] for i in range(len(q)) for j in range(i,len(q))] for q in polynomials}
    stage_audits=[];total_certificates=0
    for stage_index,stage in enumerate(data['stages'],1):
        assert stage['active_before']==sorted(active)
        expected_pairs={(i,j,q) for i in active for j in active if i<=j for q in table[key(i,j)]}
        assert {(r['pair_types'][0],r['pair_types'][1],tuple(r['Q'])) for r in stage['pair_tests']}==expected_pairs
        assert len(stage['pair_tests'])==len(expected_pairs)
        removed=[];records=[]
        for row in stage['pair_tests']:
            i,j=row['pair_types'];q=tuple(row['Q']);cert=row['certificate']
            assert set(row['third_types'])<=active
            rhs=[56]+[v-a-b0 for v,a,b0 in zip(base['target_H_sum'][3:],deck[i][3:],deck[j][3:])]
            columns=[[1]+deck[k][3:] for k in row['third_types']]
            check_certificate(columns,rhs,cert);total_certificates+=1
            if cert['status']!='excluded':continue
            if cert['kind']=='farkas':
                y=list(map(F,cert['y']))
                forbidden=[k for k in sorted(active) if sum(a*z for a,z in zip([1]+deck[k][3:],y))<0]
            elif cert['kind']=='modular_column_lattice':
                forbidden=[k for k in sorted(active) if sum(a*z for a,z in zip([1]+deck[k][3:],cert['y']))%cert['modulus']]
            elif cert['kind']=='empty_columns':forbidden=sorted(active)
            else:raise AssertionError(cert['kind'])
            before=compatibility_calls
            for k in forbidden:
                for r in table[key(i,k)]:
                    for s in table[key(j,k)]:
                        assert not compatible(i,j,k,q,r,s),(pid,stage_index,i,j,k,q,r,s)
            records.append({'pair_types':[i,j],'Q':list(q),'certificate_kind':cert['kind'],
                            'all_forbidden_third_types':forbidden,
                            'compatible_extensions_to_forbidden_types':0,
                            'candidate_label_pairs_exhausted':compatibility_calls-before})
            removed.append((key(i,j),q))
        assert [[k,list(q)] for k,q in removed]==stage['removed_pairs']
        for k,q in removed:table[k].remove(q)
        killed=[]
        assert [r['anchor_type'] for r in stage['row_tests']]==sorted(active)
        for row in stage['row_tests']:
            i=row['anchor_type'];columns=[]
            for j in sorted(active):columns.extend([1]+deck[j][3:]+gramcolumns[q] for q in table[key(i,j)])
            rhs=[57]+[v-a for v,a in zip(base['target_H_sum'][3:],deck[i][3:])]+gram[i]
            check_certificate(columns,rhs,row['certificate']);total_certificates+=1
            if row['certificate']['status']=='excluded':killed.append(i)
        assert killed==stage['removed_types'];active.difference_update(killed)
        stage_audits.append({'stage':stage_index,'pair_removals_independently_certified':len(records),
                             'type_removals_exactly_certified':killed,'pair_removal_audits':records})
    assert sorted(active)==data['remaining_types']
    assert {k:[list(q) for q in qs] for k,qs in table.items()}==data['remaining_pair_tables']
    check_certificate([[1]+deck[i][3:] for i in sorted(active)],
                      [58]+base['target_H_sum'][3:],data['final_certificate']);total_certificates+=1
    assert data['excluded']==(data['final_certificate']['status']=='excluded')
    result={'profile_id':pid,'all_checks_passed':True,'excluded':data['excluded'],
            'source_sha256':hashlib.sha256(raw).hexdigest(),'base_pair_source_sha256':hashlib.sha256(base_raw).hexdigest(),
            'independent_arithmetic':'integer polynomial remainder ring Z[t]/(t^2+b*t+c); direct integer-root determinant signs',
            'global_common_triangle_sign_checked':True,'projector_derivative_sign_checked':True,
            'all_separator_forbidden_types_exhausted':True,'triple_label_candidates_checked':compatibility_calls,
            'exact_LP_or_modular_certificates_checked':total_certificates,'stages':stage_audits,
            'seconds':round(time.monotonic()-start,4)}
    (OUT/f'nonintegral_triangle_independent_verification_{pid}.json').write_text(json.dumps(result,indent=2)+'\n')
    if pid=='n58_d2_0027':
        # Stable entry point used by the repository's integrated reproduction.
        (OUT/'nonintegral_triangle_independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='stages'}),flush=True)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',nargs='+',default=['n58_d2_0027']);args=parser.parse_args()
    for pid in args.profiles:verify_profile(pid)

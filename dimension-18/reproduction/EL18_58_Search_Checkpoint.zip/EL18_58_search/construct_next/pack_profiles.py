"""Export one explicit Gram per profile from the exact indexed attainments."""
import gzip,json
from collections import Counter
from signatures import HERE,gram,fingerprint
def main():
    src=json.loads((HERE/'signatures.json').read_text())['representatives']
    expected=Counter(dict(json.loads((HERE/'profile_indices.json').read_text())))
    assert expected=={item['index']:item['count'] for item in src.values()}
    inputs=[json.loads(l) for f in ('affine_results.jsonl','five_results.jsonl') for l in (HERE/f).read_text().splitlines()]
    out=HERE/'affine57_representatives.jsonl.gz'
    with gzip.open(out,'wt',compresslevel=6) as f:
        for key,item in sorted(src.items()):
            g=gram(inputs[item['index']]);assert fingerprint(g)==key
            print(json.dumps([key,g],separators=(',',':')),file=f)
    with gzip.open(out,'rt') as f:
        stored={h:g for l in f if (r:=json.loads(l)) for h,g in [r]}
    assert set(stored)==set(src)
    for key,g in stored.items():
        temporary=HERE/f'gram57_{key[:14]}.json'
        if temporary.exists():
            assert json.loads(temporary.read_text())==g
            temporary.unlink()
    print(len(stored),'verified Gram representatives')
if __name__=='__main__':main()

// The compiler supplies exact_clique.hpp from the independent reference-basis solver.
#include "exact_clique.hpp"
#include <limits>
#include <cassert>
using ll=long long;
using wide=__int128_t;
using Vec=array<ll,18>;
struct Lift { Vec x; ll h; int s; };
#ifndef CORE_SIZE
#define CORE_SIZE 44
#endif
int main() {
  ll den;cin>>den;
  array<array<ll,17>,18> M;
  ll bound=0;
  for(auto &row:M){ll total=0;for(ll &x:row){cin>>x;total+=abs(x);}bound=max(bound,total);}
  assert(den>0 && 10*wide(den)*den<numeric_limits<ll>::max() && 18*wide(bound)*bound<numeric_limits<ll>::max());
  array<array<int,3>,CORE_SIZE> C;
  for(auto &t:C)for(int &x:t)cin>>x;
  // Two eight-sign halves, plus a fixed positive first sign.
  array<Vec,256> lo{},hi{};
  for(int m=0;m<256;m++)for(int i=0;i<18;i++){
    lo[m][i]=M[i][0];
    for(int k=0;k<8;k++){
      int s=((m>>k)&1)?1:-1;
      lo[m][i]+=s*M[i][k+1]; hi[m][i]+=s*M[i][k+9];
    }
  }
  vector<Lift> pool;
  array<array<ll,CORE_SIZE>,256> a{},b{};
  for(int m=0;m<256;m++)for(int j=0;j<CORE_SIZE;j++)for(auto k:C[j]){
    a[m][j]+=lo[m][k]; b[m][j]+=hi[m][k];
  }
  for(int m=0;m<256;m++)for(int n=0;n<256;n++){
    bool good=true;
    for(int j=0;j<CORE_SIZE;j++)if(abs(a[m][j]+b[n][j])!=den){good=false;break;}
    if(!good)continue;
    Vec x{}; ll gap=10*den*den;
    for(int j=0;j<18;j++){x[j]=lo[m][j]+hi[n][j];gap-=x[j]*x[j];}
    if(gap<0)continue;
    pool.push_back({x,gap,1});
    if(gap)pool.push_back({x,gap,-1});
  }
  int n=pool.size(),edges=0;assert(n<=MAXN);
  Mask live;
  for(int i=0;i<n;i++){
    live.set(i);auto &p=pool[i];
    for(int j=0;j<i;j++){
      auto &q=pool[j];
      ll ip=inner_product(p.x.begin(),p.x.end(),q.x.begin(),ll(0));
      bool good=false;
      for(int s:{-1,1}){
        wide v=s*2*wide(den)*den-ip;
        if(v*v==wide(p.h)*q.h && v*p.s*q.s>=0)good=true;
      }
      if(good){adj[i].set(j);adj[j].set(i);edges++;}
    }
  }
  budget=numeric_limits<unsigned long long>::max();
  int res=search(live,58-CORE_SIZE);
  cout<<n<<" "<<edges<<" "<<res<<" "<<visits<<endl;
  return 0;
}

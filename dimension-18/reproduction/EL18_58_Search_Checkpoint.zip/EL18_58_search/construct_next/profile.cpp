#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;
using ll=long long;
using wide=__int128_t;
int main() {
    int nc;ll d; map<string,int> representatives;
    for(int id=0;cin>>nc>>d;id++){
        int m=57-nc;
        vector<array<int,3>> C(nc);
        vector<array<ll,20>> ext(m);
        for(auto &r:C)for(auto &i:r)cin>>i;
        for(auto &r:ext)for(auto &v:r)cin>>v;
        array<uint64_t,57> rows{};
        for(int i=0;i<57;i++)for(int j=0;j<i;j++){
            int s=0;
            if(i<nc){
                int n=0;for(auto a:C[i])for(auto b:C[j])n+=a==b;
                s=2*n-1;
            }else if(j<nc){
                ll v=0;for(auto a:C[j])v+=ext[i-nc][a];
                assert(v==d||v==-d);s=v/d;
            }else{
                auto &x=ext[i-nc],&y=ext[j-nc];ll dot=0;
                for(int k=0;k<18;k++)dot+=x[k]*y[k];
                for(int z:{-1,1}){
                    wide v=z*wide(2)*d*d-dot;
                    if(v*v==wide(x[18])*y[18]&&v*x[19]*y[19]>=0)s=z;
                }
            }
            assert(s==1||s==-1);
            if(s==-1){rows[i]|=uint64_t(1)<<j;rows[j]|=uint64_t(1)<<i;}
        }
        array<string,57> root;
        for(int i=0;i<57;i++)for(int j=0;j<i;j++){
            int h=__builtin_popcountll(rows[i]^rows[j]);
            auto v=((rows[i]>>j)&1)?57-h:h;
            root[i].push_back(char(v));root[j].push_back(char(v));
        }
        for(auto &s:root)sort(s.begin(),s.end());
        sort(root.begin(),root.end());string total;for(auto &s:root)total+=s;
        cout<<representatives.emplace(total,id).first->second<<'\n';
    }
}

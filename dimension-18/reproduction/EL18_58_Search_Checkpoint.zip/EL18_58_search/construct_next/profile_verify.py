"""Independent reconstruction and exact (no hash) grouping of the attained Grams."""
import json,os,subprocess,tempfile
from collections import Counter
from pathlib import Path
from affine_four import HERE,solver
if __name__=='__main__':
    inputs=[json.loads(l) for f in ('affine_results.jsonl','five_results.jsonl') for l in (HERE/f).read_text().splitlines()]
    blocks={r:solver.triples(r) for r in solver.reps}
    with tempfile.TemporaryDirectory() as td:
        tmp=Path(td);exe=tmp/'profile'
        subprocess.run([os.environ.get('CXX','c++'),'-O3','-std=c++17',str(HERE/'profile.cpp'),'-o',str(exe)],check=True)
        with (tmp/'in').open('w') as f:
            for row in inputs:
                C=[t for i,t in enumerate(blocks[row['code']]) if i not in row['deletions']]
                print(len(C),row['den'],file=f)
                for r in C+row['clique']:print(*r,file=f)
        with (tmp/'in').open() as f:keys=list(map(int,subprocess.check_output([exe],stdin=f,text=True).split()))
    assert len(keys)==len(inputs)
    counts=Counter(keys)
    print('distinct profiles',len(counts),'inputs',len(inputs))
    (HERE/'profile_indices.json').write_text(json.dumps(sorted(counts.items()),separators=(',',':')))
    if (HERE/'signatures.json').exists():
        check=json.loads((HERE/'signatures.json').read_text())['representatives']
        assert counts=={r['index']:r['count'] for r in check.values()}
        print('exact grouping matches')

"""Rebuild each graph on a reverse basis and independently exclude a 14-clique."""
from affine_four import HERE,ROOT,solver,previous,orbits
import argparse
import itertools
import json
import math
import multiprocessing as mp
import os
import subprocess
import tempfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

def verify(record):
    C=[b for k,b in enumerate(solver.triples(record['code'])) if k not in record['deletions']]
    ncore=len(C)
    rows=[[int(j in b)-int(17 in b) for j in range(17)] for b in reversed(C)]
    B=previous.basis_indices(rows);assert len(B)==17
    mat=solver.inv([rows[i] for i in B]);mat.append([-sum(v) for v in zip(*mat)])
    D=math.lcm(*(x.denominator for r in mat for x in r))
    coeff=[[int(D*x) for x in r] for r in mat]
    # Skip the basis rows first to reject signs earlier.
    order=[j for j in range(ncore) if ncore-1-j not in B]+[ncore-1-j for j in B]
    inp=str(D)+'\n'+'\n'.join(' '.join(map(str,r)) for r in coeff+[C[j] for j in order])
    n,e,res,nodes=map(int,subprocess.check_output([exe],input=inp,text=True).split())
    assert (n,e,res)==(record['directions'],record['edges'],0)
    # Lower bound: verify the actual 13 simultaneous lifts in the original coordinates.
    den=record['den'];ext=record['clique']
    assert len(ext)==57-ncore and record['maximum']==57-ncore
    for v in ext:
        x,h,s=v[:18],v[18],v[19]
        assert sum(x)==0 and h>=0 and h+sum(t*t for t in x)==10*den*den
        assert (h==0 and s==0) or (h>0 and s in (-1,1))
        assert all(abs(sum(x[k] for k in b))==den for b in C)
    for p,q in itertools.combinations(ext,2):
        ip=sum(a*b for a,b in zip(p[:18],q[:18]));h,g=p[18],q[18]
        assert any((sg*2*den*den-ip)**2==h*g and (sg*2*den*den-ip)*p[19]*q[19]>=0 for sg in (-1,1))
    return (record['code'],record['deletions'],nodes)

def main():
    global exe
    ap=argparse.ArgumentParser();ap.add_argument('--jobs',type=int,default=3);ap.add_argument('--five',action='store_true');args=ap.parse_args()
    name='five' if args.five else 'affine'
    if args.five:
        from affine_five import records
        reps=records();core_size=43;designs=1
    else:
        reps=orbits();core_size=44;designs=8
    rec=[json.loads(l) for l in (HERE/f'{name}_results.jsonl').read_text().splitlines()]
    assert [(r['code'],*r['deletions']) for r in rec]==[tuple(k) for k,m in reps]
    assert sum(r['multiplicity'] for r in rec)==designs*math.comb(48,48-core_size)
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);exe=p/'verify'
        src=(ROOT/'reference_bases/exact_clique.cpp').read_text();assert src.count('K=4,MAXN')==1
        (p/'exact_clique.hpp').write_text(src.split('int main(')[0].replace('K=4,MAXN','K=8,MAXN'))
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',f'-DCORE_SIZE={core_size}','-I',str(p),str(HERE/'verify_affine.cpp'),'-o',str(exe)],check=True)
        with ProcessPoolExecutor(args.jobs,mp_context=mp.get_context('fork')) as pool:
            nodes=list(pool.map(verify,rec,chunksize=4))
        (HERE/f'{name}_verified.json').write_text(json.dumps(dict(cases=len(nodes),labelled=512*designs*math.comb(48,48-core_size),minimum=min(r[2] for r in nodes),maximum=max(r[2] for r in nodes),nodes=sum(r[2] for r in nodes))))
if __name__=='__main__':main()

"""Compare the rooted negative-triangle degree profiles of the stored 57-line attainments."""
import hashlib
from functools import lru_cache
from concurrent.futures import ProcessPoolExecutor
from itertools import combinations
import json
from affine_four import ROOT,HERE,solver,previous
def fingerprint(g):
    n=len(g)
    masks=[sum(1<<i for i,x in enumerate(row) if x<0) for row in g]
    profile=[[] for _ in g]
    for i,j in combinations(range(n),2):
        h=(masks[i]^masks[j]).bit_count() if hasattr(int,'bit_count') else bin(masks[i]^masks[j]).count('1')
        v=h if g[i][j]>0 else n-h
        profile[i].append(v);profile[j].append(v)
    return hashlib.sha256(b''.join(sorted(bytes(sorted(row)) for row in profile))).hexdigest()
@lru_cache(None)
def base(code):
    b=solver.triples(code);return b,[[2*len(set(x)&set(y))-1 for y in b] for x in b]
def gram(row):
    b,M=base(row['code']);I=[i for i in range(48) if i not in row['deletions']]
    blocks=[b[i] for i in I];g=[[M[i][j] for j in I] for i in I];D=row['den'];ext=row['clique']
    for i,x in enumerate(ext):
        cross=[sum(x[p] for p in t)//D for t in blocks]
        for r,v in zip(g[:len(I)],cross):r.append(v)
        for j in range(i):
            y=ext[j];dot=sum(a*b for a,b in zip(x[:18],y[:18]))
            v=next(s for s in (-1,1) if (2*D**2*s-dot)**2==x[18]*y[18] and (2*D**2*s-dot)*x[19]*y[19]>=0)
            cross.append(v);g[len(I)+j].append(v)
        g.append(cross+[5])
    return g
def work(row):
    return fingerprint(gram(row)),[row['code'],row['deletions']]
if __name__=='__main__':
    files=[ROOT/'control_57.json',ROOT/'orbit_construction/reach/hex_control_57.json']
    for dirname in ('affine19','affine44_first','affine44_second','affine45','affine46','affine47'):
        files.extend((ROOT/dirname).glob('gram*.json'))
    controls={}
    for p in files:
        g=json.loads(p.read_text())
        if isinstance(g,list) and len(g)==57:controls.setdefault(fingerprint(g),[]).append(str(p.relative_to(ROOT)))
    reps={}
    import sys
    inputs=[json.loads(l) for file in ['affine_results.jsonl','five_results.jsonl'] for l in (HERE/file).read_text().splitlines()]
    if len(sys.argv)==2:
        fp=sys.argv[1];entry=json.loads((HERE/'signatures.json').read_text())['representatives'][fp]
        g=gram(inputs[entry['index']]);assert fingerprint(g)==fp
        previous.common.certify(g,57,18)
        (HERE/f'gram57_{fp[:14]}.json').write_text(json.dumps(g))
        sys.exit(0)
    with ProcessPoolExecutor(3) as ex:
        for idx,(fp,typ) in enumerate(ex.map(work,inputs,chunksize=16)):
            if fp not in reps:
                entry=dict(index=idx,case=typ,count=0,controls=controls.get(fp,[]))
                if fp not in controls:
                    g=gram(inputs[idx]);entry['certificate']=previous.common.certify(g,57,18)
                reps[fp]=entry
            reps[fp]['count']+=1
    (HERE/'signatures.json').write_text(json.dumps(dict(controls=controls,representatives=reps),indent=1))
    print('total',len(reps),'different from all compared controls',len(set(reps)-set(controls)))

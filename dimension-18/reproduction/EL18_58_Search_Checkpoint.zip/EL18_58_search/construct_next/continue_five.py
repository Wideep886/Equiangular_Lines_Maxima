"""Continue five-deletion searches beyond the zero design. Shared proved records are skipped."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import itertools
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
from functools import reduce
import subprocess
import tempfile
import affine_four as four
here=four.HERE
def records():
    s=four.solver;pts=s.pts
    switch={reduce(int.__xor__,[s.masks[i] for i in range(9) if (mask>>i)&1],0):mask for mask in range(512)}
    canon={r^v:(r,w) for r in s.reps for v,w in switch.items()}
    indices={r:{tuple(sorted(t)):j for j,t in enumerate(s.triples(r))} for r in s.reps}
    maps=[]
    for a,b,c,d in itertools.product(range(3),repeat=4):
        if (a*d-b*c)%3:
            for tx,ty in pts:
                p=[pts.index(((a*x+b*y+tx)%3,(c*x+d*y+ty)%3)) for x,y in pts]
                lines=[s.lines.index(tuple(sorted(p[v] for v in line))) for line in s.lines]
                maps.append((p,lines))
    repcount=math.comb(48,5)
    marked={r:bytearray(repcount) for r in s.reps if r!=0}
    C=[[math.comb(i,k) for i in range(48)] for k in range(6)]
    def rank(t):return sum(C[k][i] for k,i in enumerate(t,1))
    rec=[]
    for r in marked:
        perms=[]
        for p,lines in maps:
            code=sum(((r>>i)&1)<<j for i,j in enumerate(lines));q,flip=canon[code]
            assert q!=0
            f=[2*p[k//2]+((k%2)^((flip>>p[k//2])&1)) for k in range(18)]
            perm=[indices[q][tuple(sorted(f[k] for k in row))] for row in s.triples(r)]
            perms.append((q,perm))
        for t in itertools.combinations(range(48),5):
            if marked[r][rank(t)]:continue
            orbit={(q,tuple(sorted(perm[i] for i in t))) for q,perm in perms}
            assert min(orbit)==(r,t)
            for q,idx in orbit:
                j=rank(idx);assert not marked[q][j];marked[q][j]=1
            rec.append([[r,*t],len(orbit)])
    assert all(all(v) for v in marked.values()) and sum(v for _,v in rec)==7*repcount
    return rec

def main():
    p=argparse.ArgumentParser();p.add_argument('--jobs',type=int,default=4);p.add_argument('--batches',type=int,default=400)
    args=p.parse_args();file=here/'five_nonzero_orbits.json'
    if not file.exists():file.write_text(json.dumps(records(),separators=(',',':')))
    records_=json.loads(file.read_text())
    out=here/'five_nonzero_results.jsonl'
    done={(r['code'],*r['deletions']) for l in out.read_text().splitlines() if (r:=json.loads(l))} if out.exists() else set()
    pending=[(k,v) for k,v in records_ if tuple(k) not in done][:args.batches]
    with tempfile.TemporaryDirectory() as td:
        folder=Path(td);four.exe=folder/'scan';src=(four.ROOT/'affine45/scan.cpp').read_text()
        cpp=folder/'scan.cpp';cpp.write_text(src.replace('array<array<int,3>,45>','array<array<int,3>,43>'))
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(cpp),'-o',str(four.exe)],check=True)
        with ProcessPoolExecutor(args.jobs,mp_context=mp.get_context('fork')) as pool,out.open('a',buffering=1) as dest:
            for r in pool.map(four.lift,pending,chunksize=2):
                print(json.dumps(r,separators=(',',':')),file=dest)
                if r.get('maximum',0)>=15:
                    four.witness(r)
                    print('58 candidate',r['code'],r['deletions'],flush=True);break
    print('all nonzero reps',len(records_),'previous',len(done),'requested',len(pending))
if __name__=='__main__':main()

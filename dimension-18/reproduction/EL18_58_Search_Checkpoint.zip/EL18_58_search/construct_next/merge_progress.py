"""Merge the new Apple orbit and basis batches into complete prefix histories."""
import json
import shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for name,loc,start,key in [('orbits','orbit_construction/state',804126,'seed'),('bases','reference_bases/search_runs',180,'round')]:
    src=ROOT/name;dest=ROOT.parent/loc
    delta=json.loads((src/'progress.json').read_text());base=json.loads((dest/'progress.json').read_text())
    if base['next']==delta['next']:
        assert base['runs'][-(delta['next']-start):]==[r for r in delta['runs'] if r[key]>=start]
        continue
    assert base['next']==start
    added=[r for r in delta['runs'] if r[key]>=start]
    assert [r[key] for r in added]==list(range(start,delta['next']))
    if name=='bases':
        hashes={r['sha256'] for r in base['runs'] if 'sha256' in r}
        assert all(r.get('sha256') not in hashes for r in added)
    else:
        for sign,record in delta['representatives'].items():
            if record['seed']<start:continue
            assert sign not in base['representatives']
            stem=Path(record['file']).stem
            for f in src.glob(stem+'*'):shutil.copyfile(f,dest/f.name)
            base['representatives'][sign]=record
    base['runs'].extend(added);base['next']=delta['next']
    tmp=dest/'progress.next.tmp';tmp.write_text(json.dumps(base,indent=1)+'\n');tmp.replace(dest/'progress.json')
    print(name,len(added),base['next'])

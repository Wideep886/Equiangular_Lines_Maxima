"""Classify all four deleted blocks in the 4096 affine parity designs and search full real lifts."""
import argparse
import itertools
import json
import math
import multiprocessing
import os
import subprocess
import sys
import tempfile
from concurrent.futures import ProcessPoolExecutor
from functools import reduce
from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
spec=spec_from_file_location("affine45",ROOT/"affine45/search.py")
previous=module_from_spec(spec)
spec.loader.exec_module(previous)
solver=previous.solver

def orbits():
    switch={reduce(int.__xor__,[solver.masks[i] for i in range(9) if mask>>i&1],0):mask for mask in range(512)}
    reduction={r^v:(r,s) for r in solver.reps for v,s in switch.items()}
    assert len(reduction)==4096 and len(switch)==512
    designs={r:solver.triples(r) for r in solver.reps}
    indices={r:{tuple(sorted(b)):i for i,b in enumerate(blocks)} for r,blocks in designs.items()}
    points=solver.pts
    affine=[]
    for a,b,c,d in itertools.product(range(3),repeat=4):
        if (a*d-b*c)%3==0:continue
        for x,y in points:
            pi=[points.index(((a*i+b*j+x)%3,(c*i+d*j+y)%3)) for i,j in points]
            lm=[solver.lines.index(tuple(sorted(pi[i] for i in t))) for t in solver.lines]
            affine.append((pi,lm))
    assert len(affine)==432
    seen=set()
    records=[]
    for r,blocks in designs.items():
        maps=[]
        for pi,lm in affine:
            label=sum(((r>>i)&1)<<j for i,j in enumerate(lm))
            rep,flip=reduction[label]
            p=[2*pi[u//2]+((u%2)^((flip>>pi[u//2])&1)) for u in range(18)]
            maps.append((rep,[indices[rep][tuple(sorted(p[t] for t in b))] for b in blocks]))
        for a,b,c,d in itertools.combinations(range(48),4):
            tag=(r,a,b,c,d)
            if tag in seen:continue
            o={(rp,*sorted((p[a],p[b],p[c],p[d]))) for rp,p in maps}
            assert min(o)==tag and o.isdisjoint(seen)
            seen.update(o)
            records.append([tag,len(o)])
    assert len(seen)==len(designs)*math.comb(48,4)
    return records

def lift(record):
    (r,*dels),mult=record
    blocks=[t for i,t in enumerate(solver.triples(r)) if i not in dels]
    eq=[[int(k in t)-int(17 in t) for k in range(17)] for t in blocks]
    B=previous.basis_indices(eq)
    res=dict(code=r,deletions=dels,multiplicity=mult,basis=B,rank=len(B))
    if len(B)!=17:return dict(res,status="rank below 17")
    inv=solver.inv([eq[i] for i in B])
    inv.append([-sum(v) for v in zip(*inv)])
    D=math.lcm(*(x.denominator for row in inv for x in row))
    M=[[int(x*D) for x in row] for row in inv]
    inp=str(D)+'\n'+'\n'.join(' '.join(map(str,row)) for row in M+blocks)+'\n'
    lines=subprocess.check_output([exe],input=inp,text=True).splitlines()
    n,edges,m=map(int,lines[0].split())
    ext=[list(map(int,l.split())) for l in lines[1:]]
    assert len(ext)==m
    return dict(res,status='complete',den=D,directions=n,edges=edges,maximum=m,clique=ext)

def witness(row):
    r=row['code'];dels=row['deletions']
    D=row['den'];C=[b for k,b in enumerate(solver.triples(r)) if k not in dels]
    ext=row['clique'][:58-len(C)]
    g=[[2*len(set(a)&set(b))-1 for b in C] for a in C]
    for line,block in zip(g,C):
        for x in ext:
            t=sum(x[i] for i in block);assert abs(t)==D;line.append(t//D)
    for i,x in enumerate(ext):
        w=[g[t][len(C)+i] for t in range(len(C))]
        for j,y in enumerate(ext):
            if i==j:w.append(5);continue
            dot=sum(a*b for a,b in zip(x[:18],y[:18]))
            h,e=x[18:];v,f=y[18:]
            w.append(next(z for z in (-1,1) if (2*D**2*z-dot)**2==h*v and (2*D**2*z-dot)*e*f>=0))
        g.append(w)
    certificate=previous.common.certify(g,len(g),18)
    (HERE/f"affine_{len(g)}.json").write_text(json.dumps({'code':r,'deletions':dels,'gram':g,'certificate':certificate}))

def main():
    global exe
    ap=argparse.ArgumentParser();ap.add_argument('--end',type=int);ap.add_argument('--jobs',type=int,default=3)
    args=ap.parse_args()
    save=HERE/'affine_orbits.json'
    if save.exists():records=json.loads(save.read_text())
    else:records=orbits();save.write_text(json.dumps(records,separators=(',',':')))
    results=HERE/'affine_results.jsonl'
    done={(r['code'],*r['deletions']) for l in results.read_text().splitlines() if (r:=json.loads(l))} if results.exists() else set()
    work=[rec for rec in records[:args.end] if tuple(rec[0]) not in done]
    print('orbits',len(records),'this invocation',len(work),flush=True)
    src=(ROOT/'affine45/scan.cpp').read_text()
    assert src.count('array<array<int,3>,45>')==1
    with tempfile.TemporaryDirectory() as folder:
        exe=Path(folder)/'scan';cpp=exe.with_suffix('.cpp')
        cpp.write_text(src.replace('array<array<int,3>,45>','array<array<int,3>,44>'))
        subprocess.run([os.environ.get('CXX','c++'),'-std=c++17','-O3',str(cpp),'-o',str(exe)],check=True)
        with ProcessPoolExecutor(args.jobs,mp_context=multiprocessing.get_context('fork')) as pool,results.open('a',buffering=1) as f:
            for row in pool.map(lift,work,chunksize=1):
                if row.get('maximum',0)>=14 or row.get('maximum',0)==13 and not (HERE/'affine_57.json').exists():witness(row)
                print(json.dumps(row,separators=(',',':')),file=f)
                if row.get('maximum',0)>=14:print('witness',row['code'],row['deletions'],flush=True);break

if __name__=='__main__':main()

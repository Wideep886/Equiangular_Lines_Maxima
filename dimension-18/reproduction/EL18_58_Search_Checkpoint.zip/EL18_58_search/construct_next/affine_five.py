"""All five deletions for the zero parity design, modulo the 432 affine plane permutations."""
import argparse
import itertools
import json
import math
import multiprocessing as mp
import os
import subprocess
import tempfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import affine_four as four
HERE=four.HERE
def records():
    blocks=four.solver.triples(0);index={tuple(sorted(t)):j for j,t in enumerate(blocks)}
    points=four.solver.pts;perms=[]
    for a,b,c,d in itertools.product(range(3),repeat=4):
        if (a*d-b*c)%3==0:continue
        for tx,ty in points:
            pi=[points.index(((a*x+b*y+tx)%3,(c*x+d*y+ty)%3)) for x,y in points]
            perm=[index[tuple(sorted(2*pi[i//2]+(i%2) for i in t))] for t in blocks];perms.append(perm)
    assert len(perms)==432
    choose=[[math.comb(i,k) for i in range(48)] for k in range(6)]
    def rank(t):return sum(choose[k][i] for k,i in enumerate(t,1))
    seen=bytearray(math.comb(48,5));rec=[]
    for t in itertools.combinations(range(48),5):
        if seen[rank(t)]:continue
        orbit={tuple(sorted(p[i] for i in t)) for p in perms}
        assert min(orbit)==t
        for s in orbit:
            k=rank(s);assert not seen[k];seen[k]=1
        rec.append([[0,*t],len(orbit)])
    assert all(seen)
    return rec
def main():
    p=argparse.ArgumentParser();p.add_argument('--jobs',type=int,default=4);p.add_argument('--end',type=int)
    args=p.parse_args()
    recfile=HERE/'five_orbits.json'
    if recfile.exists():rec=json.loads(recfile.read_text())
    else:rec=records();recfile.write_text(json.dumps(rec,separators=(',',':')))
    print('five-deletion orbits',len(rec),flush=True)
    out=HERE/'five_results.jsonl'
    prior={tuple(r['deletions']) for s in out.read_text().splitlines() if (r:=json.loads(s))} if out.exists() else set()
    with tempfile.TemporaryDirectory() as td:
        folder=Path(td);four.exe=folder/'scan';src=(four.ROOT/'affine45/scan.cpp').read_text()
        cpp=folder/'scan.cpp';cpp.write_text(src.replace('array<array<int,3>,45>','array<array<int,3>,43>'))
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(cpp),'-o',str(four.exe)],check=True)
        with ProcessPoolExecutor(args.jobs,mp_context=mp.get_context('fork')) as pool,out.open('a',buffering=1) as dest:
            for r in pool.map(four.lift,[z for z in rec[:args.end] if tuple(z[0][1:]) not in prior],chunksize=4):
                print(json.dumps(r,separators=(',',':')),file=dest)
                if r.get('maximum',0)>=15:
                    four.witness(r)
                    print('58 directions in case',r['deletions'],flush=True)
                    # Full clique, scale and core in row suffice to reconstruct the witness.
                    break
if __name__=='__main__':main()

"""Fixed two-point exact resolvent moments for m=13, parent 2775."""
import json,sys
from pathlib import Path
from itertools import product
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'audit_layer'))
sys.dont_write_bytecode=True
from polynomial13 import SOURCE,factors,native,poly_types,deriv,val,rem,mul,phase_one,lat
INDEX=2775
def data():
    IDs=next(r[2] for r in map(json.loads,(HERE.parent/'audit_layer'/'poly13_final.jsonl').read_text().splitlines()) if r[0]==INDEX)
    fac=[([1,0],13)]+factors(json.loads((SOURCE/'parents.json').read_text())[INDEX])
    g,target,deck=native([([1,8],40)]+fac)
    _,_,pairs=poly_types({i:sum(1<<j for j in IDs) for i in IDs},fac,g,deck,IDs)
    diag=[deck[k] for k in IDs]
    base={(i,j):pairs[IDs[i],IDs[j]] for i in range(4) for j in range(i,4)}
    decks=[]
    for a in range(59):
        for b in range(59-a):
            for c in range(59-a-b):
                n=(a,b,c,58-a-b-c)
                if all(sum(m*d[k] for m,d in zip(n,diag))==v for k,v in enumerate(target)):
                    decks.append(n)
    assert decks==[(2,28,16,12)]
    return IDs,diag,g,decks[0],base
def add(a,b):
    a=[0]*max(0,len(b)-len(a))+list(a);b=[0]*max(0,len(a)-len(b))+list(b)
    return [u+v for u,v in zip(a,b)]
def scalar(v,a):return [v*x for x in a]
def sub(a,b):return add(a,scalar(-1,b))
def l2(u,v,w):return mul(mul(u,v),w)
def determinant(h,k,l,q,r,s,sign):
    return add(add(l2(h,k,l),scalar(2*sign,l2(q,r,s))),scalar(-1,add(l2(h,s,s),add(l2(k,r,r),l2(l,q,q)))))
def valid(h,k,l,q,r,s,e):
    p=determinant(h,k,l,q,r,s,e)
    if any(x%4 for x in p):return False
    # W(0) is PSD and W(-8) is negative semidefinite.
    if val(p,0)<0 or val(p,-8)>0:return False
    # At every rank-one root the signed 3x3 Gram must have rank <=1.
    simple=[1,3,-2,-6]
    if any(rem(sub(mul(q,r),scalar(e,mul(h,s))),simple)):return False
    # D vanishes twice at each rank-one root, and once at the rank-two root.
    square=mul(mul(simple,simple),[1,-2])
    if any(rem(p,square)):return False
    return True
def proj_moment(u,z,w,g):
    if z==w:return 2*(val(deriv(g),z)*val(u,z)-val(g,z)*val(deriv(u),z))
    a=2*(val(g,w)*val(u,z)-val(g,z)*val(u,w));assert a%(w-z)==0
    return a//(w-z)
def main():
    ids,H,g,n,base=data()
    active={k:list(v) for k,v in base.items()}
    def opts(i,j):return active[min(i,j),max(i,j)]
    logs=[]
    Z=range(-1,3)
    for iteration in range(100):
        deletions=[]
        for (i,j),pairs in active.items():
            for p in pairs:
                # (W(z)W(w))_ij minus the two anchors' own contributions.
                rhs=tuple(n[k]-(i==k)-(j==k) for k in range(4))
                rhs+=tuple(proj_moment(p,z,w,g)-val(H[i],z)*val(p,w)-val(p,z)*val(H[j],w) for z in Z for w in Z)
                # Both endpoint rows must simultaneously meet their own squared moments.
                rhs+=tuple(proj_moment(H[u],z,z,g)-val(H[u],z)**2-val(p,z)**2 for u in (i,j) for z in Z)
                S=set()
                for k in range(4):
                    if not rhs[k]:continue
                    for r,s,e in product(opts(i,k),opts(j,k),(-1,1)):
                        if not valid(H[i],H[j],H[k],p,r,s,e):continue
                        x=tuple(int(k==t) for t in range(4))
                        x+=tuple(e*val(r,z)*val(s,w) for z in Z for w in Z)
                        x+=tuple(val(t,z)**2 for t in (r,s) for z in Z)
                        S.add(x)
                S=sorted(S)
                if not S:c={'kind':'empty'}
                elif not lat(S,rhs):c={'kind':'lattice'}
                else:c=phase_one(S,rhs)
                if c['kind']!='primal':deletions.append([i,j,p,len(S),c])
        if not deletions:break
        logs.append(deletions)
        for i,j,p,_,_ in deletions:active[i,j].remove(p)
        if any(not opts(i,j) and (i!=j or n[i]>1) for i,j in active):break
    res={'index':INDEX,'ids':ids,'diag':H,'g':g,'counts':n,'pairs':[[*k,v]for k,v in base.items()],
         'remove':logs,'remaining':[[*k,v] for k,v in active.items()]}
    Path(__file__).with_name('result.json').write_text(json.dumps(res,separators=(',',':'))+'\n')
    print('rounds',list(map(len,logs)),'counts',[(k,len(v))for k,v in active.items()])
if __name__=='__main__':main()

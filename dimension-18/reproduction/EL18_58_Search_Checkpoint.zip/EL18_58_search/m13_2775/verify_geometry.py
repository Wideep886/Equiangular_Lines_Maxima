"""Independent interpolation for the pair superdeck and exact C4 geometry."""
from itertools import product
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json

def val(q,x):
    v=0
    for a in q:v=v*x+a
    return v

def quad(q):
    # F_0 + F_1 sqrt(2)
    a,b=0,0
    for c in q:a,b=c+2*b,a
    return a,b
def mul(x,y):
    a,b=x;c,d=y
    return (a*c+2*b*d,a*d+b*c)

def catalogue(h,k):
    w=val(h,0)*val(k,0);z=val(h,-3)*val(k,-3);s=isqrt(z)
    if s*s!=z:return []
    U,V=mul(quad(h),quad(k));out=set()
    for D in range(-isqrt(w),isqrt(w)+1):
        if (D*D-w)%4:continue
        for v in range(-isqrt(U),isqrt(U)+1):  # constant term modulo x^2-2
            r=U-v*v
            if r%2:continue
            u=isqrt(r//2)
            if 2*u*u!=r or (v-4-D)%2:continue
            B=(v-4-D)//2
            for u0,qm3 in product({-u,u},{-s,s}):
                if 2*v*u0!=V:continue
                num=81+9*B-3*u0+D-qm3
                if num%21:continue
                A=num//21;q=(1,A,B,u0-2*A,D)
                assert quad(q)==(v,u0) and val(q,-3)==qm3
                if any((p:=val(h,t)*val(k,t)-val(q,t)**2)<0 or p%4 for t in (2,-8)):continue
                # Coefficientwise mod 4 of 2x2 minors.
                ab=[0]*11
                for i,x in enumerate(h):
                    for j,y in enumerate(k):ab[i+j]+=x*y
                for i,x in enumerate(q):
                    for j,y in enumerate(q):ab[i+j+2]-=x*y
                if all(not v%4 for v in ab):out.add(q)
    return sorted(out)

def main():
    r=json.loads(Path(__file__).with_name('result.json').read_text());H=r['diag']
    for i,j,polys in r['pairs']:
        assert catalogue(H[i],H[j])==[tuple(q) for q in polys]
    Q={(i,j):p for i,j,p in r['remaining']}
    # Entries at 0, after switching A and B together using the -3 projector.
    def relative(i,j,t,sgn):
        return sorted({(1 if val(q,sgn)>0 else -1)*val(q,t) for q in Q[i,j]})
    assert relative(0,0,0,-3)==[32] and relative(0,1,0,-3)==[-16,8]
    assert [val(h,0) for h in H]==[32,44,48,36]
    assert all(val(q,0)==0 for j in (2,3) for q in Q[0,j])
    assert all(abs(val(q,0))==12 for key in ((1,2),(2,3)) for q in Q[key])
    C=quad(H[2]);Cvals=set()
    for q in Q[2,2]:
        x=quad(q);assert x in (C,tuple(-z for z in C))
        Cvals.add(val(q,0)*(1 if x==C else -1))
    assert Cvals=={-24,0}
    assert all(val(q,2) in (-20,0,20) for v in Q.values() for q in v)
    assert all(quad(q) in (quad(H[3]),tuple(-x for x in quad(H[3]))) for q in Q[3,3])
    # Norms and mutually orthogonal lines in the three-dimensional C4 space.
    balanced=[x for x in product((-1,1),repeat=4) if not sum(x)]
    def eig(x):
        y=[2*a-x[(i-1)%4]-x[(i+1)%4] for i,a in enumerate(x)]
        t=x[0]*y[0];assert all(v==t*a for v,a in zip(y,x))
        return t
    for x,y in product(balanced,repeat=2):
        lam=eig(x);mu=eig(y);d=F(sum(a*b for a,b in zip(x,y)),2*mu)
        # d is the cross contribution to (S+5I)=W/12+other terms.
        if lam==mu==4:assert abs(d)==F(1,2)
        else:assert d.denominator==1
    alternations=[]
    for nrm,first in [(44,8),(44,-16),(36,0)]:
        ks=[k for k in range(5) if F(first*first,32)+6*k+12*(4-k)==nrm]
        assert len(ks)==1;alternations.append(ks[0])
    assert alternations==[1,2,2]
    print('All ten pair superdecks independently reconstructed. C4 cross-products and alternation counts verified.')
if __name__=='__main__':main()

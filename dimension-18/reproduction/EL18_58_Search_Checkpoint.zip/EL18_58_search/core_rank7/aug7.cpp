#include <algorithm>
#include <cassert>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <set>
#include <map>
#include <cmath>
using namespace std;
struct Pt {array<int,12> z{};array<long long,9> t{}; int norm;};
int main(){int n;cin>>n;
 for(int h=0;h<n;h++){
  string word;int r,D,pr[4],cy[3],idx[9],g[12][12],w[12];long long q[9][9];
  cin>>word>>r>>D;for(char i=0;i<12;i++)w[(int)i]=word[(int)i]-'0';
  for(auto &v:pr)cin>>v;for(auto &v:cy)cin>>v;
  for(int j=0;j<r;j++)cin>>idx[j];
  for(int i=0;i<r;i++)for(int j=0;j<r;j++)cin>>q[i][j];
  for(auto &row:g)for(auto &v:row)cin>>v;
  vector<Pt> cand[8];
  for(int b=0;b<4096;b++){
   bool balanced=true;for(int cm:cy)if(2*__builtin_popcount((unsigned)(b&cm))!=__builtin_popcount((unsigned)cm))balanced=false;
   if(!balanced)continue;
   for(int c=0;c<8;c++){
    Pt u;for(int i=0;i<12;i++){u.z[i]=2*((b>>i)&1)-1;if(c/2==w[i]/2)u.z[i]-=((c%2==w[i]%2)?1:-1);}
    for(int i=0;i<r;i++)for(int j=0;j<r;j++)u.t[i]+=q[i][j]*u.z[idx[j]];
    long long norm=0;for(int j=0;j<r;j++)norm+=u.t[j]*u.z[idx[j]];
    if(norm>3*D||(r==9&&norm!=3*D))continue;
    bool ok=true;for(int i=0;i<12&&ok;i++){
     long long v=0;for(int j=0;j<r;j++)v+=u.t[j]*g[i][idx[j]];
     if(v!=D*u.z[i])ok=false;
    }
    if(ok){u.norm=(int)norm;cand[c].push_back(u);}
   }
  }
  bool ok=true;
  for(int c=0;c<8;c++){if(cand[c].empty() || (r==9 && (int)cand[c].size()<6-pr[c/2]))ok=false;}
  // For the signed column c the 6-pr[c/2] residual vectors, even when spread
  // among different rows, have inner product in {-3,-2,-1,0}. In full rank
  // the candidate projections are the actual residuals.
  if(ok && r==9){
   for(int c=0;c<8 && ok;c++){
    int k=6-pr[c/2],n=(int)cand[c].size();vector<vector<char>> edges(n,vector<char>(n));
    for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
     long long u=0;for(int t=0;t<r;t++)u+=cand[c][i].t[t]*cand[c][j].z[idx[t]];
     edges[i][j]=(u==0 || u==-D || u==-2*D || u==-3*D);
    }
    auto clique=[&](auto&& self,const vector<int>& p,int sz)->bool{
     if(sz>=k)return true;
     for(int i=0;i<(int)p.size();i++){
      if(sz+(int)p.size()-i<k)return false;
      vector<int> sub;for(int j=i+1;j<(int)p.size();j++)if(edges[p[i]][p[j]])sub.push_back(p[j]);
      if(self(self,sub,sz+1))return true;
     }return false;
    };
    vector<int> pool(n);for(int i=0;i<n;i++)pool[i]=i;
    if(!clique(clique,pool,0))ok=false;
   }
  }

  if(ok && r==8){
    auto sf=[](int x){for(int d=2;d*d<=x;d++){while(x%(d*d)==0)x/=d*d;}return x;};
    std::set<int> ds;
    for(auto &cl:cand)for(auto &u:cl){int v=3*D-u.norm;if(v){int a=sf(v);if(16*D%a==0)ds.insert(a);}}
    bool admitted=false;
    for(int d:ds){
      bool possible=true;
      for(int c=0;c<8&&possible;c++){
        vector<pair<int,int>> pts;
        for(int j=0;j<(int)cand[c].size();j++){
          int defect=3*D-cand[c][j].norm;
          if(!defect)pts.emplace_back(j,0);
          else if(defect%d==0){int z=(int)std::sqrt(defect/d);if(z*z*d==defect){pts.emplace_back(j,z);pts.emplace_back(j,-z);}}
        }
        int k=6-pr[c/2],n=(int)pts.size();
        vector<vector<char>> gr(n,vector<char>(n));
        for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
          auto a=pts[i],b=pts[j];
          long long v=(long long)d*a.second*b.second;
          for(int t=0;t<r;t++)v+=cand[c][a.first].t[t]*cand[c][b.first].z[idx[t]];
          gr[i][j]=(v==0 || v==-D || v==-2*D || v==-3*D);
        }
        auto search=[&](auto&& self,const vector<int>& set,int size)->bool{
          if(size>=k)return true;
          for(int i=0;i<(int)set.size();i++){
            if(size+(int)set.size()-i<k)return false;
            vector<int> sub;for(int j=i+1;j<(int)set.size();j++)if(gr[set[i]][set[j]])sub.push_back(set[j]);
            if(self(self,sub,size+1))return true;
          }return false;
        };
        vector<int> all(n);for(int j=0;j<n;j++)all[j]=j;
        if(!search(search,all,0))possible=false;
      }

      // A whole switched column has zero residual sum. Its plus and minus
      // outside groups both draw from the same candidate cloud after switching.
      for(int c=0;c<8&&possible;c+=2){
        vector<pair<int,int>> pts;
        for(int j=0;j<(int)cand[c].size();j++){
          int v=3*D-cand[c][j].norm;int z=(int)std::sqrt(v/d);
          if(z*z*d==v){pts.emplace_back(j,z);if(z)pts.emplace_back(j,-z);}
        }
        int k=6-pr[c/2],n=(int)pts.size();
        vector<vector<char>> gr(n,vector<char>(n));
        for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
          auto a=pts[i],b=pts[j];long long v=(long long)d*a.second*b.second;
          for(int t=0;t<r;t++)v+=cand[c][a.first].t[t]*cand[c][b.first].z[idx[t]];
          gr[i][j]=(v==0 || v==-D || v==-2*D || v==-3*D);
        }
        using Sum=array<int,13>;Sum target{},acc{};
        for(int i=0;i<12;i++) for(int a=0;a<12;a++)if(w[a]/2==c/2)target[i]-=(w[a]%2?-1:1)*g[i][a];
        set<Sum> seen;bool found=false,limit=false;int leaves=0;
        auto search=[&](auto&& self,const vector<int>& p,int chosen)->void{
          if(found||limit)return;
          if(chosen==k){
            if(++leaves>=100000){limit=true;return;}
            seen.insert(acc);Sum need;for(int i=0;i<13;i++)need[i]=target[i]-acc[i];
            found=seen.count(need);return;
          }
          for(int t=0;t<(int)p.size() && !found && !limit;t++){
            if(chosen+(int)p.size()-t<k)return;
            int a=p[t];auto u=pts[a];auto& obj=cand[c][u.first];vector<int> sub;
            for(int b=t+1;b<(int)p.size();b++)if(gr[a][p[b]])sub.push_back(p[b]);
            for(int j=0;j<12;j++)acc[j]+=obj.z[j];acc[12]+=u.second;
            self(self,sub,chosen+1);
            for(int j=0;j<12;j++)acc[j]-=obj.z[j];acc[12]-=u.second;
          }
        };
        vector<int> all(n);for(int j=0;j<n;j++)all[j]=j;search(search,all,0);
        if(!found&&!limit)possible=false;
      }
      if(possible){admitted=true;break;}
    }
    ok=admitted;
  }
  if(ok && r==7){
    int ac=-1,score=100000;
    for(int c=0;c<8;c++){
      int zeros=0;for(auto &v:cand[c])zeros+=(v.norm==3*D);
      if(zeros<6-pr[c/2] && (int)cand[c].size()-zeros<score){ac=c;score=cand[c].size()-zeros;}
    }
    if(ac!=-1){
      bool possible=false;
      for(int ai=0;ai<(int)cand[ac].size()&&!possible;ai++){
        const auto &anchor=cand[ac][ai];int h=3*D-anchor.norm;if(!h)continue;
        struct Lift{int idx, dd, g, z;};
        vector<Lift> pts0[8];int hd=D*h;set<int> classes;
        for(int c=0;c<8;c++){
          int dc=c/2==ac/2 ? (c%2==ac%2?1:-1):0;
          for(int j=0;j<(int)cand[c].size();j++){
            const auto &v=cand[c][j];long long a=0;
            for(int t=0;t<r;t++)a+=anchor.t[t]*v.z[idx[t]];
            vector<int> dots={-2-dc,-1-dc,-dc,1-dc};
            if(c==ac&&ai==j)dots.push_back(3);
            for(int ip:dots){
              int dd=ip*D-a;int gg=h*(3*D-v.norm)-dd*dd;
              if(gg<0)continue;
              pts0[c].push_back({j,dd,gg,0});
              if(gg){int key=gg;for(int s=2;s*s<=key;s++)while(key%(s*s)==0)key/=s*s;
                     if(16*hd%key==0)classes.insert(key);}
            }
          }
        }
        for(int d:classes){
          vector<Lift> pts[8];bool valid=true;
          for(int c=0;c<8&&valid;c++){
            for(auto u:pts0[c]){
              int s=(int)sqrt(u.g/d);if(s*s*d!=u.g)continue;
              u.z=s;pts[c].push_back(u);if(s){u.z=-s;pts[c].push_back(u);}
            }
            int need=6-pr[c/2],n=pts[c].size();if(n<need){valid=false;break;}
            vector<vector<char>> adj(n,vector<char>(n));
            for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
              auto a=pts[c][i],b=pts[c][j];long long val=(long long)a.dd*b.dd+(long long)d*a.z*b.z;
              for(int t=0;t<r;t++)val+=(long long)h*cand[c][a.idx].t[t]*cand[c][b.idx].z[idx[t]];
              adj[i][j]=(val==0||val==-hd||val==-2*hd||val==-3*hd);
            }
            auto clique=[&](auto&& self,const vector<int>& p,int k)->bool{
              if(k>=need)return true;
              for(int i=0;i<(int)p.size();i++){
                if(k+(int)p.size()-i<need)return false;
                vector<int> sub;for(int j=i+1;j<(int)p.size();j++)if(adj[p[i]][p[j]])sub.push_back(p[j]);
                if(self(self,sub,k+1))return true;
              }return false;
            };
            vector<int> all(n);for(int j=0;j<n;j++)all[j]=j;
            if(!clique(clique,all,0))valid=false;
          }
          // Both groups in a column agree after their signed sum and the
          // contribution of the anchor row have been added.
          for(int col=0;col<4&&valid;col++){
            using Sum=array<int,14>;Sum target{};
            for(int i=0;i<12;i++)for(int j=0;j<12;j++)if(w[j]/2==col)
              target[i]-=(w[j]%2?-1:1)*g[i][j];
            set<Sum> plus;
            bool match=false,limit=false;
            for(int side=0;side<2&&!limit&&!match;side++){
              int c=2*col+side,k=6-pr[col],n=pts[c].size();
              vector<vector<char>> edge(n,vector<char>(n));
              int fixed=-1;
              for(int i=0;i<n;i++){
                const auto &x=pts[c][i];
                if(c==ac&&x.idx==ai&&x.dd==h&&x.z==0)fixed=i;
                for(int j=i+1;j<n;j++){
                  const auto &y=pts[c][j];long long prod=(long long)x.dd*y.dd+(long long)d*x.z*y.z;
                  for(int l=0;l<r;l++)prod+=(long long)h*cand[c][x.idx].t[l]*cand[c][y.idx].z[idx[l]];
                  edge[i][j]=edge[j][i]=(prod==0||prod==-hd||prod==-2*hd||prod==-3*hd);
                }
              }
              assert(c!=ac || fixed>=0);
              int leaves=0;Sum acc{};
              auto add=[&](int i,int s){
                const auto &x=pts[c][i];
                for(int j=0;j<12;j++)acc[j]+=s*cand[c][x.idx].z[j];
                acc[12]+=s*x.dd;acc[13]+=s*x.z;
              };
              auto dfs=[&](auto &&self,const vector<int>& pool,int count)->void{
                if(count==k){
                  if(++leaves>30000){limit=true;return;}
                  if(side==0)plus.insert(acc);
                  else {Sum need;for(int j=0;j<14;j++)need[j]=target[j]+acc[j];match=plus.count(need);}
                  return;
                }
                for(int t=0;t<(int)pool.size()&& !match&&!limit;t++){
                  if(count+(int)pool.size()-t<k)return;
                  int p=pool[t]; vector<int> sub;
                  for(int j=t+1;j<(int)pool.size();j++)if(edge[p][pool[j]])sub.push_back(pool[j]);
                  add(p,1);self(self,sub,count+1);add(p,-1);
                }
              };
              vector<int> pool;for(int i=0;i<n;i++)if(fixed<0||edge[fixed][i])pool.push_back(i);
              if(fixed>=0)add(fixed,1);dfs(dfs,pool,(fixed>=0));
              if(side==0&&!limit&&plus.empty())break;
            }
            if(!match&&!limit)valid=false;
          }
          if(valid){possible=true;break;}
        }
      }
      if(!possible)ok=false;
    }
  }
  cout<<h<<' '<<ok;for(auto &c:cand)cout<<' '<<c.size();cout<<'\n';
 }
}

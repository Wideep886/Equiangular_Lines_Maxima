"""Constraint propagation for compatible intersecting complete row/column words."""
from pathlib import Path
from collections import Counter
from itertools import permutations
import argparse,json
import occupation
from functools import lru_cache

def word_states(lines):
    result=[]
    for l in lines:
        prof,parts,letters,rank=l.split()
        prof=tuple(map(int,prof)); w=list(map(int,letters));edges=set();start=0
        for n in map(int,parts.strip(',').split(',')):
            for i in range(n):edges.add(tuple(sorted((start+i,start+(i+1)%n))))
            start+=n
        state=[]
        for c,a in enumerate(prof):
            ids=sorted((i for i,z in enumerate(w) if z//2==c),key=lambda i:w[i]%2)
            mask=sum(1<<t for t,(i,j) in enumerate(occupation.bit_edges(a)) if tuple(sorted((ids[i],ids[j]))) in edges)
            state.append(occupation.canon(a,mask))
        result.append((prof,state))
    return result
def solve(t,words,closed,allowed=None):
    orders=[]; pools=[]
    for row in (*t,*zip(*t)):
        order=sorted(range(4),key=lambda c:-row[c])
        profile=tuple(row[c] for c in order);orders.append(tuple(order.index(c) for c in range(4)))
        pools.append({i for i,(prof,s) in enumerate(words) if prof==profile and (allowed is None or i in allowed)})
    stats=Counter()
    @lru_cache(None)
    def compatible(i,j,u,v):
        a,b=orders[i][j],orders[4+j][i];n=t[i][j]
        return ((u,a,v,b) not in closed and
                words[u][1][a]==occupation.complement(n,words[v][1][b]))
    def dfs(pool):
        stats['nodes']+=1
        while True:
            changed=False
            for i in range(4):
                for j in range(4):
                    q=[(u,v) for u in pool[i] for v in pool[4+j] if compatible(i,j,u,v)]
                    if not q:return None
                    first=set(u for u,v in q);second=set(v for u,v in q)
                    changed|=len(first)<len(pool[i]) or len(second)<len(pool[4+j])
                    pool[i]=first;pool[4+j]=second
            if not changed:break
        k=min((i for i in range(8) if len(pool[i])>1),key=lambda j:len(pool[j]),default=None)
        if k is None:
            vals=[next(iter(s)) for s in pool]
            st=[[words[vals[i]][1][orders[i][j]] for j in range(4)] for i in range(4)]
            if 'transversals' in globals():
                yes,reason=transversals(t,st)
                if not yes:stats[reason]+=1;return None
            return vals
        for a in sorted(pool[k]):
            nxt=pool[:];nxt[k]={a};w=dfs(nxt)
            if w is not None:return w
    return dfs(pools),stats
def main():
    p=argparse.ArgumentParser();p.add_argument('answers',type=Path);p.add_argument('--words',type=Path,default=Path('words_aug7.txt'));p.add_argument('--transversal',type=Path,default=None);p.add_argument('--ids',nargs='*',type=int,default=[216,217,218,222,223]);args=p.parse_args()
    if args.transversal:
        import sys
        sys.path.insert(0,str(args.transversal));import transversal
        global transversals
        transversals=transversal.check
    ws=word_states(args.words.read_text().splitlines())
    closed=set()
    for l in args.answers.read_text().splitlines():
        u,a,v,b,ok=map(int,l.split())
        if not ok:closed.add((u,a,v,b));closed.add((v,b,u,a))
    tables=occupation.tables()
    print(len(ws),'words,',len(closed),'oriented infeasible margin-pairs')
    for i in args.ids:
        sol,stats=solve(tables[i],ws,closed)
        print(i,sol,dict(stats),flush=True)
if __name__=='__main__':main()

"""Exact extension of a row with full residual rank 9; no antipodality assumptions."""
from fractions import Fraction as F
from itertools import product,combinations
from pathlib import Path
from math import gcd,lcm
from functools import reduce
import json
def integer_basis_and_inverse(G):
    n=len(G);a=[[F(v) for v in row] for row in G];k=0;inds=[]
    for j in range(n):
        ix=next((i for i in range(k,n) if a[i][j]),None)
        if ix is None:continue
        a[k],a[ix]=a[ix],a[k];d=a[k][j];a[k]=[v/d for v in a[k]]
        for i in range(k+1,n):
            d=a[i][j];a[i]=[x-d*y for x,y in zip(a[i],a[k])]
        k+=1;inds.append(j)
    inv=[[F(G[i][j]) for j in inds]+[F(int(j==i)) for j in inds] for i in inds]
    for i in range(k):
        d=inv[i][i];inv[i]=[v/d for v in inv[i]]
        for j in range(k):
            if i!=j:
                d=inv[j][i];inv[j]=[a-d*b for a,b in zip(inv[j],inv[i])]
    inv=[r[k:] for r in inv];det=lcm(*(x.denominator for row in inv for x in row))
    return inds,det,[[int(det*x) for x in row] for row in inv]
def geom(pr,parts,w):
    word=list(map(int,w));ls=list(map(int,parts.strip(',').split(',')));cy=[];e=set();s=0
    for n in ls:
        cy.append(list(range(s,s+n)))
        for i in range(n):e.add(tuple(sorted((s+i,s+(i+1)%n))))
        s+=n
    gram=[[4*int(i==j)-2*int(tuple(sorted((i,j))) in e)-
          (1 if word[i]%2==word[j]%2 else -1)*int(word[i]//2==word[j]//2) for i in range(12)] for j in range(12)]
    return word,cy,gram
def candidates(pr,parts,w):
    word,cy,G=geom(pr,parts,w);R,D,Q=integer_basis_and_inverse(G)
    classes=[[] for _ in range(8)]
    for selections in product(*(combinations(c,len(c)//2) for c in cy)):
        pos=set(x for s in selections for x in s); eps=[1 if i in pos else -1 for i in range(12)]
        for c in range(8):
            z=[s-((1 if w%2==c%2 else -1) if w//2==c//2 else 0) for w,s in zip(word,eps)]
            t=[sum(v*z[i] for v,i in zip(q,R)) for q in Q]
            if any(sum(t[a]*G[i][ia] for a,ia in enumerate(R))!=D*z[i] for i in range(12) if i not in R):continue
            N=sum(t[a]*z[ia] for a,ia in enumerate(R))
            if (N!=3*D if len(R)==9 else N>3*D):continue
            classes[c].append((eps,z,t))
    return R,D,Q,classes
def check_classes(pr,parts,w):
    R,D,Q,classes=candidates(pr,parts,w)
    if len(R)<9:return dict(rank=len(R),counts=list(map(len,classes)))
    caps=[]
    for c,st in enumerate(classes):
        def compatible(a,b):
            v=sum(a[2][i]*b[1][j] for i,j in enumerate(R));return v in (-D,-3*D)
        edges=[{j for j,b in enumerate(st) if j>i and compatible(a,b)} for i,a in enumerate(st)]
        def rec(active,level):
            if level==4:return 4
            best=level
            for v in active:
                best=max(best,rec(active&edges[v],level+1))
                if best==4:break
            return best
        caps.append(rec(set(range(len(st))),0))
    return dict(rank=len(R),counts=list(map(len,classes)),capacities=caps)
if __name__=='__main__':
    ROOT=Path(__file__).parent
    for l in (ROOT/'words.txt').read_text().splitlines():
        pr,parts,w,r=l.split()
        if pr not in ['4200','4110','3300','3210'] or r!='9':continue
        res=check_classes(pr,parts,w)
        print(pr,parts,w,res,flush=True)

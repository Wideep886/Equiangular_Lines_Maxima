"""Solve the exact row/column negative-cycle compatibility CSP as a necessary condition."""
from pathlib import Path
from itertools import combinations,permutations,product
from functools import lru_cache
from collections import Counter
import argparse,json

@lru_cache(None)
def bit_edges(a):return tuple(combinations(range(2*a),2))
@lru_cache(None)
def maps(a):
    edges=bit_edges(a);idx={e:i for i,e in enumerate(edges)}
    ps=list(permutations(range(a)));out=[]
    for p in ps:
        for q in ps:
            v=(*p,*(a+j for j in q))
            out.append(tuple(1<<idx[tuple(sorted((v[i],v[j])))] for i,j in edges))
    return out
@lru_cache(None)
def canon(a,mask):
    ones=[i for i in range(len(bit_edges(a))) if mask>>i&1]
    return min(sum(m[i] for i in ones) for m in maps(a))
@lru_cache(None)
def complement(a,mask):
    cross=sum(1<<t for t,(i,j) in enumerate(bit_edges(a)) if i<a<=j)
    return canon(a,mask^cross)

def profile_states(path):
    base={}
    for line in path.read_text().splitlines():
        prof,parts,letters,rank=line.split();pr=tuple(map(int,prof));word=tuple(map(int,letters))
        row_edges=set();s=0
        for ln in map(int,parts.strip(',').split(',')):
            for i in range(ln):row_edges.add(tuple(sorted([s+i,s+(i+1)%ln])))
            s+=ln
        state=[]
        for c,a in enumerate(pr):
            verts=sorted((i for i,k in enumerate(word) if k//2==c),key=lambda i:word[i]%2)
            mask=sum(1<<t for t,(i,j) in enumerate(bit_edges(a)) if tuple(sorted((verts[i],verts[j]))) in row_edges)
            state.append(canon(a,mask))
        base.setdefault(pr,set()).add(tuple(state))
    return base

def tables():
    rows=[p for p in product(range(5),repeat=4) if sum(p)==6]
    units=set()
    for ix,a in enumerate(rows):
        for jx in range(ix,len(rows)):
            b=rows[jx]
            for cx in range(jx,len(rows)):
                c=rows[cx];d=tuple(6-i-j-k for i,j,k in zip(a,b,c))
                if d<c or min(d)<0 or max(d)>4:continue
                units.add((a,b,c,d))
    left=set(units);keep=[]
    while left:
        a=min(left);keep.append(a)
        for order in permutations(range(4)):
            b=tuple(sorted(tuple(r[k] for k in order) for r in a));left.discard(b)
    return sorted(keep)
def solve(a,base):
    # Each row state consists of its four within-cell signed graph types.
    # For column states complement the cross-sign pairs so equality is required.
    pools=[]
    for h,prof in enumerate((*a,*zip(*a))):
        order=sorted(range(4),key=lambda j:-prof[j]);orig=tuple(prof[j] for j in order);ps=[]
        for v in base.get(orig,()):
            q=[None]*4
            for k,j in enumerate(order):q[j]=v[k] if h<4 else complement(prof[j],v[k])
            ps.append(tuple(q))
        pools.append(tuple(sorted(ps)))
    visited=0
    def search(d):
        nonlocal visited
        visited+=1
        while True:
            change=False
            for i in range(4):
                for j in range(4):
                    ok={x[j] for x in d[i]} & {x[i] for x in d[4+j]}
                    if not ok:return None
                    l=tuple(x for x in d[i] if x[j] in ok);r=tuple(x for x in d[4+j] if x[i] in ok)
                    change|=(len(l)!=len(d[i]) or len(r)!=len(d[4+j]))
                    d[i]=l;d[4+j]=r
            if not change:break
        ix=min((i for i in range(8) if len(d[i])>1),key=lambda i:len(d[i]),default=None)
        if ix is None:return [v[0] for v in d]
        for s in d[ix]:
            nxt=d.copy();nxt[ix]=(s,);ans=search(nxt)
            if ans:return ans
        return None
    w=search(pools)
    return w,visited
def main():
    q=argparse.ArgumentParser();q.add_argument('--words',type=Path,default=Path(__file__).with_name('words.txt'));q.add_argument('--output',type=Path);args=q.parse_args()
    base=profile_states(args.words);print('states',[(a,len(b)) for a,b in base.items()])
    models=tables();answer=[]
    for t in models:
        w,n=solve(t,base);answer.append(dict(table=t,states=w,nodes=n))
    print('row/column orbit counts',len(answer),'closed',sum(r['states'] is None for r in answer),'open',sum(r['states'] is not None for r in answer),'nodes',sum(r['nodes'] for r in answer))
    if args.output:args.output.write_text(json.dumps(answer,separators=(',',':'))+'\n')
if __name__=='__main__':main()

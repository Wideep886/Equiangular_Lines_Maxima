import json,sys
from collections import defaultdict
from itertools import permutations
from pathlib import Path
from occupation import canon,complement,bit_edges
from core48 import grid
def words(path):
    out=defaultdict(dict)
    for l in path.read_text().splitlines():
        prof,s,w,rank=l.split();p=tuple(map(int,prof));z=tuple(map(int,w));parts=tuple(map(int,s.strip(',').split(',')))
        e=set();k=0
        for m in parts:
            for i in range(m):e.add(tuple(sorted((k+i,k+(i+1)%m))))
            k+=m
        state=[];masks=[]
        for c,a in enumerate(p):
            v=sorted((i for i,x in enumerate(z) if x//2==c),key=lambda i:z[i]%2)
            m=sum(1<<t for t,(i,j) in enumerate(bit_edges(a)) if tuple(sorted((v[i],v[j]))) in e)
            state.append(canon(a,m));masks.append(m)
        out[p].setdefault(tuple(state),(z,e,masks))
    return out
def glue(table,states,lib):
    tags,y=grid(table);fixed=[[0]*48 for _ in tags];candidates={}
    for h,margin in enumerate((*table,*zip(*table))):
        order=sorted(range(4),key=lambda k:-margin[k]);p=tuple(margin[k] for k in order)
        state=tuple(states[h][k] if h<4 else complement(margin[k],states[h][k]) for k in order)
        word,edges,masks=lib[p][state];vmap={}
        for c,k in enumerate(order):
            local=sorted((i for i,v in enumerate(word) if v//2==c),key=lambda i:word[i]%2)
            n=margin[k];i,j=(h,k) if h<4 else (k,h-4)
            inds=[v for v,(r,t,s,l) in enumerate(tags) if (r,t)==(i,j)]
            assert len(inds)==len(local)==2*n
            if h>=4:
                done=False
                for x in permutations(range(n)):
                    for y in permutations(range(n)):
                        trial=[inds[q] for q in (*x,*(v+n for v in y))]
                        valid=True
                        for a,b in bit_edges(n):
                            edge=tuple(sorted((local[a],local[b]))) in edges
                            opposite=(a<n<=b)
                            if int((edge^opposite))!=(fixed[trial[a]][trial[b]]==-1):
                                valid=False;break
                        if valid:inds=trial;done=True;break
                    if done:break
                assert done
            for loc,idx in zip(local,inds):vmap[loc]=idx
        for a,b in bit_edges(6):
            i,j=vmap[a],vmap[b];s=-1 if (a,b) in edges else 1
            if h>=4:s*=tags[i][2]*tags[j][2]
            assert fixed[i][j] in (0,s)
            fixed[i][j]=fixed[j][i]=s
    return tags,fixed
def main():
    p=Path(__file__).parent;rs=json.loads((p/'results.json').read_text())
    ix=int(sys.argv[1]) if len(sys.argv)>1 else next(i for i,x in enumerate(rs) if x['states'])
    r=rs[ix];t,f=glue(r['table'],r['states'],words(p/'words.txt'))
    print(ix,r['table'],'fixed',sum(bool(f[i][j]) for i in range(48) for j in range(i)))
    args=sys.argv[2:]
    if args:
        out=Path(args[0])
        with out.open('w') as fp:
            for i,j,s,_ in t:print(i,j,s,file=fp)
            for row in f:print(*row,file=fp)
if __name__=='__main__':main()

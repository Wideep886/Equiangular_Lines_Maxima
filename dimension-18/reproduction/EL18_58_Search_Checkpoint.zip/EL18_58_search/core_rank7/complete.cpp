// Exact rank-nine completion of a 48x48 D8 residual Gram after fixing any
// one full row/column sign template. Each pivot extends the old span by at
// most one dimension. Exhaustion proves that the given template fails.
#include <array>
#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
using i64=long long;
struct Base{array<int,12> z{};array<i64,9> q{};i64 def;};
struct Point{int idx;array<i64,9> u{};i64 norm;};
using Domains=array<vector<Point>,48>;
struct Solver{
 int r,D,A[12],R[9],Q[9][9],G[12][12],S[48][48],B[48][48];
 array<vector<Base>,48> clouds;
 array<i64,9> piv{};
 array<Point,48> chosen{};array<bool,48> fixed{},anchor{};
 i64 states=0,budget;
 bool capped=false;
 i64 schur(i64 x,i64 h,i64 y,i64 z,i64 den){
  __int128 v=(__int128)x*h-(__int128)y*z;
  assert(v%den==0);v/=den;assert(v<=9223372036854775807LL && v>=-9223372036854775807LL);return (i64)v;
 }
 void read(){
  cin>>r>>D;for(int &x:A){cin>>x;fixed[x]=anchor[x]=true;}
  for(int i=0;i<r;i++)cin>>R[i];
  for(int i=0;i<r;i++)for(int j=0;j<r;j++)cin>>Q[i][j];
  for(auto &row:G)for(auto &x:row)cin>>x;
  for(auto &row:S)for(auto &x:row)cin>>x;
  for(auto &row:B)for(auto &x:row)cin>>x;
 }
 Domains initial(){
  Domains d;
  for(int i=0;i<48;i++)if(!anchor[i])for(int m=0;m<4096;m++){
   Base b;bool ok=true;
   for(int j=0;j<12;j++){
    int s=(m&(1<<j))?1:-1;
    if(S[i][A[j]] && S[i][A[j]]!=s){ok=false;break;}
    b.z[j]=s-B[i][A[j]];
   }
   if(!ok)continue;
   for(int j=0;j<r;j++)for(int l=0;l<r;l++)b.q[j]+=Q[j][l]*b.z[R[l]];
   i64 val=0;for(int j=0;j<r;j++)val+=b.q[j]*b.z[R[j]];
   b.def=3*D-val;if(b.def<0 || (r==9 && b.def))continue;
   for(int j=0;j<12;j++){
    val=0;for(int l=0;l<r;l++)val+=b.q[l]*G[j][R[l]];
    if(val!=D*b.z[j]){ok=false;break;}
   }
   if(ok){d[i].push_back({(int)clouds[i].size(),{},b.def});clouds[i].push_back(b);}
  }
  return d;
 }
 i64 residual(int i,const Point &a,int j,const Point &b,int s,int k){
  auto &x=clouds[i][a.idx];auto &y=clouds[j][b.idx];i64 z=(s-B[i][j])*D;
  for(int l=0;l<r;l++)z-=x.q[l]*y.z[R[l]];
  for(int l=0;l<k;l++)z=schur(z,piv[l],a.u[l],b.u[l],l?piv[l-1]:1);
  return z;
 }
 bool df(const Domains &d,int k){
  if(++states>budget){capped=true;return false;}
  int i=-1;for(int v=0;v<48;v++)if(!fixed[v] && (i<0||d[v].size()<d[i].size()))i=v;
  if(i==-1){
   // Distinct Seidel entries follow from the now-complete residual Gram.
   for(int x=0;x<48;x++)if(!anchor[x]){
    for(int l=0;l<12;l++)S[x][A[l]]=S[A[l]][x]=clouds[x][chosen[x].idx].z[l]+B[x][A[l]];
    for(int y=0;y<x;y++)if(!anchor[y]){
     int sg=(residual(x,chosen[x],y,chosen[y],1,k)==0)?1:-1;
     assert(residual(x,chosen[x],y,chosen[y],sg,k)==0);
     assert(!S[x][y]||S[x][y]==sg);S[x][y]=S[y][x]=sg;
    }
   }
   for(int x=0;x<48;x++)for(int y=0;y<48;y++){
    int ip=0;for(int j=0;j<48;j++)ip+=S[x][j]*S[j][y];
    assert(ip==6*S[x][y]+55*(x==y)-4*B[x][y]);
   }
   return true;
  }
  fixed[i]=true;
  for(auto p:d[i]){
   int nk=k+(p.norm!=0);if(r+nk>9)continue;
   Domains future;
   bool possible=true;
   for(int j=0;j<48&&possible;j++)if(!fixed[j]){
    for(auto v:d[j])for(int sg:{-1,1}){
     if(S[i][j]&&S[i][j]!=sg)continue;
     i64 dd=residual(i,p,j,v,sg,k);
     if(!p.norm){if(!dd)future[j].push_back(v);continue;}
     i64 h=schur(v.norm,p.norm,dd,dd,k?piv[k-1]:1);
     if(h<0 || (r+nk==9 && h))continue;
     Point u=v;u.u[k]=dd;u.norm=h;future[j].push_back(u);
    }
    possible=!future[j].empty();
   }
   if(!possible)continue;
   if(p.norm){piv[k]=p.norm;p.u[k]=p.norm;}
   chosen[i]=p;
   if(df(future,nk))return true;
   if(capped)break;
  }
  fixed[i]=false;return false;
 }
};
int main(int argc,char**argv){
 Solver s;s.budget=argc>1?atoll(argv[1]):1000000;s.read();
 Domains d=s.initial();bool ok=s.df(d,0);
 cout<<(ok?"CONSTRUCTION":s.capped?"INDETERMINATE":"INFEASIBLE")<<" nodes "<<s.states<<" anchor_rank "<<s.r<<"\n";
 if(ok)for(auto &row:s.S){for(int x:row)cout<<x<<' ';cout<<'\n';}
}

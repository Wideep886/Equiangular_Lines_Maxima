"""Positive control of the exact Gram-completion executable on a genuine 48-core."""
from pathlib import Path
import subprocess,io,random
from core48 import sts,validate_core,gram
from anchor import integer_basis_and_inverse
def main():
    y,a=sts();S=validate_core(y,3,a);B=[[e//9 for e in row] for row in gram(y)]
    G=[[S[i][j]+5*(i==j)-B[i][j] for j in range(48)] for i in range(48)]
    rng=random.Random(305)
    # Extend the span of seven random vectors with the other points it contains.
    for _ in range(400):
        seed=rng.sample(range(48),7);R,D,Q=integer_basis_and_inverse([[G[i][j] for j in seed] for i in seed])
        if len(R)!=7:continue
        ids=[]
        for i in range(48):
            z=[G[i][j] for j in seed]
            if sum(z[u]*Q[u][v]*z[v] for u in range(7) for v in range(7))==3*D:ids.append(i)
        if len(ids)>=12:
            anc=seed+[i for i in ids if i not in seed][:5];break
    else:raise ValueError('missing rank-seven control anchor')
    H=[[G[i][j] for j in anc] for i in anc];R,D,Q=integer_basis_and_inverse(H)
    out=io.StringIO();print(len(R),D,*anc,*R,file=out)
    for row in Q+H:print(*row,file=out)
    for i in range(48):
        print(*(sg if (i in anc and j in anc) or (i+j)%4 else 0 for j,sg in enumerate(S[i])),file=out)
    for row in B:print(*row,file=out)
    ret=subprocess.run([str(Path(__file__).resolve().with_name('complete'))],input=out.getvalue(),text=True,capture_output=True,check=True)
    print(ret.stdout.splitlines()[0]);assert ret.stdout.startswith('CONSTRUCTION')
    answer=[list(map(int,s.split())) for s in ret.stdout.splitlines()[1:]];assert answer==S
if __name__=='__main__':main()

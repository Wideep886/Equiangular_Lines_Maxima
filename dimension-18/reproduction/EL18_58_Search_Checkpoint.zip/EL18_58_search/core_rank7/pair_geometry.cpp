#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
using namespace std;
struct Point{array<int,12> z{};array<int,9> q{};int def;};
struct Margin{
 string word;int rank,D,pr[4],cy[3],basis[9],G[12][12],w[12],Q[9][9];
 vector<Point> cloud[8];
 void read(){
  cin>>word>>rank>>D;for(int i=0;i<12;i++)w[i]=word[i]-'0';
  for(auto &v:pr)cin>>v;for(auto &v:cy)cin>>v;
  for(int j=0;j<rank;j++)cin>>basis[j];
  for(int i=0;i<rank;i++)for(int j=0;j<rank;j++)cin>>Q[i][j];
  for(auto &row:G)for(auto &v:row)cin>>v;
  for(int b=0;b<4096;b++){
   bool balanced=true;for(int m:cy)if(2*__builtin_popcount((unsigned)(b&m))!=__builtin_popcount((unsigned)m))balanced=false;
   if(!balanced)continue;
   for(int c=0;c<8;c++){
    Point p;for(int i=0;i<12;i++)p.z[i]=2*((b>>i)&1)-1-(w[i]/2==c/2 ? (w[i]%2==c%2?1:-1):0);
    for(int i=0;i<rank;i++)for(int j=0;j<rank;j++)p.q[i]+=Q[i][j]*p.z[basis[j]];
    int n=0;for(int i=0;i<rank;i++)n+=p.q[i]*p.z[basis[i]];
    if(n>3*D)continue;p.def=3*D-n;
    bool ok=true;for(int i=0;i<12&&ok;i++){
     int v=0;for(int j=0;j<rank;j++)v+=p.q[j]*G[i][basis[j]];
     if(v!=D*p.z[i])ok=false;
    }
    if(ok)cloud[c].push_back(p);
   }
  }
 }
};
using Mat=array<array<long long,12>,12>;
bool fits(Mat m,int n,int k){
 long long denominator=1;
 for(int i=0;i<n;i++){
  int p=-1;
  for(int j=i;j<n;j++){
   if(m[j][j]<0)return false;
   if(m[j][j] && p<0)p=j;
   if(!m[j][j])for(int l=i;l<n;l++)if(m[j][l])return false;
  }
  if(p<0)return true;
  if(i==k)return false;
  if(i!=p){swap(m[i],m[p]);for(int j=0;j<n;j++)swap(m[j][i],m[j][p]);}
  long long pivot=m[i][i];
  for(int j=i+1;j<n;j++)for(int l=j;l<n;l++){
   __int128 x=(__int128)pivot*m[j][l]-(__int128)m[i][j]*m[i][l];
   assert(x%denominator==0);x/=denominator;assert(x<=9223372036854775807LL&&x>=-9223372036854775807LL);
   m[l][j]=m[j][l]=(long long)x;
  }
  denominator=pivot;
 }
 return true;
}
struct Pair{
 Margin &a,&b;int ca,cb;
 int T[12][12],used[12]{},order[12],steps=0,cap;
 const Point* pts[12];
 vector<const Point*> domains[12];Mat h{};
 Pair(Margin &x,Margin &y,int i,int j,int maxsteps):a(x),b(y),ca(i),cb(j),cap(maxsteps){
  for(int l=0;l<12;l++)for(int m=0;m<12;m++)
    T[l][m]=(b.w[l]%2==b.w[m]%2?1:-1)*b.G[l][m];
 }
 bool dfs(int level,int need){
  if(level==need||++steps>cap)return true;
  int v=order[level];for(auto p:domains[v]){
   pts[level]=p;h[level][level]=p->def;
   for(int i=0;i<level;i++){
    int n=0;for(int j=0;j<a.rank;j++)n+=p->q[j]*pts[i]->z[a.basis[j]];
    h[level][i]=h[i][level]=a.D*T[v][order[i]]-n;
   }
   if(fits(h,level+1,9-a.rank)&&dfs(level+1,need))return true;
  }
  return false;
 }
 bool run(){
  vector<int> shared[2],remote[2];for(int i=0;i<12;i++){
   if(a.w[i]/2==ca)shared[a.w[i]%2].push_back(i);
   if(b.w[i]/2==cb)remote[b.w[i]%2].push_back(i);
  }
  int n=shared[0].size();assert(shared[0].size()==remote[0].size());
  do{do{
   int im[12];fill(im,im+12,-1);
   for(int s=0;s<2;s++)for(int i=0;i<n;i++)im[remote[s][i]]=shared[s][i];
   bool ok=true;
   for(int i=0;i<12&&ok;i++)if(im[i]>=0)for(int j=0;j<i;j++)if(im[j]>=0 && a.G[im[i]][im[j]]!=T[i][j])ok=false;
   if(!ok)continue;
   int count=0;
   for(int i=0;i<12&&ok;i++)if(im[i]<0){
    order[count++]=i;domains[i].clear();
    for(auto &p:a.cloud[2*ca+b.w[i]%2]){
     bool good=true;for(int j=0;j<12&&good;j++)if(im[j]>=0&&p.z[im[j]]!=T[i][j])good=false;
     if(good)domains[i].push_back(&p);
    }
    if(domains[i].empty())ok=false;
   }
   if(!ok)continue;
   stable_sort(order,order+count,[&](int u,int v){return domains[u].size()<domains[v].size();});
   if(dfs(0,count))return true;
  }while(next_permutation(shared[1].begin(),shared[1].end()));
  }while(next_permutation(shared[0].begin(),shared[0].end()));return false;
 }
};
int main(int argc,char** argv){
 int cap=argc>1?atoi(argv[1]):300;int minsize=argc>2?atoi(argv[2]):1;
 int n;cin>>n;vector<Margin> words(n);for(auto &a:words)a.read();
 for(int i=0;i<n;i++)for(int j=i;j<n;j++){
  for(int x=0;x<4;x++)for(int y=0;y<4;y++){
   if(words[i].pr[x]!=words[j].pr[y]||words[i].pr[x]<minsize)continue;
   Pair pair(words[i],words[j],x,y,cap);bool ok=pair.run();
   if(ok&&pair.steps>cap){
    Pair rev(words[j],words[i],y,x,cap);ok=rev.run();
   }
   cout<<i<<" "<<x<<" "<<j<<" "<<y<<" "<<ok<<"\n";
  }
 }
}

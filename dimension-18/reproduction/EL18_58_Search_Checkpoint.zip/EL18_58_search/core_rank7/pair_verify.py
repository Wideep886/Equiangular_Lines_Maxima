"""Regenerate all 13,623 checked ordered-canonical margin pairs from 61 words."""
from pathlib import Path
import io,subprocess
from anchor import geom,integer_basis_and_inverse
P=Path(__file__).resolve().parent
def main():
    words=(P/'words_aug7.txt').read_text().splitlines();f=io.StringIO();print(len(words),file=f)
    for s in words:
        pr,parts,w,rs=s.split();labels,cycles,G=geom(pr,parts,w);R,D,Q=integer_basis_and_inverse(G);assert int(rs)==len(R)
        print(w,len(R),D,*map(int,pr),*(sum(1<<i for i in c) for c in cycles),*([0]*(3-len(cycles))),file=f)
        print(*R,file=f)
        for row in Q+G:print(*row,file=f)
    subprocess.run(['c++','-std=c++17','-O3',str(P/'pair_geometry.cpp'),'-o',str(P/'pair_geometry')],check=True)
    z=subprocess.run([str(P/'pair_geometry'),'200','1'],input=f.getvalue(),text=True,capture_output=True,check=True).stdout
    assert z==(P/'pair200.out').read_text()
    bad=set()
    for line in z.splitlines():
        u,a,v,b,ok=map(int,line.split())
        if not ok:bad.add((u,a,v,b));bad.add((v,b,u,a))
    print(len(words),'words;',len(z.splitlines()),'tested margin pairings;',len(bad),'infeasible directed pairings')
if __name__=='__main__':main()

from pathlib import Path
import subprocess,sys
from make_template import build
from make_anchor import export
P=Path(__file__).resolve().parent
def compile(name):
    subprocess.run(['c++','-O3','-std=c++17',name+'.cpp','-o',str(P/name)],cwd=P,check=True)
def main():
    compile('complete')
    subprocess.run([sys.executable,'complete_control.py'],cwd=P,check=True)
    for idx,n in [(216,17),(217,57),(218,9),(222,57),(223,9)]:
        t=P/('fix%d.dat'%idx);f=P/('input%d.dat'%idx)
        build(idx,P/'words_aug7.txt',P/'pair200.out',P/'words_moment_input.txt',t)
        with f.open('w') as out:export(t,out)
        with f.open() as stream:p=subprocess.run([str(P/'complete')],stdin=stream,text=True,capture_output=True,check=True)
        print(p.stdout.strip());assert p.stdout.strip()=='INFEASIBLE nodes %d anchor_rank 7'%n
    if len(sys.argv)>1:
        f=Path(sys.argv[1]).resolve();compile('aug7')
        with f.open() as stream:p=subprocess.run([str(P/'aug7')],stdin=stream,text=True,capture_output=True,check=True)
        words=(f.parent/'words.txt').read_text().splitlines();ls=p.stdout.splitlines()
        assert len(ls)==len(words)==2275
        kept=[w for w,s in zip(words,ls) if s.split()[1]=='1']
        assert kept==(P/'words_aug7.txt').read_text().splitlines();print(len(kept),'augmented words independently regenerated')
if __name__=='__main__':main()

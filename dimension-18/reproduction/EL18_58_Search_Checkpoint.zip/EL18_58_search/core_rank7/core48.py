"""Exact construction/search model of the 48-vector D8-projection core.
Generate .opb for any 4x4 occupancy table, or verify a candidate 48x48
adjacency matrix and obtain a 58-line Gram matrix in integers.
Requires only Python 3.9+. No antipodal relation among the residual vectors.
"""
from pathlib import Path
from itertools import combinations,permutations,product
from collections import Counter
import argparse, json, math

def dot(x,y):
    return sum(a*b for a,b in zip(x,y))
def rowsum_product(a,b):
    return [[dot(row,col) for col in zip(*b)] for row in a]
def gram(x):
    return [[dot(u,v) for v in x] for u in x]
def grid(table):
    assert len(table)==4 and all(len(row)==4 for row in table)
    assert all(sum(r)==6 for r in table) and all(sum(col)==6 for col in zip(*table))
    assert all(type(a) is int and 0<=a<=4 for r in table for a in r)
    tags=[(i,j,s,l) for i in range(4) for j in range(4) for s in (1,-1) for l in range(table[i][j])]
    y=[[int(k==i) for k in range(4)]+[s*int(k==j) for k in range(4)] for i,j,s,l in tags]
    return tags,y
def sts():
    blocks={tuple(sorted((a+t)%19 for a in base)) for base in [(0,1,4),(0,2,9),(0,5,11)] for t in range(19)}
    assert len(blocks)==57 and len({e for b in blocks for e in combinations(b,2)})==171
    cells=[set(v for v in b if v) for b in sorted(blocks) if 0 in b]
    bs=[set(b) for b in sorted(blocks) if 0 not in b]
    t=[[int(bool(b&c)) for c in cells] for b in bs]
    assert all(sum(r)==3 for r in t)
    z=[[3*x-1 for x in row] for row in t]
    adj=[[int(i!=j and not a&b) for j,b in enumerate(bs)] for i,a in enumerate(bs)]
    return z,adj
def validate_core(y,scale,a):
    n=len(a);k=sum(a[0]);s=[[0 if i==j else 1-2*a[i][j] for j in range(n)] for i in range(n)]
    b=gram(y);d=scale*scale
    assert all(v%d==0 for r in b for v in r)
    b=[[v//d for v in r] for r in b]
    assert n==48 and all(len(r)==48 for r in a)
    assert all(a[i][i]==0 and sum(a[i])==k and all(v in (0,1) for v in a[i]) and a[i]==[r[i] for r in a] for i in range(n))
    assert rowsum_product(s,y)==[[7*v for v in row] for row in y]
    for i in range(n):
        for j in range(n):
            assert dot(s[i],s[j])==6*s[i][j]+55*(i==j)-4*b[i][j]
    return s
def extension(table,a):
    tags,y=grid(table);s=validate_core(y,1,a);n=48
    w=[[(-1 if q==4 or k%4==q else 1) if k//4==g else 0 for k in range(8)] for g in range(2) for q in range(5)]
    G=[[0]*58 for _ in range(58)]
    for i in range(48):
        for j in range(48):G[i][j]=s[i][j]+5*(i==j)
        for j in range(10):G[i][48+j]=G[48+j][i]=dot(y[i],w[j])
    for i in range(10):
        for j in range(10):G[48+i][48+j]=1+dot(w[i],w[j])
    assert all(G[i][j] in ((5,) if i==j else (-1,1)) for i in range(58) for j in range(58))
    return G
class Model:
    def __init__(self,path,witness=None):
        self.out=path.open('w') if path else None
        self.witness=witness
        self.count=0
        self.variables=0
    def new(self,value=None):
        self.variables+=1
        if self.witness is not None:self.witness.append(value)
        return self.variables
    def constraint(self,terms,op,rhs):
        self.count+=1
        if self.witness is not None:
            t=sum(c*self.witness[i] for c,i in terms)
            assert (t==rhs) if op=='=' else (t>=rhs)
        if self.out:
            self.out.write(' '.join(f'{c:+d} x{i}' for c,i in terms)+f' {op} {rhs};\n')
    def close(self):
        if self.out:self.out.close()

def create(y,scale,k,path=None,positive=None):
    n=len(y);assert n==48
    modulus=scale**2
    b=gram(y);assert all(v%modulus==0 for r in b for v in r)
    m=Model(path,None if positive is None else [None])
    edges={}
    for i,j in combinations(range(n),2):
        eid=m.new(None if positive is None else positive[i][j]);edges[i,j]=edges[j,i]=eid
    for i in range(n):
        m.constraint([(1,edges[i,j]) for j in range(n) if i!=j],'=',k)
        for col in zip(*y):
            terms=[(2*col[j],edges[i,j]) for j in range(n) if i!=j and col[j]]
            m.constraint(terms,'=',sum(col)-8*col[i])
    for i,j in combinations(range(n),2):
        e=edges[i,j];terms=[(4,e)]
        for l in range(n):
            if l in (i,j):continue
            x,yvar=edges[i,l],edges[j,l]
            z=m.new(None if positive is None else positive[i][l]*positive[j][l])
            m.constraint([(1,x),(-1,z)],'>=',0)
            m.constraint([(1,yvar),(-1,z)],'>=',0)
            m.constraint([(1,z),(-1,x),(-1,yvar)],'>=',-1)
            terms.append((1,z))
        m.constraint(terms,'=',k-10-b[i][j]//modulus)
    m.close();return m.variables,m.count
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='command',required=True)
    sub.add_parser('control')
    new=sub.add_parser('model');new.add_argument('occupancy',type=Path);new.add_argument('output',type=Path)
    check=sub.add_parser('verify');check.add_argument('occupancy',type=Path);check.add_argument('adjacency',type=Path);check.add_argument('gram58',type=Path)
    args=ap.parse_args()
    if args.command=='control':
        y,a=sts();validate_core(y,3,a);print('STS control',create(y,3,sum(a[0]),positive=a));return
    table=json.loads(args.occupancy.read_text());_,y=grid(table)
    if args.command=='model':
        print('D8-core model',create(y,1,20,args.output))
    else:
        G=extension(table,json.loads(args.adjacency.read_text()))
        args.gram58.write_text(json.dumps(G)+'\n')
if __name__=='__main__':main()

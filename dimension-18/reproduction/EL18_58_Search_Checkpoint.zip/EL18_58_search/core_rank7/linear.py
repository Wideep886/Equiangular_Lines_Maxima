"""Check linear dependencies from known residual Gram rows of a fixed template."""
from fractions import Fraction as F
from math import gcd,lcm
from functools import reduce
from itertools import combinations
from pathlib import Path
import sys
def kernel(G):
    n=len(G);a=[[F(v) for v in row] for row in G];piv=[];k=0
    for j in range(n):
        z=next((i for i in range(k,n) if a[i][j]),None)
        if z is None:continue
        a[k],a[z]=a[z],a[k];d=a[k][j];a[k]=[v/d for v in a[k]]
        for i in range(n):
            if i!=k and a[i][j]:
                d=a[i][j];a[i]=[v-d*w for v,w in zip(a[i],a[k])]
        piv.append(j);k+=1
    ans=[]
    for free in range(n):
        if free in piv:continue
        v=[F(0)]*n;v[free]=F(1)
        for p,r in zip(piv,a):v[p]=-r[free]
        d=lcm(*(x.denominator for x in v));u=[int(d*x) for x in v]
        assert all(sum(x*y for x,y in zip(r,u))==0 for r in G);ans.append(u)
    return ans
def read(path):
    w=list(map(int,Path(path).read_text().split()))
    tags=[tuple(w[3*j:3*j+3]) for j in range(48)];s=[w[144+48*i:144+48*(i+1)] for i in range(48)]
    return tags,s
def systems(tags,s):
    B=[[int(i==k)+u*v*int(j==l) for k,l,v in tags] for i,j,u in tags]
    ix={};n=0
    for i,j in combinations(range(48),2):
        if not s[i][j]:ix[i,j]=ix[j,i]=n;n+=1
    eq=[]
    for h in (0,1):
        for r in range(4):
            cell=[i for i,t in enumerate(tags) if t[h]==r]
            G=[[s[i][j]+5*(i==j)-B[i][j] for j in cell] for i in cell]
            ker=kernel(G)
            outside=set(range(48))-set(cell)
            for i in outside:
                for v in ker:
                    c={};rhs=0
                    for j,m in zip(cell,v):
                        if not m:continue
                        if s[i][j]:rhs+=m*(s[i][j]-B[i][j])
                        else:rhs+=m*(1-B[i][j]);c[ix[i,j]]=m
                    if rhs%2:eq.append(({n:1},'odd'));continue
                    c[n]=rhs//2;eq.append((c,None))
    return n,eq
def gf(n,eq,p):
    basis={}
    def add(a,b):
        ap,am=a;bp,bm=b
        return ((ap&~(bp|bm))|(bp&~(ap|am))|(am&bm),(am&~(bp|bm))|(bm&~(ap|am))|(ap&bp))
    for i,(c,err) in enumerate(eq):
        if err:return False,len(basis),i
        v=(sum(1<<j for j,x in c.items() if x%p==1),sum(1<<j for j,x in c.items() if p==3 and x%3==2))
        while v[0]|v[1]:
            lead=(v[0]|v[1])&-(v[0]|v[1]);j=lead.bit_length()-1
            if j==n:return False,len(basis),i
            if v[1]&lead:v=v[::-1]
            w=basis.get(j)
            if w is None:basis[j]=v;break
            v=(v[0]^w[0],0) if p==2 else add(v,w[::-1])
    return True,len(basis),len(eq)
if __name__=='__main__':
    for f in sys.argv[1:]:
        n,eq=systems(*read(f));print(f,n,len(eq),*[gf(n,eq,p) for p in [2,3]])

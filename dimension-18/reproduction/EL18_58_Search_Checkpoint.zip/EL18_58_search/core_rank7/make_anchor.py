from pathlib import Path
import sys
from linear import read
from anchor import integer_basis_and_inverse

def export(template,handle):
    tags,S=read(template)
    B=[[int(i==k)+u*v*int(j==l) for k,l,v in tags] for i,j,u in tags]
    records=[]
    for h in range(8):
        a=[i for i,t in enumerate(tags) if t[h//4]==h%4];G=[[S[i][j]+5*(i==j)-B[i][j] for j in a] for i in a]
        R,D,Q=integer_basis_and_inverse(G);records.append((len(R),-D,a,R,D,Q,G))
    r,_,a,R,D,Q,G=max(records,key=lambda r:r[:2]);print(r,D,*a,*R,file=handle)
    for q in Q:print(*q,file=handle)
    for g in G:print(*g,file=handle)
    for s in S:print(*s,file=handle)
    for b in B:print(*b,file=handle)
if __name__=='__main__':export(sys.argv[1],sys.stdout)

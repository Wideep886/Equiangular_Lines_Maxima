"""Equiangular norm-five extensions of the 40 points of W(3,3) in real dimension 18."""
from collections import Counter
from itertools import product
from math import isqrt
import argparse, json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'core_search'))
from anchor import integer_basis_and_inverse

points=[x for x in product(range(3),repeat=4) if any(x) and next(v for v in x if v)==1]
def orthogonal(x,y):
    return (x[0]*y[1]-x[1]*y[0]+x[2]*y[3]-x[3]*y[2])%3==0
def canon(x):
    sign=next(t for t in x if t)
    return tuple((v*sign)%3 for v in x)

def transform(x,t):
    k=x[0]*t[1]-x[1]*t[0]+x[2]*t[3]-x[3]*t[2]
    return canon(tuple((a+k*b)%3 for a,b in zip(x,t)))

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dual',action='store_true',help='Start with the 40 totally isotropic projective lines.')
parser.add_argument('--lines',type=int,default=58)
parser.add_argument('--nodes',type=int,default=1000000)
args=parser.parse_args()
if args.dual:
    pos={p:i for i,p in enumerate(points)}
    isotropic=set()
    for i,x in enumerate(points):
        for j in range(i):
            y=points[j]
            if orthogonal(x,y):
                plus=canon(tuple((a+b)%3 for a,b in zip(x,y)))
                minus=canon(tuple((a-b)%3 for a,b in zip(x,y)))
                isotropic.add(frozenset((i,j,pos[plus],pos[minus])))
    cells=sorted(isotropic,key=lambda c:sorted(c))
    assert len(cells)==40 and all(len(c)==4 for c in cells)
    G=[[5 if x==y else 1-2*bool(x&y) for y in cells] for x in cells]
else:
    G=[[5 if x==y else 1-2*orthogonal(x,y) for y in points] for x in points]
assert len(G)==40 and all(r.count(-1)==12 and sum(r)==20 for r in G)
assert all(sum(a*b for a,b in zip(G[i],G[j]))==12*G[i][j]+4 for i in range(40) for j in range(40))
I,D,Q=integer_basis_and_inverse(G)
assert len(I)==16
assert all(sum(G[i][a]*Q[k][l]*G[b][j] for k,a in enumerate(I) for l,b in enumerate(I))==D*G[i][j] for i in range(40) for j in range(40))
# First basis coordinate positive fixes the projective sign. Gray-code update avoids matrix inversion per trial.
vals=[1]*16
z=[sum(row) for row in Q];q=sum(z);cloud=[]
for step in range(1<<15):
    if step:
        k=(step&-step).bit_length();previous=vals[k];q+=4*(Q[k][k]-previous*z[k]);z=[a-2*previous*row[k] for a,row in zip(z,Q)];vals[k]=-previous
    if q<=5*D and all(abs(sum(G[j][b]*t for b,t in zip(I,z)))==D for j in range(40) if j not in I):
        cloud.append((tuple(vals),tuple(z),q))
print('projective points',len(points),'Gram rank',len(I),'inverse denominator',D,'admissible projections',len(cloud),'norm numerator distribution',sorted(Counter(c[2] for c in cloud).items()),flush=True)

sys.path.insert(0,str(ROOT))
from verify_gram import certify
full=[tuple(sum(G[j][b]*t for b,t in zip(I,z))//D for j in range(40)) for _,z,_ in cloud]
assert all(all(abs(v)==1 for v in s) for s in full)
look={s:i for i,s in enumerate(full)}
generators=[]
for t in points:
    p=[points.index(transform(x,t)) for x in points]
    if args.dual:p=[cells.index(frozenset(p[j] for j in c)) for c in cells]
    assert len(set(p))==40 and all(G[p[i]][p[j]]==G[i][j] for i in range(40) for j in range(i))
    action=[]
    for s in full:
        v=tuple(s[j]*s[p[I[0]]] for j in p)
        action.append(look[v])
    generators.append(action)
remaining=set(range(len(cloud)));orbits=[]
while remaining:
    a=min(remaining);seen={a};front=[a]
    while front:
        x=front.pop()
        for g in generators:
            y=g[x]
            if y not in seen:seen.add(y);front.append(y)
    remaining-=seen;orbits.append((a,len(seen)))
print('representative projection orbits (index,size)',orbits,flush=True)
H=[[sum(a*b for a,b in zip(z,s)) for s,_,_ in cloud] for _,z,_ in cloud]
R=[5*D-q for _,_,q in cloud]
def lifts(anchor):
    h=R[anchor];vs=[]
    for i in range(len(cloud)):
        for sg in (1,-1):
            u=sg*D-H[anchor][i];v=R[i]*h-u*u
            if v>=0:
                for e in ([1,-1] if v else [1]):vs.append((i,u,v,e,sg))
    def signed(i,j):
        k,u,v,e,_=vs[i];l,w,x,f,_=vs[j];n=v*x;root=isqrt(n)
        if root*root!=n:return 0
        val=H[k][l]*h+u*w+e*f*root
        return 1 if val==D*h else -1 if val==-D*h else 0
    adj=[0]*len(vs)
    for i in range(len(vs)):
        for j in range(i):
            if signed(i,j):adj[i]|=1<<j;adj[j]|=1<<i
    return vs,signed,adj

def clique(adj,need,budget):
    visits=0
    def search(cur,req):
        nonlocal visits
        visits+=1
        if visits>budget:raise TimeoutError
        if not req:return []
        if bin(cur).count("1")<req:return None
        left=cur;order=[];colors=[];c=0
        while left:
            c+=1;avail=left
            while avail:
                bit=avail&-avail;i=bit.bit_length()-1
                left^=bit;avail=(avail^bit)&~adj[i];order.append(i);colors.append(c)
        for i,c in zip(reversed(order),reversed(colors)):
            if c<req:return None
            found=search(cur&adj[i],req-1)
            if found is not None:return found+[i]
            cur^=1<<i
    try:
        out=search((1<<len(adj))-1,need)
        return ('found' if out is not None else 'excluded'),out,visits
    except TimeoutError:return 'budget',None,visits

if __name__=='__main__':
    a=args
    for anchor,sz in orbits:
        vs,sg,adj=lifts(anchor);status,fix,visits=clique(adj,a.lines-41,a.nodes)
        print('anchor',anchor,'orbit',sz,'compatible lifts',len(vs),'nodes',visits,'result',status,flush=True)
        if fix is not None:
            Hnew=[list(r) for r in G];extras=[anchor]+[vs[v][0] for v in fix]
            for i in range(40):Hnew[i].extend(full[v][i] for v in extras)
            Hnew.append(list(full[anchor])+[5]+[vs[v][4] for v in fix]);
            for i in fix:Hnew.append(list(full[vs[i][0]])+[vs[i][4]]+[5 if i==j else sg(i,j) for j in fix])
            proof=certify(Hnew,count=a.lines);print(proof,flush=True)
            path=Path(__file__).with_name(('dual' if a.dual else 'witness')+str(a.lines)+'.json');path.write_text(json.dumps(Hnew)+'\n');break

"""Construct integer norm-five vectors from a 24-bit doubly even code; search compatible signs."""
import argparse
from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path
import random

WEIGHT=lambda x:bin(x).count('1')
def span(rows):
    words=[0]
    for g in rows:words += [g^w for w in words]
    return words

def binary_codes():
    # Extended Hamming [8,4,4] and the indecomposable paired length 8k family.
    E=[0xff,0x0f,0x33,0x55]
    def paircode(n):
        return [(3 << (2*i))^3 for i in range(1,n//2)] + [sum(1 << (2*i) for i in range(n//2))]
    # Cyclic [23,12,7] Golay generator, extended by overall parity.
    generator=sum(1<<i for i in (11,9,7,6,5,1,0))
    golay=[(generator << i)|(1<<23) for i in range(12)]
    codes={'3e8':E+[v<<8 for v in E]+[v<<16 for v in E],
           'd16_e8':paircode(16)+[v<<16 for v in E], 'd24':paircode(24), 'golay':golay}
    result={}
    for name,rs in codes.items():
        C=span(rs)
        assert len(C)==len(set(C))==4096
        assert all(WEIGHT(w)%4==0 for w in C)
        assert all(WEIGHT(a&b)%2==0 for a in rs for b in rs)
        if name=='golay':assert Counter(map(WEIGHT,C))[8]==759 and min(WEIGHT(w) for w in C if w)==8
        result[name]=[w for w in C if WEIGHT(w) in (4,8)]
    return result

def supports(words,fixed,ones):
    return [w^ones for w in words if w&fixed==ones]

def graph(blocks):
    vs=[]
    for B in blocks:
        coords=[i for i in range(24) if B>>i&1]
        for negs in range(16):
            mask=sum(1<<u for i,u in enumerate(coords[1:]) if negs>>i&1)
            vs.append((B,mask))
    adj=[0]*len(vs)
    for i,(u,n) in enumerate(vs):
        for j in range(i):
            v,m=vs[j];inter=u&v
            if abs(WEIGHT(inter)-2*WEIGHT((n^m)&inter))==1:
                adj[i]|=1<<j;adj[j]|=1<<i
    return vs,adj

def heuristic(adj,seed,trials):
    rng=random.Random(seed)
    best=[]
    full=(1<<len(adj))-1
    for k in range(trials):
        chosen=[];allowed=full
        while allowed:
            candidates=[];bits=allowed
            while bits:
                bit=bits&-bits;bits^=bit
                candidates.append(bit.bit_length()-1)
            if len(candidates)>12:candidates=rng.sample(candidates,12)
            i=max(candidates,key=lambda j:WEIGHT(adj[j]&allowed)+2*rng.random())
            chosen.append(i);allowed&=adj[i]
        if len(chosen)>len(best):best=chosen
    return best

def run(samples,seed,trials):
    rng=random.Random(seed)
    for name,words in binary_codes().items():
        stats=Counter(); best=[]; recorded={}; seen=set()
        for i in range(samples):
            coords=rng.sample(range(24),6)
            f=sum(1<<x for x in coords);o=sum(1<<x for x in coords[:3])
            blocks=supports(words,f,o)
            if any(WEIGHT(b)==1 for b in blocks):
                stats['contains_singleton']+=1;continue
            pts=set(j for b in blocks for j in range(24) if b>>j&1)
            common=set.intersection(*(set(j for j in pts if b>>j&1) for b in blocks)) if blocks else set()
            if len(pts)<18 or common or 5*len(blocks)<58:
                stats['dimension_or_capacity']+=1;continue
            stats['admitted']+=1
            # Exact identical supports represent the same graph, irrespective of chosen fixed bits.
            key=tuple(sorted(blocks))
            if key in seen:continue
            seen.add(key)
            if name=='golay': raise AssertionError('Golay cut with more than 10 quintets')
            # For this pilot explore at most eight surviving cuts per code.
            if len(seen)>8:continue
            vs,adj=graph(blocks)
            chosen=heuristic(adj,seed+i,trials)
            assert all((adj[a]>>b)&1 for a,b in combinations(chosen,2))
            if len(chosen)>len(best):
                best=[vs[j] for j in chosen]
                recorded={'sample':i,'zero_and_one_positions':coords,'supports':len(blocks),'vectors':best}
        print(json.dumps({'code':name,'samples':samples,'seed':seed,'trials':trials,
                         'actual_graphs_searched':min(8,len(seen)),'counts':dict(stats),'best':len(best),'witness':recorded}),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--samples',type=int,default=1500);p.add_argument('--seed',type=int,default=20261121);p.add_argument('--trials',type=int,default=35)
    a=p.parse_args();run(a.samples,a.seed,a.trials)

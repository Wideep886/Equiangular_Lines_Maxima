"""Identify coordinate-equivalent component support systems, with explicit coordinate permutations."""
from pathlib import Path
from collections import Counter,defaultdict
import json
from orbits import HERE

def signature(rows):
    coords=sum(1<<j for j in range(24) if any(r>>j&1 for r in rows))
    return len(rows),tuple(sorted(sum(r>>j&1 for r in rows) for j in range(24) if coords>>j&1))
def pattern(rows):
    return [sum((r>>j&1)<<i for i,r in enumerate(rows)) for j in range(24)]
def isom(left,right):
    assert len(left)==len(right)
    a=pattern(left);b=pattern(right)
    # At every new row, compare multiplicities of the partition of all coordinates.
    def rec(i,rows,colors,mask):
        if i==len(left):
            images=defaultdict(list)
            for j,x in enumerate(colors):images[x].append(j)
            perm=[images[x].pop() for x in a]
            assert {sum(((s>>j)&1)<<p for j,p in enumerate(perm)) for s in left}==set(right)
            return perm
        target=sorted(x&((1<<(i+1))-1) for x in a)
        for k in range(len(right)):
            if mask>>k&1: continue
            colored=[v+(((right[k]>>j)&1)<<i) for j,v in enumerate(colors)]
            if sorted(colored)==target:
                found=rec(i+1,rows+[k],colored,mask|1<<k)
                if found:return found
        return None
    return rec(0,[],[0]*24,0)
def main():
    records=json.loads((HERE/'cut_orbits.json').read_text())
    reps=[];by=defaultdict(list);maps=[];types=Counter()
    for r in records:
        tp=[];pmap=[]
        for c in r['components']:
            sig=signature(c)
            for h in by[sig]:
                perm=isom(c,reps[h])
                if perm:break
            else:
                h=len(reps);reps.append(c);by[sig].append(h);perm=list(range(24))
            tp.append(h);pmap.append([h,perm])
        maps.append(pmap);types[tuple(sorted(tp))]+=r['size']
    dest={'reps':reps,'maps':maps,'type_counts':[[list(t),k] for t,k in types.items()]}
    (HERE/'components.json').write_text(json.dumps(dest,separators=(',',':')))
    print('component representatives',len(reps),'sizes',list(map(len,reps)),'type counts',types,flush=True)
if __name__=='__main__':main()

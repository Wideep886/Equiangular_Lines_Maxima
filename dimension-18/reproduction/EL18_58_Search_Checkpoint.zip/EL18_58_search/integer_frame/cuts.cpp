// Exhaust ordered (one-triple, zero-triple) cuts of each 24-coordinate Type II code.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;
using U=uint32_t;
int wt(U u){return __builtin_popcount(u);}
int main(){
 vector<U> tri;
 for(int i=0;i<24;i++)for(int j=0;j<i;j++)for(int k=0;k<j;k++)tri.push_back((1u<<i)|(1u<<j)|(1u<<k));
 ofstream survivors("cuts_remaining.txt");
 string name;int n;
 while(cin>>name>>n){
  vector<U> code(n);for(U &v:code)cin>>v;
  array<long long,5> stats{};vector<U> block;vector<pair<U,U>> next;
  for(U o:tri){
   vector<U> bank;
   for(U w:code)if((w&o)==o)bank.push_back(w^o);
   for(U z:tri)if(!(z&o)){
    block.clear();U used=0,common=(1u<<24)-1;bool singleton=false;
    for(U w:bank)if(!(z&w)){
     if(wt(w)==1){singleton=true;break;}
     block.push_back(w);used|=w;common&=w;
    }
    if(singleton||common){stats[0]++;continue;}
    if(wt(used)<18 || block.size()*5<58){stats[1]++;continue;}
    array<int,24> deg{};vector<int> ids;
    for(int k=0;k<24;k++)if(used>>k&1){ids.push_back(k);for(U w:block)deg[k]+=(w>>k)&1;}
    sort(ids.begin(),ids.end(),[&](int i,int j){return deg[i]!=deg[j]?deg[i]>deg[j]:i<j;});
    U mask=0;bool excluded=false;
    for(int r=1;r<18;r++){
     mask|=1u<<ids[r-1];array<int,6> hist{};for(U w:block)hist[wt(w&mask)]++;
     int low=0,high=0,t=58,u=58;
     for(int i=0;i<=5;i++){int a=min(t,5*hist[i]),b=min(u,5*hist[5-i]);low+=i*a;high+=(5-i)*b;t-=a;u-=b;}
     long long gap=max(0,max(18*low-290*r,290*r-18*high));
     if(gap*gap>1508LL*r*(18-r)){excluded=true;break;}
    }
    if(excluded){stats[2]++;continue;}
    stats[3]++;survivors<<name<<" "<<o<<" "<<z<<"\n";if(next.size()<16)next.emplace_back(o,z);
   }
  }
  long long total=stats[0]+stats[1]+stats[2]+stats[3];if(total!=2691920)return 2;
  cout<<name;for(int i=0;i<4;i++)cout<<" "<<stats[i];cout<<" example";for(auto a:next)cout<<" "<<a.first<<","<<a.second;cout<<endl;
 }
}

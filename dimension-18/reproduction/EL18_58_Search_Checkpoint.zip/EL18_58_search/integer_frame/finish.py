"""Check the final three possibilities in the norm-five integer-coordinate search."""
from collections import Counter
from itertools import combinations
import json
from orbits import HERE
from pilot import WEIGHT, graph

def common(B):
    a=B[0]
    for b in B[1:]:a&=b
    return a

def exact_clique(blocks):
    _,adj=graph(blocks);best=0
    def search(allowed,n):
        nonlocal best
        best=max(best,n)
        while n+WEIGHT(allowed)>best:
            v=allowed&-allowed;allowed^=v
            search(allowed&adj[v.bit_length()-1],n+1)
    search((1<<len(adj))-1,0);return best

def main():
    data=json.loads((HERE/'components.json').read_text())
    reps=data['reps'];counts={tuple(k):v for k,v in data['type_counts']}
    assert counts=={(0,1):2880,(2,2,2):32,(3,3,3,4,4,4):11520}
    assert common(reps[0]) and common(reps[1])
    # Frame Cauchy bound for a 2-element transversal.
    assert (18*58-290*2)**2>1508*2*16
    B=reps[2]
    occ=Counter(j for b in B for j in range(24) if b>>j&1)
    first=sum(1<<j for j,n in occ.items() if n==6)
    second=sum(1<<j for j,n in occ.items() if n==4)
    stars=sorted({b&first for b in B})
    pairs=sorted({b&second for b in B})
    assert len(stars)==4 and len(pairs)==3 and set(B)=={s|p for s in stars for p in pairs}
    assert all(WEIGHT(s)==3 for s in stars) and all(WEIGHT(p)==2 for p in pairs)
    assert all(a&b==0 for a,b in combinations(pairs,2))
    edges={a&b for a,b in combinations(stars,2)}
    assert len(edges)==6 and all(WEIGHT(i)==1 for i in edges)
    # Upper bounds obtained in proof.md. Small support optima replayed from scratch.
    assert max(min(16+h,24-2*h) for h in range(7))==18
    limits=[exact_clique(reps[i]) for i in (3,4)]
    assert limits==[8,10] and 3*sum(limits)==54
    assert exact_clique([31])==5
    print('Final cuts ruled out by a two-coordinate transversal, capacity 54, and capacity 54. Single-support maximum 5.')
if __name__=='__main__':main()

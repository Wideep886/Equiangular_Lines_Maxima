"""Find both a compatible set and an upper bound by exact coloring branch-and-bound per component."""
from pathlib import Path
from pilot import graph,heuristic
import subprocess,json,sys,tempfile
from orbits import HERE
def solve(blocks,executable,limit=250000):
    vs,adj=graph(blocks)
    chosen=heuristic(adj,17,80)
    with tempfile.TemporaryDirectory() as tmp:
        f=Path(tmp)/'graph'
        while True:
            k=len(chosen)+1;n=len(vs)
            f.write_text(f'{n} {k}\n'+''.join(''.join('1' if (a>>j)&1 else '0' for j in range(n))+'\n' for a in adj))
            result=subprocess.check_output([executable,str(f),str(limit)],text=True).split()
            status=int(result[1])
            if status!=1:break
            chosen=list(map(int,result[3:]))
            assert len(chosen)==k and all(adj[x]>>y&1 for a,x in enumerate(chosen) for y in chosen[:a])
    return {'blocks':blocks,'lower':len(chosen),'exact':status==0,'last_nodes':int(result[2]),'vectors':[vs[i] for i in chosen]}
if __name__=='__main__':
    rows=json.loads((HERE/'cut_orbits.json').read_text())
    seen=set();out=[]
    for r in rows:
        if r['code'] in seen:continue
        seen.add(r['code']);checks=[]
        for b in r['components']:
            v=solve(b,sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 250000)
            checks.append(v); print(r['code'],len(b),v['lower'],v['exact'],v['last_nodes'],flush=True)
        out.append({'orbit':[r['code'],r['ones'],r['zeros']],'results':checks})
    (HERE/'first_components.json').write_text(json.dumps(out,separators=(',',':')))

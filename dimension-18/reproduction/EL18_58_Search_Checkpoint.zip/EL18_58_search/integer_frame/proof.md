# No 58 integer vectors of squared norm five in dimension 18

This is a restriction on a potential realization up to orthogonal change of basis. A general real Gram matrix with integer entries need not admit integer vector coordinates. Integer coordinates at another scale such as squared norm 10 also fall outside this assertion.

Suppose V is an 18-by-58 integer matrix with Gram diagonal five and all off-diagonal entries ±1. Its columns x have either five coordinates ±1, or one ±1 and a different coordinate ±2. Write A=VVᵀ. Then tr A=290 and tr A²=58·(25+57)=4756. For any size-r coordinate subset R, Cauchy–Schwarz on centered matrices gives

    (18 tr A[R] − 290 r)² ≤ 1508 r(18−r).

Indeed 18·4756−290²=1508. In particular no single coordinate can occur in every vector with an odd entry. No two coordinates can jointly meet every odd support either: the left side for r=2 and tr A[R]≥58 exceeds the right side. The rank must be 18 (rank ≥290²/4756>17).

## Binary code reduction

Adjoin three 1s and three 0s to each 18-bit coordinate parity word. Each extended word has weight 4 or 8. Two are orthogonal over F₂ because their original dot product is odd. Their binary linear span is doubly even. This subcode lies in a doubly even self-dual binary code of length 24. One proof is to adjoin the all-ones word and pass to the even-weight hyperplane modulo the all-ones word with quadratic form wt/2 mod 2. Its polar form is the binary dot product. This 22-dimensional nondegenerate quadratic space has plus type (a direct sum of three extended Hamming codes supplies a maximal totally singular subspace). By Witt's extension theorem a totally singular subspace extends to dimension 11 in this quotient. Lifting gives the required dimension-12 code. The Pless–Sloane classification gives exactly nine equivalence classes of length-24 Type II codes. We build nine codes and distinguish them using their tetrad subcodes. Sources: Pless and Sloane, https://doi.org/10.1016/0097-3165(75)90042-4 ; Elkies and Kominers, https://arxiv.org/abs/0902.1942 ; Freibert and Kim, https://doi.org/10.1016/j.ffa.2013.09.002 .

For each representative choose two disjoint triples of coordinates O,Z. Retain words of weights 4,8 equal to 1 on O and 0 on Z, then remove O,Z. There are 2,691,920 ordered cuts per code. The 18-bit supports that remain are precisely the possible singletons and quintets for this test. Any two distinct supported quintets intersect in 1 or 3; the weights of their sum are multiples of four. If a singleton occurs, every other candidate support contains its coordinate. That cut fails the one-coordinate trace bound. The same bound applies when all quintets have a common coordinate. All other cuts contain only quintets.

A given quintet supports at most five lines. This small fact is checked by an exhaustive clique calculation on 16 sign vectors up to global sign. A full system requires 18 used coordinates and at least 12 different quintets. For each remaining cut sort the coordinates by their number of incident quintets and try every initial segment R. If each available quintet can be used at most five times, filling 58 places in increasing or decreasing order of |B∩R| bounds tr A[R]. Reject if its entire interval violates the trace inequality. All remaining cuts and their explicit representatives under certified coordinate symmetries are recorded. Orbits here may be smaller than full automorphism orbits. Sufficiency of the list follows by inspecting every labelled cut.

## Three remaining support systems

Make a graph on quintets, joining two when they intersect in three positions. Different components have no sign constraints on one another: across them the inner product is automatically ±1. Within a quintet identify signs up to overall negation. The code checks equivalence of components by explicit coordinate permutations. The 14,432 surviving labelled cuts give just three multisets of component types.

1. For 2,880 cuts there are two components, each with a common coordinate. The two-coordinate trace bound rules these out.
2. For 11,520 cuts there are three copies of a two-quintet component and three copies of a four-quintet component. Exact sign clique maxima are 8 and 10, hence at most 54 lines.
3. For 32 cuts there are three copies of one 12-quintet component. Its coordinate supports are a Cartesian product: four triples S₁,…,S₄ on six coordinates, and three disjoint pairs on a separate six coordinates. Distinct triples share one coordinate, with all six intersections different. Hence the triples are the four stars in the complete graph K₄, and the vectors are supported on star ∪ pair.

For the last case orient each vector so its first coordinate in its occupied pair is +1. There are six groups, according to the pair used and the sign of the other coordinate. Within one group, the pair contributes 2 to an inner product. The signed triples must have inner product −1 or −3. Suppose k distinct stars are represented in that group. For each occupied star, its signs on the k−1 edges shared with the other occupied stars are fixed by opposition. On its remaining 4−k coordinates its sign words have Hamming distance at least two. For k=1,2,3,4 the total number of vectors in this group is at most 4,4,3,4 respectively.

For a fixed star there are four signed triples up to overall negation, giving 16 resources across all four stars. Vectors in different groups cannot use the same resource: their pair contributions are zero and equal/opposite signed triples have inner product ±3. A group reusing a resource contains both orientations of the same triple. No other star can be present because its shared coordinate cannot oppose both signs; and no third sign on that same triple has Hamming distance at least two from both opposite triples. Such a group therefore has exactly two vectors. If h groups reuse a resource, the number of vectors is bounded by both 16+h (number of available resources plus duplicates) and 24−2h (group bounds). Their minimum is at most 18 for integer 0≤h≤6. Three components therefore give at most 54.

These steps exhaust the stated integer-coordinate model under the assumption of 58 lines. The number 54 is specific to the final two cut types.

## Reproduce

In this directory, with Python 3.9+ and a C++17 compiler:

    python3 all_codes.py
    c++ -O3 -std=c++17 cuts.cpp -o /tmp/EL18_integer_cuts
    /tmp/EL18_integer_cuts < codes.txt > cuts.log
    python3 orbits.py
    python3 identify.py
    python3 finish.py

Each constructed code has 4,096 distinct words and every weight is divisible by four. The prescribed tetrad subcode is checked on completion of the glued codes. The standalone integer-coordinate pilot search and sign heuristic served to locate the finite cases. The final proof above uses exhaustive calculations.

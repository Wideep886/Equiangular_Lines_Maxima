#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
using namespace std;
constexpr int K=5,MAXN=64*K;
struct Mask {
  array<uint64_t,K> x{};
  bool nonempty() const {for(auto w:x)if(w)return true;return false;}
  int size()const {int n=0;for(auto w:x)n+=__builtin_popcountll(w);return n;}
  int first()const {for(int i=0;i<K;i++)if(x[i])return 64*i+__builtin_ctzll(x[i]); return -1;}
  void set(int v){ x[v/64]|=uint64_t(1)<<(v%64); }
  void erase(int v){ x[v/64]&=~(uint64_t(1)<<(v%64)); }
  Mask intersect(const Mask& y)const{Mask m;for(int i=0;i<K;i++)m.x[i]=x[i]&y.x[i];return m;}
  void subtract(const Mask& y){for(int i=0;i<K;i++) x[i]&=~y.x[i];}
};
int N,need; unsigned long long visits=0,budget=20000000;
array<Mask,MAXN> adj;
array<int,MAXN> ans;
int search(Mask cur,int req) {
  visits++;if(visits>budget)return -1;
  if(req==0)return 1;
  if(cur.size()<req)return 0;
  array<int,MAXN> vert{},color{};int nvert=0,ncolor=0;Mask left=cur;
  while(left.nonempty()){
    ++ncolor;auto ind=left;
    while(ind.nonempty()){
      int v=ind.first();left.erase(v);ind.erase(v);ind.subtract(adj[v]);
      vert[nvert]=v;color[nvert++]=ncolor;
    }
  }
  for(int pos=nvert-1;pos>=0;pos--){
    if(color[pos]<req)return 0;
    auto v=vert[pos];auto ret=search(cur.intersect(adj[v]),req-1);
    if(ret){if(ret==1)ans[req]=v;return ret;}
    cur.erase(v);
  }
  return 0;
}
int main(int argc,char**argv){
 ifstream in(argv[1]);in>>N>>need;if(!in||N>MAXN)return 2;
 if(argc>2)budget=stoull(argv[2]);
 vector<string> mat(N);for(auto &s:mat)in>>s;
 vector<int> pv(N);iota(pv.begin(),pv.end(),0);
 stable_sort(pv.begin(),pv.end(),[&](int a,int b){return count(mat[a].begin(),mat[a].end(),'1')>count(mat[b].begin(),mat[b].end(),'1');});
 Mask all;for(int i=0;i<N;i++){all.set(i);for(int j=0;j<N;j++)if(mat[pv[i]][pv[j]]=='1')adj[i].set(j);}
 int ret=search(all,need);cout<<argv[1]<<' '<<ret<<' '<<visits;
 if(ret==1)for(int i=1;i<=need;i++)cout<<' '<<pv[ans[i]];
 cout<<endl;return 0;
}

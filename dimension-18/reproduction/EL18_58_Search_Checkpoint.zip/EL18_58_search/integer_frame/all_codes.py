"""Build the nine length-24 Type II code representatives, distinguished by their tetrad subcodes."""
from itertools import product
from functools import reduce
from operator import xor
from pathlib import Path
from pilot import binary_codes,WEIGHT,span
import json

def basis_reduce(x,basis):
    for v in basis:x=min(x,x^v)
    return x

def independent(words):
    b=[]
    for w in words:
        r=basis_reduce(w,b)
        if r:b.append(r);b.sort(reverse=True)
    return b

def code(blocks):
    pivot=0;rows=[]
    for t in blocks:
        if t=='e7':
            n=7;r=[sum(1<<i for i in range(7) if (i+1)>>j&1) for j in range(3)]
        elif t=='e8':
            n=8;r=[255,15,51,85]
        else:
            n=int(t[1:]);r=[3^(3<<(i*2)) for i in range(1,n//2)]
        rows.extend(x<<pivot for x in r);pivot+=n
    assert pivot==24
    basis=independent(rows);ch=span(basis);olds={w for w in ch if WEIGHT(w)==4}
    # Compute C0-perp by Gaussian reduction of all parity-check equations.
    eq=sorted(basis,reverse=True);piv=[v.bit_length()-1 for v in eq]
    vec=[]
    for j in set(range(24))-set(piv):
        u=1<<j
        for col,r in reversed(list(zip(piv,eq))):
            if WEIGHT(u&r)%2:u ^=1<<col
        assert all(WEIGHT(u&w)%2==0 for w in rows);vec.append(u)
    q=span(independent([basis_reduce(v,basis) for v in vec]))
    options=sorted(u for u in q if u and WEIGHT(u)%4==0 and all(WEIGHT(u^w)>=8 for w in ch))
    valid=set(options)
    def go(current,added,pos):
        if len(basis)+len(added)==12:return added
        for i in range(pos,len(options)):
            u=options[i]
            new=[u^v for v in current]
            if all(v in valid for v in new):
                sol=go(current+new,added+[u],i+1)
                if sol is not None:return sol
    add=go([0],[],0)
    assert add is not None
    C=span(basis+add)
    assert len(set(C))==4096 and all(WEIGHT(w)%4==0 for w in C)
    assert {w for w in C if WEIGHT(w)==4}==olds
    return [w for w in C if WEIGHT(w) in (4,8)]

def all_codes():
    D=binary_codes()
    for blocks in [('d12','d12'),('d10','e7','e7'),('d8',)*3,('d6',)*4,('d4',)*6]:
        D['_'.join(blocks)]=code(blocks)
    signatures=set()
    for words in D.values():
        tetrads=[w for w in words if WEIGHT(w)==4]
        classes=[]
        for tet in tetrads:
            hit=[c for c in classes if c&tet]
            classes=[c for c in classes if not c&tet]
            for c in hit:tet|=c
            classes.append(tet)
        sig=tuple(sorted((WEIGHT(c),sum((w&c)==w for w in tetrads)) for c in classes))
        signatures.add(sig)
    assert len(signatures)==9
    return D
if __name__=='__main__':
    D=all_codes()
    here=Path(__file__).resolve().parent
    with (here/'codes.txt').open('w') as f:
        for k,C in D.items():print(k,len(C),*C,file=f)
    print({k:(sum(WEIGHT(w)==4 for w in C),len(C)) for k,C in D.items()})

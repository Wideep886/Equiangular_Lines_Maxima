"""Reduce surviving triples by explicit coordinate permutations preserving the length-24 code."""
from collections import Counter,defaultdict
from itertools import combinations
from pathlib import Path
import json
from pilot import WEIGHT,supports
from all_codes import independent,span

HERE=Path(__file__).resolve().parent
def apply(v,moves):
    for i,j in moves:
        if (v>>i^v>>j)&1:v^=(1<<i)|(1<<j)
    return v
def generators(words):
    base=independent(words)
    assert len(base)==12
    C=set(span(base))
    pairs=list(combinations(range(24),2))
    opts=[(a,) for a in pairs]
    for a,b,c,d in combinations(range(24),4):
        opts.extend([((a,b),(c,d)),((a,c),(b,d)),((a,d),(b,c))])
    return [t for t in opts if all(apply(w,t) in C for w in base)]
def components(blocks):
    rest=set(blocks);out=[]
    while rest:
        root=rest.pop();q=[root];part=[root]
        while q:
            v=q.pop();ns={w for w in rest if WEIGHT(w&v)==3}
            rest-=ns;q.extend(ns);part.extend(ns)
        out.append(sorted(part))
    return sorted(out,key=lambda t:(len(t),t))
def main():
    codes={a[0]:list(map(int,a[2:])) for a in (line.split() for line in (HERE/'codes.txt').read_text().splitlines())}
    by=defaultdict(set)
    for line in (HERE/'cuts_remaining.txt').read_text().splitlines():
        code,s,z=line.split();by[code].add((int(s),int(z)))
    records=[]
    for name,allcuts in by.items():
        gens=generators(codes[name]);index=defaultdict(list)
        # Collapse actions with the same effect on all coordinates in the two triples at runtime.
        lut={m:tuple(apply(m,g) for g in gens) for m in {m for t in allcuts for m in t}}
        todo=set(allcuts)
        while todo:
            start=min(todo);todo.remove(start);q=[start];size=1
            while q:
                s,z=q.pop()
                for other in zip(lut[s],lut[z]):
                    if other in todo:todo.remove(other);q.append(other);size+=1
            b=supports(codes[name],start[0]|start[1],start[0])
            records.append({'code':name,'ones':start[0],'zeros':start[1],'size':size,'components':components(b)})
        c=[r for r in records if r['code']==name]
        assert sum(r['size'] for r in c)==len(allcuts)
        print(name,'generators',len(gens),'labeled cuts',len(allcuts),'representatives',len(c),'component sizes',Counter(tuple(map(len,r['components'])) for r in c),flush=True)
    (HERE/'cut_orbits.json').write_text(json.dumps(records,separators=(',',':')))
if __name__=='__main__':main()

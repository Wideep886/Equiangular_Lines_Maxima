"""Complete the six rank-four decorated templates by exact signed-pair graphs."""
from tangent import *
from field import targets,trace,H,Q,decks
from fractions import Fraction as F
from pathlib import Path
import sys,json
from functools import lru_cache
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'unit_simple'))
from walks import configurations
def potential_lists(words):
    A=[];B=[]
    for t in words:
        A.extend(potential([(x>0)-(x<0) if abs(x)==1 else 0 for x in t]))
        B.extend(potential([(x>0)-(x<0) if abs(x)==2 else 0 for x in t]))
    return A,B
def walkers():
    for x,p in configurations((4,)*5):
        if x!=4:continue
        v=tuple(a for f,t in p for a in t)
        edge=tuple((v[4*i+(j+1)%4]-v[4*i+j])//4 for i in range(5) for j in range(4))
        yield v,edge
def options(words,ds):
    A,B=potential_lists(words)
    out=[]
    for v,edge in walkers():
        aa=dot(v,A);bb=dot(v,B)
        if aa%16 or bb%16:continue
        a=aa//16;b=bb//16
        for typ,cross,other in targets_cached:
            if not ds[typ] or abs(a)!=abs(cross) or abs(b)!=abs(other):continue
            sig=(a,cross//a,b,other//b)
            out.append((typ,sig,v))
    return out
targets_cached=targets()
def graph(opts):
 edges=[0]*len(opts)
 for i,(t,sig,v) in enumerate(opts):
    for j,(t2,sig2,v2) in enumerate(opts[:i]):
        d=dot(v,v2)+16*(sig[1]*sig2[1]+sig[3]*sig2[3])
        if abs(d)!=32:continue
        edges[i]|=1<<j;edges[j]|=1<<i
 return edges

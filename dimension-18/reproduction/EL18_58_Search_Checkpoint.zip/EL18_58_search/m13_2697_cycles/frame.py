from complete import *
import numpy as np
from collections import Counter
def system(t,opts,ds):
    words=sum(t,())
    a=np.array([v if abs(v)==1 else 0 for v in words]);b=np.array([v//2 if abs(v)==2 else 0 for v in words])
    K=np.array([[5 if i==j else -1 if i//4==j//4 and (i-j)%2 else 1 for j in range(20)] for i in range(20)])
    F=np.zeros((22,22),dtype=np.int64)
    F[:20,:20]=16*K+4-2*np.outer(a,a)-2*np.outer(b,b)-K@K
    F[20,20]=F[21,21]=38
    F[:20,20]=F[20,:20]=2*a
    F[:20,21]=F[21,:20]=2*b
    ij=np.triu_indices(22)
    stypes=(0,1,4,5)
    tar=np.concatenate((F[ij],np.array([ds[i] for i in stypes])))
    Z=[]
    for typ,sig,v in opts:
        y=[(v[k//4*4+(k+1)%4]-v[k])//4 for k in range(20)]+[sig[1],sig[3]]
        Z.append(np.concatenate((np.outer(y,y)[ij],[int(typ==i) for i in stypes])))
    return np.array(Z),tar
def stream():
    st=representatives()
    for comb in combinations_with_replacement(sorted(st),5):
        sa,sb,sc,n=map(sum,zip(*(st[t] for t in comb)))
        if (sa,sb,sc)!=(48,80,0):continue
        ds=next(d for d,status in decks if d[2]==n)
        opts=options(comb,ds)
        yield comb,ds,opts,graph(opts)
def mat_rank_rows(M,tar,p=7):
    A=np.array([*M,tar],dtype=np.int16)%p
    independent=[]
    j=0
    for k in range(A.shape[1]):
        nz=np.flatnonzero(A[j:-1,k])
        if len(nz)==0:
            if A[-1,k]:return False
            continue
        v=j+nz[0]
        if v!=j:A[[j,v]]=A[[v,j]]
        b=A[j]*pow(int(A[j,k]),-1,p)%p
        A[j+1:]=(A[j+1:] - (A[j+1:,k,None]*b))%p
        j+=1
    return True
def main():
    res=[]
    for comb,ds,opts,g in stream():
        Z,tar=system(comb,opts,ds)
        # Use a fixed projective image modulo 7 for the fast span test.
        # A projected inconsistency remains an inconsistency in the original exact equations.
        # Retain original coordinates using rows independent on this entire option pool.
        p=7
        keep=np.ones(len(g),dtype=bool)
        for stage in range(50):
            if not mat_rank_rows(Z[keep],tar,p):
                keep[:]=False;break
            removed=[]
            for i in np.flatnonzero(keep):
                inds=[j for j in np.flatnonzero(keep) if g[i]>>int(j)&1]
                if len(inds)<37 or not mat_rank_rows(Z[inds],tar-Z[i],p):removed.append(i)
            if not removed:break
            keep[removed]=False
        print(ds[2],len(g),sum(keep),flush=True)
        res.append(dict(template=comb,deck=ds,vertices=len(g),remain=list(map(int,np.flatnonzero(keep)))))
        (here/'frame.json').write_text(json.dumps(res))
if __name__=='__main__':main()

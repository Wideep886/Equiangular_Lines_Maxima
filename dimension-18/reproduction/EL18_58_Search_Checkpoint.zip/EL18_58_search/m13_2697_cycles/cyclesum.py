"""Exact signed cofactor sum constraints on each cycle-indicator column."""
from pathlib import Path
from itertools import product
from functools import lru_cache
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'unit_simple'))
from walks import partitions
jdir=HERE.parent/'m13_joint'
data=json.loads((jdir/'input_2697.json').read_text())
decks=json.loads((jdir/'ledger_2697.json').read_text())
M=data['minimal'];H=data['deck'];Q=data['pairs']
def val(p,t):
 y=0
 for v in p:y=y*t+v
 return y
def quotient(p,t):
 q=[]
 for k in p:q.append(k+(t*q[-1] if q else 0))
 assert q.pop()==0
 return q
A=[2*v for v in quotient(M,-8)]
B=[2*v for v in quotient(M,2)]
@lru_cache(None)
def profiles(i,j,n,mode):
 # mode 0 external row, 1 inside another cycle, 2 in the cycle.
 if not n:return {(0,)*6}
 opts=[tuple(s*v for v in p) for s in [-1,1] for p in Q[i][j] if mode==0 or s*val(p,2)==2 and (mode==2 or s==1)]
 return {tuple(x+y for x,y in zip(r,k)) for r in profiles(i,j,n-1,mode) for k in opts}
@lru_cache(None)
def possible(i,m,n,mode):
 l=m+n
 numer=[int(mode==2)*20*a+(l*(b-a) if mode!=0 else 0)-(20*h if mode==2 else 0) for a,b,h in zip(A,B,H[i])]
 assert numer[0]==0 and all(c%20==0 for c in numer)
 goal=tuple(c//20 for c in numer[1:])
 tab=profiles(i,2,m-int(mode==2 and i==2),mode)
 rhs=profiles(i,3,n-int(mode==2 and i==3),mode)
 if len(tab)>len(rhs):tab,rhs=rhs,tab
 return any(tuple(c-x for c,x in zip(goal,t)) in rhs for t in tab)
def options(ds,l):
 out=[]
 for m in range(l+1):
    ct=[0,0,m,l-m,0,0]
    if any(c>d for c,d in zip(ct,ds)):continue
    if all((not ct[i] or possible(i,m,l-m,2))
           and (ct[i]==d or possible(i,m,l-m,1 if i in (2,3) else 0))
           for i,d in enumerate(ds)):
        out.append(m)
 return out
def main():
 res=[]
 for ds,status in decks:
    opts={l:options(ds,l) for l in range(4,13,2)}
    surv=[]
    for ls in partitions(20):
        if len(ls)<3:continue
        for ct in product(*(opts[l] for l in ls)):
            if sum(ct)==ds[2] and all(ls[i-1]!=ls[i] or ct[i-1]<=ct[i] for i in range(1,len(ls))):surv.append((ls,ct))
    print(ds,opts,surv,flush=True)
    res.append(dict(deck=ds,options=opts,surviving=surv))
 (HERE/'cycle_sums.json').write_text(json.dumps(res))
if __name__=='__main__':main()

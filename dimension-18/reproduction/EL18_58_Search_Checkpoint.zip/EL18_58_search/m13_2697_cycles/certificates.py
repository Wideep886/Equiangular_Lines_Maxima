"""Export small modular separating vectors; verify.py checks with standard Python."""
from frame import *
def nullword(M,t,p=7):
    E=np.asarray([*M,t],dtype=np.int16)%p
    piv=[];k=0
    for j in range(E.shape[1]):
        nz=np.flatnonzero(E[k:-1,j])
        if len(nz):
            m=k+nz[0]
            if k!=m:E[[k,m]]=E[[m,k]]
            E[k]=E[k]*pow(int(E[k,j]),-1,p)%p
            E[k+1:]=(E[k+1:] - E[k+1:,j,None]*E[k])%p
            piv.append(j);k+=1
        elif E[-1,j]:
            v=np.zeros(E.shape[1],dtype=np.int64);v[j]=1
            for i in range(k-1,-1,-1):v[piv[i]]=-(E[i]@v)%p
            assert not any((M@v)%p) and t@v%p
            return v
    return None
def encode(u):return [(i,int(x)) for i,x in enumerate(u) if x]
def main():
    out=[]
    for c,d,o,g in stream():
        Z,t=system(c,o,d)
        u=nullword(Z,t);cert=[];remaining=[]
        if u is not None:kind='global';cert=[encode(u)]
        else:
            kind='anchored'
            todo=set(range(len(g)))
            for i in range(len(g)):
                if i not in todo:continue
                ix=[j for j in range(len(g)) if g[i]>>j&1]
                u=nullword(Z[ix],t-Z[i])
                if u is None:continue
                cert.append(encode(u));values=(Z@u)%7;goal=t@u%7
                mask=sum(1<<int(k) for k in np.flatnonzero(values))
                excluded=[j for j in todo if values[j]!=goal and not mask&g[j]]
                assert i in excluded
                todo.difference_update(excluded)
            remaining=sorted(todo)
            assert len(todo)<38
        print(d[2],len(o),kind,len(cert),len(remaining),flush=True)
        out.append(dict(template=c,vertices=len(o),kind=kind,certificates=cert,remaining=remaining))
    (here/'certificates.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':main()

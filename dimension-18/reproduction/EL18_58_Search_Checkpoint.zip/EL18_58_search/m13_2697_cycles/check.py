"""Cycle frames for the m=13 tail 2697, squared-norm 5 scaling."""
import sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'unit_simple'))
from three_cycles import *
def key(v,ls):
    k=0;keys=[]
    for l in ls:
        keys.append((l,canonical(v[k:k+l])));k+=l
    return tuple(sorted(keys))
def orbit_prune(g,keys,target=38):
    if len(g)<target:return []
    keep=np.ones(len(g),dtype=np.bool_)
    while any(keep):
        todo={};removed=[]
        for i in np.flatnonzero(keep): todo.setdefault(keys[i],i)
        for k,i in todo.items():
            ix=np.flatnonzero(keep&g[i])
            if len(ix)<target-1 or color_fast(g[np.ix_(ix,ix)])<target-1:
                removed.append(k)
        if not removed:break
        bad=set(removed);keep&=np.array([k not in bad for k in keys])
    return list(map(int,np.flatnonzero(keep)))
def q3(ls):
    L=lcm(*ls);D=2*L**2
    v=[tuple((L//ell)*z for ell,(n,t) in zip(ls,p) for z in t)
        for x,p in configurations(ls) if x==5]
    if not v:return []
    U=np.array(v);g=np.abs(U@U.T)==D
    keys=[key(z,ls) for z in U]
    left=orbit_prune(g,keys)
    print('three',ls,len(v),len(left),flush=True)
    return left
def q4(ls):
    out=[]
    for c,g,b,U in graphs(ls):
        keys=[(int(z),key(v,ls)) for z,v in zip(b,U)]
        left=orbit_prune(g,keys)
        print('four',ls,c,len(g),len(left),flush=True)
        out.append(dict(c=c,left=left))
    return out
if __name__=='__main__':
    out=[]
    for ls in partitions(20):
        if len(ls) not in [3,4]: continue
        left=(q3 if len(ls)==3 else q4)(ls)
        out.append(dict(cycles=ls,remaining=left))
        (P/'results.json').write_text(json.dumps(out))

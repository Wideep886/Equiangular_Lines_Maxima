from cyclesum import *
from fractions import Fraction as F
def rem(p,f):
 p=p[:]
 while len(p)>2:
  a=p[0];p=[p[i]-a*f[i] if i<len(f) else p[i] for i in range(len(p))][1:]
 return tuple(([0,0]+p)[-2:])
def multiply(a,b,f):return rem([a[0]*b[0],a[0]*b[1]+a[1]*b[0],a[1]*b[1]],f)
def trace(p,f):
 den=rem([2*(len(M)-1-i)*a for i,a in enumerate(M[:-1])],f)
 s,t=den
 # inverse of st+t under quadratic f, conjugate slope -s, const t-s*f[1]
 conj=(-s,t-s*f[1]);norm=multiply(den,conj,f)
 assert norm[0]==0
 num=multiply(rem(p,f),(2,16),f)
 v,w=multiply(num,conj,f)
 return F(2*w-v*f[1],norm[1])
def targets():
 out=[]
 planes=([1,0,-3],2,3,13),([1,1,-5],3,5,11)
 for i in (0,1,4,5):
    terms=[]
    for f,j,k,diagonal in planes:
        v=trace(H[i],f);length=trace(H[j],f)
        assert length==F(2,k)
        q=Q[i][j][0]  # Only a witness for a quadratic-field square root.
        assert multiply(rem(q,f),rem(q,f),f)==multiply(rem(H[i],f),rem(H[j],f),f)
        sq=trace(q,f)**2/length
        assert v-sq==F(1,2)
        # trace() scales by the Gram eigenvalue; multiplying the argument
        # by its eigenvalue once more gives the restricted frame moment.
        gq=[2*x for x in H[i]]+[0]
        for t,x in enumerate(H[i]):gq[t+1]+=16*x
        cross=trace(gq,f)-diagonal*sq-F(19,2)
        assert cross*cross==2*k*sq
        terms.append(int(cross));assert cross.denominator==1
    out.append((i,*terms))
 return out
if __name__=='__main__':print(targets())

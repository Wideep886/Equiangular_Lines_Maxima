"""Two tangent directions determined on the five four-cycles."""
from itertools import product,combinations_with_replacement
from collections import Counter
def potential(v):
 p=[0]
 for a in v[:-1]:p.append(p[-1]+a)
 return tuple(4*a-sum(p) for a in p)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def representatives():
 states={}
 def canonical(t):
  return min(v[k:]+v[:k] for v in (t,t[::-1]) for k in range(4))
 for t in product([1,-1,2,-2],repeat=4):
  if t!=canonical(t):continue
  a=tuple((x>0)-(x<0) if abs(x)==1 else 0 for x in t)
  b=tuple((x>0)-(x<0) if abs(x)==2 else 0 for x in t)
  if sum(a) or sum(b):continue
  u=potential(a);v=potential(b)
  states[t]=(dot(u,u),dot(v,v),dot(u,v),sum(abs(x) for x in a))
 return states
if __name__=='__main__':
 st=representatives()
 sols=[]
 for comb in combinations_with_replacement(sorted(st),5):
  sa,sb,sc,n=map(sum,zip(*(st[t] for t in comb)))
  if (sa,sb,sc)==(48,80,0):sols.append((n,comb))
 print('all',len(sols),Counter(n for n,c in sols))
 for q in sols[:10]:print(q)

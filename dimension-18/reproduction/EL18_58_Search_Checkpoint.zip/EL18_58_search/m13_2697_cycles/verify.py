"""Independent standard-library verification of separating vectors for all templates."""
from complete import *
def columns(words,ds,vs):
    word=sum(words,())
    a=[int(t==1)-int(t==-1) for t in word]
    b=[int(t==2)-int(t==-2) for t in word]
    K=[[5 if i==j else -1 if i//4==j//4 and (i-j)%2 else 1 for j in range(20)] for i in range(20)]
    coordinates=[(i,j) for i in range(22) for j in range(i,22)]
    def frame(i,j):
        if j<20:return 16*K[i][j]+4-2*a[i]*a[j]-2*b[i]*b[j]-dot(K[i],K[j])
        if i<20:return 2*(a[i] if j==20 else b[i])
        return 38*int(i==j)
    types=(0,1,4,5)
    tar=[frame(i,j) for i,j in coordinates]+[ds[k] for k in types]
    Z=[]
    for typ,sig,v in vs:
        signs=[(v[i//4*4+(i+1)%4]-v[i])//4 for i in range(20)]+[sig[1],sig[3]]
        Z.append([signs[i]*signs[j] for i,j in coordinates]+[int(typ==k) for k in types])
    return Z,tar
def main():
    from field import Q,H,M,trace,rem
    from cyclesum import val
    assert [val(q,2) for q in H]==[0,0,2,2,0,0]
    assert val([(len(M)-1-i)*v for i,v in enumerate(M[:-1])],2)==20
    # Reconstruct all nonnegative one-point counts directly. Fix last type count
    # and solve the independent five-column system by exact Gauss--Jordan.
    from cyclesum import data
    def unique(n):
        R=[[F(H[j][i]) for j in range(5)]+[F(t-n*H[5][i])] for i,t in enumerate(data['cofactor_sum'])]
        for i in range(5):
            k=next(j for j in range(i,len(R)) if R[j][i])
            R[i],R[k]=R[k],R[i]
            R[i]=[x/R[i][i] for x in R[i]]
            for j in range(len(R)):
                if j!=i:R[j]=[x-R[j][i]*y for x,y in zip(R[j],R[i])]
        if any(R[j][-1] for j in range(5,len(R))):return
        row=[R[j][-1] for j in range(5)]+[F(n)]
        if all(x>=0 and x.denominator==1 for x in row):return list(map(int,row))
    assert [row for n in range(59) if (row:=unique(n)) is not None]==[ds for ds,_ in decks]
    assert all(ds[2]+ds[3]==20 for ds,_ in decks)
    for f,A,B,scale in [([1,0,-3],2,3,3),([1,1,-5],3,2,5)]:
        assert trace(H[A],f)==F(2,scale) and rem(H[B],f)==(0,0)

    assert targets_cached==[(0,1,-1),(1,1,3),(4,-1,1),(5,3,1)]
    st=representatives()
    cases=[]
    for c in combinations_with_replacement(sorted(st),5):
        sa,sb,sc,n=map(sum,zip(*(st[t] for t in c)))
        if (sa,sb,sc)==(48,80,0):
            ds=next(d for d,_ in decks if d[2]==n)
            cases.append((c,ds))
    rows=json.loads((here/'certificates.json').read_text())
    assert len(cases)==len(rows)==6
    for (t,ds),r in zip(cases,rows):
        assert json.loads(json.dumps(t))==r['template']
        opts=options(t,ds);Z,T=columns(t,ds,opts);assert len(Z)==r['vertices']
        if r['kind']=='anchored':g=graph(opts)
        keep=set(range(len(Z)))
        for p in r['certificates']:
            def ev(v):return sum(v[j]*a for j,a in p)%7
            rhs=ev(T);vals=list(map(ev,Z))
            if r['kind']=='global':
                assert rhs and not any(vals);keep.clear()
            else:
                mask=sum(1<<j for j,k in enumerate(vals) if k)
                keep={i for i in keep if rhs==vals[i] or mask&g[i]}
        assert sorted(keep)==r['remaining'] and len(keep)<38
        print(ds[2],len(Z),r['kind'],len(r['certificates']),len(keep))
if __name__=='__main__':main()

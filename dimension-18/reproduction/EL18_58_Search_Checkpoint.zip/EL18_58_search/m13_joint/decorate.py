"""Switch all rows positively towards one anchor. Retain common orientation at all simple roots."""
from screen import *
from itertools import product
from fractions import Fraction
from math import gcd

def rem(a,f):
    a=list(a)
    while len(a)>=len(f):
        v=a[0]
        a=[x-v*y for x,y in zip(a,f)]+a[len(f):]
        a.pop(0)
    return tuple([0]*(len(f)-1-len(a))+a)

def row_options(G,H,anchor,ds,P):
    need=[n-(i==anchor) for i,n in enumerate(ds)]
    groups=[];variables=[];bounds=[]
    rhs=list(coefficient_gram(G,H[anchor],H[anchor],H[anchor],True))
    for j,n in enumerate(need):
        if not n:continue
        groups.append((j,n))
        labels=P[anchor][j]
        if not labels:return
        base=gram_column(labels[0])
        rhs=[a-n*b for a,b in zip(rhs,base)]
        for q in labels[1:]:
            variables.append([a-b for a,b in zip(gram_column(q),base)])
            bounds.append(n)
    assignments=feasible_counts(variables,rhs,bounds) if variables else ([()] if not any(rhs) else [])
    for assignment in assignments:
        cells=[(anchor,tuple(H[anchor]),1)]
        cur=0
        for j,n in groups:
            labels=P[anchor][j]
            rest=assignment[cur:cur+len(labels)-1]
            cur+=len(rest)
            for q,k in zip(labels,(n-sum(rest),*rest)):
                if k<0:break
                if k:cells.append((j,tuple(q),k))
            else:continue
            break
        else:yield cells

def refine(cells,H,P,f):
    ref,q0,_=cells[0]
    residues=[rem(q,f) for i,q,n in cells]
    for a,(i,q,n) in enumerate(cells):
        rr=residues[a]
        target=list(rem(mul([2,11],rr),f))
        optional=[];bounds=[]
        for b,(j,r,nj) in enumerate(cells):
            z=nj-(a==b)
            if not z:continue
            if a==0 or b==0:s={1}
            else:
                wanted=rem(mul(q,r),f)
                choices={rem(mul(q0,p),f) for p in P[i][j]}
                s={val for val in (-1,1) if tuple(val*t for t in wanted) in choices}
            if not s:return False
            base=min(s)
            target=[u-z*base*v for u,v in zip(target,residues[b])]
            if len(s)==2:
                optional.append([2*v for v in residues[b]]);bounds.append(z)
        if optional:
            if not feasible_counts(optional,target,bounds,first_only=True):return False
        elif any(target):return False
    return True

def main(idx):
    data=json.loads((HERE/f'input_{idx}.json').read_text())
    H=data['deck'];g=data['minimal'];P=data['pairs']
    f=[1]
    for h,k in data['factors']:
        if k==1:f=mul(f,h)
    ds=[d for d,status in json.loads((HERE/f'ledger_{idx}.json').read_text()) if status=='passed']
    track=[]
    for counts in ds:
        anchors=sorted((i for i,n in enumerate(counts) if n),key=lambda i:sum(len(z) for z in P[i]))
        records=[]
        for i in anchors:
            good=[];total=0
            for cells in row_options(g,H,i,counts,P):
                total+=1
                if refine(cells,H,P,f):good.append(cells)
            records.append(dict(anchor=i,total=total,survivors=len(good),first=good[:1]))
            if not good:break
        track.append(dict(counts=counts,anchors=records,open=all(r['survivors'] for r in records)))
        print(idx,counts,[(r['anchor'],r['total'],r['survivors']) for r in records],flush=True)
    (HERE/f'decorated_{idx}.json').write_text(json.dumps(track,separators=(',',':')))
if __name__=='__main__':
    for i in map(int,sys.argv[1:]):main(i)

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <vector>
using I=long long;
struct Form{I d,constant,lower;std::vector<I> c;};
std::vector<Form> system_rows;
unsigned long long nodes=0,solutions=0;
I floor_div(I a,I b){ I q=a/b, r=a%b; return q-(r && ((r<0)!=(b<0))); }
I ceil_div(I a,I b){return -floor_div(-a,b);}
void visit(std::vector<I> lo,std::vector<I> hi){
 if(++nodes>5000000 || solutions>=10000)return;
 bool change=true;
 while(change){
  change=false;
  for(const auto& row:system_rows){
   I low=row.constant,high=row.constant;
   for(size_t j=0;j<lo.size();++j){I a=row.c[j];low+=a*(a>=0?lo[j]:hi[j]);high+=a*(a>=0?hi[j]:lo[j]);}
   if(low>58*row.d || high<row.lower*row.d)return;
   for(size_t j=0;j<lo.size();++j){
    I a=row.c[j];if(!a||lo[j]==hi[j])continue;
    I lhs=row.lower*row.d-high+a*(a>0?hi[j]:lo[j]);
    I rhs=58*row.d-low+a*(a>0?lo[j]:hi[j]);
    I l=std::max(lo[j],a>0?ceil_div(lhs,a):ceil_div(rhs,a));
    I h=std::min(hi[j],a>0?floor_div(rhs,a):floor_div(lhs,a));
    if(l>h)return;
    if(l!=lo[j]||h!=hi[j]){lo[j]=l;hi[j]=h;change=true;break;}
   }
   if(change)break;
  }
 }
 int k=-1;for(size_t j=0;j<lo.size();++j)if(lo[j]!=hi[j]&&(k<0||hi[j]-lo[j]<hi[k]-lo[k]))k=j;
 if(k<0){
  std::vector<I> sol;
  for(const auto& r:system_rows){I value=r.constant+std::inner_product(lo.begin(),lo.end(),r.c.begin(),I(0)); if(value%r.d)return;sol.push_back(value/r.d);}
  ++solutions;for(I v:sol)std::cout<<v<<" ";std::cout<<"\n";return;
 }
 I top=hi[k];for(I a=lo[k];a<=top;++a){lo[k]=hi[k]=a;visit(lo,hi);if(solutions>=10000||nodes>5000000)break;}
}
int main(){
 int n,k;std::cin>>n>>k;
 for(int i=0;i<n;++i){Form r;std::cin>>r.d>>r.constant>>r.lower;r.c.resize(k);for(auto &v:r.c)std::cin>>v;system_rows.push_back(r);}
 if(!std::cin)return 2;
 visit(std::vector<I>(k,0),std::vector<I>(k,58));
 if(solutions>=10000||nodes>5000000)return 3;
}

"""For every anchor label and endpoint, enforce joint resolvent coefficients."""
from decorate import *
import argparse
def check(cells,H,G,P,f):
    i,h,_=cells[0]
    for a,(j,w,n) in enumerate(cells[1:],1):
        mixed=coefficient_gram(G,w,H[i],H[j],False)
        sq=[u-v for u,v in zip(coefficient_gram(G,H[j],H[j],H[j],True),gram_column(w))]
        counts=[];groups=[]
        for b,(k,r,nk) in enumerate(cells[1:],1):
            count=nk-(a==b)
            if not count:continue
            want=[rem(mul(H[i],z),f) for z in P[j][k]]
            wr=rem(mul(w,r),f)
            jr=rem(mul(H[j],r),f)
            opts=[]
            for z,z0 in zip(P[j][k],want):
                wz=rem(mul(w,z),f)
                for e in [-1,1]:
                    if any(u!=e*v for u,v in zip(z0,wr)) or any(u!=e*v for u,v in zip(wz,jr)):continue
                    opts.append(tuple(gram_column(z))+tuple(e*x*y for x in reversed(r) for y in reversed(z)))
            counts.append(count);groups.append(opts)
        if not test(groups,counts,sq+mixed):return False
    return True

def go(idx,anchors):
    data=json.loads((HERE/f'input_{idx}.json').read_text())
    H=data['deck'];g=data['minimal'];P=data['pairs']
    f=[1]
    for h,k in data['factors']:
        if k==1:f=mul(f,h)
    ds=[d for d,status in json.loads((HERE/f'ledger_{idx}.json').read_text()) if status=='passed']
    records=[]
    for counts in ds:
        tests=[]
        for i in anchors:
            if not counts[i]:continue
            run=0;seen=0;survive=[]
            for cells in row_options(g,H,i,counts,P):
                run+=1
                if not refine(cells,H,P,f):continue
                seen+=1
                if check(cells,H,g,P,f):survive.append(cells)
            tests.append(dict(anchor=i,generated=run,signed=seen,survivors=len(survive),witness=survive[:1]))
            print(idx,counts,i,run,seen,len(survive),flush=True)
            if not survive:break
        records.append(dict(counts=counts,checks=tests))
        (HERE/f'mixed_{idx}.json').write_text(json.dumps(records))
if __name__=='__main__':go(int(sys.argv[1]),list(map(int,sys.argv[2:])))

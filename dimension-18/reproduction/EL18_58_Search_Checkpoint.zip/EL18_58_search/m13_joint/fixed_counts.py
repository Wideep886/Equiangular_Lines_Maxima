"""Filter a stored finite deck list by bounded single-row cofactor moments."""
from global_decks import *
from collections import Counter
import math

def solve(idx):
    d=json.loads((HERE/f'input_{idx}.json').read_text());H,g,P=d['deck'],d['minimal'],d['pairs']
    start=json.loads((HERE/f'global_{idx}.json').read_text())
    assert not start['open_nodes']
    decks=start['decks']
    # For each anchor, repeated linear-program separators apply to every deck at once.
    for i in sorted(range(len(H)),key=lambda i:sum(map(len,P[i]))):
        pools=[[tuple(gram_column(q)) for q in group] for group in P[i]]
        target=tuple(coefficient_gram(g,H[i],H[i],H[i],True));dim=len(target)
        basis={}
        for group in pools:
            for v in group[1:]: insert([x-y for x,y in zip(v,group[0])],basis,dim)
        # Already enforced the exact affine equations globally. Restrict to pivot coordinates.
        piv=list(basis)
        groups=[[tuple(v[k] for k in piv) for v in group] for group in pools]
        tar=tuple(target[k] for k in piv)
        cuts=[];keep=[]
        for counts in decks:
            pops=[n-int(i==j) for j,n in enumerate(counts)]
            if not counts[i]:keep.append(counts);continue
            if any(n and not group for n,group in zip(pops,groups)):continue
            if any(sum(n*a for n,a in zip(pops,co))<v for co,v in cuts):continue
            # Solve a relaxation: fixed number of neighbors in every class, correct joint moments.
            active=[j for j,n in enumerate(pops) if n]
            cols=[tuple(int(j==a) for a in active)+r for j in active for r in groups[j]]
            rhs=tuple(pops[a] for a in active)+tar
            from lpscreen import phase_one
            cert=phase_one(cols,rhs)
            if cert['kind']=='primal':keep.append(counts);continue
            y=cert['y'];w=y[len(active):]
            # Support function in direction -w gives a reusable exact inequality.
            co=[max((-sum(x*z for x,z in zip(w,r)) for r in group),default=0) for group in groups]
            bound=-sum(x*z for x,z in zip(w,tar))
            assert sum(n*a for n,a in zip(pops,co))<bound
            cuts.append((co,bound))
        decks=keep
        print(idx,i,len(decks),len(cuts),flush=True)
        (HERE/f'fixed_{idx}.json').write_text(json.dumps(dict(index=idx,last_anchor=i,survivors=decks)))
        if not decks:break
if __name__=='__main__':
    for i in map(int,sys.argv[1:]):solve(i)

"""Rebuild exact pair polynomials from the completed m=13 row screen."""
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'audit_layer'))
from polynomial13 import poly_types, native, factors, SOURCE
def prepare(i):
    h=json.loads((SOURCE/'parents.json').read_text())[i]
    ids=next(r[2] for r in map(json.loads,(HERE.parent/'audit_layer/poly13_final.jsonl').read_text().splitlines()) if r[0]==i)
    fs=[([1,0],13)]+factors(h)
    g,t,d=native([([1,8],40)]+fs)
    _,_,edge=poly_types({j:sum(1<<k for k in ids) for j in ids},fs,g,d,ids)
    record=dict(index=i,factors=fs,minimal=g,cofactor_sum=t,types=ids,deck=[d[j] for j in ids],
                pairs=[[edge.get((min(a,b),max(a,b)),[]) for b in ids] for a in ids])
    (HERE/f'input_{i}.json').write_text(json.dumps(record,separators=(',',':')))
    print(i,len(ids),sum(len(v) for row in record['pairs'] for v in row),flush=True)
if __name__=='__main__':
    for i in map(int,sys.argv[1:]):prepare(i)

"""Independent direct evaluation of the coefficient and rank-one identities used by the pair certificates."""
from screen import HERE, coefficient_gram, gram_column, reduced_product, mul
import json
import sys
from functools import lru_cache
from fractions import Fraction

def value(p,x):
    out=0
    for c in p:out=x*out+c
    return out

def derivative(p):
    return [v*(len(p)-1-i) for i,v in enumerate(p[:-1])]

def kernel(g,q,t,u):
    if t==u:
        return 2*(value(q,t)*value(derivative(g),t)-value(g,t)*value(derivative(q),t))
    return Fraction(2*(value(q,t)*value(g,u)-value(g,t)*value(q,u)),u-t)

def reconstruct(entries,degree,symmetric):
    out=[[0]*degree for _ in range(degree)]
    it=iter(entries)
    for i in range(degree):
        for j in range(i if symmetric else 0, degree):
            out[i][j]=next(it)
            if symmetric:out[j][i]=out[i][j]
    assert next(it,None) is None
    return out

def remainder(p,f):
    # Horner in Z[t]/f in ascending degree.
    d=len(f)-1;coeff=f[:0:-1]
    r=[0]*d
    for a in p:
        top=r[-1];r=[a]+r[:-1]
        r=[x-top*y for x,y in zip(r,coeff)]
    return tuple(reversed(r))

def run(idx):
    data=json.loads((HERE/f'input_{idx}.json').read_text())
    h,g,P=data['deck'],data['minimal'],data['pairs']
    simple=[z for z,m in data['factors'] if m==1]
    f=[1]
    for z in simple:f=mul(f,z)
    @lru_cache(None)
    def residue(a,b):
        c=mul(a,b);r=reduced_product(a,b,f)
        assert tuple(r)==remainder(c,f)
        return r
    degree=len(g)-2
    grid=range(-2,-2+degree)
    def check(q,hi,hj,diag,entries):
        matrix=reconstruct(entries,degree,diag)
        for t in grid:
            row=[value(tuple(reversed(v)),t) for v in zip(*matrix)]
            for u in grid:
                want=kernel(g,q,t,u)
                if diag:want-=value(hi,t)*value(hj,u)
                else:want-=value(hi,t)*value(q,u)+value(q,t)*value(hj,u)
                assert value(row[::-1],u)==want
    for hi in h:check(hi,hi,hi,True,coefficient_gram(g,hi,hi,hi,True))
    count=0
    for i,hi in enumerate(h):
        for j in range(i,len(h)):
            for w in P[i][j]:
                check(w,hi,h[j],False,coefficient_gram(g,w,hi,h[j],False))
                count+=1
                m=reconstruct(gram_column(w),degree,True)
                assert all(m[a][b]==w[-a-1]*w[-b-1] for a in range(degree) for b in range(degree))
                for k,hk in enumerate(h):
                    residue(tuple(w),tuple(hk))
                    for a in P[i][k]:
                        for b in P[j][k]:residue(tuple(a),tuple(b))
    print(idx,'grid',degree,'by',degree,'ordered-endpoint targets (one orientation)',count)
if __name__=='__main__':run(int(sys.argv[1]))

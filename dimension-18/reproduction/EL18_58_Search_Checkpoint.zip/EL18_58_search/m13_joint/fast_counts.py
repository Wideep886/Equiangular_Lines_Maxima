"""Reject a deck only after checking an exact support inequality. Reuse cuts across decks."""
from global_decks import *
from decimal import Decimal
from math import gcd
from functools import reduce
def vector(v,groups,tar):
    w=[-int(x*10**12) for x in v]
    g=reduce(gcd,w,0) or 1;w=[x//g for x in w]
    c=[max((sum(x*y for x,y in zip(w,r)) for r in group),default=0) for group in groups]
    h=sum(x*y for x,y in zip(w,tar))
    return c,h,w
def run(idx,engine):
    d=json.loads((HERE/f'input_{idx}.json').read_text());H,g,P=d['deck'],d['minimal'],d['pairs']
    start=json.loads((HERE/f'global_{idx}.json').read_text())
    assert not start['open_nodes']
    decks=start['decks'];cert=[]
    for i in sorted(range(len(H)),key=lambda i:sum(map(len,P[i]))):
        pools=[[tuple(gram_column(q)) for q in group] for group in P[i]]
        target=tuple(coefficient_gram(g,H[i],H[i],H[i],True));dim=len(target)
        basis={}
        for group in pools:
            for v in group[1:]:insert([x-y for x,y in zip(v,group[0])],basis,dim)
        piv=list(basis)
        groups=[[tuple(v[k] for k in piv) for v in group] for group in pools]
        tar=tuple(target[k] for k in piv)
        cuts=[];keep=[]
        for counts in decks:
            pops=[n-int(i==j) for j,n in enumerate(counts)]
            if not counts[i]:keep.append(counts);continue
            if any(n and not group for n,group in zip(pops,groups)):continue
            if any(sum(n*a for n,a in zip(pops,co))<v for co,v,_ in cuts):continue
            active=[j for j,n in enumerate(pops) if n]
            cols=[tuple(int(j==a) for a in active)+r for j in active for r in groups[j]]
            rhs=tuple(pops[a] for a in active)+tar
            engine.stdin.write(' '.join(map(str,[len(cols),len(rhs),*rhs,*[v for c in cols for v in c]]))+'\n');engine.stdin.flush()
            y=list(map(Decimal,engine.stdout.readline().split()))
            assert len(y)==len(rhs)
            c,v,w=vector(y[len(active):],groups,tar)
            if sum(n*a for n,a in zip(pops,c))<v:cuts.append((c,v,w))
            else:keep.append(counts)
        cert.append([i,piv,[w for _,_,w in cuts]])
        decks=keep
        print(idx,i,len(decks),len(cuts),flush=True)
        if not decks:break
    (HERE/f'cuts_{idx}.json').write_text(json.dumps(dict(cuts=cert,survivors=decks),separators=(',',':')))
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        exe=Path(temp)/'suggest'
        subprocess.run(['c++','-std=c++17','-O3',str(HERE/'suggest.cpp'),'-o',str(exe)],check=True)
        proc=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
        try:
            for i in map(int,sys.argv[1:]):run(i,proc)
        finally:
            proc.stdin.close();assert proc.wait()==0

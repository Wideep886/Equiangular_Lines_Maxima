// Suggest dual directions; Python verifies all resulting inequalities over the integers.
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>
using Vec=std::vector<long double>;
int main(){
 int n,m;
 while(std::cin>>n>>m){
  std::vector<Vec> a(n+m,Vec(m)),inv(m,Vec(m));Vec target(m),scale(m,1);
  for(auto &x:target)std::cin>>x;
  for(int k=0;k<n;k++)for(int j=0;j<m;j++){std::cin>>a[k][j];scale[j]=std::max(scale[j],std::abs(a[k][j]));}
  for(int j=0;j<m;j++)target[j]/=scale[j];
  for(int k=0;k<n;k++)for(int j=0;j<m;j++)a[k][j]/=scale[j];
  std::vector<int> basis(m);Vec dual(m);
  for(int j=0;j<m;j++){basis[j]=n+j;inv[j][j]=a[n+j][j]=(target[j]>=0?1:-1);}
  bool found=false;
  for(int round=0;round<500;round++){
   std::fill(dual.begin(),dual.end(),0);
   for(int j=0;j<m;j++)if(basis[j]>=n)for(int t=0;t<m;t++)dual[t]-=inv[j][t];
   int enter=-1;long double cheapest=-1e-9L;
   for(int k=0;k<n+m;k++){long double cost=(k>=n);for(int t=0;t<m;t++)cost+=dual[t]*a[k][t];if(cost<cheapest){enter=k;cheapest=cost;}}
   if(enter<0){found=true;break;}
   int leave=-1;long double limit=1e99L;Vec step(m);
   for(int j=0;j<m;j++){
    long double v=0;
    for(int t=0;t<m;t++){step[j]+=inv[j][t]*a[enter][t];v+=inv[j][t]*target[t];}
    if(step[j]>1e-9L && (v/step[j]<limit-1e-12L || (std::abs(v/step[j]-limit)<=1e-12L && (leave<0||basis[j]<basis[leave])))){leave=j;limit=v/step[j];}
   }
   if(leave<0)break;
   for(auto &x:inv[leave])x/=step[leave];
   for(int j=0;j<m;j++)if(j!=leave)for(int t=0;t<m;t++)inv[j][t]-=step[j]*inv[leave][t];
   basis[leave]=enter;
  }
  for(int j=0;j<m;j++)std::cout<<std::setprecision(18)<<(found?dual[j]/scale[j]:0)<<" ";
  std::cout<<"\n"<<std::flush;
 }
}

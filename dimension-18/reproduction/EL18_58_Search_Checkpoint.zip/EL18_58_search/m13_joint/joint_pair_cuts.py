"""Integer support inequalities for two fixed endpoints and a common third vertex."""
from decimal import Decimal
from fast_counts import vector
from global_decks import HERE, gram_column, coefficient_gram, mul, reduced_product
from functools import lru_cache
from itertools import combinations_with_replacement
from pathlib import Path
import subprocess
import tempfile
import json
import sys

def solve(idx, engine=None):
    data=json.loads((HERE/f'input_{idx}.json').read_text())
    H,g,P=data['deck'],data['minimal'],data['pairs']
    f=[1]
    for factor, mult in data['factors']:
        if mult == 1:
            f=mul(f,factor)
    product=lru_cache(None)(lambda a,b: reduced_product(a,b,f))
    gram=lru_cache(None)(lambda q: tuple(gram_column(q)))
    row=[tuple(coefficient_gram(g,h,h,h,True)) for h in H]
    P=[[[tuple(q) for q in group] for group in groups] for groups in P]
    decks=json.loads((HERE/f'cuts_{idx}.json').read_text())['survivors']
    order=sorted(combinations_with_replacement(range(len(H)),2),key=lambda ij:len(P[ij[0]][ij[1]]))
    out=HERE/f'joint_pair_cuts_{idx}.json'
    if engine is None:
        archive=json.loads(out.read_text())
    records=[]
    for i,j in order:
        relevant=[n for n in decks if n[i] and n[j]>(i==j)]
        if not relevant:
            continue
        labels=P[i][j]
        equations=[]
        for l,w in enumerate(labels):
            target=tuple(u-v for u,v in zip(row[i],gram(w)))+tuple(u-v for u,v in zip(row[j],gram(w)))+tuple(coefficient_gram(g,w,H[i],H[j],False))
            groups=[]
            for k in range(len(H)):
                want=product(tuple(H[k]),w)
                vs=set()
                for a in P[i][k]:
                    for b in P[j][k]:
                        value=product(a,b)
                        for s in (1,-1):
                            if any(y!=s*x for y,x in zip(want,value)):
                                continue
                            vs.add(gram(a)+gram(b)+tuple(s*x*y for x in reversed(a) for y in reversed(b)))
                groups.append(sorted(vs))
            # Choose independent varying coordinates modulo a prime. Using only these
            # coordinates relaxes the real system, so success alone never certifies feasibility.
            dim=len(target)
            basis={}
            for group in groups:
                for opt in group[1:]:
                    r=[(x-y)%101 for x,y in zip(opt,group[0])]
                    for k,old in basis.items():
                        t=r[k]
                        if t:r=[(x-t*y)%101 for x,y in zip(r,old)]
                    pivot=next((k for k,x in enumerate(r) if x),None)
                    if pivot is not None:
                        m=pow(r[pivot],-1,101)
                        basis[pivot]=[x*m%101 for x in r]
            piv=list(basis)
            groups=[[tuple(v[k] for k in piv) for v in group] for group in groups]
            target=tuple(target[k] for k in piv)
            known=[]
            if engine is None:
                saved=archive['records'][len(records)]
                assert saved[:2]==[i,j]
                for w0 in saved[2][l]:
                    assert len(w0)==len(piv)
                    bound=sum(a*b for a,b in zip(w0,target))
                    maxima=[max((sum(a*b for a,b in zip(w0,v)) for v in group),default=0) for group in groups]
                    known.append((maxima,bound,w0))
            equations.append((groups,target,known))
        eliminated=[]
        for deck in relevant:
            pop=[n-(k==i)-(k==j) for k,n in enumerate(deck)]
            for groups,target,cuts in equations:
                if any(n and not group for n,group in zip(pop,groups)):
                    continue
                if any(sum(x*y for x,y in zip(pop,c))<v for c,v,_ in cuts):
                    continue
                if engine is None:break
                active=[k for k,n in enumerate(pop) if n]
                cols=[tuple(int(j==k) for j in active)+v for k in active for v in groups[k]]
                rhs=tuple(pop[k] for k in active)+target
                line=[len(cols),len(rhs),*rhs,*[x for col in cols for x in col]]
                engine.stdin.write(' '.join(map(str,line))+'\n');engine.stdin.flush()
                y=list(map(Decimal,engine.stdout.readline().split()))
                assert len(y)==len(rhs)
                c,b,w=vector(y[len(active):],groups,target)
                if sum(x*y for x,y in zip(pop,c))<b:
                    cuts.append((c,b,w))
                else:break
            else:eliminated.append(deck)
        decks=[d for d in decks if d not in eliminated]
        records.append([i,j,[[w for _,_,w in cuts] for _,_,cuts in equations]])
        if engine is not None:
            print(i,j,len(decks),len(eliminated),flush=True)
            out.write_text(json.dumps(dict(records=records,survivors=decks),separators=(',',':')))
        if not decks:break
    if engine is None:
        assert decks==archive['survivors'] and len(records)==len(archive['records'])
        print('verified',len(records),'endpoint-type pairs;',len(decks),'decks remain')

if __name__=='__main__':
    idx=int(sys.argv[1])
    if '--verify' in sys.argv:solve(idx)
    else:
        with tempfile.TemporaryDirectory() as d:
            exe=Path(d)/'suggest'
            subprocess.run(['c++','-O3','-std=c++17',str(HERE/'suggest.cpp'),'-o',str(exe)],check=True)
            with subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1) as p:
                try:solve(idx,p)
                finally:p.stdin.close()

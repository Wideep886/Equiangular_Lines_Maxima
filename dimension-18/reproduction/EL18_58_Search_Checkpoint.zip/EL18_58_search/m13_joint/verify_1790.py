"""Check candidate 1790 at distinct integer evaluation points, independently of Bezout coefficient extraction."""
from mixed_cells import *
from lowmult import deriv,val

def outer(a,b):
    return [x*y for x in a for y in b]

def kernel(g,w,t,u):
    if t==u:
        return 2*(val(deriv(g),t)*val(w,t)-val(g,t)*val(deriv(w),t))
    n=2*(val(g,u)*val(w,t)-val(g,t)*val(w,u))
    assert n%(u-t)==0
    return n//(u-t)

def verify():
    inp=json.loads((HERE/'input_1790.json').read_text())
    H,g,pp=inp['deck'],inp['minimal'],inp['pairs']
    f=[1]
    for h,k in inp['factors']:
        if k==1:f=mul(f,h)
    zs=range(-3,3)
    @lru_cache(None)
    def evals(q):return tuple(val(q,z) for z in zs)
    def gram(q):return outer(evals(q),evals(q))
    def diag(h):return [kernel(g,h,t,u)-val(h,t)*val(h,u) for t in zs for u in zs]
    def row(i,counts):
        pools=[[gram(tuple(q)) for q in col] for col in pp[i]]
        return test(pools,[n-int(i==j) for j,n in enumerate(counts)],diag(H[i]))
    decks=feasible_counts(H,inp['cofactor_sum'],[58]*len(H))
    alive=[c for c in decks if all(not n or row(i,c) for i,n in enumerate(c))]
    assert len(decks)==19 and alive==[(28,4,2,8,8,4,4)]
    rejected=[]
    # Anchor the original cofactor type 136; in every solution four such vertices exist.
    root=1
    for cells in row_options(g,H,root,alive[0],pp):
        for pos,(i,w,n) in enumerate(cells[1:],1):
            h=H[root]
            mix=[kernel(g,w,t,u)-val(h,t)*val(w,u)-val(w,t)*val(H[i],u) for t in zs for u in zs]
            squares=[a-b for a,b in zip(diag(H[i]),gram(w))]
            counts=[];groups=[]
            for k,(j,r,m) in enumerate(cells[1:],1):
                count=m-(k==pos)
                if not count:continue
                choices=[]
                for q in map(tuple,pp[i][j]):
                    for e in [-1,1]:
                        # All three signed equalities are necessary on every simple root.
                        terms=[(h,q,w,r),(H[i],r,w,q),(H[j],w,r,q)]
                        if any(any(x!=e*y for x,y in zip(rem(mul(a,b),f),rem(mul(c,d),f))) for a,b,c,d in terms):continue
                        choices.append(gram(q)+[e*x for x in outer(evals(r),evals(q))])
                counts.append(count);groups.append(choices)
            if not test(groups,counts,squares+mix):
                rejected.append(pos);break
        else:
            raise AssertionError(('compatible decorated rows',cells))
    assert len(rejected)==170
    print('19 decks -> 1; all 170 rooted assignments contradicted by joint exact tests.')
if __name__=='__main__':verify()

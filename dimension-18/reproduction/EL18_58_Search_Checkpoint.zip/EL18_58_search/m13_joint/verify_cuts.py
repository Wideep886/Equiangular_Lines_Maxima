"""Replay integer separating hyperplanes against every enumerated type count."""
from screen import HERE, coefficient_gram, gram_column
import json
import sys

def dot(a, b):
    assert len(a) == len(b)
    return sum(x*y for x, y in zip(a, b))

def verify(idx):
    def read(name):
        return json.loads((HERE / f'{name}_{idx}.json').read_text())
    inp, initial, evidence = (read(key) for key in ('input', 'global', 'cuts'))
    assert initial['open_nodes'] == 0
    decks = initial['decks']
    for anchor, positions, normals in evidence['cuts']:
        h = inp['deck'][anchor]
        rhs = coefficient_gram(inp['minimal'], h, h, h, True)
        target = [rhs[k] for k in positions]
        groups = []
        for polynomials in inp['pairs'][anchor]:
            values = [gram_column(q) for q in polynomials]
            groups.append([[v[k] for k in positions] for v in values])
        bounds = [(dot(w, target), [max((dot(w, v) for v in group), default=0)
                                    for group in groups]) for w in normals]
        retained = []
        for deck in decks:
            if deck[anchor]:
                neighbors = list(deck)
                neighbors[anchor] -= 1
                if any(n and not g for n, g in zip(neighbors, groups)):
                    continue
                if any(dot(neighbors, maxima) < target_bound for target_bound, maxima in bounds):
                    continue
            retained.append(deck)
        decks = retained
    assert decks == evidence['survivors']
    print(idx, len(initial['decks']), len(decks))

if __name__ == '__main__':
    for idx in (map(int, sys.argv[1:]) if sys.argv[1:] else [2087, 2453, 2588, 2593, 2878]):
        verify(idx)

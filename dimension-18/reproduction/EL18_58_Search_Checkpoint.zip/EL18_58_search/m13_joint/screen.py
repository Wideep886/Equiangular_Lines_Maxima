"""Fixed-deck one- and two-vertex tests. All rejected rows use exact necessary conditions."""
from pathlib import Path
import sys,json
from functools import lru_cache
from itertools import combinations
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'m15_upstream/source/output'))
from verify_quadratic_0020 import coefficient_gram, feasible_counts, gram_column
sys.path.insert(0,str(HERE.parent/'m13'))
from lattice import lat
from lowmult import mul

def reduced_product(p,q,f):
    h=mul(p,q)
    while len(h)>=len(f):
        h=[v-h[0]*x for v,x in zip(h,f)]+h[len(f):]
        h=h[1:]
    return tuple(h)

def span_mod(columns,target,mod=101):
    piv={}
    for col in columns:
        r=[v%mod for v in col]
        for j,w in piv.items():
            a=r[j]
            if a:r=[(x-a*y)%mod for x,y in zip(r,w)]
        j=next((k for k,v in enumerate(r) if v),None)
        if j is not None:
            a=pow(r[j],-1,mod)
            piv[j]=[x*a%mod for x in r]
    t=list(target)
    for j,w in piv.items():
        a=t[j]%mod
        if a:t=[(x-a*y)%mod for x,y in zip(t,w)]
    return all(x%mod==0 for x in t)

def test(groups,counts,tar):
    # Eliminate one base option per type, using that its multiplicities sum to counts[k].
    diff=[]
    bounds=[]
    b=list(tar)
    for n,cols in zip(counts,groups):
        if not n:continue
        if not cols:return False
        base=cols[0]
        b=[x-n*y for x,y in zip(b,base)]
        for col in cols[1:]:
            diff.append(tuple(u-v for u,v in zip(col,base)))
            bounds.append(n)
    if not diff:return not any(b)
    if not span_mod(diff,b):return False
    if len(diff)<=30:
        if not lat(diff,b):return False
    if len(diff)<=18:
        # Omitting group sum upper bounds for non-base counts enlarges this set.
        return bool(feasible_counts(diff,b,bounds,first_only=True))
    return True

def run(idx, subset=None):
    d=json.loads((HERE/f'input_{idx}.json').read_text())
    G,H,target=d['minimal'],d['deck'],d['cofactor_sum']
    p=[[[tuple(w) for w in c] for c in r] for r in d['pairs']]
    gm=lru_cache(None)(lambda p:tuple(gram_column(p)))
    f=[1]
    for v,k in d['factors']:
        if k==1:f=mul(f,v)
    prod=lru_cache(None)(lambda a,b:reduced_product(a,b,f))
    rows=[tuple(coefficient_gram(G,h,h,h,True)) for h in H]
    out=[]
    if subset is None:
        decks = feasible_counts(H,target,[58]*len(H))
        output = HERE/f'ledger_{idx}.json'
    else:
        decks = json.loads((HERE/f'{subset}_{idx}.json').read_text())['survivors']
        output = HERE/f'{subset}_pairs_{idx}.json'
    for ds in decks:
        verdict='passed'
        for i,n in enumerate(ds):
            if not n:continue
            if not test([[gm(a) for a in pool] for pool in p[i]],[k-(j==i) for j,k in enumerate(ds)],rows[i]):
                verdict=['row',i];break
        if verdict=='passed':
            for i,n in enumerate(ds):
                if not n:continue
                for j in range(i,len(ds)):
                    if ds[j]-(i==j)<=0:continue
                    counts=[n-(k==i)-(k==j) for k,n in enumerate(ds)]
                    for w in p[i][j]:
                        gram=gm(w)
                        tar=[x-y for x,y in zip(rows[i],gram)]+[x-y for x,y in zip(rows[j],gram)]+coefficient_gram(G,w,H[i],H[j],False)
                        groups=[]
                        for k,nk in enumerate(counts):
                            hh=prod(tuple(H[k]),w)
                            opts=[]
                            if nk:
                                for a in p[i][k]:
                                    for b in p[j][k]:
                                        ab=prod(a,b)
                                        for s in (-1,1):
                                            if any(t!=s*v for t,v in zip(hh,ab)):continue
                                            mixed=tuple(s*x*y for x in reversed(a) for y in reversed(b))
                                            opts.append(gm(a)+gm(b)+mixed)
                            groups.append(sorted(set(opts)))
                        if test(groups,counts,tar):break
                    else:verdict=['pair',i,j];break
                if verdict!='passed':break
        print(idx,ds,verdict,flush=True)
        out.append([ds,verdict])
        output.write_text(json.dumps(out))
if __name__=='__main__':
    for i in map(int,sys.argv[1:]):run(i)

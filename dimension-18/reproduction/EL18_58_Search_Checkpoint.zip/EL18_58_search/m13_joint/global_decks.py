"""Exact simultaneous type-count equations after eliminating row-label multiplicities."""
from screen import *
from fractions import Fraction as F
from itertools import product
import argparse, subprocess, tempfile
from math import lcm

def reduce_row(v,basis):
    for j,h in basis.items():
        a=v[j]
        if a:v=[x-a*y for x,y in zip(v,h)]
    return v

def insert(v,basis,n):
    v=reduce_row(list(map(F,v)),basis)
    j=next((i for i,a in enumerate(v[:n]) if a),None)
    if j is None:return not any(v[n:])
    basis[j]=[x/v[j] for x in v]
    return True

def equations(G,H,i,P):
    target=coefficient_gram(G,H[i],H[i],H[i],True)
    dim=len(target);num=len(H)
    diff={};base=[];extra=[]
    for j in range(num):
        opt=[gram_column(q) for q in P[i][j]]
        if not opt:
            extra.append([int(a==j) for a in range(num)]+[int(j==i)])
            base.append([0]*dim)
        else:
            a=opt[0];base.append(a)
            for w in opt[1:]:insert([u-v for u,v in zip(w,a)],diff,dim)
    # total = sum_j n_j base[j]+ span(differences), with self term removed.
    rem=[reduce_row(list(map(F,a)),diff) for a in base]
    rhs=reduce_row(list(map(F,[x+y for x,y in zip(target,base[i])])),diff)
    rows=list(zip(*rem,rhs))
    return extra+[list(row) for row in rows if any(row)]

def boxed(base,free,on,N,exe):
    forms=[[F(j==i) for j in free]+[F(0)] for i in range(N)]
    for i,row in reversed(list(base.items())):
        forms[i]=[F(0)]*len(free)+[row[-1]]
        for j,a in enumerate(row[:N]):
            if j!=i and a:forms[i]=[v-a*w for v,w in zip(forms[i],forms[j])]
    lines=[f"{N} {len(free)}"]
    for i,v in enumerate(forms):
        den=lcm(*(x.denominator for x in v))
        coeff=[int(t*den) for t in v]
        assert (den+sum(map(abs,coeff))+1)*200<2**62
        lines.append(" ".join(map(str,[den,coeff[-1],int(i in on),*coeff[:-1]])))
    result=subprocess.run([str(exe)],input="\n".join(lines)+"\n",text=True,capture_output=True)
    assert result.returncode in (0,3),result.stderr
    return result.returncode,[tuple(map(int,l.split())) for l in result.stdout.splitlines()]

def run_all(idx,cutoff,exe):
    d=json.loads((HERE/f'input_{idx}.json').read_text())
    H,g,P=d['deck'],d['minimal'],d['pairs']
    N=len(H); ds=[];count=0;unfinished=0
    conditional=[equations(g,H,i,P) for i in range(N)]
    init={}
    for v in zip(*H,d['cofactor_sum']):assert insert(v,init,N)
    order=sorted(range(N),key=lambda i:len(conditional[i]),reverse=True)
    def visit(base,left,on):
        nonlocal count,unfinished
        count+=1
        if count>cutoff:
            unfinished+=1;return
        free=[i for i in range(N) if i not in base]
        if len(free)<=1 or not left:
            code,solutions=boxed(base,free,on,N,exe)
            if code:unfinished+=1
            for x in solutions:
                assert sum(x)==58 and all(n>=0 for n in x)
                if all(not x[i] or all(sum(a*v for a,v in zip(r[:N],x))==r[-1] for r in conditional[i]) for i in range(N)):
                    ds.append(x)
            return
        i,*rest=left
        full=dict(base)
        ok=all(insert(row,full,N) for row in conditional[i])
        if ok and len(full)==len(base):
            visit(base,rest,on);return
        if ok:visit(full,rest,on|{i})
        zero=dict(base)
        if insert([int(i==j) for j in range(N)]+[0],zero,N):visit(zero,rest,on)
    visit(init,order,set())
    assert len(ds)==len(set(ds))
    out=dict(index=idx,type_ids=d['types'],nodes=count,open_nodes=unfinished,decks=ds)
    (HERE/f'global_{idx}.json').write_text(json.dumps(out,separators=(',',':')))
    print(idx,N,count,unfinished,len(ds),flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('indices',type=int,nargs='+');ap.add_argument('--limit',type=int,default=50000);a=ap.parse_args()
    with tempfile.TemporaryDirectory() as temp:
        exe=Path(temp)/"boxes"
        subprocess.run(["c++","-O3","-std=c++17",str(HERE/"boxes.cpp"),"-o",str(exe)],check=True)
        for idx in a.indices:run_all(idx,a.limit,exe)

#include <algorithm>
#include <array>
#include <bitset>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;
using ll=long long;
using wide=__int128_t;
constexpr int limit=2048;
using Bits=bitset<limit>;
struct Line {array<ll,18> x; ll h; int e;};
vector<Line> lines;
vector<Bits> adj;
vector<int> best;

void visit(Bits remaining,vector<int>& chosen){
    if(chosen.size()>best.size())best=chosen;
    vector<pair<int,int>> order;
    Bits rest=remaining;
    for(int color=1;rest.any();++color){
        Bits avail=rest;
        for(int v=0;v<(int)adj.size();v++)if(avail[v]){
            rest.reset(v);avail.reset(v);avail &= ~adj[v];
            order.emplace_back(v,color);
        }
    }
    for(auto it=order.rbegin();it!=order.rend();++it){
        auto [v,color]=*it;
        if(chosen.size()+color<=best.size())break;
        chosen.push_back(v);visit(remaining&adj[v],chosen);chosen.pop_back();
        remaining.reset(v);
    }
}
int main(){
    ll D;
    array<array<ll,17>,18> M;
    array<array<int,3>,45> blocks;
    if(!(cin>>D))return 2;
    for(auto &r:M)for(ll &a:r)cin>>a;
    for(auto &r:blocks)for(int &a:r)cin>>a;
    // With 17 changes of sign the horizontal coordinate numerators remain
    // bounded by each row's absolute sum; check every long-long product below.
    ll bound=0;
    for(auto r:M){ll b=0;for(auto a:r)b+=abs(a);bound=max(b,bound);}
    if(18*(wide)bound*bound>INT64_MAX || 10*(wide)D*D>INT64_MAX) return 3;
    array<ll,18>x{};
    array<int,17>s;s.fill(1);
    for(int i=0;i<18;i++)for(ll a:M[i])x[i]+=a;
    for(unsigned k=0;k<65536;k++){
        bool ok=true;
        for(auto t:blocks)if(abs(x[t[0]]+x[t[1]]+x[t[2]])!=D){ok=false;break;}
        if(ok){
            ll h=10*D*D;
            for(ll a:x)h-=a*a;
            if(h>=0){lines.push_back({x,h,h?1:0});if(h)lines.push_back({x,h,-1});}
        }
        if(k<65535){int j=1+__builtin_ctz(k+1);s[j]*=-1;
            for(int i=0;i<18;i++)x[i]+=2*s[j]*M[i][j];
        }
    }
    int n=lines.size();if(n>limit)return 4;
    adj.resize(n);
    int edges=0;
    for(int i=0;i<n;i++)for(int j=0;j<i;j++){
        auto &a=lines[i],&b=lines[j];ll dot=0;
        for(int z=0;z<18;z++)dot+=a.x[z]*b.x[z];
        for(int z:{-1,1}){
            wide d=2*(wide)D*D*z-dot;
            if(d*d==(wide)a.h*b.h && d*a.e*b.e>=0){
                edges++;adj[i].set(j);adj[j].set(i);break;
            }
        }
    }
    Bits all;for(int i=0;i<n;i++)all.set(i);
    vector<int> chosen;visit(all,chosen);
    cout<<n<<" "<<edges<<" "<<best.size()<<"\n";
    for(int i:best){auto &a=lines[i];for(auto v:a.x)cout<<v<<" ";cout<<a.h<<" "<<a.e<<"\n";}
}

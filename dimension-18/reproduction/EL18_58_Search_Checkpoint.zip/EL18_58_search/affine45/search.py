"""Exact 46-core search over unordered marked triples in all affine parity lifts."""
import itertools as it
import json
import os
import subprocess
import tempfile
from fractions import Fraction
from math import gcd
import sys
from concurrent.futures import ProcessPoolExecutor
from functools import reduce
from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
import multiprocessing as mp

here=Path(__file__).resolve().parent
def load(path):
    spec=spec_from_file_location(path.stem,path)
    mod=module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
common=load(here.parent/'affine47'/'search.py')
solver=common.solver
def orbit_records():
    switch={reduce(int.__xor__,[solver.masks[i] for i in range(9) if mask>>i&1],0):mask
            for mask in range(512)}
    assert len(switch)==512
    reductions={r^v:(r,t) for r in solver.reps for v,t in switch.items()}
    pts=solver.pts
    maps=[]
    for a,b,c,d in it.product(range(3),repeat=4):
        if (a*d-b*c)%3:
            for tx,ty in pts:
                pi=[pts.index(((a*x+b*y+tx)%3,(c*x+d*y+ty)%3)) for x,y in pts]
                lm=[solver.lines.index(tuple(sorted(pi[i] for i in t))) for t in solver.lines]
                maps.append((pi,lm))
    designs={r:solver.triples(r) for r in solver.reps}
    indices={r:{tuple(sorted(t)):i for i,t in enumerate(bl)} for r,bl in designs.items()}
    groups={}
    seen=set()
    for r,blocks in designs.items():
        images=[]
        for pi,lm in maps:
            label=sum(((r>>i)&1)<<p for i,p in enumerate(lm))
            representative,flip=reductions[label]
            point_map=[2*pi[u//2]+((u%2)^((flip>>pi[u//2])&1)) for u in range(18)]
            block_map=[indices[representative][tuple(sorted(point_map[u] for u in t))] for t in blocks]
            images.append((representative,block_map))
        for a,b,d in it.combinations(range(48),3):
            key=(r,a,b,d)
            if key in seen:
                continue
            orbit={(c,*sorted((p[a],p[b],p[d]))) for c,p in images}
            assert min(orbit)==key and not seen.intersection(orbit)
            groups[key]=len(orbit)
            seen.update(orbit)
    assert sum(groups.values())==8*17296
    return sorted(groups.items())

def run(record):
    (r,a,b,c),mult=record
    blocks=solver.triples(r)
    C=[t for i,t in enumerate(blocks) if i not in (a,b,c)]
    eq=[[int(k in t)-int(17 in t) for k in range(17)] for t in C]
    B=basis_indices(eq)
    if len(B)<17:
        return dict(code=r,deletions=[a,b,c],multiplicity=mult,rank=len(B),status='lower_rank_open')
    mat=solver.inv([eq[i] for i in B])
    mat.append([-sum(col) for col in zip(*mat)])
    D=reduce(lambda a,b:a*b//gcd(a,b),(x.denominator for row in mat for x in row),1)
    M=[[int(x*D) for x in row] for row in mat]
    inputs=str(D)+'\n'+'\n'.join(' '.join(map(str,row)) for row in M+C)
    output=subprocess.run([exe],input=inputs,text=True,capture_output=True,check=True).stdout.splitlines()
    n,edges,maximum=map(int,output[0].split())
    lifted=[list(map(int,line.split())) for line in output[1:]]
    assert len(lifted)==maximum
    witness=None
    if maximum>=13 or (r,a,b,c)==(0,0,1,2):
        selected=lifted[:13]
        gram=[[2*len(set(x)&set(y))-1 for y in C] for x in C]
        for row,t in zip(gram,C):
            for v in selected:
                u=sum(v[p] for p in t)
                assert abs(u)==D
                row.append(u//D)
        for i,x in enumerate(selected):
            row=[gram[k][45+i] for k in range(45)]
            for j,y in enumerate(selected):
                dot=sum(a*b for a,b in zip(x[:18],y[:18]))
                h,e=x[18:];g,f=y[18:]
                row.append(5 if i==j else next(z for z in (-1,1)
                     if (2*D*D*z-dot)**2==h*g and (2*D*D*z-dot)*e*f>=0))
            gram.append(row)
        witness='gram_%d_%d_%d_%d_%d.json'%(r,a,b,c,len(gram))
        common.certify(gram,len(gram),18)
        (here/witness).write_text(json.dumps(gram))
    return dict(code=r,deletions=[a,b,c],multiplicity=mult,basis=B,den=D,rank=17,
                directions=n,edges=edges,maximum=maximum,witness=witness,status='complete')

def basis_indices(eq):
    # Work modulo 65521 to identify 17 independent rows quickly. If the rank
    # is lower, exact rational elimination recovers the true rank and basis.
    for prime in (65521,None):
        pivots=[]
        basis=[]
        for i,r in enumerate(eq):
            v=[x%prime for x in r] if prime else list(map(Fraction,r))
            for j,u in pivots:
                if v[j]:
                    f=v[j]
                    v=[(x-f*y)%prime for x,y in zip(v,u)] if prime else [x-f*y for x,y in zip(v,u)]
            if any(v):
                j=next(k for k,x in enumerate(v) if x)
                if prime:
                    w=pow(v[j],-1,prime)
                    pivots.append((j,[(x*w)%prime for x in v]))
                else:
                    pivots.append((j,[x/v[j] for x in v]))
                basis.append(i)
                if len(basis)==17:
                    return basis
    return basis

if __name__=='__main__':
    build=tempfile.TemporaryDirectory(prefix='affine45-')
    exe=str(Path(build.name)/'scan')
    subprocess.run([os.environ.get('CXX','c++'),'-std=c++17','-O3',str(here/'scan.cpp'),'-o',exe],check=True)
    classes=orbit_records()
    (here/'orbits.json').write_text(json.dumps(classes))
    print('classes',len(classes),flush=True)
    resultfile=here/'results.json'
    prior=json.loads(resultfile.read_text()) if resultfile.exists() else []
    done={(x['code'],*x['deletions']) for x in prior}
    todo=[z for z in classes if z[0] not in done]
    with ProcessPoolExecutor(max_workers=min(5,os.cpu_count() or 1),
                             mp_context=mp.get_context('fork')) as pool:
        for result in pool.map(run,todo):
            prior.append(result)
            tmp=resultfile.with_suffix('.tmp')
            tmp.write_text(json.dumps(prior));tmp.replace(resultfile)
            if len(prior)%25==0 or len(prior)==len(classes) or result.get('maximum',0)>=13 or result['status']!='complete':
                print(len(prior),result['code'],result['deletions'],result.get('directions'),result.get('maximum'),flush=True)

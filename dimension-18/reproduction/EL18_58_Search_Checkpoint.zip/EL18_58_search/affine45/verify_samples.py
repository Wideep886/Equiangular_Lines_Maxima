"""Independently recompute one full graph per observed direction count in Python."""
from pathlib import Path
import json
from search import common, solver
rows=json.loads(Path(__file__).with_name('results.json').read_text())
tested=set()
for row in rows:
    key=row['directions']
    if key in tested:
        continue
    C=[t for i,t in enumerate(solver.triples(row['code'])) if i not in row['deletions']]
    D,opts,B=solver.coords(C)
    assert len(opts)==key
    adj=[0]*len(opts)
    for i,(x,h,e) in enumerate(opts):
        for j,(y,g,f) in enumerate(opts[:i]):
            dot=sum(a*b for a,b in zip(x,y))
            if any((2*D**2*z-dot)**2==h*g and (2*D**2*z-dot)*e*f>=0 for z in (-1,1)):
                adj[i]|=1<<j
                adj[j]|=1<<i
    assert sum(bin(m).count('1') for m in adj)==2*row['edges']
    assert len(common.max_clique(adj))==row['maximum']==12
    tested.add(key)
print("Python rational-coordinate and maximum-clique recheck:",sorted(tested))

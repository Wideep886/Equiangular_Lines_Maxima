"""Switched cells and rank-thirteen residual for spectrum 2453."""
import sys,json
from pathlib import Path
from fractions import Fraction as F
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'m13_decorations'))
from reduction import load,red,times,inv,gpoly,pol,trace
def data():
    f,_,d,_,op,_=load(2453)
    sol,=json.loads((P.parent/'m13_decorations'/'reanchor2453.json').read_text())
    ref=sol['ref'];h=red(d[ref],f);hi=inv(h,f)
    cells={}
    for i,q,n in [(ref,h,1)]+sol['cells']:
        r=min(tuple(q),tuple(-a for a in q));cells[i,r]=cells.get((i,r),0)+n
    keys=list(cells);N=[cells[k] for k in keys]
    assert sum(N)==58
    e=times([1,8],inv(pol.deriv(gpoly(f)),f),f)
    R=[k[1] for k in keys];lab={};dots={}
    for a,(i,x) in enumerate(keys):
        for b,(j,y) in enumerate(keys):
            z=times(times(x,y,f),hi,f)
            lab[a,b]=sorted(set(s for p in op.get((min(i,j),max(i,j)),[]) for s in (-1,1) if red([s*w for w in p],f)==z))
            dots[a,b]=trace(times(e,z,f),f)
    return f,keys,N,R,lab,dots
if __name__=='__main__':
    f,keys,N,R,lab,L=data()
    for i,(j,r) in enumerate(keys):
        print(i,j,N[i],5-L[i,i],lab[i,i],' '.join(''.join('+' if s==1 else '-' for s in lab[i,b]) or '.' for b in range(len(N))))

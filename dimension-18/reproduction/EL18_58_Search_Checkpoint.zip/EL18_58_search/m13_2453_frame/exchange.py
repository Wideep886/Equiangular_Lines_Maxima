"""All universal replaceable directions in the ten-dimensional exceptional + core space."""
from core import *
from itertools import combinations
def matmul(A,B):return [[dot(r,s) for s in zip(*B)] for r in A]
def main():
    f,keys,N,R,sign,L=data();N,T,K,D,I,invK,BI,W=core()
    EI=piv([[L[i,j] for j in range(len(N))] for i in range(len(N))])
    assert len(EI)==len(BI)==5
    H=[[L[i,j] for j in EI]+[0]*5 for i in EI]+[[0]*5+[D[i][j] for j in BI] for i in BI];V=inverse(H)
    def ipvec(a,s):
        return tuple([L[a,j] for j in EI]+[s[i]-L[a,T[i]] for i in BI])
    ext=[ipvec(a,s) for a,z in W.items() for s,w in z]
    corevec=[ipvec(a,K[i]) for i,a in enumerate(T)]
    def dual(w):return [dot(r,w) for r in V]
    G=[[dot(dual(x),y) for y in ext] for x in ext];J=piv(G)
    print('exterior projection span',len(J))
    assert len(J)==10
    A=[ext[j] for j in J];gram=[[G[i][j] for j in J] for i in J];base=inverse(gram)
    look=[[G[j][i] for j in J] for i in range(len(ext))]
    cand=[]
    for tail in product([-1,1],repeat=9):
        w=(1,)+tail;c=[dot(r,w) for r in base]
        if dot(c,w)!=5 or any(abs(dot(c,r))!=1 for r in look):continue
        cand.append((w,c))
    n=len(cand);adj=[{j for j,(y,e) in enumerate(cand) if abs(dot(c,y))==1} for x,c in cand]
    def canonical(w):return tuple(z*w[0] for z in w)
    orig=[canonical([dot(dual(x),y) for y in A]) for x in corevec]
    print('universal dirs',n,'original',len(set(orig)),'new',sum(w not in orig for w,c in cand))
    def rec(r,ps,xs):
        if not ps and not xs:yield r;return
        pivot=max(ps|xs,key=lambda x:len(ps&adj[x]))
        for a in sorted(ps-adj[pivot]):
            yield from rec(r+[a],ps&adj[a],xs&adj[a]);ps.remove(a);xs.add(a)
    from collections import Counter
    out=list(rec([],set(range(n)),set()))
    print('maximal cliques',Counter(map(len,out)))
    # Gram on exterior projection basis for the original frame: on E, K eigenvalues 16+2t;
    # on residual core space, all eigenvalues 16.
    h=red(keys[0][1],f)
    # The anchor type is 3, with W_aa reduced sign depending on normalization of its label.
    _,_,deck,_,_,_=load(2453);h=red(deck[3],f)
    e=times(times([1,8],inv(pol.deriv(gpoly(f)),f),f),inv(h,f),f)
    et=times([2,16],e,f)
    F0=[[trace(times(times(keys[i][1],keys[j][1],f),et,f),f) for j in EI]+[0]*5 for i in EI]+[[0]*5+[16*D[i][j] for j in BI] for i in BI]
    F0=matmul(matmul(matmul(A,V),F0),matmul(V,list(zip(*A))))
    from collections import defaultdict
    orders=defaultdict(list)
    def rank(M):
        b={}
        for row in M:
            q=list(map(F,row))
            for i,r in sorted(b.items()):
                a=q[i];q=[v-a*z for v,z in zip(q,r)]
            i=next((i for i,t in enumerate(q) if t),None)
            if i is not None:b[i]=[t/q[i] for t in q]
        return len(b)
    def det(A):
        A=[list(map(F,row)) for row in A];v=1
        for j in range(len(A)):
            r=next((i for i in range(j,len(A)) if A[i][j]),None)
            if r is None:return 0
            if r!=j:A[j],A[r]=A[r],A[j];v=-v
            t=A[j][j];v*=t
            for i in range(j+1,len(A)):
                z=A[i][j]/t
                if z:A[i]=[a-z*b for a,b in zip(A[i],A[j])]
        return v
    catalogue=json.loads((P.parent/'m13'/'parents.json').read_text())
    # Evaluation at a separating integer suffices to identify a spectrum among the complete parents.
    B=128
    vals={pol.val(q,B):j for j,q in enumerate(catalogue)}
    assert len(vals)==len(catalogue)
    freq=Counter();best=None;den=det(gram)*2**10*B**5
    for ix in out:
        if len(ix)<10:continue
        M=[[F0[i][j]-16*gram[i][j]+sum(cand[a][0][i]*cand[a][0][j] for a in ix)-sum(w[i]*w[j] for w in orig) for j in range(10)] for i in range(10)]
        m=18-rank(M)
        orders[len(ix),m].append(ix)
        if m==13:
            num=det([[2*B*gram[i][j]-M[i][j] for j in range(10)] for i in range(10)])
            parent=vals.get(num/den,-1);freq[parent]+=1
            if parent==2588:
                kept=sum(cand[a][0] in orig for a in ix)
                if best is None or kept>best[0]:
                    add=[a for a in ix if cand[a][0] not in orig]
                    removed=[j for j,w in enumerate(orig) if w not in [cand[a][0] for a in ix]]
                    new=[tuple(dot(cand[a][1],v) for v in zip(*A)) for a in add]
                    best=kept,removed,new
    print('count and multiplicity',[(z,len(t)) for z,t in orders.items()])
    print('swapped parent indices',freq,'best kept',best[0],best[1])
    (P/'swap_witness.json').write_text(json.dumps(dict(EI=EI,BI=BI,remove=best[1],inner_products=[[str(v) for v in r] for r in best[2]]),indent=1))
    return N,T,W,cand,orig,orders
if __name__=='__main__':main()

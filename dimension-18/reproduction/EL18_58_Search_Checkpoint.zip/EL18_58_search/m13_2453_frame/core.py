"""Core of ten forced signs and every projection of an exterior line on its span."""
from model import *
from itertools import product
from math import lcm
def piv(A):
    M=[list(map(F,r)) for r in A];I=[]
    for i,r in enumerate(M):
        if r[i]<0 or (not r[i] and any(r[i:])):return None
        if r[i]:
            I.append(i)
            for j in range(i+1,len(r)):
                z=M[j][i]/r[i]
                M[j]=[a-z*b for a,b in zip(M[j],r)]
    return I
def inverse(A):
    M=[list(map(F,r))+[F(i==j) for j in range(len(A))] for i,r in enumerate(A)]
    for i in range(len(M)):
        M[i]=[z/M[i][i] for z in M[i]]
        for j in range(len(M)):
            if j!=i:M[j]=[a-M[j][i]*b for a,b in zip(M[j],M[i])]
    return [r[len(M):] for r in M]
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def core():
    f,keys,N,R,sign,L=data()
    T=[4,5,13,14]+[11]*3+[12]*3
    # For each triplet the sum of residuals has norm squared 3/2 and inner
    # product -3/2 with each type-13,14 residual, so both equal its negative.
    for a in [11,12]:
        assert sign[a,a]==[1] and 3*(5-L[a,a])+6*(1-L[a,a])==F(3,2)
        for b in [13,14]:
            assert sign[a,b]==[1] and 5-L[b,b]==F(3,2) and 3*(1-L[a,b])==-F(3,2)
    assert F(3,2)+L[13,14]==1
    assert 3*(1-L[11,12])==L[11,13]-1
    def entry(i,j):
        a,b=T[i],T[j]
        if i==j:return 5
        if {a,b} in ({11,12},{13,14}):return 1
        v,=sign[a,b];return v
    K=[[entry(i,j) for j in range(10)] for i in range(10)]
    D=[[z-L[a,b] for z,b in zip(r,T)] for r,a in zip(K,T)]
    BI=piv(D);I=piv(K)
    invD=inverse([[D[i][j] for j in BI] for i in BI])
    invK=inverse([[K[i][j] for j in I] for i in I])
    words={}
    for a in range(len(N)):
        if a in T:continue
        words[a]=[]
        for s in product(*(sign[a,b] for b in T)):
            dx=[v-L[a,b] for v,b in zip(s,T)];coef=[dot(row,[dx[i] for i in BI]) for row in invD]
            if any(dot([r[i] for i in BI],coef)!=v for r,v in zip(D,dx)):continue
            norm=dot(coef,[dx[i] for i in BI])
            if norm>5-L[a,a]:continue
            words[a].append((s,5-L[a,a]-norm))
    return N,T,K,D,I,invK,BI,words
if __name__=='__main__':
    from collections import Counter
    N,T,K,D,I,V,B,W=core()
    print('core',I,B)
    for k,q in W.items():print(k,N[k],len(q),Counter(z for s,z in q))

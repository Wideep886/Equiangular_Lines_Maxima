"""Check the three replacements directly and prove the new characteristic polynomial."""
from core import *
def det(A):
    A=[list(map(F,r)) for r in A];z=F(1)
    for i in range(len(A)):
        j=next((j for j in range(i,len(A)) if A[j][i]),None)
        if j is None:return 0
        if i!=j:A[i],A[j]=A[j],A[i];z=-z
        t=A[i][i];z*=t
        for j in range(i+1,len(A)):
            a=A[j][i]/t
            if a:A[j]=[u-a*v for u,v in zip(A[j],A[i])]
    return z
def main():
    w=json.loads((P/'swap_witness.json').read_text())
    N,T,K,D,I,invK,B,W=core()
    f,keys,N,R,sign,L=data()
    E=w['EI'];B=w['BI']
    G=[[L[a,b] for b in E]+[0]*5 for a in E]+[[0]*5+[D[a][b] for b in B] for a in B]
    assert piv(G)==list(range(10))
    Gi=inverse(G)
    def ip(x,y):return sum(dot(r,y)*z for r,z in zip(Gi,x))
    def words(t,s):return tuple([L[t,c] for c in E]+[s[j]-L[t,T[j]] for j in B])
    Z=[tuple(map(F,q)) for q in w['inner_products']]
    old=[words(a,s) for a,s in zip(T,K)]
    rm=w['remove'];assert len(set(rm))==len(Z)==3
    for i,z in enumerate(Z):
        assert ip(z,z)==5 and all(abs(ip(z,t))==1 for t in Z[:i])
        assert all(abs(ip(z,q))==1 for j,q in enumerate(old) if j not in rm)
        assert all(abs(ip(z,words(a,s)))==1 for a,Q in W.items() for s,_ in Q)
    # Matrix entries of the original frame on this basis. Cross terms vanish
    # because the core residual basis belongs to the eigenvalue 16 space.
    _,_,d,_,_,_=load(2453)
    h=red(d[3],f);dg=pol.deriv(gpoly(f))
    fac=times(times([2,16],times([1,8],inv(dg,f),f),f),inv(h,f),f)
    M=[[trace(times(fac,times(R[i],R[j],f),f),f) for j in E]+[0]*5 for i in E]+[[0]*5+[16*D[i][j] for j in B] for i in B]
    catalogue=json.loads((P.parent/'m13'/'parents.json').read_text())
    for parent,added,removed in [(2453,[],[]),(2588,Z,[old[j] for j in rm])]:
        A=[[a+sum(x[i]*x[j] for x in added)-sum(x[i]*x[j] for x in removed) for j,a in enumerate(r)] for i,r in enumerate(M)]
        for y in range(-6,5): # eleven distinct points suffice for degree ten
            test=[[(16+2*y)*G[i][j]-A[i][j] for j in range(10)] for i in range(10)]
            assert det(test)==det(G)*2**10*y**5*pol.val(catalogue[parent],y)
    assert pol.val(catalogue[2588],-8)!=0
    print('Three-for-three exchange verified; 55 lines retained; new m=13 parent 2588.')
if __name__=='__main__':main()

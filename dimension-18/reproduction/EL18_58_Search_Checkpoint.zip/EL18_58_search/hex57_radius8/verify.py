from pathlib import Path
import json,sys,subprocess,tempfile,os
from fractions import Fraction as F
from math import lcm
from functools import reduce
from collections import Counter
from full_bound import bound
HERE=Path(__file__).resolve().parent
def rref(A):
    v=[[F(x) for x in r] for r in A];i=0
    for j in range(len(v[0])):
        k=next((k for k in range(i,len(v)) if v[k][j]),None)
        if k is None:continue
        v[i],v[k]=v[k],v[i]
        d=v[i][j];v[i]=[x/d for x in v[i]]
        for k,row in enumerate(v):
            if k!=i and row[j]:v[k]=[x-row[j]*y for x,y in zip(row,v[i])]
        i+=1
        if i==len(v):break
    return v[:i]

def emit(G,B,path):
 Q=rref([[G[i][j]for j in B]+[int(i==j)for j in B] for i in B])
 Q=[r[18:]for r in Q]
 D=reduce(lcm,(x.denominator for r in Q for x in r),1);A=[[int(x*D)for x in r]for r in Q]
 assert all(sum(G[i][k]*A[l][t] for l,k in enumerate(B))==D*(j==t) for j,i in enumerate(B) for t in range(18))
 mat=[[sum(r[t]*G[B[t]][j]for t in range(18))for j in range(57)]+r for r in A]
 assert max(abs(x)for r in mat for x in r)*36*36<2**62 and 5*D<2**62
 with path.open('w')as f:
  print(*B,D,file=f)
  for r in mat:print(*r,file=f)
 return mat

def graph(K,P):
 t=[list(map(int,l.split()))for l in (P/'bases/b0000').read_text().splitlines()]
 *b,D=t[0];Q=[r[57:]for r in t[1:]]
 raw=[list(map(int,l.split()))for l in (P/('extras%d.txt'%K)).read_text().splitlines()];R=[]
 for d,*r in raw:
  m=sum((abs(v)!=d)<<i for i,v in enumerate(r));v=[r[i]for i in b];q=[sum(x*y for x,y in zip(row,v))for row in Q];assert sum(x*y for x,y in zip(v,q))==5*D*d*d
  R.append((m,v,q,d))
 R.sort(key=lambda a:(bin(a[0]).count('1'),a[0],a[1]))
 with (P/('graph%d.txt'%K)).open('w')as f:
  print(len(R),file=f)
  for i,(m,v,q,d) in enumerate(R):
   edges=[j for j,(n,w,s,e) in enumerate(R) if i!=j and abs(sum(x*y for x,y in zip(v,s)))==D*d*e]
   print(m,len(edges),*edges,file=f)
 print('budget',K,'extras by mismatch count',dict(sorted(Counter(bin(x[0]).count('1')for x in R).items())),flush=True)

def main():
 K=int(sys.argv[1]) if len(sys.argv)>1 else max(int(p.stem[5:])for p in HERE.glob('bases*.json'))
 G=json.loads((HERE/'G.json').read_text())
 assert len(G)==57 and all(len(r)==57 for r in G)
 assert all(G[i][j]==G[j][i] and (G[i][j]==5 if i==j else abs(G[i][j])==1)for i in range(57)for j in range(57))
 B=json.loads((HERE/('bases%d.json'%K)).read_text())
 with tempfile.TemporaryDirectory()as folder:
  P=Path(folder);(P/'bases').mkdir();names=[]
  for i,b in enumerate(B):
   assert len(b)==len(set(b))==18 and all(0<=u<57 for u in b)
   p=P/'bases'/('b%04d'%i);mat=emit(G,b,p);names.append(str(p))
   if i==0:
    d=int(p.read_text().splitlines()[0].split()[-1])
    assert all(sum(G[u][k]*mat[j][v]for j,k in enumerate(b))==d*G[u][v] for u in range(57)for v in range(57))
    # Exact leading principal pivots of the basis check positive definiteness.
    a=[[F(G[u][v])for v in b]for u in b]
    for k in range(18):
     assert a[k][k]>0
     for j in range(k+1,18):
      t=a[j][k]/a[k][k];a[j]=[c-t*x for c,x in zip(a[j],a[k])]
  for f in ['hitting','enumerate']:
   subprocess.run([os.environ.get('CXX','c++'),'-O3','-std=c++17',str(HERE/(f+'.cpp')),'-o',str(P/f)],check=True)
  masks=[sum(1<<v for v in b)for b in B]
  input_data=' '.join(map(str,[57,K,len(B),*masks]))+'\n'
  assert subprocess.check_output([str(P/'hitting')],text=True,input=input_data).strip()=='NO'
  print('Every deletion set of size at most',K,'avoids at least one certified basis, using',len(B),'bases.',flush=True)
  with (P/('extras%d.txt'%K)).open('w')as f:
   subprocess.run([str(P/'enumerate'),str(K),*names],stdout=f,check=True)
  graph(K,P)
  bound(P/('graph%d.txt'%K))
if __name__=='__main__':main()

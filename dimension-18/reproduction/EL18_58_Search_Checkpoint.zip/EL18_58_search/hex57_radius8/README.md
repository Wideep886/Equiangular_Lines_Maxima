# Eight-line replacement search around the order-three 57-line witness

A 58-line equiangular system in dimension 18 can share at most **48 of the 57 rays** represented by `G.json`. Deleting any zero to eight original lines and replacing them by enough new ones to reach 58 has no solution. All rays have squared norm 5; distinct representatives have inner products \(\pm1\).

## Coverage

For each of 430 independent 18-element subsets \(B\) in `bases8.json`, the verifier checks the inverse of the Gram minor \(G_B\). A symmetric positive-definite basis and reconstruction of all entries check the input Gram. The hitting-set verifier proves that no eight-element deletion set meets all 430 bases. At a search node it chooses an unhit basis and branches over each remaining way to meet it. Once the branch tries a vertex, the following sibling branches exclude that vertex. All smaller deletion sets are covered as well.

## Exact candidate enumeration

Given such a retained \(B\), every new line has sign vector \(s\in\{\pm1\}^{18}\) of inner products with \(B\). A global sign sets its last entry to \(+1\). Since \(B\) spans the ambient space, its squared norm and its products with the 57 source lines are uniquely given by
\[
 s^\top G_B^{-1}s,\qquad s^\top G_B^{-1}G_{B,:}.
\]
The program enumerates all \(2^{17}\) possibilities per basis, retains norm 5 and counts original lines failing the absolute-product test. A compatible extension after deletion of at most eight points has at most eight such failures. Coincidence with an original ray is tested by absolute inner product 5 and excluded from the extra pool. Integer-normalized full product vectors deduplicate all projectively equal rays. Across all bases the numbers of new rays with 1, 2, 3 and 4 failures are 12, 45, 219 and 3, respectively. No additional candidates have 0 or 5 through 8 failures.

## Global bound on the finite candidate pool

For any two candidates their products against the first basis determine their mutual inner product through \(G_B^{-1}\). Connect two candidates exactly when their absolute inner product differs from 1. Adjoin the 57 original rays to this conflict graph. Its four connected components have sizes \(216,40,40,40\). The large component has 108 detected conflict cliques of size six; 36 disjoint six-cliques cover it, so at most 36 lines in it can coexist. A take-or-delete recursion computes independence number 7 for each of the three smaller components. The resulting bound \(36+3\cdot7=57\) is attained by the original input.

## Reproduction

Run `python3 verify.py` with assertions enabled, standard Python 3.9+ and a C++17 compiler. All source, the 57-line input, and the basis cover are included. The verifier recompiles both search programs in a temporary directory. The separate `bases7.json` permits a faster independent check with `python3 verify.py 7`. The two searches produce the same 279 extras. The notes and certificate concern the supplied 57-line switching class.

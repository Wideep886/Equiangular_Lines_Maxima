#include<cstdint>
#include<vector>
#include<algorithm>
#include<cstdio>
#include<cassert>
using namespace std;
using Word=uint64_t;
bool solve(const vector<Word>& rows,Word allowed,int d,Word& answer){
 if(rows.empty())return true;
 if(!d)return false;
 int smallest=65;Word R=0;
 for(auto row:rows){
     Word opts=row&allowed;int n=__builtin_popcountll(opts);
     if(!n)return false;
     if(n<smallest){R=opts;smallest=n;}
 }
 if(d==1){
     Word all=allowed;for(auto row:rows)all&=row;
     if(all){answer|=all&-all;return true;}return false;
 }
 vector<pair<int,int>> choices;
 for(Word r=R;r;r&=r-1){
  int i=__builtin_ctzll(r);Word bit=Word(1)<<i;int count=0;
  for(auto row:rows)count+=bool(row&bit);
  choices.push_back({-count,i});
 }
 sort(choices.begin(),choices.end());
 for(auto [used,i]:choices){
  Word bit=Word(1)<<i;allowed^=bit;
  vector<Word> next;next.reserve(rows.size()+used);
  for(auto row:rows)if(!(row&bit))next.push_back(row);
  if(solve(next,allowed,d-1,answer)){answer|=bit;return true;}
 }
 return false;
}
int main(){int n,d,m;while(scanf("%d%d%d",&n,&d,&m)==3){vector<Word>rows(m);for(auto&v:rows){unsigned long long z;scanf("%llu",&z);v=z;}Word ret=0;bool ok=solve(rows,(Word(1)<<n)-1,d,ret);if(ok)printf("%llu\n",(unsigned long long)ret);else puts("NO");fflush(stdout);}}

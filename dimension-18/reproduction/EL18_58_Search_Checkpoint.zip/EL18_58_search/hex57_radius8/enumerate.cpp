#include <iostream>
#include <cstdio>
#include <fstream>
#include <vector>
#include <set>
#include <cstdint>
#include <array>
#include <algorithm>
#include <numeric>
using namespace std;
using num=long long;
using mask=uint64_t;
vector<mask> bs;
set<vector<num>> opts;

int K;
int main(int argc,char**argv){
  K=atoi(argv[1]);
  for (int f=2;f<argc;f++){
    ifstream in(argv[f]); if(!in)return 1;
    mask bm=0;for(int i=0,a;i<18;i++){in>>a;bm|=1ULL<<a;} bs.push_back(bm);
    num den,V[18][75];in>>den; for(auto &row:V)for(auto &x:row)in>>x;
    int s[18];num inv_s[18]={}; fill(s,s+18,1);
    for(int j=0;j<18;j++)for(int i=0;i<18;i++)inv_s[j]+=V[i][57+j];
    num norm=accumulate(inv_s,inv_s+18,0LL);
    for(unsigned t=0;t<(1u<<17);t++){
       if(norm==5*den){
          num dots[57]={};int bad=0; bool orig=false;
          for(int j=0;j<57;j++){
             for(int i=0;i<18;i++)dots[j]+=s[i]*V[i][j];
             if(abs(dots[j])==5*den){orig=true;break;}
             bad+=abs(dots[j])!=den; if(bad>K)break;
          }
          if(!orig&&bad<=K){
             num v=den;for(auto x:dots)v=gcd(v,x);vector<num> key{den/v};
             int sign=1;for(auto x:dots)if(x){sign=(x>0?1:-1);break;}
             for(auto x:dots)key.push_back(sign*x/v); opts.insert(key);
          }
       }
       if(t+1==(1u<<17))break;
       int b=__builtin_ctz(t+1), u=s[b]; norm+=-4*u*inv_s[b]+4*V[b][57+b];
       for(int j=0;j<18;j++)inv_s[j]-=2*u*V[b][57+j];s[b]=-u;
    }
  }
  for(auto &key:opts){for(auto x:key)cout<<x<<" ";cout<<"\n";}
  cerr<<"bases "<<bs.size()<<" candidate extras "<<opts.size()<<"\n";
}

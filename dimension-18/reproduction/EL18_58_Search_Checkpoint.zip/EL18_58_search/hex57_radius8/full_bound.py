from pathlib import Path
import sys
P=Path(__file__).resolve().parent
def vertices(mask):
 while mask:
  b=mask&-mask;mask^=b;yield b.bit_length()-1
def components(graph,mask):
 out=[]
 while mask:
  q=mask&-mask;mask^=q;C=q
  while q:
   b=q&-q;q^=b;z=graph[b.bit_length()-1]&mask;q|=z;C|=z;mask^=z
  out.append(C)
 return out
def bound(path):
 L=path.read_text().splitlines();n=int(L[0]);N=57+n;Q=[0]*57;F=(1<<n)-1
 for i,l in enumerate(L[1:]):
  m,k,*edges=map(int,l.split());assert len(edges)==k
  for j in vertices(m):Q[j]|=1<<(57+i)
  Q.append(m|(((F^(1<<i))^sum(1<<j for j in edges))<<57))
 assert len(Q)==N and all(Q[i]>>j&1==(Q[j]>>i&1) for i in range(N)for j in range(N))
 C=components(Q,(1<<N)-1);print('conflict components',list(map(lambda c:len(list(vertices(c))),C)),flush=True)
 count=lambda x:bin(x).count('1')
 maxima=[]
 for c in C:
  if count(c)<50:
   def maximum(P):
    if not P:return 0
    i=next(vertices(P));q=P^(1<<i)
    return max(maximum(q&~Q[i])+1,maximum(q))
   # A point belongs to each block and cross-block pairs are compatible.
   from functools import lru_cache
   maximum=lru_cache(None)(maximum)
   v=maximum(c);print('small maximum',v);maxima.append(v);continue
  assert count(c)==216
  subsets=set()
  for i in vertices(c):
   for j in vertices(Q[i]&c):
    T=(Q[i]&Q[j]&c)|(1<<i)|(1<<j)
    if count(T)==6 and all((T^(1<<u))&~Q[u]==0 for u in vertices(T)):
        subsets.add(T)
  # Complete conflict six-cliques partition the component.
  def cover(rem,sol):
   if rem==0:return sol
   good=[t for t in subsets if t&~rem==0]
   choices=min(([t for t in good if t>>i&1] for i in vertices(rem)),key=len)
   for t in choices:
    out=cover(rem^t,sol+[t])
    if out is not None:return out
   return None
  parts=cover(c,[]);assert len(parts)==36;maxima.append(36);print('large component',len(subsets),'six-cliques; disjoint cover',len(parts))
 assert sum(maxima)==57
 print('unrestricted maximum among the original points and all listed extra points is 57.')
if __name__=='__main__':bound(P/('graph%s.txt'%sys.argv[1]))

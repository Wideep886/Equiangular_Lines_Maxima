"""Simultaneous co-occurrence of signed type cells over the three simple fields."""
from signs import *
from functools import lru_cache
import time
refs=[next(j for j,h in enumerate(H) if any(rem(h,f))) for f in fs]
active=[tuple(j for j,z in enumerate((any(a),any(b),bool(c))) if z) for a,b,c in zip(V1,V2,V3)]
cells=[]
for i,js in enumerate(active):
    for signs in product((-1,1),repeat=len(js)-1):
        w=[0]*3
        for k,v in zip(js,(1,)+signs):w[k]=v
        cells.append((i,tuple(w)))
def options(i,j):
    ans=[]
    for q in Q[i][j]:
        vals=[]
        for f,v,k in zip(fs,(V1,V2),refs):
            d=rem(mul(v[i],v[j]),f);p=rem(mul(q,H[k]),f)
            if p==d:vals.append(int(any(d)))
            elif p==tuple(-z for z in d):vals.append(-1)
            else:raise ValueError((i,j,d,p))
        if V3[i]*V3[j]:
            z=val(q,1)//(5*V3[i]*V3[j]);assert abs(z)==1
        else:z=0;assert val(q,1)==0
        vals.append(z);ans.append(tuple(vals))
    return ans
tags={(i,j):options(i,j) for i in range(len(H)) for j in range(len(H))}
ok=[]
for i,a in cells:
 r=0
 for j0,(j,b) in enumerate(cells):
    if any(all(u==s*v*w for u,v,w in zip(o,a,b)) for o in tags[i,j] for s in (-1,1)):r|=1<<j0
 ok.append(r)
@lru_cache(None)
def occupancy(i,n,r,s,t):
 if not n:return 0
 vals={(0,1):r,(0,2):s,(1,2):t}
 used=0
 for c,(j,w) in enumerate(cells):
    if j!=i:continue
    d=n+sum(x*w[a]*w[b] for (a,b),x in vals.items() if x is not None)
    div=2**(len(active[i])-1)
    if d<0 or d%div:return -1
    cnt=d//div
    if cnt:
        if cnt>=2 and not (ok[c]>>c&1):return -1
        used|=1<<c
 return used
@lru_cache(None)
def bad(x):
 m=0
 while x:
    b=x&-x;m|=~(ok[b.bit_length()-1]|b);x^=b
 return m
def main():
 out=[]
 for d in pops:
    sols=[vectors(c,d) for c in channels]
    keep=[];tested=0
    for r in sols[0]:
      for s in sols[1]:
       for t in sols[2]:
        sup=0
        for i,n in enumerate(d):
            w=occupancy(i,n,r[i],s[i],t[i])
            if w<0 or bad(w)&(sup|w):break
            sup|=w
        else:keep.append((r,s,t))
    print(d,len(keep),flush=True)
    out.append(dict(deck=d,orientations=len(keep),survivors=keep))
    (HERE/'oriented.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':main()

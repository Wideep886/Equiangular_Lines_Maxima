"""Joint sign counts between the two quadratic conjugate pairs and the simple integer root."""
from pathlib import Path
import sys,json
from itertools import product
from collections import Counter
HERE=Path(__file__).resolve().parent
J=HERE.parent/'m13_joint'
sys.path.insert(0,str(J));from decorate import rem, mul
D=json.loads((J/'input_2087.json').read_text())
H,Q=D['deck'],D['pairs']
pops=json.loads((J/'fixed_2087.json').read_text())['survivors']
fs=((1,1,-4),(1,-1,-5))
def val(q,z):
    s=0
    for x in q:s=s*z+x
    return s
def coeffs(f):
    j=next(j for j,h in enumerate(H) if any(rem(h,f)))
    V=[]
    for i,h in enumerate(H):
        prod=rem(mul(h,H[j]),f)
        if not any(prod):V.append((0,0));continue
        w=rem(Q[i][j][0],f)
        assert rem(mul(w,w),f)==prod
        V.append(w)
    return V
V1,V2=(coeffs(f) for f in fs)
V3=[int({0:0,5:1,20:2}[val(h,1)]) for h in H]
channels=[[(u[0]*v[0],u[0]*v[1],u[1]*v[0],u[1]*v[1]) for u,v in zip(V1,V2)],
          [tuple(a*z for a in u) for u,z in zip(V1,V3)],
          [tuple(a*z for a in u) for u,z in zip(V2,V3)]]
def vectors(C,counts):
    ids=[i for i,(v,n) in enumerate(zip(C,counts)) if any(v) and n]
    ids.sort(key=lambda i:-counts[i])
    groups=[[],[]];tot=[1,1]
    for i in ids:
        k=int(tot[0]>tot[1]);groups[k].append(i);tot[k]*=counts[i]+1
    def halves(g,neg):
        def f(k,v,word):
            if k==len(g):
                yield tuple(v),tuple(word);return
            i=g[k]
            for s in range(-counts[i],counts[i]+1,2):
                yield from f(k+1,[q+neg*s*y for q,y in zip(v,C[i])],word+[s])
        yield from f(0,[0]*len(C[0]),[])
    classes={}
    for v,t in halves(groups[0],1):classes.setdefault(v,[]).append(t)
    results=[]
    for v,t in halves(groups[1],-1):
        for s in classes.get(v,[]):
            w=[None]*len(counts)
            for i,x in zip(groups[0]+groups[1],s+t):w[i]=x
            results.append(w)
    return results
def compatible(n,r,s,t):
    if None in (r,s,t):return True
    return all((v:=n+a*r+b*s+a*b*t)>=0 and v%4==0
               for a,b in product((1,-1),repeat=2))
def main():
    rows=[]
    for d in pops:
        sol=[vectors(c,d) for c in channels]
        n=0;first=None
        for r in sol[0]:
            for s in sol[1]:
                for t in sol[2]:
                    if all(compatible(*v) for v in zip(d,r,s,t)):
                        first=(r,s,t);n=1;break
                if n:break
            if n:break
        print(d,[len(z) for z in sol],n,flush=True)
        rows.append(dict(deck=d,separate=[len(z) for z in sol],open=bool(n),example=first))
        (HERE/'signs.json').write_text(json.dumps(rows,separators=(',',':')))
if __name__=='__main__':main()

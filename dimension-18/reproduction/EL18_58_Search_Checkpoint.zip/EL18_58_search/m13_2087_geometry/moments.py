"""Use orthogonality of the multiplicity-13 projector to five simple eigenvectors."""
from cellrows import *
from decorate import coefficient_gram,gram_column
from fractions import Fraction as F
G=D['minimal']
def vals(v):return tuple(gram_column(v))
def opt(a,b):
 i,u=cells[a];j,w=cells[b]
 return [(s,q) for z,q in zip(tags[i,j],Q[i][j]) for s in (-1,1) if all(v==s*h*k for v,h,k in zip(z,u,w))]
cols={}
for a in range(len(cells)):
 for b in range(len(cells)):
    v=vec[b][0]
    cols[a,b]=set(tuple(s*t for t in v)+tuple(s*q[-1]*t for t in v)+vals(q) for s,q in opt(a,b))
def check(a,pop):
 i=cells[a][0];vv,ss=vec[a]
 t=list(ss)+[-H[i][-1]*x for x in vv]+list(coefficient_gram(G,H[i],H[i],H[i],True))
 C=[];upper=[]
 for b,n in enumerate(pop):
    n-=int(a==b)
    if not n:continue
    pool=sorted(cols[a,b]);base=pool[0];t=[x-n*y for x,y in zip(t,base)]
    for alt in pool[1:]:
        C.append([x-y for x,y in zip(alt,base)]);upper.append(n)
 # Omitting the per-cell sum bound only enlarges the feasible set.
 return bool(feasible_counts(C,t,upper,first_only=True)) if C else not any(t)
def main():
 res=[]
 for row in json.loads((HERE/'rows.json').read_text()):
    keep=[]
    for pop in row['cell_populations']:
        if all(check(a,pop) for a,n in enumerate(pop) if n):keep.append(pop)
    res.append(dict(deck=row['deck'],cell_populations=keep))
    print(len(res),len(keep),flush=True)
    (HERE/'moments.json').write_text(json.dumps(res,separators=(',',':')))
if __name__=='__main__':main()

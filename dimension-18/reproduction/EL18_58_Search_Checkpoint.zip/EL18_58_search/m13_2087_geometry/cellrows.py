from coherent import *
from decorate import feasible_counts
def cellcount(i,n,s1,s2,s3,w):
    return (n+sum(x*w[a]*w[b] for x,(a,b) in zip((s1,s2,s3),((0,1),(0,2),(1,2))) if x is not None))//(2**(len(active[i])-1))
def form(i,w):
    a,b,c=w
    v=(*[a*z for z in V1[i]],*[b*z for z in V2[i]],c*V3[i])
    e=(*[a*z for z in rem(mul(V1[i],(2,11)),fs[0])],
       *[b*z for z in rem(mul(V2[i],(2,11)),fs[1])],13*c*V3[i])
    return v,e
vec=[form(i,w) for i,w in cells]
bounds={}
for a,(i,u) in enumerate(cells):
 for b,(j,v) in enumerate(cells):
    bounds[a,b]=[s for s in (-1,1) if any(all(z==s*h*k for z,h,k in zip(q,u,v)) for q in tags[i,j])]
def filterrow(pop,a):
    i,_=cells[a]
    tar=list(vec[a][1]);cols=[];ns=[]
    for b,n in enumerate(pop):
        n-=int(a==b)
        if not n:continue
        signs=bounds[a,b];assert signs
        v=vec[b][0]
        tar=[x-n*signs[0]*y for x,y in zip(tar,v)]
        if len(signs)==2:
            cols.append([2*y for y in v]);ns.append(n)
    return bool(feasible_counts(cols,tar,ns,first_only=True)) if cols else not any(tar)
def main():
    out=[]
    for row in json.loads((HERE/'oriented.json').read_text()):
        d=row['deck'];kept=[]
        for r,s,t in row['survivors']:
            pop=[cellcount(i,d[i],r[i],s[i],t[i],w) for i,w in cells]
            assert sum(pop)==58
            if all(filterrow(pop,a) for a,n in enumerate(pop) if n):kept.append(pop)
        out.append(dict(deck=d,cell_populations=kept))
        print(d,len(kept),flush=True)
        (HERE/'rows.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':main()

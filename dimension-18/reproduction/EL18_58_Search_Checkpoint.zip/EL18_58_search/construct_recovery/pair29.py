"""Branch on the second direction in the first unresolved root of graph 29."""
from branch164 import peel
from components_all import P,REF,coord
from pathlib import Path
import tempfile,json,subprocess
if __name__=='__main__':
    G=json.loads((REF/'search_runs/progress.json').read_text())['runs'][29]['gram']
    previous=json.loads((P/'root29.json').read_text())
    first=next(v for v,status,_ in previous if status==-1)
    with tempfile.TemporaryDirectory() as d:
        tmp=Path(d)
        for name in ('basis_candidates','exact_clique'):
            subprocess.run(['c++','-O3','-std=c++17',str(REF/(name+'.cpp')),'-o',str(tmp/name)],check=True)
        A=coord(G,tmp/'basis_candidates')
        group=next(V for v,V in peel(A,list(range(len(A))),40) if v==first)
        rows=[]
        for v,V in peel(A,group,39):
            assert len(V)<=256
            f=tmp/'graph';f.write_text(f'{len(V)} 38\n'+'\n'.join(''.join('1' if j in A[i] else '0' for j in V) for i in V))
            q=subprocess.check_output([tmp/'exact_clique',f,'100000'],text=True).split()
            status,n=map(int,q[1:3]);rows.append([v,status,n])
            if status==1:
                chosen=[first,v]+[V[int(k)] for k in q[3:]]
                assert len(chosen)==40 and all(y in A[x] for j,x in enumerate(chosen) for y in chosen[:j])
                rows[-1].append(chosen);break
        result={'round':29,'first':first,'second':rows}
        f=P/'pair29.json'
        if f.exists():assert result==json.loads(f.read_text())
        else:f.write_text(json.dumps(result))
        print(first,len(rows),{k:sum(r[1]==k for r in rows) for k in (-1,0,1)})

// Fractional clique-cover relaxation. Python verifies every pruning bound with integers.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <numeric>
#include <vector>
using namespace std;
int main() {
    int n,m;
    while(cin>>n>>m){
        vector<vector<double>> a(m+1,vector<double>(n+1));
        vector<int> row(m),col(n);
        iota(col.begin(),col.end(),0);
        for(int i=0;i<m;i++){
            int size;cin>>size;
            while(size--){int j;cin>>j;a[i][j]=1;}
            a[i][n]=1;row[i]=n+i;
        }
        fill(a[m].begin(),a[m].end()-1,-1.0);
        for(int t=0;t<3000;t++){
            int e=min_element(a[m].begin(),a[m].end()-1)-a[m].begin();
            if(a[m][e]>-1e-8)break;
            int s=-1;double ratio=0;
            for(int i=0;i<m;i++)if(a[i][e]>1e-8){
                double r=a[i][n]/a[i][e];
                if(s<0||r<ratio-1e-9||(abs(r-ratio)<1e-9&&row[i]<row[s])){ratio=r;s=i;}
            }
            if(s<0)return 2;
            double p=a[s][e];
            for(double& v:a[s])v/=p;
            a[s][e]=1/p;
            for(int i=0;i<=m;i++)if(i!=s){
                double d=a[i][e];
                if(abs(d)<1e-10){a[i][e]=0;continue;}
                for(int j=0;j<=n;j++)a[i][j]-=d*a[s][j];
                a[i][e]=-d/p;
            }
            swap(row[s],col[e]);
        }
        vector<double>x(n),y(m);
        for(int i=0;i<m;i++)if(row[i]<n)x[row[i]]=a[i][n];
        for(int j=0;j<n;j++)if(col[j]>=n)y[col[j]-n]=a[m][j];
        for(double v:x)cout<<llround(v*1000000)<<' ';cout<<'\n';
        for(double v:y)cout<<max(0ll,llround(v*1000000))<<' ';cout<<'\n'<<flush;
    }
}

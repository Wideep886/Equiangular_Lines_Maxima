"""Complete the remaining first-vertex cases for graph 164 by peeling a second time."""
from components_all import *
from concurrent.futures import ThreadPoolExecutor
def peel(A,V,need):
    live=set(V)
    while live:
        v=min(live,key=lambda u:(len(live&A[u]),u));live.remove(v)
        after=sorted(live&A[v])
        if len(after)>=need-1:yield v,after
def main():
    G=json.loads((REF/'search_runs/progress.json').read_text())['runs'][164]['gram']
    rec=json.loads((P/'near164.json').read_text());assert len(rec)==1
    unresolved={v for v,status,_ in rec[0][2] if status==-1}
    with tempfile.TemporaryDirectory() as d:
        tmp=Path(d)
        for name in ('basis_candidates','exact_clique'):
            subprocess.run(['c++','-O3','-std=c++17',str(REF/(name+'.cpp')),'-o',str(tmp/name)],check=True)
        A=coord(G,tmp/'basis_candidates');V=components(A);assert len(V)==1
        def go(q):
            first,group=q;records=[]
            for v,left in peel(A,group,39):
                file=tmp/f'g{first}';file.write_text(f'{len(left)} 38\n'+'\n'.join(''.join('1'if y in A[x] else '0'for y in left) for x in left))
                sol=subprocess.check_output([tmp/'exact_clique',file,'100000'],text=True).split()
                ret,n=map(int,sol[1:3]);records.append([v,ret,n])
                if ret==1:break
            return [first,records]
        with ThreadPoolExecutor(3) as pool:out=list(pool.map(go,[(v,k) for v,k in peel(A,V[0],40) if v in unresolved]))
        assert {v for v,k in out}==unresolved
        p=P/'branch164.json'
        if p.exists():assert out==json.loads(p.read_text())
        else:p.write_text(json.dumps(out,separators=(',',':')))
        print(len(out),sum(len(r) for v,r in out),{k:sum(s==k for v,r in out for _,s,_ in r)for k in [-1,0,1]})
if __name__=='__main__':main()

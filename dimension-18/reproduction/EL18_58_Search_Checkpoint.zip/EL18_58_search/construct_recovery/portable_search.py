"""Build a portable sampler matching the saved Linux mt19937 search trajectory."""
from pathlib import Path
import subprocess,sys
P=Path(__file__).resolve().parent
source=(P.parent/'orbit_construction/orbit_search.cpp').read_text()
source=source.replace('int pick(','''
uint32_t draw(mt19937 &engine, uint32_t n) {
    uint64_t prod = uint64_t(engine()) * n;
    if (uint32_t(prod) < n) {
        const uint32_t threshold = uint32_t(-n) % n;
        while (uint32_t(prod) < threshold) prod = uint64_t(engine()) * n;
    }
    return uint32_t(prod >> 32);
}
void permute(vector<Id> &v, mt19937 &engine) {
    unsigned n = v.size();
    if (n < 2) return;
    unsigned i = 1;
    if (n % 2 == 0) {swap(v[i],v[draw(engine,2)]);++i;}
    while (i<n) {
        unsigned k = i+1;
        unsigned r = draw(engine,k*(k+1));
        swap(v[i],v[r/(k+1)]);
        swap(v[i+1],v[r%(k+1)]);
        i += 2;
    }
}
int pick(''').replace('uniform_int_distribution<int> dist(0,n-1);','').replace('dist(rng)','draw(rng,n)').replace('shuffle(previous.begin(),previous.end(),rng)','permute(previous,rng)')
dest=Path(sys.argv[1]).resolve();dest.mkdir(exist_ok=True,parents=True)
(dest/'portable.cpp').write_text(source)
subprocess.run(['c++','-std=c++17','-O3',str(dest/'portable.cpp'),'-o',str(dest/'orbit_search')],check=True)

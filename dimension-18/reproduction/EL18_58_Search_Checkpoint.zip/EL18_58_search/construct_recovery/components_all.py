"""Cover construction graphs by irreducible components of the incompatibility relation."""
from pathlib import Path
import json,sys,subprocess,tempfile,os
from component144 import REF,basis_inverse,maximal
P=Path(__file__).resolve().parent
def components(A):
    unseen=set(range(len(A)));out=[]
    while unseen:
        reached=set();X={min(unseen)}
        while X:
            unseen-=X;reached|=X;X={w for v in X for w in unseen if w not in A[v]}
        out.append(sorted(reached))
    return sorted(out,key=lambda v:(len(v),v))
def tiny_max(V,A):
    best=[]
    def visit(X,r):
        nonlocal best
        if len(r)>len(best):best=r
        while len(X)+len(r)>len(best):
            v=min(X,key=lambda v:(-len(A[v]&X),v));X.remove(v)
            visit(X&A[v],r+[v])
    visit(set(V),[]);return len(best)
def coord(g,exe):
    Q,d=basis_inverse(g)
    masks=sorted(map(int,subprocess.check_output([exe],input=str(d)+'\n'+'\n'.join(' '.join(map(str,row)) for row in Q),text=True).split()))
    signs=[[1]+[1-2*(m>>j&1)for j in range(17)]for m in masks]
    imgs=[[sum(a*b for a,b in zip(q,s))for q in Q]for s in signs]
    return [{j for j,s in enumerate(signs)if abs(sum(a*b for a,b in zip(q,s)))==d} for q in imgs]
def get(A,lp,verify):
    out=[]
    for k,V in enumerate(components(A)):
        if len(V)<=55:
            count=tiny_max(V,A)
            out.append([len(V),count]);continue
        record=verify[k] if verify else None;S=set(V)
        if record and len(record)>2 and record[2]=='greedy' or not verify and sum(len(S-A[v])-1 for v in V)>24*len(V):
            colors=[]
            for v in sorted(V,key=lambda v:(-len(S&A[v]),v)):
                for g in colors:
                    if not g&A[v]:g.add(v);break
                else:colors.append({v})
            out.append([len(V),len(colors),'greedy']);continue
        G=maximal([{i for i,w in enumerate(V) if w!=v and w not in A[v]} for v in V])
        if record:weights=record[2]
        else:
            lp.stdin.write(f'{len(V)} {len(G)}\n'+'\n'.join(' '.join(map(str,(len(g),*g))) for g in G)+'\n');lp.stdin.flush()
            lp.stdout.readline();weights=[[i,t] for i,t in enumerate(map(int,lp.stdout.readline().split())) if t]
        covered=[0]*len(V);val=0
        for i,t in weights:
            assert 0<=i<len(G) and t>=0 and type(t) is int;val+=t
            for v in G[i]:covered[v]+=t
        val+=sum(max(0,10**6-t)for t in covered)
        out.append([len(V),val//10**6,weights])
    if verify:assert verify==out
    return out
def main():
    root=P.parent
    xs=json.loads((REF/'search_runs/progress.json').read_text())['runs']
    dead={q['round'] for q in json.loads((root/'basis_followup/results.json').read_text()) if q['verdict']==0}
    dead|={q['round'] for q in json.loads((root/'basis_followup/color_results.json').read_text()) if q['coloring']}
    xs=[x for x in xs if x['round'] not in dead and (x['status']=='NODE_CAP' or x['status'].startswith('SAMPLED'))]
    path=P/'components_all.json';old={r['round']:r for r in json.loads(path.read_text())} if path.exists() else {}
    replay=len(sys.argv)>1 and sys.argv[1]=='replay'
    with tempfile.TemporaryDirectory() as d:
        temp=Path(d)
        for src,name in [(REF/'basis_candidates.cpp','candidates'),(P/'cover_lp.cpp','lp')]:
            if replay and name=='lp':continue
            subprocess.run(['c++','-std=c++17','-O3',str(src),'-o',str(temp/name)],check=True)
        lp=None if replay else subprocess.Popen([temp/'lp'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
        for x in sorted(xs,key=lambda r:r['compatible_single_lines']):
            i=x['round'];rec=old.get(i)
            if replay and not rec:continue
            if not replay and rec:continue
            A=coord(x['gram'],temp/'candidates');assert len(A)==x['compatible_single_lines']
            W=get(A,lp,rec['parts'] if replay else None)
            obj=dict(round=i,sha256=x['sha256'],parts=W,bound=sum(q[1]for q in W))
            if replay:assert rec==obj
            else:
                old[i]=obj
                path.with_suffix('.tmp').write_text(json.dumps([old[j] for j in sorted(old)],separators=(',',':')))
                path.with_suffix('.tmp').replace(path)
            print(i,len(A),obj['bound'],[(z[0],z[1])for z in W],flush=True)
        if lp:lp.stdin.close();assert lp.wait()==0
if __name__=='__main__':main()

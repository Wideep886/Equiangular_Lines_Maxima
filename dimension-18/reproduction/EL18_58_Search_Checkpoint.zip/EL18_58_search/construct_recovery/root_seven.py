"""Partition each remaining 40-clique decision by first admissible vertex."""
from components_all import *
from branch164 import peel
from concurrent.futures import ThreadPoolExecutor
def main():
    xs=json.loads((REF/'search_runs/progress.json').read_text())['runs']
    with tempfile.TemporaryDirectory() as d:
        tmp=Path(d);src=tmp/'wide.cpp'
        src.write_text((REF/'exact_clique.cpp').read_text().replace('K=4,MAXN=64*K','K=9,MAXN=64*K'))
        for f,n in [(REF/'basis_candidates.cpp','candidates'),(src,'clique')]:
            subprocess.run(['c++','-O3','-std=c++17',str(f),'-o',str(tmp/n)],check=True)
        def run(i):
            p=P/f'root{i}.json';A=coord(xs[i]['gram'],tmp/'candidates');out=[]
            for first,V in peel(A,list(range(len(A))),40):
                graph=tmp/f'g{i}';graph.write_text(f'{len(V)} 39\n'+'\n'.join(''.join('1' if w in A[v] else '0' for w in V)for v in V))
                q=subprocess.check_output([tmp/'clique',graph,'30000'],text=True).split()
                ret,n=map(int,q[1:3]);out.append([first,ret,n])
                if ret==1:
                    # Store all vertices of the possible 40-clique for reconstruction and exact Gram verification.
                    out[-1].append([first]+[V[int(j)] for j in q[3:]]);break
            if p.exists():assert out==json.loads(p.read_text())
            else:p.write_text(json.dumps(out,separators=(',',':')))
            print(i,len(out),{k:sum(q[1]==k for q in out)for k in (-1,0,1)},flush=True)
        with ThreadPoolExecutor(3)as pool:list(pool.map(run,(29,38,78,95,104,131,165)))
if __name__=='__main__':main()

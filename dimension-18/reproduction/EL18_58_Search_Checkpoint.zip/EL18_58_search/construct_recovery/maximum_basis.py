"""Spectrum-free necessary conditions when the 18 marked lines maximize the squared basis volume."""
from pathlib import Path
from itertools import combinations
import tempfile,subprocess,json
from components_all import REF,basis_inverse
P=Path(__file__).resolve().parent
def reduce(row,candidates):
    G=row['gram']
    B,e=basis_inverse(G);inp=str(e)+'\n'+'\n'.join(' '.join(map(str,r)) for r in B)
    pool=list(map(int,subprocess.check_output([candidates],input=inp,text=True).split()))
    words=[];images=[]; codes=[]
    for code in pool:
        s=[1]+[1-2*(code>>j&1) for j in range(17)]
        w=[sum(a*b for a,b in zip(r,s)) for r in B]
        assert sum(a*b for a,b in zip(s,w))==5*e
        if max(map(abs,w))<=e:
            codes.append(code);words.append(s);images.append(w)
    rows=[0]*len(codes);edges=ret=0
    ix=list(combinations(range(18),2));limit=e*e
    for i,z in enumerate(images):
        for j in range(i):
            if abs(sum(x*y for x,y in zip(z,words[j])))!=e:continue
            edges+=1
            w=images[j]
            if all(abs(z[a]*w[b]-z[b]*w[a])<=limit for a,b in ix):
                ret+=1;rows[i]|=1<<j;rows[j]|=1<<i
    return pool,codes,rows,edges,ret
def main():
    xs=json.loads((REF/'search_runs/progress.json').read_text())['runs'];cases=[29,38,78,95,104,131,165]
    results=[]
    with tempfile.TemporaryDirectory() as td:
        d=Path(td)
        subprocess.run(['c++','-std=c++17','-O3',str(REF/'basis_candidates.cpp'),'-o',str(d/'cand')],check=True)
        for i in cases:
            pool,cs,adj,edges,ret=reduce(xs[i],d/'cand');groups=[]
            for v in sorted(range(len(cs)),key=lambda j:(-bin(adj[j]).count('1'),j)):
                for group in groups:
                    if not any(adj[v]>>w&1 for w in group):group.append(v);break
                else:groups.append([v])
            r={'round':i,'initial':len(pool),'one_exchange':len(cs),'initial_edges_after_one_exchange':edges,'two_exchange_edges':ret,'color_bound':len(groups),'colors':[[cs[v] for v in g] for g in groups]}
            results.append(r);print(i,len(pool),len(cs),edges,ret,len(groups),flush=True)
    f=P/'maximum_basis.json'
    if f.exists():assert json.loads(f.read_text())==results
    else:f.write_text(json.dumps(results))
if __name__=='__main__':main()

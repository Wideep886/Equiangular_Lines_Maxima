"""Increase exact node limits on the three residual bounds equal to 40."""
from components_all import *
from concurrent.futures import ThreadPoolExecutor
def main():
    # The component sizes and bounds are independently checked by exact_parts.py.
    runs=json.loads((REF/'search_runs/progress.json').read_text())['runs']
    records=json.loads((P/'parts_search.json').read_text())
    with tempfile.TemporaryDirectory() as d:
        tmp=Path(d)
        for name in ('basis_candidates','exact_clique'):
            subprocess.run(['c++','-O3','-std=c++17',str(REF/(name+'.cpp')),'-o',str(tmp/name)],check=True)
        def run(r):
            i=r['round'];g=runs[i]['gram'];A=coord(g,tmp/'basis_candidates')
            best=[]
            for j,(V,part) in enumerate(zip(components(A),r['parts'])):
                cap,trials=part
                if trials[-1][1]!=-1:continue
                # Search all cliques by their first vertex in minimum-degree peeling order.
                live=set(V);by_first=[]
                while live:
                    v=min(live,key=lambda u:(len(live&A[u]),u));live.remove(v)
                    later=sorted(live&A[v]);need=cap-1
                    if len(later)<need:continue
                    file=tmp/f'graph_{i}';file.write_text(f'{len(later)} {need}\n'+'\n'.join(''.join('1' if w in A[z] else '0' for w in later)for z in later))
                    ret=subprocess.check_output([tmp/'exact_clique',file,'100000'],text=True).split()
                    status,nodes=map(int,ret[1:3]);by_first.append([v,status,nodes])
                    if status==1:break
                best.append([j,cap,by_first])
            p=P/f'near{i}.json'
            if p.exists():assert json.loads(p.read_text())==best
            else:p.write_text(json.dumps(best,separators=(',',':')))
            print(i,[(j,cap,{k:sum(row[1]==k for row in rows) for k in (-1,0,1)}) for j,cap,rows in best],flush=True)
        with ThreadPoolExecutor(3) as pool:list(pool.map(run,[r for r in records if r['bound']==40]))
if __name__=='__main__':main()

"""Tighten bounds separately on each join factor; preserve finite node caps as open."""
from components_all import *
from verify_gram import certify
def main():
    bits=json.loads((P/'components_all.json').read_text())
    xs={r['round']:r for r in json.loads((REF/'search_runs/progress.json').read_text())['runs']}
    dest=P/'parts_search.json';done=json.loads(dest.read_text()) if dest.exists() else []
    replay=len(sys.argv)>1 and sys.argv[1]=='replay';index={r['round']:r for r in done}
    with tempfile.TemporaryDirectory() as d:
        tmp=Path(d)
        for name in ('exact_clique','basis_candidates'):
            subprocess.run(['c++','-std=c++17','-O3',str(REF/(name+'.cpp')),'-o',str(tmp/name)],check=True)
        for rec in sorted(bits,key=lambda r:max(q[0] for q in r['parts'])):
            i=rec['round']
            if rec['bound']<40:continue
            if replay and i not in index or not replay and i in index:continue
            A=coord(xs[i]['gram'],tmp/'basis_candidates');cc=components(A);details=[]
            tot=rec['bound'];selected=[]
            for V,p in zip(cc,rec['parts']):
                cap=p[1];vs=[];trials=[]
                if len(V)>256:
                    src=tmp/'wide.cpp';src.write_text((REF/'exact_clique.cpp').read_text().replace('K=4,MAXN','K='+str(1+len(V)//64)+',MAXN'))
                    exe=tmp/'wide';subprocess.run(['c++','-std=c++17','-O3',str(src),'-o',str(exe)],check=True)
                else:exe=tmp/'exact_clique'
                graph=tmp/'graph'
                rows='\n'.join(''.join('1' if w in A[v] else '0'for w in V)for v in V)
                while cap>0:
                    graph.write_text(f'{len(V)} {cap}\n'+rows)
                    q=subprocess.check_output([exe,graph,'300000'],text=True).split()
                    status,nodes=map(int,q[1:3]);trials.append([cap,status,nodes])
                    if status==1:vs=[V[int(b)]for b in q[3:]];break
                    if status==-1:break
                    cap-=1;tot-=1
                if vs:assert len(vs)==cap and all(v in A[w]for j,v in enumerate(vs)for w in vs[:j])
                details.append([cap,trials]);selected+=vs
            if len(selected)>=40:
                print('WITNESS',i,flush=True)
                G=xs[i]['gram'];Q,e=basis_inverse(G)
                inp=str(e)+'\n'+'\n'.join(' '.join(map(str,r))for r in Q)
                masks=sorted(map(int,subprocess.check_output([tmp/'basis_candidates'],input=inp,text=True).split()))
                W=[[1]+[1-2*(masks[v]>>l&1)for l in range(17)]for v in selected[:40]]
                Z=[[sum(a*b for a,b in zip(q,s))for q in Q]for s in W]
                K=[r+[s[j] for s in W]for j,r in enumerate(G)]+[s+[sum(a*b for a,b in zip(z,t))//e for t in W]for s,z in zip(W,Z)]
                print(certify(K));(P/'witness58.json').write_text(json.dumps(K));return
            record={'round':i,'parts':details,'bound':tot,'lower':len(selected)}
            if replay:assert index[i]==record
            else:done.append(record);dest.write_text(json.dumps(done,separators=(',',':')))
            print(i,rec['bound'],tot,len(selected),flush=True)
if __name__=='__main__':main()

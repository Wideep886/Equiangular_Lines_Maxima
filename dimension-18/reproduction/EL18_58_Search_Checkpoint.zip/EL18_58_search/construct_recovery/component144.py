"""Prove the #144 40-clique decision via fractional independent-set covers and branching."""
from pathlib import Path
import json,os,subprocess,sys,tempfile
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'basis_followup'))
from replay import REF,basis_inverse
from verify_gram import certify

def build(g,tmp):
    inverse,d=basis_inverse(g)
    exe=tmp/'candidates'
    subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(REF/'basis_candidates.cpp'),'-o',str(exe)],check=True)
    masks=sorted(map(int,subprocess.check_output([exe],text=True,input=str(d)+'\n'+'\n'.join(' '.join(map(str,r))for r in inverse)).split()))
    signs=[[1]+[1-2*(m>>i&1) for i in range(17)] for m in masks]
    images=[[sum(v*w for v,w in zip(r,s))for r in inverse]for s in signs]
    adj=[{j for j,s in enumerate(signs) if abs(sum(v*w for v,w in zip(t,s)))==d} for t in images]
    return adj,masks,signs,images,d

def maximal(A):
    cl=[]
    def walk(r,p,x):
        if not p and not x:cl.append(tuple(sorted(r)));return
        v=max(p|x,key=lambda i:(len(p&A[i]),-i))
        for i in sorted(p-A[v]):
            walk(r+[i],p&A[i],x&A[i]);p.remove(i);x.add(i)
    walk([],set(range(len(A))),set())
    return sorted(cl)

def main():
    G=next(q['gram'] for q in json.loads((P.parent/'basis_followup/color_inputs.json').read_text()) if q['round']==144)
    out=P/'component144.json';replay=out.exists()
    with tempfile.TemporaryDirectory() as f:
        tmp=Path(f);adj,masks,signs,images,d=build(G,tmp);n=len(adj)
        groups=maximal([set(range(n))-{i}-s for i,s in enumerate(adj)])
        weights,=json.loads(out.read_text())
        classes=[]
        for index,weight in weights:
            assert weight==10**6
            independent=groups[index]
            assert all(w not in adj[v] for i,v in enumerate(independent) for w in independent[:i])
            classes.append(set(independent))
        live=set(range(n));cc=[]
        while live:
            seen=set();nexts={min(live)}
            while nexts:
                seen|=nexts;live-=nexts
                nexts={w for v in nexts for w in live if w not in adj[v]}
            cc.append(sorted(seen))
        assert sorted(map(len,cc))==[46,155]
        best=[]
        # A clique is the disjoint union of cliques in the two parts.
        for V in sorted(cc,key=len):
            t=8 if len(V)==46 else 31
            if len(V)==46:
                def search(candidates,chosen,goal):
                    if len(chosen)==goal:return chosen
                    while len(candidates)+len(chosen)>=goal:
                        v=min(candidates,key=lambda v:(-len(adj[v]&candidates),v));candidates.remove(v)
                        result=search(candidates&adj[v],chosen+[v],goal)
                        if result:return result
                    return None
                assert search(set(V),[],9) is None
            else:
                assert len(classes)==31 and set(V)<=set.union(*classes)
            path=P/'component144_clique.json'
            if path.exists():
                data=json.loads(path.read_text());cl=[masks.index(k) for k in data if masks.index(k) in V]
            else:
                exe2=tmp/'clq'
                subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(REF/'exact_clique.cpp'),'-o',str(exe2)],check=True)
                graph=tmp/'graph'
                graph.write_text(f'{len(V)} {t}\n'+'\n'.join(''.join('1' if w in adj[v] else '0'for w in V)for v in V))
                r=subprocess.check_output([str(exe2),str(graph),'3000000'],text=True).split()
                assert r[1]=='1'
                cl=[V[int(j)]for j in r[3:]]
            assert len(cl)==t and all(v in adj[w]for i,v in enumerate(cl)for w in cl[:i]);best+=cl
        assert len(best)==39 and all(v in adj[w] for i,v in enumerate(best)for w in best[:i])
        if not path.exists():path.write_text(json.dumps([masks[i] for i in best]))
        K=[r+[signs[k][i] for k in best] for i,r in enumerate(G)]
        K+= [signs[k]+[sum(v*w for v,w in zip(images[k],signs[j]))//d for j in best]for k in best]
        print(certify(K,57))

        print("Certified maximum 18+8+31=57.")
if __name__=='__main__':main()

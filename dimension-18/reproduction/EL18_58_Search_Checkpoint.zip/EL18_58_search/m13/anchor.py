"""Resumable unconditional one-point/deletion pair square-class sieve on normalized parent spectra."""
import argparse,gzip,json
from concurrent.futures import ProcessPoolExecutor
from math import isqrt
from pathlib import Path
from build import factors
from fastdeck import native
from lowmult import val,deriv,allowed_deck
from lattice import lat
from lpscreen import phase_one
P=Path(__file__).resolve().parent
PRIMES=[p for p in range(3,262,2) if all(p%j for j in range(2,isqrt(p)+1))]

def indices(s):
    while s:
        bit=s&-s;yield bit.bit_length()-1;s-=bit

def possible(S,b):
    if not S:return False
    z=b[0]
    for j in range(1,len(b)):
        v=[x[j] for x in S]
        if not z*min(v)<=b[j]<=z*max(v):return False
    if len(S)<=30:
        if not lat(S,b):return False
        if phase_one(S,b)['kind']!='primal':return False
    return True

def anchor(m,h,pure=False):
    fs=[([1,0],m)]+factors(h)
    g,target,deck=(allowed_deck if pure else native)([([1,8],40)]+fs)
    cols=[(1,*q[3:]) for q in deck];b=(58,*target[3:])
    n=len(deck);active=(1<<n)-1
    if not possible(cols,b):return (n,[],0)
    nbrs=[active]*n
    for f,k in fs:
        if k!=1:continue
        d=deriv(f)
        for p in PRIMES:
            symbols=[0]+[pow(x,(p-1)//2,p) for x in range(1,p)]
            for a in range(p):
                if val(f,a)%p or not val(d,a)%p:continue
                vals=[symbols[val(q,a)%p] for q in deck]
                badp=sum(1<<i for i,w in enumerate(vals) if w==p-1)
                badm=sum(1<<i for i,w in enumerate(vals) if w==1)
                if not (badp and badm):continue
                mask={1:~badp,p-1:~badm,0:active}
                nbrs=[s&mask[w] for s,w in zip(nbrs,vals)]
    rounds=[]
    while active:
        removed=[]
        for i in indices(active):
            S=[cols[j] for j in indices(active&nbrs[i])]
            if not possible(S,tuple(x-y for x,y in zip(b,cols[i]))):removed.append(i)
        if not removed:break
        for j in removed:active^=1<<j
        rounds.append(len(removed))
    if active and not possible([cols[j] for j in indices(active)],b):active=0
    return n,rounds,bin(active).count('1')

def unit(q):
    m,i,h,d,pure=q;dest=d/f'{i:05}.json'
    if dest.exists():return
    n,rs,k=anchor(m,h,pure)
    out=[m,i,h,n,rs,k]
    tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(out,separators=(',',':')));tmp.replace(dest)

def main():
    a=argparse.ArgumentParser();a.add_argument('--input',type=Path);a.add_argument('--m',type=int,default=13);a.add_argument('--start',type=int,default=0);a.add_argument('--end',type=int);a.add_argument('--pure',action='store_true');a.add_argument('--jobs',type=int,default=2);a.add_argument('--root',type=Path,default=P);a.add_argument('--parents',type=Path);args=a.parse_args()
    m=args.m;d=args.root/f'anchor{m}';d.mkdir(parents=True,exist_ok=True)
    if args.parents:hs=json.loads(args.parents.read_text())
    else:hs=sorted(q[:-m] for l in gzip.open(args.input,'rt') if (q:=json.loads(l))[-m:]==[0]*m and q[-m-1])
    todo=[(m,i,h,d,args.pure) for i,h in enumerate(hs) if i>=args.start and (args.end is None or i<args.end) and not (d/f'{i:05}.json').exists()]
    with ProcessPoolExecutor(args.jobs) as pool:
        for _ in pool.map(unit,todo,chunksize=1):pass
    print('processed',len(todo))
if __name__=='__main__':main()

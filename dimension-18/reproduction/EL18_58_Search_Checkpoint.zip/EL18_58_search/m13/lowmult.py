"""One-deletion arithmetic and rank-one projector tests for low multiplicity spectra."""
from math import comb,gcd,isqrt,prod
from functools import lru_cache
from pathlib import Path
from fractions import Fraction
import json,sys
from check import mul,shift,fails_at,weighted_divisors
from lpscreen import phase_one
from verify_no11 import isol,dN
from itertools import product

def val(p,x):
    a=0
    for v in p:a=a*x+v
    return a
def deriv(p):
    return [a*(len(p)-1-i) for i,a in enumerate(p[:-1])]
def parts(p):
    out=[]
    for i,f in enumerate(p):
        q=[1]
        for j,h in enumerate(p):
            if i!=j:q=mul(q,h)
        out.append(q)
    return out

def prunes(c):
    if any(z%2 for z in c[2::2]):return True
    b=[1]
    for m in range(2,len(c)-1,2):
        b.extend([(2*c[m+1]+c[m]+2*c[m-1]*c[3])%4,(-57*c[m+1])%4])
    if len(b)>1 and b[1]:return True
    if any(v%2 for v in b[1::2]):return True
    p=[0]
    for m in range(1,len(b)):
        p.append(-m*b[m]-sum(b[i]*p[m-i] for i in range(1,m)))
        if m>=4 and m%2==0 and sum(w*p[d] for d,w in weighted_divisors(m))%(2*(m & -m)):return True
    return False

def monic_product(fs):
    a=[1]
    for f in fs:a=mul(a,f)
    return a

def allowed_deck(factors):
    polys,mults=zip(*factors)
    g=monic_product(polys);deg=len(g)-2
    common=monic_product([f for f,m in factors for i in range(m-1)])
    terms=[mul(part,deriv(f)) for part,f in zip(parts(polys),polys)]
    target=[2*sum(m*term[i] for m,term in zip(mults,terms)) for i in range(deg+1)]
    coords=[[0]*j+mul(shift(common,-6),shift([1]+[0]*(deg-j),-6)) for j in range(deg+1)]
    @lru_cache(None)
    def admissible(h):
        m=len(h)
        c=[sum(z*col[k] for z,col in zip(h,coords))%4 for k in range(58 if m==deg+1 else m)]
        return not (fails_at(c) if m==deg+1 else prunes(c))
    opts=[[2,2*g[1]-11,2*g[2]-11*g[1]+89]]
    B=2**28
    for k in range(3,deg+1):
        ell=deg-k
        weights=[comb(deg-i,ell) for i in range(k)]
        roots=[(int(l*B),int(h*B)) for l,h in isol(dN(g,ell))]
        assert len(roots)==k+1
        from fractions import Fraction as F
        D=1<<32
        bounds=[]
        for j,(l,h) in enumerate(roots):
            terms=[]
            for pos,w in enumerate(weights):
                exponent=k-pos
                vs=[F(l,B)**exponent,F(h,B)**exponent]
                if l<=0<=h:vs.append(0)
                lower=min(vs)*w*D; upper=max(vs)*w*D
                terms.append((lower//1,-((-upper)//1)))
            bounds.append((bool((j-k)%2),terms))
        nxt=[]
        for q in opts:
            lo=hi=None
            for negative,terms in bounds:
                if negative:
                    low=sum(a*(mins if a>=0 else maxs) for a,(mins,maxs) in zip(q,terms))
                    t=(-low)//D
                    hi=t if hi is None else min(hi,t)
                else:
                    high=sum(a*(maxs if a>=0 else mins) for a,(mins,maxs) in zip(q,terms))
                    t=-(high//D)
                    lo=t if lo is None else max(lo,t)
            qr=tuple(x%4 for x in q)
            for residue in range(4):
                begin=lo+(residue-lo)%4
                if begin<=hi and admissible(qr+(residue,)):
                    nxt.extend(q+[v] for v in range(begin,hi+1,4))
        opts=nxt
    return g,target,[q for q in opts if val(q,-8)!=0]

def sf(v):
    a=1;d=2
    while d*d<=v:
        while v%(d*d)==0:v//=d*d
        d+=1
    return v

def screen(row):
    factors=[([1,8],40)]+row['factors']
    g,target,deck=allowed_deck(factors)
    single=[-f[1] for f,m in factors if m==1 and len(f)==2]
    choices=[]
    for t in single:
        c=2*abs(val(deriv(g),t))
        classes=sorted({sf(abs(val(h,t))) for h in deck if val(h,t)}-{0})
        choices.append([a for a in classes if c%a==0])
    branches=[]
    for pars in product(*choices):
        active=[i for i,h in enumerate(deck) if all(val(h,t)==0 or sf(abs(val(h,t)))==v for t,v in zip(single,pars))]
        cert=phase_one([(1,*deck[i][3:]) for i in active],(58,*target[3:])) if active else {'kind':'empty'}
        if cert['kind']=='primal':cert['support']=[[active[j],coeff] for j,coeff in cert['support']]
        branches.append({'classes':pars,'cert':cert})
    return {'factors':row['factors'],'g':g,'target':target,'deck':deck,'simple_roots':single,'options':choices,'branches':branches}

if __name__=='__main__':
    rows=json.loads(Path(sys.argv[1]).read_text())
    with open(sys.argv[2],'w') as f:
        for k,row in enumerate(rows):
            r=screen(row)
            print(k,len(r['deck']),sum(b['cert']['kind']=='primal' for b in r['branches']),flush=True)
            print(json.dumps(r),file=f,flush=True)

# One-deletion screen for multiplicity 13

After the earlier combined filters, this layer contains 2,965 sorted tails h of F=t^13 h. The first 100 tails were independently checked. Their real one-deletion supports leave 3 candidates, while exact integral column-lattice membership leaves only index 35 (zero-based), h=t^5-t^4-10t^3-6t²+9t+7. The integer lattice test checks a necessary condition. The open tail has no accompanying 58-line construction.

Run from this directory with Python 3.9 or later and a C++17 compiler.

    python3 replay.py first100 --jobs 2
    python3 replay.py anchor --jobs 2
    python3 replay.py resume --jobs 3

The first command reconstructs the Sturm/derivative interlacing and full order-57 Euler-congruence superdeck for every polynomial, checks the full square-class case cover and every recorded integer Farkas witness, and recomputes lattice membership by unimodular column operations. Adding --pure uses the independent Python superdeck routine. The second command regenerates the stage saved in progress.json. An optional --end N bounds this scan to indices below N. The third command takes every completed row from the snapshot and processes the remaining tails, writing each atomically into anchor13/. It may be interrupted and resumed. The generic anchor.py accepts --m and --input for other multiplicities, using the predecessor combined/remaining.jsonl.gz as input.

Put T=(S−11I)/2. Let g be the squarefree characteristic polynomial of T. For each vertex i define H_i(t)=2g(t)((tI−T)^−1)_{ii}, a polynomial in the one-point superdeck. The finite target identity is sum_i H_i=2 sum_r m_r g/(t−r), over distinct roots r. Group rational conjugate roots by irreducible factors when forming this integer sum. Each simple eigenspace has a rank-one projector. Consequently H_i H_j=Q_ij² at every simple root, where Q_ij=2g(t)((tI−T)^−1)_{ij} has coefficients in Z[1/2]. Indeed g(T)=0 and the resolvent numerator is the polynomial obtained from (g(t)−g(T))/(tI−T). Polynomial divisibility by each corresponding monic simple factor therefore persists modulo every odd prime. At any root a of such a factor modulo an odd prime p, nonzero H_i(a) and H_j(a) must have identical quadratic characters.

The first 100 certificates branch on the two possible nonzero characters and place zero in both branches. Maximal supersets cover smaller descendants. At a leaf the putative 58 vertex counts must be nonnegative integers satisfying the target sum. The saved Farkas vector y has nonnegative pairing with every column and negative pairing with their target. The integer lattice test further excludes a target outside the integer span.

The faster anchor scan uses all linear roots modulo odd primes through 261. For each hypothetical row i, it takes all neighbors j compatible with every modular character test. The remaining 57 rows must represent the target minus column i. Exact coordinate bounds, integer column lattice, and a rational feasibility test delete impossible i. Repeating to stability and then retesting the full target gives the reported exclusions. For supports over 30 the implementation uses only the individual coordinate bounds. In all stages an open result is inconclusive. Counts for this scan and the first 100 overlap.

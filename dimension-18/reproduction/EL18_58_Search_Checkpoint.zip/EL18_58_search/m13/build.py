import sys,json,gzip
from fractions import Fraction as F
from math import gcd
from functools import reduce
from pathlib import Path
from collections import Counter
def strip(p):
 while p and not p[0]:p=p[1:]
 return p
def div(p,f):
 p=list(map(F,p));f=list(map(F,f));q=[]
 for i in range(len(p)-len(f)+1):
  z=p[i]/f[0];q.append(z)
  for j,v in enumerate(f):p[i+j]-=z*v
 return strip(q),strip(p)
def gc(p,q):
 while q:p,q=q,div(p,q)[1]
 return [x/p[0] for x in p]
def exact(p,f):
 q,r=div(p,f);assert not r and all(int(z)==z for z in q)
 return [int(a) for a in q]
def factors(p):
 out=[]
 for k in range(-4,5):
  m=0
  while len(p)>=2 and (v:=div(p,[1,-k]))[1]==[]:p=exact(p,[1,-k]);m+=1
  if m:out.append(([1,-k],m))
 if len(p)<=1:return out
 rep=gc(p,[a*(len(p)-1-i) for i,a in enumerate(p[:-1])])
 f=exact(p,rep);d=1
 while len(f)>1:
  h=gc(f,rep);v=exact(f,h)
  if len(v)>1:out.append((v,d))
  f=list(map(int,h));rep=exact(rep,h);d+=1
 return out
def main():
 src=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/el18-generation/survivors_full.jsonl.gz')
 records=[]
 for line in gzip.open(src,'rt'):
  p=json.loads(line)
  if p[-4:]==[0]*4 and p[-5]:
   fs=factors(p);records.append(dict(poly=p,factors=fs,degree=sum(len(f)-1 for f,m in fs)))
 records.sort(key=lambda x:(x['degree'],x['poly']))
 Path('parents.json').write_text(json.dumps(records))
 print(len(records),Counter(x['degree'] for x in records))
if __name__=='__main__':main()

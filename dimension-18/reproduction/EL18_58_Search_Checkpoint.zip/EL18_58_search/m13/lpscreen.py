"""Exact small equality LP with integer reduced costs and verified primal/dual output."""
import sys
from fractions import Fraction as F
from pathlib import Path
import json
from math import lcm
from functools import reduce
from collections import Counter

def dot(a,b): return sum(x*y for x,y in zip(a,b))

def phase_one(cols,b):
    dim=len(b);n=len(cols)
    # Use signed unit artificials to build a feasible starting basis.
    signs=[1 if t>=0 else -1 for t in b]
    Z=cols+[tuple(signs[i]*int(i==j) for j in range(dim)) for i in range(dim)]
    inv=[[F(signs[i]*int(i==j)) for j in range(dim)] for i in range(dim)]
    basis=list(range(n,n+dim));seen=set();bland=False
    while True:
        state=tuple(basis)
        if state in seen: bland=True
        seen.add(state)
        val=[dot(r,b) for r in inv]
        assert min(val)>=0
        if all(v==0 for v,k in zip(val,basis) if k>=n):
            cert=[(k,str(v)) for k,v in zip(basis,val) if v]
            assert all(sum(F(v)*Z[k][i] for k,v in cert)==b[i] for i in range(dim))
            return dict(kind='primal',support=cert)
        dual=[-sum(r[j] for r,k in zip(inv,basis) if k>=n) for j in range(dim)]
        den=reduce(lcm,(F(v).denominator for v in dual),1)
        y=[int(v*den) for v in dual]
        if bland:
            ent=next((k for k,col in enumerate(Z) if dot(y,col)+(den if k>=n else 0)<0),None)
        else:
            rc,ent=min((dot(y,col)+(den if k>=n else 0),k) for k,col in enumerate(Z))
            if rc>=0: ent=None
        if ent is None:
            assert dot(y,b)<0 and all(dot(y,col)>=0 for col in cols)
            return dict(kind='farkas',y=y)
        direction=[dot(r,Z[ent]) for r in inv]
        _,_,ind=min((v/d,basis[i],i) for i,(v,d) in enumerate(zip(val,direction)) if d>0)
        pivot=[v/direction[ind] for v in inv[ind]]
        inv=[[a-k*z for a,z in zip(row,pivot)] if i!=ind else pivot for i,(row,k) in enumerate(zip(inv,direction))]
        basis[ind]=ent

def screen(f,summary):
    record=json.loads(f.read_text());md=record['metadata'];rule=set(map(tuple,summary['kept_residues']))
    deck=record['H_deck']
    indices=[i for i,h in enumerate(deck) if tuple(y%4 for y in h) in rule]
    if not indices: return dict(kind='empty')
    # same fixed first three coefficients for every deck member
    cols=[(1,*deck[i][3:]) for i in indices];target=(58,*md['target_H_sum'][3:])
    cert=phase_one(cols,target)
    if cert['kind']=='primal':
        cert['support']=[(indices[k],a) for k,a in cert['support']]
    return cert

if __name__=='__main__':
    path=Path(sys.argv[1]);results=json.loads(Path(sys.argv[2]).read_text())
    for s in results:
        p=s['profile'];f=path/('decks_%02d.json'%p if type(p) is int else 'nonintegral_deck_%s.json'%p)
        s['certificate']=screen(f,s)
    prior=json.loads((path/'proof_status.json').read_text())
    for group,already in [(False,prior['n58']['excluded']),(True,prior['n58_nonintegral_degree_at_most_two']['excluded'])]:
        rows=[r for r in results if isinstance(r['profile'],str)==group]
        ids={r['profile'] if group else 'n58_%02d'%r['profile'] for r in rows if r['certificate']['kind']!='primal'}
        print(group,len(rows),len(ids),len(ids-set(already)),sorted(ids-set(already)),flush=True)
    Path(sys.argv[3]).write_text(json.dumps(results))

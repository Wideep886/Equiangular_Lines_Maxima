"""Replay the sealed first 100 or all saved anchor checkpoints, or resume the anchor run."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse,gzip,json,subprocess,sys,os
from verify_middle import checkjob
from anchor import unit
P=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['first100','anchor','resume']);ap.add_argument('--jobs',type=int,default=2);ap.add_argument('--pure',action='store_true');ap.add_argument('--end',type=int)
    args=ap.parse_args()
    if not args.pure:
        subprocess.run([os.environ.get('CXX','c++'),'-std=c++17','-O3',str(P/'fastdeck.cpp'),'-o',str(P/'fastdeck')],check=True)
    parents=json.loads((P/'parents.json').read_text())
    if args.mode=='first100':
        d=P/'replay100';d.mkdir(exist_ok=True);jobs=[]
        for l in gzip.open(P/'first100.jsonl.gz','rt'):
            i,r=json.loads(l);assert r['tail']==parents[i];p=d/f'{i:05}.json';p.write_text(json.dumps(r));jobs.append((13,i,p,args.pure))
        with ProcessPoolExecutor(args.jobs) as pool:out=list(pool.map(checkjob,jobs))
        assert out==json.loads((P/'check_100.json').read_text())
        print(len(out),sum(x[-2]>0 for x in out),sum(x[-1]>0 for x in out))
        return
    d=P/('anchor13' if args.mode=='resume' else 'replay_anchor');d.mkdir(exist_ok=True);jobs=[];todo={}
    for l in gzip.open(P/'anchor_done.jsonl.gz','rt'):
        row=json.loads(l);m,i,h=row[:3];assert m==13 and h==parents[i]
        todo[i]=row
        if args.mode=='resume':(d/f'{i:05}.json').write_text(json.dumps(row))
        elif args.end is None or i<args.end:
            p=d/f'{i:05}.json'
            if p.exists():p.unlink()
            jobs.append((m,i,h,d,args.pure))
    if args.mode=='resume':
        jobs=[(13,i,h,d,args.pure) for i,h in enumerate(parents) if not(d/f'{i:05}.json').exists() and (args.end is None or i<args.end)]
    with ProcessPoolExecutor(args.jobs) as pool:
        for _ in pool.map(unit,jobs):pass
    if args.mode=='anchor':
        for _,i,h,d,_ in jobs:assert json.loads((d/f'{i:05}.json').read_text())==todo[i]
        print('rechecked',len(jobs))
    else:print('newly processed',len(jobs))
if __name__=='__main__':main()

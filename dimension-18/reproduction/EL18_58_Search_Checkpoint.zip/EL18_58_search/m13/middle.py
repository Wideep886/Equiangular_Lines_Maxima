"""Check one-deletion spectra, finite-field rank-one consistency, and exact linear necessities."""
from concurrent.futures import ProcessPoolExecutor
from itertools import chain
from math import isqrt
from pathlib import Path
import argparse,gzip,json,os,time
from fastdeck import native
from lowmult import val,deriv
from lpscreen import phase_one
from build import factors
P=Path(__file__).resolve().parent
PRIMES=[p for p in range(3,130,2) if all(p%i for i in range(2,isqrt(p)+1))]

def splitting(fs,deck):
    options=[]
    for f,m in fs:
        if m!=1:continue
        for p in PRIMES:
            for a in range(p):
                if val(f,a)%p or val(deriv(f),a)%p==0:continue
                chars=[pow(val(q,a)%p,(p-1)//2,p) for q in deck]
                plus=sum(1<<i for i,v in enumerate(chars) if v==1)
                minus=sum(1<<i for i,v in enumerate(chars) if v==p-1)
                if plus and minus:options.append((f,p,a,plus,minus))
    return options

def work(arg):
    m,i,h,folder=arg
    dest=folder/f'{i:05}.json'
    if dest.exists():return
    fs=[([1,0],m)]+factors(h)
    g,b,deck=native([([1,8],40)]+fs);n=len(deck)
    cols=[(1,*q[3:]) for q in deck];target=(58,*b[3:]); big=(1<<n)-1
    out={'m':m,'tail':h,'factors':fs,'n':n,'splits':[]}
    def lin(s):
        if not s:return dict(kind='empty')
        return phase_one([c for j,c in enumerate(cols) if s>>j&1],target)
    def walk():
        cert=lin(big)
        if cert['kind']!='primal':return [],[[hex(big),cert]]
        ss={big}
        for f,p,a,u,v in splitting(fs,deck):
            if not any(s&u and s&v for s in ss):continue
            new={t for s in ss for t in [s&~u,s&~v]}
            if len(new)>8000:break
            ordered=sorted(new,key=int.bit_count,reverse=True) if hasattr(int,'bit_count') else sorted(new,key=lambda x:bin(x).count('1'),reverse=True)
            maxim=[]
            for s in ordered:
                if not any((s&t)==s for t in maxim):maxim.append(s)
            ss=set(maxim)
            out['splits'].append([f,p,a])
        dead=[];alive=[]
        for s in sorted(ss):
            c=lin(s)
            if c['kind']=='primal':alive.append(hex(s))
            else:dead.append([hex(s),c])
        return alive,dead
    alive,dead=walk();out.update(alive=alive,dead=dead)
    tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(out,separators=(',',':')));tmp.replace(dest)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--m',type=int,default=13);ap.add_argument('--limit',type=int);ap.add_argument('--jobs',type=int,default=2);args=ap.parse_args()
    folder=P/f'm{args.m}';folder.mkdir(exist_ok=True)
    hs=sorted(json.loads(l)[:-args.m] for l in gzip.open(args.input,'rt') if (q:=json.loads(l))[-args.m:]==[0]*args.m and q[-args.m-1]!=0)
    (folder/'parents.json').write_text(json.dumps(hs))
    todo=[(args.m,i,h,folder) for i,h in enumerate(hs[:args.limit]) if not (folder/f'{i:05}.json').exists()]
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for _ in pool.map(work,todo,chunksize=1):pass
    print('done',len(todo),flush=True)
if __name__=='__main__':main()

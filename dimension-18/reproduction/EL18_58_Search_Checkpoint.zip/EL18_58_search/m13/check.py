"""Order-57 deletion screen via Euler-graph coefficients and closed-walk counts."""
from functools import lru_cache
from math import comb, gcd
from pathlib import Path
from collections import Counter
import argparse
import json
import random

def mul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            out[i+j]+=x*y
    return out

def shift(poly,k):
    n=len(poly)-1
    return [sum(v*comb(n-i,j-i)*k**(j-i) for i,v in enumerate(poly[:j+1])) for j in range(n+1)]

@lru_cache(None)
def weighted_divisors(m):
    return [(d,sum(gcd(i,m//d)==1 for i in range(1,m//d+1)))
            for d in range(1,m+1) if m%d==0]

def fails_at(c):
    """c[0]=2, c[j]=a_j/2^(j-1) mod 4 for chi_(S+I)."""
    n=len(c)-1
    assert n%2 and c[:3]==[2,-n%4,0]
    # Cor. 3.8 additionally demands c_j even for even j.
    if any(x%2 for x in c[2::2]):
        return -1
    b=[1]
    for m in range(2,n,2):
        b.append((2*c[m+1]+c[m]+2*c[m-1]*c[3])%4)
        b.append((-n*c[m+1])%4)  # n is its own inverse mod 4
    if b[1] or any(x%2 for x in b[1::2]):
        return -2
    # Integer power sums of a representative with these coefficients mod 4.
    # Traces at d are well-defined mod 2^(2+v2(d)) for such lifts.
    p=[0]
    for m in range(1,n):
        p.append(-m*b[m]-sum(b[i]*p[m-i] for i in range(1,m)))
        if m>=4 and m%2==0:
            val=sum(phi*p[d] for d,phi in weighted_divisors(m))
            if val%(2*(m & -m)):
                return m
    return 0

def exact_char(M):
    n=len(M)
    X=[r[:] for r in M]
    p=[0]; coeff=[1]
    for j in range(1,n+1):
        p.append(sum(X[i][i] for i in range(n)))
        val=-sum(coeff[k]*p[j-k] for k in range(j))
        assert val%j==0
        coeff.append(val//j)
        if j<n:
            X=[[sum(a*b for a,b in zip(row,col)) for col in M] for row in X]
    return coeff

def positive_tests(path):
    rng=random.Random(1996)
    for n in (5,7,9,11,13,15):
        for _ in range(6):
            B=[[1]*n for _ in range(n)]
            for i in range(n):
                for j in range(i):
                    B[i][j]=B[j][i]=rng.choice([-1,1])
            a=exact_char(B)
            c=[2]+[(x//(1<<(j-1)))%4 for j,x in enumerate(a[1:],1)]
            assert fails_at(c)==0
    data=json.loads((path/'positive_control57.json').read_text())
    a=shift(data['characteristic_polynomial_coefficients_descending'],-1)
    c=[2]+[(x//(1<<(j-1)))%4 for j,x in enumerate(a[1:],1)]
    assert fails_at(c)==0

def process(path):
    saved=json.loads(path.read_text()); md=saved['metadata']
    nonintegral='full_normalized_factors' in md
    if nonintegral:
        factors=[(shift(x['coefficients_descending'],-6),x['multiplicity']) for x in md['full_normalized_factors']]
    else:
        factors=[([1,-(int(root)+1)//2],m) for root,m in md['spectrum'].items()]
    F=[1]
    for f,m in factors:
        for _ in range(m-1):
            F=[v%4 for v in mul(F,f)]
    cache={}
    def check(h):
        h=tuple(v%4 for v in h)
        if h not in cache:
            c=[v%4 for v in mul(F,shift(h,-6) if nonintegral else h)]
            cache[h]=fails_at(c)
        return cache[h]
    deck=saved['H_deck']
    hits=[i for i,h in enumerate(deck) if check(h)==0]
    target=md['target_H_sum']
    excluded=not hits or any(target[j]<58*min(deck[i][j] for i in hits) or target[j]>58*max(deck[i][j] for i in hits) for j in range(3,len(target)))
    return {'profile':md['profile_id'],'before':len(deck),'after':len(hits),'excluded_by_box':excluded,'kept_residues':[q for q in sorted(cache) if cache[q]==0]}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output_dir',type=Path);p.add_argument('results',type=Path)
    args=p.parse_args();path=args.output_dir
    positive_tests(path)
    results=[process(f) for f in sorted((*path.glob('decks_[0-9][0-9].json'),*path.glob('nonintegral_deck_n58_d2_*.json')))]
    prior=json.loads((path/'proof_status.json').read_text())
    for group,already in [(False,prior['n58']['excluded']),(True,prior['n58_nonintegral_degree_at_most_two']['excluded'])]:
        rows=[r for r in results if isinstance(r['profile'],str)==group]
        ids={r['profile'] if group else 'n58_%02d'%r['profile'] for r in rows if r['excluded_by_box']}
        print(group,len(rows),sum(r['before'] for r in rows),sum(r['after'] for r in rows),len(ids),sorted(ids-set(already)),flush=True)
    args.results.write_text(json.dumps(results))

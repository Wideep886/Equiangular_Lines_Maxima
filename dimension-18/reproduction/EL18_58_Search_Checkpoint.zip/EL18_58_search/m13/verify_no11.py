"""Reconstruct the no-11 branch for 58 real equiangular lines in R^18.
Run with Python 3.9+; standard library only. All root tests and LP tests are exact.
Outputs one JSON certificate report to the path assigned by --output (optional).
The accompanying note defines the normalization and explains exhaustiveness.
"""
import argparse
import json
from fractions import Fraction as F
from functools import reduce, lru_cache
from math import ceil, floor, comb, gcd, isqrt, lcm
from pathlib import Path


def primit(p):
 i=0
 while i<len(p) and not p[i]:i+=1
 p=p[i:]
 g=reduce(gcd,p,0)
 return [k//g for k in p] if g>1 else p
def rem(p,q):
 qn=q[0]; a=abs(qn); s=1 if qn>0 else -1
 r=primit(p)
 while len(r)>=len(q):
  b=r[0]*s
  r=primit([a*v-(b*q[j] if j<len(q) else 0) for j,v in enumerate(r)])
 return r
def ds(p):return [v*(len(p)-1-i) for i,v in enumerate(p[:-1])]
def real(p):
 seq=[p,ds(p)]
 while seq[-1]:
  seq.append([-v for v in rem(seq[-2],seq[-1])])
 seq.pop()
 inf=[v[0]>0 for v in seq]
 neg=[(v[0] if len(v)%2 else -v[0])>0 for v in seq]
 diff=sum(a!=b for a,b in zip(neg,neg[1:]))-sum(a!=b for a,b in zip(inf,inf[1:]))
 if diff!=len(p)-len(seq[-1]):return False
 return len(seq[-1])<=2 or real(seq[-1])
def mul(p,q):
 r=[0]*(len(p)+len(q)-1)
 for i,a in enumerate(p):
  for j,b in enumerate(q):r[i+j]+=a*b
 return r
def val(p,v):
 s=0
 for a in p:s=s*v+a
 return s
def shift(p,h): # p(x+h)
 return [sum(a*comb(len(p)-1-i,k-i)*h**(k-i) for i,a in enumerate(p[:k+1])) for k in range(len(p))]
def tails(m,s):
 if m==0:return []
 if (s*s-m-3)%2 or s*s>m*(m+3):return []
 if m==1:return [[1,-s]] if s*s==4 else []
 second=(s*s-m-3)//2
 opts=[[1,-s,second]]
 for k in range(3,m+1):
  b=isqrt((comb(m,k)**2*(m+3)**k)//m**k)
  w=[comb(m-j,k-j) for j in range(k+1)]
  opts=[q+[v] for q in opts for v in range(-b,b+1)
        if real([wj*a for wj,a in zip(w,q+[v])])]
 return [p for p in opts if all(val(p,x)!=0 for x in [0,1,-1])]


def div(p,q):
 out=[];r=p[:];D=len(p)-len(q)
 for i in range(D+1):
  assert r[i]%q[0]==0
  d=r[i]//q[0];out.append(d)
  for j,v in enumerate(q):r[i+j]-=d*v
 assert not any(r)
 return out

def squarefree(p):
 a,b=p,ds(p)
 while b:a,b=b,rem(a,b)
 if a[0]<0:a=[-v for v in a]
 return div(p,primit(a))
def dN(p,l):
 return [v*comb(len(p)-1-i,l) for i,v in enumerate(p[:len(p)-l])]
def isol(p):
 # Sturm count (-inf,b]; endpoints can coincide with roots.
 seq=[p,ds(p)]
 while seq[-1]:
  seq.append([-v for v in rem(seq[-2],seq[-1])])
 seq.pop()
 B=2**28
 def v(x):
  pos=[]
  for q in seq:
   y=q[0]; den=B
   for a in q[1:]:
    y=x*y+den*a;den*=B
   if y:pos.append(y>0)
  return sum(a!=b for a,b in zip(pos,pos[1:]))
 def rec(l,h,vl,vh):
  if vl==vh:return []
  if h-l==1:assert vl-vh==1;return [(F(l,B),F(h,B))]
  mid=(l+h)//2;vm=v(mid)
  return rec(l,mid,vl,vm)+rec(mid,h,vm,vh)
 a,b=-10*B,10*B
 assert v(a)-v(b)==len(p)-1, "isolating interval misses a root"
 return rec(a,b,v(a),v(b))

def interval(p,x):
 l=h=p[0]
 for a in p[1:]:
  b=[z*v for z in x for v in [l,h]];l=min(b)+a;h=max(b)+a
 return l,h


def feasible(A,b):
 # column dictionary simplex. Artificial starting basis, phase I maximize minus artificial sum.
 m=len(b);n=len(A[0])
 if n==0:return False,[],[]
 mat=[];base=[n+i for i in range(m)]
 for i,row in enumerate(A):
  sign=1 if b[i]>=0 else -1
  mat.append([F(v*sign) for v in row]+[F(int(i==j)) for j in range(m)]+[F(b[i]*sign)])
 c=[0]*n+[-1]*m
 while 1:
  basic=set(base)
  j=next((j for j in range(n+m) if j not in basic and c[j]>sum(c[bi]*r[j] for bi,r in zip(base,mat))),None)
  if j is None:break
  i=min((i for i,r in enumerate(mat) if r[j]>0),key=lambda i:(mat[i][-1]/mat[i][j],base[i]))
  p=mat[i][j];nr=[t/p for t in mat[i]];mat[i]=nr
  for k,r in enumerate(mat):
   if k!=i and r[j]: f=r[j];mat[k]=[x-y*f for x,y in zip(r,nr)]
  base[i]=j
 val=sum(c[bi]*r[-1] for bi,r in zip(base,mat))
 if val==0:
  return True,[(bi,r[-1]) for bi,r in zip(base,mat) if bi<n and r[-1]],None
 # dual y A >= 0, y b<0
 y=[(1 if b[i]>=0 else -1)*sum(c[bi]*r[n+i] for bi,r in zip(base,mat)) for i in range(m)]
 assert all(sum(yi*row[j] for yi,row in zip(y,A))>=0 for j in range(n)) and sum(yi*bi for yi,bi in zip(y,b))<0
 return False,None,y


def project(q): # Q(sqrt5), b=(1+sqrt5)/2
 a,b=0,0
 for c in q:a,b=b+c,a+b
 return F(a)+F(b,2),F(b,2)
def prod(t,u):return(t[0]*u[0]+5*t[1]*u[1],t[0]*u[1]+t[1]*u[0])
def sqr(t):
 if t<0:return False
 return isqrt(t.numerator)**2==t.numerator and isqrt(t.denominator)**2==t.denominator
def sqK(t):
 a,b=t
 if b==0:return sqr(a) or sqr(a/5)
 N=a*a-5*b*b
 if not sqr(N):return False
 z=F(isqrt(N.numerator),isqrt(N.denominator))
 return sqr((a+z)/2) or sqr((a-z)/2)
def cliques(P,X,R,adj):
 if not P and not X:yield R
 u=max(P|X,key=lambda y:len(P & adj[y]),default=None)
 for v in sorted(P - (adj[u] if u is not None else set())):
  yield from cliques(P&adj[v],X&adj[v],R|{v},adj)
  P=P-{v};X=X|{v}



def euler_pass(c, max_length):
    # c_j = a_j/2^(j-1) for chi_(S_i+I); all calculations below are exact.
    n = len(c)-1
    if any(x % 2 for x in c[2::2]):
        return False
    assert c[:3] == [2, (-n) % 4, 0]
    b = [1]
    for m in range(2, max_length+1, 2):
        b.append((2*c[m+1]+c[m]+2*c[m-1]*c[3]) % 4)
        b.append((-n*c[m+1]) % 4)
    if b[1] or any(x % 2 for x in b[1::2]):
        return False
    power = [0]
    for m in range(1, max_length+1):
        power.append(-m*b[m]-sum(b[i]*power[m-i] for i in range(1,m)))
    walks = {4: power[4]+power[2]+2*power[1],
             6: power[6]+power[3]+2*power[2]+2*power[1]}
    if max_length == 8:
        walks[8] = power[8]+power[4]+2*power[2]+4*power[1]
    return all(v % (2*(m & -m)) == 0 for m,v in walks.items())


def make(r):
 p=r['tail'][:]
 for k,num in [(8,40),(-1,r['plus']),(1,r['minus'])]:
  for _ in range(num):p=mul(p,[1,k])
 g=squarefree(p); common=div(p,g);D=len(g)-2
 # first two coefficients in resolvent r/g at infinity
 second=2*g[1]-11
 third=2*g[2]-11*g[1]+89
 opts=[[2,second,third]]
 for k in range(3,D+1):
  l=D-k; roots=isol(dN(g,l)); next_opt=[]
  for q in opts:
   c=dN(q+[0]+[0]*l,l)
   lo=None; hi=None
   for j,x in enumerate(roots):
    a,b=interval(c,x)
    if (len(roots)-1-j)%2:
     hi=floor(-a) if hi is None else min(hi,floor(-a))
    else:
     lo=ceil(-b) if lo is None else max(lo,ceil(-b))
   assert lo is not None and hi is not None
   for v in range(lo,hi+1):
    next_opt.append(q+[v])
  opts=next_opt

 target=[2*v for v in div(ds(p),common)]
 return common, [q for q in opts if val(q,-8)], target



def positive_tests():
    # Dyadic Sturm endpoint handling, multiplicities and nonreal pairs.
    assert real([1,0,-1]) and real([1,0,-2,0,1])
    assert not real([1,0,1]) and not real([1,0,2,0,1])
    assert len(isol([1,0,-1])) == 2
    assert sqK((F(6),F(2))) and not sqK((F(2),F(0)))
    ok, sol, _ = feasible([[1,1],[0,1]], [4,3])
    assert ok and dict(sol)=={0:1,1:3}
    # Actual order-57 Seidel matrices from equitable blow-ups. The block
    # quotient determines the 5 nontrivial roots. The other eigenvalues
    # of S+I are zero because rows within each group coincide.
    import random
    rng=random.Random(92317)
    sizes=[2,4,9,16,26]
    for _ in range(40):
        q=[[0]*5 for _ in range(5)]
        for i in range(5):
            q[i][i]=sizes[i]
            for j in range(i):
                sign=rng.choice([-1,1]);q[i][j]=sign*sizes[j];q[j][i]=sign*sizes[i]
        powers=[[int(i==j) for j in range(5)] for i in range(5)]
        t=[0]; coeff=[1]
        for k in range(1,6):
            powers=[[sum(powers[i][j]*q[j][a] for j in range(5)) for a in range(5)] for i in range(5)]
            t.append(sum(powers[i][i] for i in range(5)))
            v=-sum(coeff[k-i]*t[i] for i in range(1,k+1))
            assert v%k==0
            coeff.append(v//k)
        coeff += [0]*52
        assert all(x%(1<<(j-1))==0 for j,x in enumerate(coeff[1:],1))
        c=[2]+[(x//(1<<(j-1)))%4 for j,x in enumerate(coeff[1:],1)]
        assert euler_pass(c,8)

def primitive_certificate(vector):
    den=lcm(*(v.denominator for v in vector))
    w=[int(v*den) for v in vector]
    g=reduce(gcd,w)
    return [v//g for v in w]

def dot(u,v):
    return sum(a*b for a,b in zip(u,v))

def verify_lp(deck,target):
    ok, primal, dual=feasible(list(zip(*deck)),target)
    if ok:
        assert all(sum(a*deck[i][j] for i,a in primal)==t for j,t in enumerate(target))
        return None
    y=primitive_certificate(dual)
    assert all(dot(y,q)>=0 for q in deck) and dot(y,target)<0
    return y

def unique_solution(deck,target):
    mat=[[F(v) for v in row]+[F(t)] for row,t in zip(zip(*deck),target)]
    n=len(deck)
    for i in range(n):
        k=next(k for k in range(i,len(mat)) if mat[k][i])
        mat[i],mat[k]=mat[k],mat[i]
        d=mat[i][i];mat[i]=[x/d for x in mat[i]]
        for k in range(len(mat)):
            if k!=i:
                d=mat[k][i];mat[k]=[x-d*y for x,y in zip(mat[k],mat[i])]
    assert not any(any(row) for row in mat[n:])
    return [mat[i][-1] for i in range(n)]

def close_last(deck,target):
    e=[project(q) for q in deck]
    adj={i:{j for j in range(len(e)) if j!=i and sqK(prod(e[i],e[j]))} for i in range(len(e))}
    results=[]
    for cl in cliques(set(adj),set(),set(),adj):
        ix=sorted(cl);ds=[deck[i] for i in ix]
        y=verify_lp(ds,target)
        if y is not None:
            results.append(dict(indices=ix,farkas=y))
        else:
            sol=unique_solution(ds,target)
            assert any(x.denominator!=1 for x in sol)
            results.append(dict(indices=ix,unique_solution=[str(x) for x in sol]))
    assert len(results)==5
    return results

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    positive_tests()
    rows=[]
    for m in range(1,7):
        for a in range(19-m):
            b=18-m-a
            for h in tails(m,1-a+b):
                row=dict(m=m,plus=a,minus=b,tail=h)
                common, deck, target=make(row)
                data=[(q,[v%4 for v in shift(mul(common,q),-6)]) for q in deck]
                row['target']=target
                for length in (6,8):
                    ds=[q for q,c in data if euler_pass(c,length)]
                    assert ds
                    y=verify_lp(ds,target)
                    case=dict(deck=ds,farkas=y)
                    if y is None:
                        assert length==6 and row['tail']==[1,1,-4,-3,4,1,-1]
                        case['cliques']=close_last(ds,target)
                    row['m'+str(length)]=case
                rows.append(row)
                print(len(rows),m,a,b,len(row['m6']['deck']),len(row['m8']['deck']),flush=True)
    assert len(rows)==18 and all(r['m8']['farkas'] for r in rows)
    assert sum(r['m6']['farkas'] is None for r in rows)==1
    print('All 18 polynomials excluded; every 58-line system in R^18 must have Seidel eigenvalue 11.')
    if args.output:
        args.output.write_text(json.dumps(rows,indent=2)+'\n')

if __name__=='__main__':
    main()

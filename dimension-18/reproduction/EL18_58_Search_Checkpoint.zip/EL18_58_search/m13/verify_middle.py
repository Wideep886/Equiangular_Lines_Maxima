"""Reconstruct each selected deck, independently check the square-class cover and certificates."""
import argparse,json,gzip,os,shutil
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from fastdeck import native
from lowmult import val,deriv,allowed_deck,monic_product
from lattice import lat
P=Path(__file__).resolve().parent

def members(s):
    while s:
        b=s&-s;yield b.bit_length()-1;s-=b

def checkjob(args):
    m,i,src,pure=args
    r=json.loads(src.read_text());fs=r['factors'];h=r['tail']
    assert m==r['m'] and monic_product([f for f,k in fs for _ in range(k)])==h+[0]*m
    # Re-derive squarefreeness requirements even when fs combines several simple factors.
    from verify_no11 import squarefree
    product=monic_product([[1,8]]+[f for f,k in fs])
    assert squarefree(product)==product
    f=[([1,8],40)]+fs
    g,b,deck=(allowed_deck if pure else native)(f)
    assert g==product and r['n']==len(deck)
    target=(58,*b[3:]);columns=[(1,*q[3:]) for q in deck]
    allmask=(1<<len(deck))-1
    cover=[allmask]
    for poly,p,a in r['splits']:
        assert [poly,1] in fs and p>=3 and p%2 and all(p%j for j in range(2,1+int(p**.5)))
        assert val(poly,a)%p==0 and val(deriv(poly),a)%p
        pos=neg=0
        for j,q in enumerate(deck):
            x=pow(val(q,a)%p,(p-1)//2,p)
            if x==1:pos|=1<<j
            if x==p-1:neg|=1<<j
        # Keep all distinct descendants. Each must be included in a recorded leaf.
        ss={z for s in cover for z in (s&~pos,s&~neg)}
        maximal=[]
        for s in sorted(ss,key=lambda x:-bin(x).count('1')):
            if all(s&t!=s for t in maximal):maximal.append(s)
        cover=maximal
    leaves={int(k,16) for k in r['alive']}|{int(k,16) for k,c in r['dead']}
    assert leaves==set(cover)
    dot=lambda x,y:sum(a*b for a,b in zip(x,y))
    for k,c in r['dead']:
        s=int(k,16)
        if c['kind']=='empty':assert not s;continue
        assert c['kind']=='farkas';y=c['y']
        assert len(y)==len(target) and all(isinstance(j,int) for j in y) and dot(y,target)<0
        assert all(dot(y,columns[j])>=0 for j in members(s))
    lattice_alive=[]
    for k in r['alive']:
        s=int(k,16)
        if lat([columns[j] for j in members(s)],target):lattice_alive.append(k)
    return [i,h,len(deck),len(r['alive']),len(lattice_alive)]

def main():
    a=argparse.ArgumentParser();a.add_argument('--m',type=int,default=13);a.add_argument('--up-to',type=int);a.add_argument('--pure',action='store_true');a.add_argument('--jobs',type=int,default=2);a.add_argument('--root',type=Path,default=P);a.add_argument('--output',type=Path);args=a.parse_args()
    d=args.root/f'm{args.m}';inputs=sorted(d.glob('[0-9]*.json'))
    if args.up_to is not None:inputs=[x for x in inputs if int(x.stem)<args.up_to]
    checks=[(args.m,int(f.stem),f,args.pure) for f in inputs];out=[]
    with ProcessPoolExecutor(args.jobs) as pool:
        for x in pool.map(checkjob,checks):out.append(x)
    print('checked, excluded over R, excluded over Z',len(out),sum(not v[-2] for v in out),sum(not v[-1] for v in out),flush=True)
    if args.output:args.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
if __name__=='__main__':main()

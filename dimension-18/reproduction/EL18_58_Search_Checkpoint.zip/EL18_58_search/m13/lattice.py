"""Decide membership in the integral column lattice with unimodular elimination."""
def gcdex(a,b):
 x0,y0,x1,y1=1,0,0,1
 while b:
  q,r=divmod(a,b)
  a,b=b,r;x0,x1=x1,x0-q*x1;y0,y1=y1,y0-q*y1
 sgn=1 if a>0 else -1
 return abs(a),sgn*x0,sgn*y0
def lat(columns,target):
 a=[list(c) for c in columns]
 t=list(target);j=0
 for row in range(len(t)):
  cand=next((i for i in range(j,len(a)) if a[i][row]),None)
  if cand is None:
   if t[row]:return False
   continue
  a[j],a[cand]=a[cand],a[j]
  for i in range(j+1,len(a)):
   x,y=a[j][row],a[i][row]
   if not y:continue
   g,s,u=gcdex(x,y);assert s*x+u*y==g
   a[j],a[i]=([s*v+u*w for v,w in zip(a[j],a[i])],[(-y//g)*v+(x//g)*w for v,w in zip(a[j],a[i])])
  x=a[j][row]
  if t[row]%x:return False
  mult=t[row]//x;t=[v-mult*w for v,w in zip(t,a[j])];j+=1
 return not any(t)


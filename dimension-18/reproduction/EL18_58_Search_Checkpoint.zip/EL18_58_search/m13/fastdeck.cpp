#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <string>
#include <unordered_map>

using I = __int128;
using L = long long;
using Key = uint64_t;
const int MAXD=24;
const L D=L(1)<<32;
struct Term { I low,high; };
struct Bound { bool neg; Term terms[MAXD];};
Bound bounds[MAXD][MAXD+1];
int weights[MAXD][58],phi[58][58],deg;
L q[MAXD];
std::unordered_map<Key,bool> cache[MAXD];
I plus(I a,I b){I n;if(__builtin_add_overflow(a,b,&n))throw std::runtime_error("128-bit addition overflow");return n;}
I times(I a,I b){I n;if(__builtin_mul_overflow(a,b,&n))throw std::runtime_error("128-bit multiplication overflow");return n;}
I readint(){
 std::string s;std::cin>>s;if(s.empty())throw std::runtime_error("empty input");I n=0;
 for(char c:s){if(c=='-')continue;if(c<'0'||c>'9')throw std::runtime_error("bad integer");
 n=plus(times(n,10),c-'0');}return s[0]=='-'?-n:n;
}
L narrow(I v){if(v>std::numeric_limits<L>::max()||v<std::numeric_limits<L>::min()+4)throw std::runtime_error("bound too large");return (L)v;}
L floorD(I x){return narrow(x>=0?x/D:-1-((-1-x)/D));}
bool allowed(Key key,int k){
 auto &C=cache[k];auto f=C.find(key);if(f!=C.end())return f->second;
 int n=k==deg?58:k+1;
 int c[58]={},b[58]={1},p[58]={};
 for(int j=0;j<=k;j++){
   int x=(key>>(2*j))&3;
   if(x)for(int i=j;i<n;i++) c[i]+=x*weights[j][i];
 }
 for(int i=0;i<n;i++)c[i]&=3;
 bool ok=true;for(int i=2;i<n;i+=2)if(c[i]&1){ok=false;break;}
 int z=1;
 if(ok)for(int i=2;i+1<n;i+=2){
   b[z++]=(2*c[i+1]+c[i]+2*c[i-1]*c[3])&3;
   b[z++]=(-57*c[i+1])&3;
 }
 if(ok&&z>1&&b[1])ok=false;
 if(ok)for(int i=1;i<z;i+=2)if(b[i]&1){ok=false;break;}
 // All moduli 2*(m & -m) for m<=56 divide 64.
 if(ok)for(int m=1;m<z;m++){
   int value=-m*b[m];
   for(int i=1;i<m;i++)value-=b[i]*p[m-i];
   p[m]=value&63;
   if(m>=4&&!(m&1)){int u=0;for(int d=1;d<=m;d++)u+=phi[m][d]*p[d];
     if(u%(2*(m&-m))){ok=false;break;}}
 }
 C[key]=ok;return ok;
}
void search(int k,Key key){
 if(k==deg+1){
   I v=0;for(int j=0;j<=deg;j++)v=plus(times(v,-8),q[j]);if(!v)return;
   for(int j=0;j<=deg;j++)std::cout<<q[j]<<(j==deg?'\n':' ');return;
 }
 L lo=std::numeric_limits<L>::min(),hi=std::numeric_limits<L>::max();
 for(int j=0;j<=k;j++){
   auto &bb=bounds[k][j];I total=0;
   for(int t=0;t<k;t++){
     auto &v=bb.terms[t];
     auto coeff=(q[t]>=0)==bb.neg?v.low:v.high;
     total=plus(total,times(q[t],coeff));
   }
   if(bb.neg)hi=std::min(hi,floorD(-total));else lo=std::max(lo,-floorD(total));
 }
 if(hi<lo)return;
 for(int r=0;r<4;r++){
   L first=lo+((r-(lo&3)+4)&3);
   if(first>hi)continue;
   auto next=key | (Key(r)<<(2*k));
   if(!allowed(next,k))continue;
   for(L v=first;v<=hi;v+=4){q[k]=v;search(k+1,next);}
 }
}
int main(){
 std::cin>>deg; if(deg<3||deg>=MAXD)return 2;
 for(int j=0;j<=deg;j++)for(int i=0;i<58;i++)std::cin>>weights[j][i];
 Key key=0;for(int j=0;j<3;j++){std::cin>>q[j];key|=Key(q[j]&3)<<(2*j);}
 for(int k=3;k<=deg;k++)for(int j=0;j<=k;j++){
   auto &bb=bounds[k][j];int neg;std::cin>>neg;bb.neg=neg;
   for(int i=0;i<k;i++){bb.terms[i].low=readint();bb.terms[i].high=readint();}
 }
 if(!std::cin)return 2;
 for(int m=1;m<58;m++)for(int d=1;d<=m;d++)if(m%d==0)for(int i=1;i<=m/d;i++)phi[m][d]+=(std::gcd(i,m/d)==1);
 search(3,key);
}

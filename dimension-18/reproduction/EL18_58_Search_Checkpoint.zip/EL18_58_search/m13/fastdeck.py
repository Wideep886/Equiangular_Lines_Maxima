from pathlib import Path
from subprocess import run
from fractions import Fraction as F
from math import comb
import json,sys,time,os
HERE=Path(__file__).resolve().parent
import lowmult
from lowmult import mul,deriv,shift,parts,isol,dN,monic_product
def native(factors):
    polys,mults=zip(*factors);g=monic_product(polys);deg=len(g)-2
    if not 3<=deg<24:return original(factors)
    common=monic_product([f for f,m in factors for i in range(m-1)])
    terms=[mul(part,deriv(f)) for part,f in zip(parts(polys),polys)]
    target=[2*sum(m*term[i] for m,term in zip(mults,terms)) for i in range(deg+1)]
    coords=[[0]*j+mul(shift(common,-6),shift([1]+[0]*(deg-j),-6)) for j in range(deg+1)]
    rows=[[deg]]+[[v%4 for v in col] for col in coords]+[[2,2*g[1]-11,2*g[2]-11*g[1]+89]]
    assert all(len(c)==58 for c in coords)
    B=2**28;D=2**32
    for k in range(3,deg+1):
        ell=deg-k;weights=[comb(deg-i,ell) for i in range(k)]
        roots=[(int(l*B),int(h*B)) for l,h in isol(dN(g,ell))]
        assert len(roots)==k+1
        for j,(l,h) in enumerate(roots):
            vals=[int(bool((j-k)%2))]
            for pos,w in enumerate(weights):
                exponent=k-pos
                vs=[F(l,B)**exponent,F(h,B)**exponent]
                if l<=0<=h:vs.append(0)
                low=min(vs)*w*D;high=max(vs)*w*D
                vals.extend([low//1,-((-high)//1)])
            rows.append(vals)
    result=run([str(HERE/'fastdeck')],input='\n'.join(' '.join(map(str,r)) for r in rows)+'\n',text=True,capture_output=True)
    if result.returncode: return original(factors)
    deck=[list(map(int,line.split())) for line in result.stdout.splitlines()]
    return g,target,deck
original=lowmult.allowed_deck
if __name__=='__main__':
    parents=json.loads(Path(sys.argv[1]).read_text())
    dest=Path(sys.argv[2]);dest.mkdir(exist_ok=True)
    lowmult.allowed_deck=native
    for a in sys.argv[3:]:
        i=int(a);t=time.monotonic();r=lowmult.screen(parents[i])
        p=dest/f'{i}.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r));tmp.replace(p)
        print(i,len(r['deck']),[b['cert']['kind'] for b in r['branches']],time.monotonic()-t,flush=True)

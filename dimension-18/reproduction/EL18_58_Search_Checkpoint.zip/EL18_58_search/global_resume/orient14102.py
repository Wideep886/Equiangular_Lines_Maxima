"""Orient the six simple conjugate eigenspaces using an occurring type of least index."""
from degree12 import *
from lowmult import mul
from itertools import product
from polynomial13 import rem
from fractions import Fraction
sys.path.insert(0,str(BASE/'m4_126'))
from spectrum import separator
def unit(strong=False):
    R=json.loads((P/'degree12/14102.json').read_text());h=R['tail'];ids=R['active'];fs=[([1,0],12),(h,1)]
    g,target,deck=native([([1,8],40)]+fs)
    # There are no rational factors of degree at most three. Gauss' lemma bounds
    # their coefficients by the elementary symmetric sums of roots of magnitude <=5.
    from math import comb
    from lowmult import isol
    assert len(h)==7 and all(-5<=a<=b<=5 for a,b in isol(h))
    for d in (1,2,3):
        for coeff in product(*(range(-comb(d,j)*5**j,comb(d,j)*5**j+1) for j in range(1,d)),
                              (v for v in range(-abs(h[-1]),abs(h[-1])+1) if v and h[-1]%v==0)):
            assert any(rem(list(h),[1,*coeff]))
    graph=dict.fromkeys(ids,sum(1<<k for k in ids));p,cap,opts=poly_types(graph,fs,g,deck,ids)
    C={a:(1,*deck[a][3:]) for a in ids}
    b=(58,*target[3:])
    def rep(q):return tuple(([0]*6+list(rem(list(q),h)))[-6:])
    def pro(q,r):return rep(tuple(mul(q,r)))
    import functools
    rep=functools.lru_cache(None)(rep);pro=functools.lru_cache(None)(pro)
    labels={k:tuple(v) for k,v in opts.items()}
    def pair(a,b):return labels.get(tuple(sorted((a,b))),())
    g=tuple(g);deck=list(map(tuple,deck));L=len(h)-1
    src=P/('oriented14102_joint.json' if strong else 'oriented14102.json');replay=src.exists();out=json.loads(src.read_text()) if replay else []
    for n,anchor in enumerate(ids):
        active=[j for j in ids[n:] if anchor==j or pair(j,anchor)]
        assert any(rep(deck[anchor]))
        # At the chosen anchor's conjugate simple roots, write vector labels up to individual orientation.
        U={j:(rep(pair(anchor,j)[0]) if j!=anchor else rep(deck[j])) for j in active}
        for j in active:
            assert any(U[j])
            assert pro(U[j],U[j])==pro(deck[anchor],deck[j])
        tvar={j:pro((2,11),U[j]) for j in active}
        pts=(-2,-1,0,1,2,3,4) if strong else ()
        # (f(t)-f(X))/(t-X) by synthetic division in the variable X.
        def divided(t):
            coeff=[h[0]]
            for v in h[1:-1]:coeff.append(v+t*coeff[-1])
            return tuple(2*t*(t+8)*k for k in coeff)
        def kernel(q,t,u):
            if t==u:return 2*(val(deriv(g),t)*val(q,t)-val(g,t)*val(deriv(q),t))
            return 2*(val(g,u)*val(q,t)-val(g,t)*val(q,u))//(u-t)
        extra_rhs={};extra_col={}
        if pts:
            for a in active:
                G=deck[a];u=U[a];D=[val(G,t) for t in pts];mass=[pro(divided(t),u) for t in pts]
                extra_rhs[a]=tuple((2*t+11)*v-4*val(g,t) for t,v in zip(pts,D))
                extra_rhs[a]+=tuple(kernel(G,t,v)-val(G,t)*val(G,v) for t,v in combinations_with_replacement(pts,2))
                extra_rhs[a]+=tuple(x-v*y for l,v in zip(mass,D) for x,y in zip(l,u))
        sets={}
        for j,k in combinations_with_replacement(active,2):
            ls=[]
            for w in pair(j,k):
                tang=pro(w,deck[anchor]);goal=pro(U[j],U[k])
                for s in [-1,1]:
                    if tuple(s*z for z in tang)==goal:ls.append((s,w))
            sets[j,k]=ls
        rec=[]
        def proof(cols,t,saved):
            if replay:
                if saved is None:return None
                if saved['kind']=='empty':assert not cols
                else:
                    y=saved['y'];assert len(y)==len(t) and sum(q*z for q,z in zip(t,y))<0 and all(sum(q*z for q,z in zip(c,y))>=0 for c in cols)
                return saved
            y=separator(cols,t)
            return None if y['kind']=='primal' else y
        roundno=0
        while anchor in active:
            cglobal=[C[k] for k in active];t=tuple(q-v for q,v in zip(b,C[anchor]))
            part=out[n]['rounds'][roundno] if replay and roundno<len(out[n]['rounds']) else {}
            c=proof(cglobal,t,part.get('global'))
            if c:rec.append({'global':c});active=[];break
            bad=[]
            for a in active:
                tail=tuple(x-y for x,y in zip(b,C[a]))
                q0=deck[a][-1];root=2*g[-2]
                Z=tuple(tvar[a])+tuple(-q0*z for z in U[a])
                t=tail+(11*q0,(root-q0)*q0)+Z
                t+=extra_rhs.get(a,())
                cs=[]
                for j in active:
                    for sign,w in sets[min(a,j),max(a,j)]:
                        z=w[-1];extra=()
                        if strong:
                            if (j,sign,w) not in extra_col:
                                W=tuple(val(w,t) for t in pts)
                                extra_col[j,sign,w]=W+tuple(x*y for x,y in combinations_with_replacement(W,2))+tuple(sign*x*y for x in W for y in U[j])
                            extra=extra_col[j,sign,w]
                        cs.append(C[j]+(z,z*z)+tuple(sign*q for q in U[j])+tuple(sign*z*q for q in U[j])+extra)
                c=proof(cs,t,next((v for j,v in part.get('bad',[]) if j==a),None))
                if c:bad.append([a,c])
            if not bad:break
            rec.append({'bad':bad});active=[a for a in active if a not in {j for j,_ in bad}];roundno+=1
        status={'anchor':anchor,'remaining':active if anchor in active else [],'rounds':rec}
        if replay:assert status==out[n]
        else:out.append(status)
    if not replay:src.write_text(json.dumps(out,separators=(',',':')))
    print('remaining anchors:',[(r['anchor'],len(r['remaining'])) for r in out if r['remaining']])
if __name__=='__main__':
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(Path(build)/'fastdeck')],check=True);init(build);unit(strong='--strong' in sys.argv)

"""Audit parent membership and deduplicate by the lexicographic index of the normalized tail."""
from screen import group_parents,P,BASE
from collections import Counter
import json,sys,importlib.util
def ranges(seq):
    spans=[]
    for i in seq:
        if spans and spans[-1][1]==i-1:spans[-1][1]=i
        else:spans.append([i,i])
    return spans
def main():
    gs=group_parents()
    rows=[json.loads(l) for l in (P/'rows.jsonl').read_text().splitlines()]
    m4src=BASE/'m4/status.py'
    spec=importlib.util.spec_from_file_location('m4status',m4src);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    s=module.status();left=[i for i,v in enumerate(s) if v.startswith('pending') or v=='open']
    ans={4:{'parents_file':'m4/parents.json','parent_count':len(s),'tested':len(s),'open_tested':left,'untested_ranges':[],'excluded':len(s)-len(left),'cursor':None,'stage_totals':dict(Counter(s))}}
    for m,ps in gs.items():
        # Map a record to its canonical index rather than summing run sizes.
        stage0={r[1]:r[-1] for r in rows if r[0]==m}
        assert all(r[2]==ps[r[1]] for r in rows if r[0]==m)
        seen=set(stage0);excluded={i for i,z in stage0.items() if not z}
        f=P/'zero'/str(m)
        det=[json.loads(q.read_text()) for q in f.glob('*.json')]
        assert {r['i'] for r in det}==set(stage0)-excluded
        excluded.update(r['i'] for r in det if not r['open'])
        local_survivors=sorted(seen-excluded)
        curve={'prefix_tested':len(stage0),'after_anchor':sum(bool(z) for z in stage0.values()),'after_joint_row':len(local_survivors)}
        if m==12:
            other=[json.loads(l) for l in (BASE/'m12_sweep/rows.jsonl').read_text().splitlines()]
            assert all(ps[r[0]]==r[1] for r in other)
            seen.update(r[0] for r in other)
            excluded.update(r[0] for r in other if not r[-1])
            pair=[json.loads(l) for l in (BASE/'m12_sweep/pairs.jsonl').read_text().splitlines()]
            assert {r[0] for r in pair}=={r[0] for r in other if r[-1]}
            excluded.update(r[0] for r in pair if not r[2])
            late=[json.loads(p.read_text()) for p in (P/'degree12').glob('*.json')]
            assert {r['index'] for r in late}==seen-excluded
            curve['before_full_polynomial']=len(seen-excluded)
            excluded.update(r['index'] for r in late if not r['open'])
            curve['after_full_polynomial']=len(seen-excluded)
            orient=P/'oriented14102_joint.json'
            if orient.exists():
                marks=json.loads(orient.read_text())
                ids=next(r['active'] for r in late if r['index']==14102)
                assert [r['anchor'] for r in marks]==ids
                curve['oriented_minimum_anchor_options']=sum(bool(v['remaining']) for v in marks)
                if not curve['oriented_minimum_anchor_options']:excluded.add(14102)
        assert seen==set(range(len(stage0))) if m<12 else len(seen)>=len(stage0)
        ans[m]={'parents_file':'global_resume/remaining.jsonl.gz (see README)','parent_count':len(ps),'tested':len(seen),'open_tested':sorted(seen-excluded),'untested_ranges':ranges(i for i in range(len(ps)) if i not in seen),'excluded':len(excluded),'cursor':next((i for i in range(len(ps)) if i not in seen),None),'stage_totals':curve}
    (P/'status.json').write_text(json.dumps(ans,indent=1)+'\n')
    for m,v in ans.items():print(m,v['parent_count'],v['tested'],v['excluded'],len(v['open_tested']),v['cursor'])
if __name__=='__main__':main()

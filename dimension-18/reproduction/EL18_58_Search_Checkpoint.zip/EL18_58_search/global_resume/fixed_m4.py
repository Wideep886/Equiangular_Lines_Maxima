"""Check every counted cofactor histogram against joint signed and quadratic polynomial row moments."""
import sys,json
from pathlib import Path
from itertools import combinations_with_replacement
P=Path(__file__).resolve().parent
M=P.parent/'m4'
sys.path.insert(0,str(M/'moment'))
from rows import collect,gram
from row import certificate
from lowmult import mul
def solve(k):
 r=json.loads((M/'results'/f'{k}.json').read_text());full=json.loads((M/'full'/f'{k}.json').read_text())
 hist,nodes=collect(k)
 assert hist is not None
 assert json.loads(json.dumps(hist))==json.loads((M/'moment'/f'hist{k}.json').read_text())
 edges={(a,b):ws for a,b,ws in full['coefficients']}
 path=P/f'fixed{k}.json';replay=path.exists();ledger=json.loads(path.read_text()) if replay else []
 remaining=[]
 for i,histogram in enumerate(hist):
  proof=None
  if replay and ledger[i]['verdict']=='open':
   remaining.append(i);continue
  for a,na in sorted(histogram,key=lambda t:t[1]):
   if replay and ledger[i].get('type')!=a:continue
   counts=[(j,n-int(j==a)) for j,n in histogram if n>int(j==a)]
   C=gram(r['g'],r['deck'][a]);n=len(C);ix=list(combinations_with_replacement(range(n),2))
   # Multiplication by S in the resolvent is (2t+11)W-4g I.
   prod=mul([2,11],r['deck'][a]);s=[v-4*b for v,b in zip(prod,r['g'])]
   assert s[:-n]==[0]*(len(s)-n)
   tar=tuple(m for j,m in counts)+tuple(s[-n:])+tuple(C[j][l] for j,l in ix)
   cols=[tuple(int(j==b) for j,m in counts)+tuple(w)+tuple(w[j]*w[l] for j,l in ix) for b,m in counts for w in edges.get(tuple(sorted((a,b))),[])]
   # Cheap one-dimensional cuts independently for each fixed group size.
   fail=None
   for d,t in enumerate(tar[len(counts):],len(counts)):
    lo=hi=0
    for g,(_,c) in enumerate(counts):
     v=[x[d] for x in cols if x[g]]
     if not v:fail='empty';break
     lo+=c*min(v);hi+=c*max(v)
    if fail or not lo<=t<=hi:fail=d;break
   if fail is not None:proof={'type':a,'verdict':'bounds','coordinate':fail}
   else:
    cert=certificate(cols,tar)
    if cert['kind']!='primal':proof={'type':a,'verdict':'row','certificate':cert}
   if proof:break
  if proof is None:remaining.append(i);proof={'verdict':'open'}
  if replay:assert proof==ledger[i]
  else:ledger.append(proof)
 if not replay:path.write_text(json.dumps(ledger,separators=(',',':')))
 print(k,nodes,len(hist),len(remaining),remaining,flush=True)
if __name__=='__main__':
 for s in sys.argv[1:]:solve(int(s))

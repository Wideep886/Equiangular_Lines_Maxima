"""Create/verify missing complete one-point superdecks and validate every separating integer vector."""
from pathlib import Path
from tempfile import TemporaryDirectory
from itertools import product
import subprocess
import os
import sys
import json
P=Path(__file__).resolve().parent
M=P.parent/'m4'
sys.path.insert(0,str(M))
import fastdeck,lowmult
def main():
    dest=P/'m4';dest.mkdir(exist_ok=True)
    ids=list(map(int,sys.argv[1:])) or list(range(415,419))
    parents=json.loads((M/'parents.json').read_text())
    with TemporaryDirectory() as work:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(M/'fastdeck.cpp'),'-o',str(Path(work)/'fastdeck')],check=True)
        fastdeck.HERE=Path(work)
        lowmult.allowed_deck=fastdeck.native
        for i in ids:
            r=lowmult.screen(parents[i])
            f=dest/f'{i}.json'
            if f.exists():assert json.loads(f.read_text())==json.loads(json.dumps(r))
            else:f.write_text(json.dumps(r,separators=(',',':')))
            assert [list(q) for q in product(*r['options'])]==[list(b['classes']) for b in r['branches']]
            for b in r['branches']:
                valid=[q for q in r['deck'] if all(not lowmult.val(q,t) or lowmult.sf(abs(lowmult.val(q,t)))==v for t,v in zip(r['simple_roots'],b['classes']))]
                cert=b['cert']
                if cert['kind']=='empty':assert not valid;continue
                assert cert['kind']=='farkas'
                y=cert['y'];dot=lambda q:sum(a*v for a,v in zip(y,q))
                assert dot([58]+list(r['target'][3:]))<0 and all(dot([1]+list(q[3:]))>=0 for q in valid)
            print(i,len(r['deck']),'excluded',flush=True)
if __name__=='__main__':main()

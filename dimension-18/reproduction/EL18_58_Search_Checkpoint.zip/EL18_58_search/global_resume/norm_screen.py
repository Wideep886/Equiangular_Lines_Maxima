"""Rank-one field norm tests, including each quadratic place mod p, on every surviving anchor."""
from screen import P,BASE,init,TemporaryDirectory,ProcessPoolExecutor,subprocess,os,argparse,sys,json
from itertools import product
from math import isqrt
from build import factors
from fastdeck import native
from anchor import indices,possible
from lpscreen import phase_one
from lattice import lat
from lowmult import val,deriv
from functools import lru_cache

def determinant(a):
    """Fraction-free elimination with exact Bareiss divisions."""
    a=[r[:] for r in a];sign=old=1
    for i in range(len(a)-1):
        j=next((j for j in range(i,len(a)) if a[j][i]),None)
        if j is None:return 0
        if i!=j:a[j],a[i]=a[i],a[j];sign=-sign
        pivot=a[i][i]
        for j in range(i+1,len(a)):
            for k in range(i+1,len(a)):
                v=a[j][k]*pivot-a[j][i]*a[i][k]
                assert not v%old
                a[j][k]=v//old
            a[j][i]=0
        old=pivot
    return sign*a[-1][-1]

def remainder(q,f):
    z=list(q)
    for j in range(len(z)-len(f)+1):
        t=z[j]
        for k,c in enumerate(f):z[j+k]-=t*c
    d=len(f)-1
    return ([0]*d+z)[-d:]

def field_norm(q,f):
    z=remainder(q,f);basis=[]
    for _ in f[1:]:
        basis.append(z[::-1])
        z=remainder(z+[0],f)
    return determinant(basis)

def pair_compatible(a,b):
    ab=a*b
    return ab>=0 and isqrt(ab)**2==ab

def quadratic_places(f):
    for p in [3,5,7,11,13,17,19]:
        residues={i*i%p for i in range(p)}
        for a,b in product(range(p),range(p)):
            if (a*a-4*b)%p in residues:continue
            g=(1,a,b)
            if not any(x%p for x in remainder(f,g)):yield p,g

def extend(m,i,h,n,rounds,count,return_graph=False):
    from anchor import PRIMES
    sf=[([1,0],m)]+factors(h)
    _,target,deck=native([([1,8],40)]+sf);assert n==len(deck)
    b=(58,*target[3:]);C=[(1,*q[3:]) for q in deck]
    simple=[tuple(f) for f,j in sf if j==1]
    A=set(range(n));nbr=[(1<<n)-1]*n
    for f in simple:
        for p in PRIMES:
            for a in range(p):
                if val(f,a)%p or not val(deriv(f),a)%p:continue
                s=[pow(val(q,a),(p-1)//2,p) for q in deck]
                u=sum(1<<j for j,v in enumerate(s) if v==1)
                v=sum(1<<j for j,w in enumerate(s) if w==p-1)
                if u and v:nbr=[t&({1:~v,p-1:~u}.get(w,-1)) for w,t in zip(s,nbr)]
    for r in rounds:
        dead={a for a in A if not possible([C[j] for j in sorted(A) if nbr[a]>>j&1],tuple(x-y for x,y in zip(b,C[a])))}
        assert len(dead)==r;A-=dead
    assert len(A)==count
    # The graph retains all one-point/square-class tests before adding any norms.
    graph={j:{k for k in A if j!=k and (nbr[j]>>k)&1} for j in A}
    cuts=[]
    def refine(values,where):
        changed=0
        for j in sorted(A):
            for k in list(graph[j]):
                if k<j or pair_compatible(values[j],values[k]):continue
                graph[j].remove(k);graph[k].remove(j);changed+=1
        if changed:cuts.append([where,changed])
    for f in simple:
        refine({j:field_norm(deck[j],f) for j in A},['rational',f])
        for p,g in quadratic_places(f):
            def char(q):
                a,b=remainder(q,g)
                v=(b*b-a*b*g[1]+a*a*g[2])%p
                return -1 if pow(v,(p-1)//2,p)==p-1 else int(bool(v))
            refine({j:char(deck[j]) for j in A},[p,g])
    if return_graph:return A,graph,deck,C,b,sf
    def maximal(R,cand,used):
        if not cand and not used:
            yield tuple(sorted(R));return
        pivot=max(sorted(cand|used),key=lambda t:len(cand&graph[t]))
        for j in sorted(cand-graph[pivot]):
            yield from maximal(R|{j},cand&graph[j],used&graph[j])
            cand.remove(j);used.add(j)
    cover=[]
    for ids in maximal(set(),set(A),set()):
        cols=[C[j] for j in ids]
        if not lat(cols,b):cert={'kind':'lattice'}
        else:cert=phase_one(cols,b)
        cover.append([ids,cert])
        if cert['kind']=='primal':break
    return {'m':m,'i':i,'tail':h,'anchor_types':sorted(A),'norm_reductions':cuts,'cover':cover,'open':cover[-1][1]['kind']=='primal'}

def run(arg):
    r,verify=arg;folder=P/'norms'/str(r[0]);folder.mkdir(parents=True,exist_ok=True)
    p=folder/f'{r[1]}.json'
    if p.exists() and not verify:return
    v=extend(*r)
    if verify:assert json.loads(p.read_text())==json.loads(json.dumps(v))
    else:
        temp=p.with_suffix('.tmp');temp.write_text(json.dumps(v,separators=(',',':')));temp.replace(p)
    return v['m'],v['i'],v['open']

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('--jobs',type=int,default=2);cli.add_argument('--verify',action='store_true');args=cli.parse_args()
    rows=[json.loads(l) for l in (P/'rows.jsonl').read_text().splitlines()]
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(__import__('pathlib').Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(args.jobs,initializer=init,initargs=(build,)) as pool:
            for result in pool.map(run,[(r,args.verify) for r in rows if r[-1]]):
                if result:print(*result,flush=True)

"""Reconstruct a tenable superset of signed pair polynomials using independent Vandermonde interpolation."""
from degree12 import *
from itertools import product
from math import isqrt
from polynomial13 import rem,mul
from lowmult import monic_product

def inv_mod(matrix,p):
    n=len(matrix);w=[r[:]+[int(i==j) for j in range(n)] for i,r in enumerate(matrix)]
    for k in range(n):
        j=next(v for v in range(k,n) if w[v][k]%p);w[k],w[j]=w[j],w[k]
        v=pow(w[k][k],-1,p);w[k]=[z*v%p for z in w[k]]
        for j in range(n):
            if j!=k:
                v=w[j][k];w[j]=[(a-v*b)%p for a,b in zip(w[j],w[k])]
    return [r[n:] for r in w]

def verify(task,labels_only=False):
    i,h,initial=task
    src=json.loads((P/'degree12'/f'{i}.json').read_text())
    fs=[([1,0],12)]+factors(h)
    g,b,deck=native([([1,8],40)]+fs);p=src['prime'];simple=monic_product([f for f,k in fs if len(f)>2]);n=len(g)-2
    assert p>2 and all(p%k for k in range(2,isqrt(p)+1))
    from fully import gram
    limits={i:[isqrt(row[t]) for t,row in enumerate(gram(g,deck[i]))] for i in initial}
    assert 2*max(max(r) for r in limits.values())<p
    ints=[(-f[1],k) for f,k in fs if len(f)==2]
    roots=[t for t in range(p) if not val(simple,t)%p]
    xs=[t for t,k in ints]+roots;assert len(xs)==n==len(set(t%p for t in xs))
    V=inv_mod([[pow(t,k,p) for k in reversed(range(n))] for t in xs],p)
    squares={a*a%p:a for a in range(p//2+1)}
    def options(a,b):
        A,B=deck[a],deck[b]
        intsvals=[]
        for t,k in ints:
            ab=val(A,t)*val(B,t);r=isqrt(ab)
            intsvals.append([v for v in range(-r,r+1) if (v*v-ab)%4==0 and (k!=1 or v*v==ab)])
        rest=[]
        for t in roots:
            v=squares.get(val(A,t)*val(B,t)%p)
            if v is None:return []
            rest.append(sorted({v,-v%p}))
        out=[];prod0=mul(A,B)
        for z in product(*intsvals,*rest):
            if sum(i*j for i,j in zip(V[0],z))%p!=1:continue
            w=[(sum(i*j for i,j in zip(row,z))+p//2)%p-p//2 for row in V]
            if any(abs(k)>min(l,r) for k,l,r in zip(w,limits[a],limits[b])):continue
            if not all(val(w,t)==k for (t,m),k in zip(ints,z)):continue
            delta=[x-y for x,y in zip(prod0,[0,0]+mul(w,w))]
            if any(x%4 for x in delta) or any(rem(delta,simple)) or val(delta,-8)<0:continue
            out.append(w)
        return out
    z=(-2,-1,0,1);C={i:(1,*deck[i][3:]) for i in initial};b=(58,*b[3:])
    if labels_only:return deck,g,b,{(i,j):list(map(tuple,options(i,j))) for i,j in combinations_with_replacement(sorted(initial),2)}
    E={(i,j):[tuple(val(q,x) for x in z) for q in options(i,j)] for i,j in combinations_with_replacement(sorted(initial),2)}
    active=set(initial)
    for phase in src['ledger']:
        for j,c in phase:
            a=deck[j];v=[val(a,x) for x in z]
            t=tuple(s-y for s,y in zip(b,C[j]))+tuple((11+2*x)*vv-4*val(g,x) for x,vv in zip(z,v))
            addition=[]
            for u,v2 in combinations_with_replacement(range(4),2):
                x,y=z[u],z[v2]
                e=2*(val(deriv(g),x)*val(a,x)-val(g,x)*val(deriv(a),x)) if x==y else 2*(val(g,y)*val(a,x)-val(g,x)*val(a,y))//(y-x)
                addition.append(e-v[u]*v[v2])
            t+=tuple(addition)
            col={C[k]+v+tuple(s*t for l,s in enumerate(v) for t in v[l:]) for k in active for v in E[min(k,j),max(k,j)]}
            if c['kind']=='empty':assert not col
            elif c['kind']=='lattice':assert not lat(sorted(col),t)
            else:
                sy=c['y'];D=lambda col:sum(s*t for s,t in zip(col,sy))
                assert len(sy)==len(t) and D(t)<0 and all(D(c)>=0 for c in col)
        active-=set(j for j,c in phase)
    assert sorted(active)==sorted(src['active'])
    if active and not src['open']:
        y=src['global_test']
        if y['kind']=='farkas':
            D=lambda c:sum(s*t for s,t in zip(c,y['y']))
            assert D(b)<0 and all(D(C[k])>=0 for k in active)
        else:assert not lat([C[k] for k in sorted(active)],b)
    return i,len(active)
if __name__=='__main__':
    gs=group_parents()[12];old={r[0]:r[2] for l in (BASE/'m12_sweep/pairs.jsonl').read_text().splitlines() if (r:=json.loads(l))}
    prefix={r['i']:r['active'] for p in (P/'zero/12').glob('*.json') if (r:=json.loads(p.read_text()))['open']}
    tasks=[(i,gs[i],(prefix|old)[i]) for i in sorted(set(prefix)|{j for j,ids in old.items() if ids})]
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(2,initializer=init,initargs=(build,)) as pool:
            for q in pool.map(verify,tasks):print(*q,flush=True)

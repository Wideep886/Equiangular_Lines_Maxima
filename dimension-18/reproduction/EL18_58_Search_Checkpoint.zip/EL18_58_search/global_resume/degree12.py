"""Integer polynomial pair labels and joint moments for the m=12 survivors of both scans."""
from screen import P,BASE,group_parents,init,ProcessPoolExecutor,TemporaryDirectory,subprocess,os,sys,json
from pathlib import Path
sys.path.insert(0,str(BASE/'audit_layer'))
from polynomial13 import poly_types,deriv,val
from rows13 import native,factors,lat,phase_one
from itertools import combinations_with_replacement
def solve(task, multiplicity=12, output=None, points=None):
    i,h,active=task;f=(output or P/'degree12')/f'{i}.json';f.parent.mkdir(exist_ok=True)
    replay=f.exists();stored=json.loads(f.read_text()) if replay else None
    fs=[([1,0],multiplicity)]+factors(h)
    assert all(k==1 or len(p)==2 for p,k in fs)
    g,target,deck=native([([1,8],40)]+fs)
    graph=dict.fromkeys(active,sum(1<<j for j in active))
    prime,cap,options=poly_types(graph,fs,g,deck,active)
    z=list(range(-2,2) if points is None else points);Q={w:tuple(val(w,x) for x in z) for opt in options.values() for w in opt}
    ix=list(combinations_with_replacement(range(len(z)),2));diag={a:[val(deck[a],x) for x in z] for a in active}
    C={a:(1,*deck[a][3:]) for a in active};b=(58,*target[3:])
    rhs={}
    for a in active:
        d=diag[a];t=[x-y for x,y in zip(b,C[a])]+[(2*x+11)*o-4*val(g,x) for x,o in zip(z,d)]
        for u,v in ix:
            x,y=z[u],z[v]
            if x==y:v0=2*(val(deriv(g),x)*d[u]-val(g,x)*val(deriv(deck[a]),x))
            else:
                num=2*(val(g,y)*d[u]-val(g,x)*d[v]);assert not num%(y-x);v0=num//(y-x)
            t.append(v0-d[u]*d[v])
        rhs[a]=tuple(t)
    ledger=[];step=0
    while active:
        bad=[]
        for a in active:
            skip=None
            if replay:
                skip=next((v for v in (stored['ledger'][step] if step<len(stored['ledger']) else []) if v[0]==a),None)
                if not skip:continue
            col=sorted({C[j]+Q[w]+tuple(Q[w][u]*Q[w][v] for u,v in ix) for j in active for w in options.get(tuple(sorted((a,j))),())})
            t=rhs[a]
            if replay:
                v=skip[1]
                if v['kind']=='empty':assert not col
                elif v['kind']=='lattice':assert not lat(col,t)
                else:
                    y=v['y'];dot=lambda c:sum(v*w for v,w in zip(y,c))
                    assert len(y)==len(t) and dot(t)<0 and all(dot(c)>=0 for c in col)
            elif not col:v={'kind':'empty'}
            elif not lat(col,t):v={'kind':'lattice'}
            else:v=phase_one(col,t)
            if v['kind']!='primal':bad.append([a,v])
        if not bad:break
        active=[a for a in active if a not in {j for j,v in bad}];ledger.append(bad);step+=1
    cert={'kind':'empty'} if not active else phase_one([C[a] for a in active],b)
    out=dict(index=i,tail=h,prime=prime,active=active,open=bool(active and cert['kind']=='primal' and lat([C[a] for a in active],b)),ledger=ledger,global_test=cert)
    if replay:assert stored==json.loads(json.dumps(out))
    else:f.write_text(json.dumps(out,separators=(',',':')))
    return i,len(options),len(active),out['open']
if __name__=='__main__':
    gs=group_parents()[12];old={r[0]:r[2] for l in (BASE/'m12_sweep/pairs.jsonl').read_text().splitlines() if (r:=json.loads(l))}
    prefix={r['i']:r['active'] for p in (P/'zero/12').glob('*.json') if (r:=json.loads(p.read_text()))['open']}
    jobs=[(i,gs[i],(prefix|old)[i]) for i in sorted(set(prefix)|{j for j,ids in old.items() if ids})]
    assert len(jobs)==11
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(2,initializer=init,initargs=(build,)) as pool:
            for r in pool.map(solve,jobs):print(*r,flush=True)

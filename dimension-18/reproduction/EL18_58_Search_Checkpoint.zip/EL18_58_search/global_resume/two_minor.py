"""Complete coefficientwise square congruence for the two-point Jacobi resolvent identity."""
from norm_screen import *
from lowmult import mul

def compatible(p,q):
    z=[a%4 for a in mul(p,q)];assert z[0]==0
    z=z[2:]
    # Strip the two leading coefficients of the product; the first has degree 2d,
    # the second 2d-1, both must vanish since the off-diagonal degree is d-1.
    if (p[0]*q[1]+p[1]*q[0])%4:return False
    w=[v%2 for v in z[::2]]
    return all((a-b)%4==0 for a,b in zip(mul(w,w),z))

def maximal(R,cand,used,graph):
    if not cand and not used:
        yield tuple(sorted(R));return
    pivot=max(sorted(cand|used),key=lambda t:len(cand&graph[t]))
    for j in sorted(cand-graph[pivot]):
        yield from maximal(R|{j},cand&graph[j],used&graph[j],graph)
        cand.remove(j);used.add(j)

def run(arg):
    row,verify=arg;m,i=row[:2];folder=P/'two_minor'/str(m);folder.mkdir(parents=True,exist_ok=True)
    dest=folder/f'{i}.json'
    if dest.exists() and not verify:return
    A,g,d,C,b,sf=extend(*row,return_graph=True)
    removed=0
    for j in sorted(A):
        for k in list(g[j]):
            if k>j and not compatible(d[j],d[k]):g[j].remove(k);g[k].remove(j);removed+=1
    cover=[];open_=False
    for ids in maximal(set(),set(A),set(),g):
        # Distinct vertices may have the same type. A type incompatible with itself
        # is usable at most once; ignoring these additional caps weakens the cut.
        cols=[C[j] for j in ids];cert={'kind':'lattice'} if not lat(cols,b) else phase_one(cols,b)
        cover.append([ids,cert])
        if cert['kind']=='primal':open_=True;break
    out=dict(m=m,i=i,open=open_,edges_removed=removed,cover=cover)
    if verify:assert json.loads(dest.read_text())==json.loads(json.dumps(out))
    else:dest.write_text(json.dumps(out,separators=(',',':')))
    return (m,i,open_,removed)

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('--jobs',type=int,default=2);cli.add_argument('--verify',action='store_true');args=cli.parse_args()
    rows=[json.loads(l) for l in (P/'rows.jsonl').read_text().splitlines()]
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(__import__('pathlib').Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(args.jobs,initializer=init,initargs=(build,)) as ex:
            for v in ex.map(run,[(r,args.verify) for r in rows if r[-1]]):
                if v:print(*v,flush=True)

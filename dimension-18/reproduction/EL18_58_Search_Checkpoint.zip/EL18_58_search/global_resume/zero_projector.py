"""A shared signed row equation for the zero-root projector applies to every multiplicity."""
from two_minor import *
from lowmult import deriv
from lowmult import monic_product

def one(arg):
    row,verify=arg
    m,i=row[:2];dest=P/'zero'/str(m)/f'{i}.json';dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists() and not verify:return
    A,g,deck,C,b,fs=extend(*row,return_graph=True)
    poly=monic_product([[1,8]]+[f for f,k in fs]);scale=2*val(deriv(poly),0)
    allowed={}
    for a in A:
        for j in g[a]|{a}:
            if not compatible(deck[a],deck[j]):continue
            h=deck[a][-1]*deck[j][-1]
            if h<0:continue
            bound=isqrt(h)
            allowed[a,j]=[n for n in range(-bound,bound+1) if (n*n-h)%4==0]
    eliminations=[];active=A.copy()
    while active:
        bad=[]
        for a in sorted(active):
            z=deck[a][-1]
            cols=sorted({C[j]+(w,w*w) for j in active for w in allowed.get((a,j),[])})
            t=tuple(v-k for v,k in zip(b,C[a]))+(11*z,scale*z-z*z)
            # Eliminating the saturated leading column with its known sum also permits
            # a rapid trivial infeasibility check via the full lattice.
            if not cols:cert={'kind':'empty'}
            elif not lat(cols,t):cert={'kind':'lattice'}
            else:cert=phase_one(cols,t)
            if cert['kind']!='primal':bad.append([a,cert])
        if not bad:break
        eliminations.append(bad);active-=set(a for a,_ in bad)
    cover=[];open_=False
    if active:
        graph={a:{j for j in active if j!=a and allowed.get((a,j))} for a in active}
        for ids in maximal(set(),set(active),set(),graph):
            cols=[C[j] for j in ids];cert={'kind':'lattice'} if not lat(cols,b) else phase_one(cols,b)
            cover.append([ids,cert])
            if cert['kind']=='primal':open_=True;break
    out=dict(m=m,i=i,scale=scale,removed=eliminations,active=sorted(active),cover=cover,open=open_)
    if verify:assert json.loads(dest.read_text())==json.loads(json.dumps(out))
    else:dest.write_text(json.dumps(out,separators=(',',':')))
    return m,i,open_,len(active)

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('--jobs',type=int,default=2);cli.add_argument('--verify',action='store_true');args=cli.parse_args()
    rows=[json.loads(s) for s in (P/'rows.jsonl').read_text().splitlines()]
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(__import__('pathlib').Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(args.jobs,initializer=init,initargs=(build,)) as ex:
            for r in ex.map(one,[(r,args.verify) for r in rows if r[-1]]):
                if r:print(*r,flush=True)

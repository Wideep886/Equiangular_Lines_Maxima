"""Resume or verify the prefix of each layer against the complete lexicographically indexed catalogue."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import argparse
import gzip
import json
import os
import subprocess
import sys

P = Path(__file__).resolve().parent
BASE = P.parent
sys.path.insert(0, str(BASE/'m13'))

def group_parents():
    catalog=P/'remaining.jsonl.gz'
    if not catalog.exists():
        with ZipFile(BASE.parent/'EL18_58_Research_20261121.zip') as z:
            catalog.write_bytes(z.read('EL18_58/combined/remaining.jsonl.gz'))
    groups={m:[] for m in range(5,13)}
    with gzip.open(catalog,'rt') as f:
        for line in f:
            p=json.loads(line)
            m=next(i for i,x in enumerate(reversed(p)) if x)
            if m in groups:groups[m].append(p[:-m])
    return {m:sorted(g) for m,g in groups.items()}

def init(build):
    import fastdeck
    fastdeck.HERE=Path(build)

def task(arg):
    from anchor import anchor
    m,i,h,pure=arg
    return [m,i,h,*anchor(m,h,pure)]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--end',type=int,default=128)
    ap.add_argument('--jobs',type=int,default=2)
    ap.add_argument('--verify',action='store_true')
    arg=ap.parse_args()
    groups=group_parents()
    fn=P/'rows.jsonl'
    saved={(r[0],r[1]):r for line in (fn.read_text().splitlines() if fn.exists() else []) if (r:=json.loads(line))}
    assert all(groups[m][i]==r[2] for (m,i),r in saved.items())
    batch=[(m,i,groups[m][i],arg.verify and i%64==0) for i in range(arg.end) for m in groups
           if arg.verify or (m,i) not in saved]
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(arg.jobs,initializer=init,initargs=(build,)) as ex,fn.open('a',buffering=1) as out:
            for r in ex.map(task,batch,chunksize=1):
                if arg.verify:assert saved[r[0],r[1]]==r
                else:print(json.dumps(r,separators=(',',':')),file=out)
    print(len(batch),'verified' if arg.verify else 'processed',flush=True)
if __name__=='__main__':main()

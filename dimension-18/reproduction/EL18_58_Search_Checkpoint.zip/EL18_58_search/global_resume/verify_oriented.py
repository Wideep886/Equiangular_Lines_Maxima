"""Recheck the oriented sextic cuts using independent pair interpolation and multiplication in Q[X]/f."""
from replay12 import *
from functools import lru_cache
def audit():
    r=json.loads((P/'degree12/14102.json').read_text());h=r['tail'];I=r['active']
    deck,g,b,Q=verify((14102,h,I),labels_only=True)
    rows=json.loads((P/'oriented14102_joint.json').read_text());assert [x['anchor'] for x in rows]==I
    C=[(1,*q[3:]) for q in deck];T=list(range(-2,5))
    @lru_cache(None)
    def red(a):return tuple(([0]*6+rem(list(a),h))[-6:])
    @lru_cache(None)
    def times(a,b):return red(tuple(mul(a,b)))
    def subtract(a,b):return tuple(x-y for x,y in zip(a,b))
    def scale(v,s):return tuple(s*x for x in v)
    def rootdiv(z,u):
        # Horner expansion of U times (f(t)-f(X))/(t-X). Verify the defining field equation.
        D=tuple(h[0:1])
        for v in h[1:-1]:D=(*D,z*D[-1]+v)
        w=scale(times(D,u),2*z*(z+8))
        assert times((1,-z),w)==scale(u,-2*val(g,z))
        return w
    def get(a,b):return Q[tuple(sorted((a,b)))]
    def dot(a,b):return sum(x*y for x,y in zip(a,b))
    ncuts=0
    for row in rows:
        e=row['anchor'];S=set(j for j in I if j>=e and (j==e or get(e,j)))
        # Independent interpolation can enumerate the two representatives in the opposite order.
        # Stored duals use the first lexicographic representative (the spectrum builder sorts them).
        U={j:(red(tuple(deck[e])) if j==e else red(min(get(e,j)))) for j in S}
        for a in S:assert times(U[a],U[a])==times(tuple(deck[a]),tuple(deck[e]))
        rhs={}
        for a in S:
            d=deck[a];u=U[a];q=d[-1];z=tuple(val(d,t) for t in T)
            energy=[]
            for j,l in combinations_with_replacement(range(7),2):
                t,v=T[j],T[l]
                if j==l:k=2*(val(deriv(g),t)*z[j]-val(g,t)*val(deriv(d),t))
                else:k=2*(val(g,t)*z[l]-val(g,v)*z[j])//(t-v)
                energy.append(k-z[j]*z[l])
            rhs[a]=subtract(b,C[a])+(11*q,(2*g[-2]-q)*q)+times((2,11),u)+scale(u,-q)
            rhs[a]+=tuple((2*t+11)*z[j]-4*val(g,t) for j,t in enumerate(T))+tuple(energy)
            rhs[a]+=tuple(v for t,j in zip(T,z) for v in subtract(rootdiv(t,u),scale(u,j)))
        @lru_cache(None)
        def cols(a,j):
            col=[]
            for w in get(a,j):
                z=tuple(val(w,t) for t in T)
                for sg in (-1,1):
                    if times(w,tuple(deck[e]))!=scale(times(U[a],U[j]),sg):continue
                    v=scale(U[j],sg);k=w[-1]
                    col.append(C[j]+(k,k*k)+v+scale(v,k)+z+tuple(x*y for x,y in combinations_with_replacement(z,2))+tuple(x*y for x in z for y in v))
            return col
        def check(c,columns,t):
            if not columns:assert c['kind']=='empty';return
            w=c['y'];assert len(w)==len(t) and all(type(i)==int for i in w)
            assert dot(w,t)<0 and all(dot(w,col)>=0 for col in columns)
        for phase in row['rounds']:
            assert e in S
            if 'global' in phase:
                check(phase['global'],[C[j] for j in S],subtract(b,C[e]));S.clear();ncuts+=1
            else:
                for a,c in phase['bad']:
                    assert a in S
                    check(c,[v for j in S for v in cols(a,j)],rhs[a]);ncuts+=1
                S-=set(a for a,c in phase['bad'])
        assert e not in S and not row['remaining']
    print('14102:',len(rows),'branches;',ncuts,'integer cuts verified.')
if __name__=='__main__':
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(Path(build)/'fastdeck')],check=True);init(build);audit()

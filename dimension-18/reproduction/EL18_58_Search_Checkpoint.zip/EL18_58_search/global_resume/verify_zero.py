"""Check every zero-projector removal, without solving any LP. Use separately enumerated maximal cliques."""
from zero_projector import *
from fractions import Fraction
def check(cols,b,v):
    if v['kind']=='empty':assert not cols;return
    if v['kind']=='lattice':assert not lat(cols,b);return
    if v['kind']=='primal':
        xx=[(i,Fraction(z)) for i,z in v['support']]
        assert all(w>=0 for i,w in xx)
        assert [sum(w*cols[i][j] for i,w in xx) for j in range(len(b))]==list(b)
        return
    assert v['kind']=='farkas'
    y=v['y'];assert len(y)==len(b) and all(type(t) is int for t in y)
    dot=lambda a:sum(q*t for q,t in zip(y,a))
    assert dot(b)<0 and all(dot(c)>=0 for c in cols)

def leafs(A,graph):
    def visit(seed,p,x):
        if not p and not x:
            yield tuple(sorted(seed));return
        pivot=min(p|x)
        for j in sorted(p-graph[pivot]):
            yield from visit(seed+[j],p&graph[j],x&graph[j])
            p.remove(j);x.add(j)
    return set(visit([],set(A),set()))

def audit(row):
    m,i=row[:2]
    record=json.loads((P/'zero'/str(m)/f'{i}.json').read_text())
    A,g,deck,C,b,fs=extend(*row,return_graph=True)
    poly=monic_product([[1,8]]+[f for f,k in fs])
    scale=2*poly[-2];assert record['scale']==scale
    def vals(a,j):
        if a!=j and j not in g[a]:return ()
        prod=mul(deck[a],deck[j])
        # In F_2 the square root's coefficients are read at the even powers.
        root=[v%2 for v in prod[::-1][::2]][::-1]
        if any((z-t)%4 for z,t in zip(prod,mul(root,root))):return ()
        h=deck[a][-1]*deck[j][-1]
        return [u for u in range(-isqrt(h),isqrt(h)+1) if (u*u-h)%4==0] if h>=0 else []
    for round_ in record['removed']:
        for a,v in round_:
            assert a in A
            z=deck[a][-1];rhs=tuple(r-s for r,s in zip(b,C[a]))+(11*z,(scale-z)*z)
            cols=sorted({C[j]+(w,w*w) for j in A for w in vals(a,j)})
            check(cols,rhs,v)
        A-=set(a for a,v in round_)
    assert sorted(A)==record['active']
    graph={a:{j for j in A if j!=a and vals(a,j)} for a in A}
    if not record['open'] and A:assert leafs(A,graph)=={tuple(ids) for ids,v in record['cover']}
    for ids,v in record['cover']:check([C[j] for j in ids],b,v)
    return m,i
if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('--jobs',type=int,default=2);args=cli.parse_args()
    rows=[json.loads(s) for s in (P/'rows.jsonl').read_text().splitlines()]
    with TemporaryDirectory() as build:
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(BASE/'m13/fastdeck.cpp'),'-o',str(__import__('pathlib').Path(build)/'fastdeck')],check=True)
        with ProcessPoolExecutor(args.jobs,initializer=init,initargs=(build,)) as ex:
            result=list(ex.map(audit,[r for r in rows if r[-1]]));print(len(result),'zero projector certificates verified')

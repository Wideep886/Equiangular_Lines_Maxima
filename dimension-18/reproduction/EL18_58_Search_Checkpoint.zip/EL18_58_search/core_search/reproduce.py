"""Rebuild every exact local result, including all 162 occupation orbits."""
from pathlib import Path
import json, itertools, os, subprocess, sys
P=Path(__file__).parent
def run(cmd,src=None,dst=None):
    with open(src,'rb') if src else open(os.devnull,'rb') as fin, open(dst,'wb') if dst else open(os.devnull,'wb') as fout:
        subprocess.run(cmd,cwd=P,stdin=fin,stdout=fout,check=True)
def transpose_key(a):
    def key(b):return min(tuple(sorted(tuple(r[j] for j in p) for r in b)) for p in itertools.permutations(range(4)))
    return min(key(a),key(list(zip(*a))))
def main():
    for x in ['row_words','column8']:
        run([os.environ.get('CXX','c++'),'-std=c++17','-O3',str(P/(x+'.cpp')),'-o',str(P/x)])
    run([str(P/'row_words')],dst=P/'words.txt')
    run([sys.executable,str(P/'project.py')],dst=P/'projections.dat')
    run([str(P/'column8')],P/'projections.dat',P/'cloud_answers.txt')
    words=(P/'words.txt').read_text().splitlines()
    answers=[int(x.split()[1]) for x in (P/'cloud_answers.txt').read_text().splitlines()]
    assert len(words)==len(answers)==2275
    kept=[w for w,h in zip(words,answers) if h]
    assert len(kept)==143 and all(int(w.split()[-1])<9 for w in kept)
    (P/'words_col8.txt').write_text('\n'.join(kept)+'\n')
    run([sys.executable,str(P/'occupation.py'),'--words',str(P/'words_col8.txt'),'--output',str(P/'rechecked.json')])
    rows=json.loads((P/'rechecked.json').read_text());assert rows==json.loads((P/'results_col8.json').read_text())
    overall={}
    for i,row in enumerate(rows):
        k=transpose_key(row['table']);yes=row['states'] is not None
        if k in overall:assert yes==overall[k]
        overall[k]=yes
    assert len(overall)==162 and sum(overall.values())==11
    run([sys.executable,str(P/'core48.py'),'control'])
    print('2275 locally admissible row words, 143 remain, 151/162 table orbits excluded.')
    print('Open IDs',[i for i,r in enumerate(rows) if r['states'] is not None])
if __name__=='__main__':main()

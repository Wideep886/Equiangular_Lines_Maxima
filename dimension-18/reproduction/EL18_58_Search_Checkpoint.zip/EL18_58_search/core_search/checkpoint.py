"""Recompute the two integer errors of a tabu incumbent; recover Gram at zero."""
import argparse,json
from pathlib import Path
from core48 import dot,extension
def main():
    p=argparse.ArgumentParser();p.add_argument('template',type=Path);p.add_argument('checkpoint',type=Path)
    p.add_argument('--gram',type=Path);args=p.parse_args()
    lines=args.template.read_text().splitlines();t=[tuple(map(int,s.split())) for s in lines[:48]]
    fixed=[list(map(int,s.split())) for s in lines[48:]]
    cl=args.checkpoint.read_text().splitlines();best,seed,step,a,b=map(int,cl[0].split())
    S=[list(map(int,s.split())) for s in cl[1:]]
    assert all(S[i][i]==0 for i in range(48)) and all(S[i][j]==S[j][i] in (-1,1) and fixed[i][j] in (0,S[i][j]) for i in range(48) for j in range(i))
    y=[[int(i==u) for u in range(4)]+[k*int(j==u) for u in range(4)] for i,j,k in t]
    pvals=[dot(S[i],S[j])-6*S[i][j]+4*dot(y[i],y[j]) for i in range(48) for j in range(i)]
    qvals=[dot(S[i],column)-7*y[i][k] for i in range(48) for k,column in enumerate(zip(*y))]
    x=sum(v*v for v in pvals);z=sum(v*v for v in qvals)
    assert (best,a,b)==(x+8*z,x,z)
    print('seed',seed,'step',step,'integer score',best,'quadratic',x,'linear',z,
          'nonzero residuals',sum(bool(v) for v in pvals),sum(bool(v) for v in qvals))
    if best==0 and args.gram:
        table=[[sum((i,j,k)==(a,b,1) for i,j,k in t) for b in range(4)] for a in range(4)]
        A=[[int(w==-1) for w in row] for row in S]
        args.gram.write_text(json.dumps(extension(table,A))+'\n')
if __name__=='__main__':main()

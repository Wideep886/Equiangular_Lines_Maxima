// Search for a 48-line Seidel core by exact integer residual minimization.
// Usage: search seed total_steps fixed_template incumbent [restart_file]
#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>
using namespace std;
constexpr int N=48,K=8,lambda=8;
int Y[N][K]{},S[N][N]{},fixedS[N][N]{},B[N][N]{},E[N][N]{},U[N][K]{},bestS[N][N]{};
struct Edge{int a,b,tabu;}; vector<Edge> edges;
long long best=LLONG_MAX;
mt19937_64 rng;
long long uenergy(long long& p,long long& q){p=q=0;
  for(int i=0;i<N;i++)for(int j=i+1;j<N;j++){int t=-6*S[i][j]+4*B[i][j];for(int k=0;k<N;k++)t+=S[i][k]*S[k][j];E[i][j]=E[j][i]=t;p+=(long long)t*t;}
  for(int i=0;i<N;i++)for(int k=0;k<K;k++){int t=-7*Y[i][k];for(int j=0;j<N;j++)t+=S[i][j]*Y[j][k];U[i][k]=t;q+=t*t;}
  return p+lambda*q;
}
long long delta(int a,int b){
 int h=-2*S[a][b];
 int w=-6*E[a][b]+inner_product(E[a],E[a]+N,S[b],0)+inner_product(E[b],E[b]+N,S[a],0);
 int t=inner_product(U[a],U[a]+K,Y[b],0)+inner_product(U[b],U[b]+K,Y[a],0);
 return 2*(long long)h*(w+lambda*t)+4*(36+2*(N-2))+16*lambda;
}
void flip(int a,int b){
 int h=-2*S[a][b];E[a][b]-=6*h;E[b][a]=E[a][b];
 for(int k=0;k<N;k++)if(k!=a&&k!=b){
  E[a][k]+=h*S[b][k];E[k][a]=E[a][k];
  E[b][k]+=h*S[a][k];E[k][b]=E[b][k];
 }
 for(int k=0;k<K;k++){U[a][k]+=h*Y[b][k];U[b][k]+=h*Y[a][k];}
 S[a][b]+=h;S[b][a]=S[a][b];
}
void save(const string& name,long long best,int seed,int step,long long p,long long q){
 ofstream file(name+".tmp");file<<best<<" "<<seed<<" "<<step<<" "<<p<<" "<<q<<'\n';
 for(auto& row:S){for(int v:row)file<<v<<' ';file<<'\n';}file.close();assert(!std::rename((name+".tmp").c_str(),name.c_str()));
}
int main(int argc,char**argv){if(argc<5)return 2;int seed=atoi(argv[1]),budget=atoi(argv[2]);rng.seed(seed);ifstream in(argv[3]);
 for(int i=0;i<N;i++){int a,b,s;in>>a>>b>>s;Y[i][a]=1;Y[i][4+b]=s;}
 for(auto& row:fixedS)for(int& x:row)in>>x;assert(in);
 for(int i=0;i<N;i++)for(int j=0;j<N;j++)B[i][j]=inner_product(Y[i],Y[i]+K,Y[j],0);
 for(int i=0;i<N;i++)for(int j=i+1;j<N;j++)if(!fixedS[i][j])edges.push_back({i,j,0});
 if(argc>5){ifstream f(argv[5]);long long a;int sd,iter;long long p,q;f>>a>>sd>>iter>>p>>q;
  for(int i=0;i<N;i++)for(int j=0;j<N;j++){f>>bestS[i][j];assert(i==j?bestS[i][j]==0:(abs(bestS[i][j])==1 && (!fixedS[i][j]||fixedS[i][j]==bestS[i][j])));}assert(f);best=a;
 }
 long long energy=0,p=0,q=0,initial=-1;
 for(int step=0;step<budget;step++){
  if(step%9000==0){
   bool warm=(argc>5 && step==0) || (step>0 && (rng()%4));
   for(int i=0;i<N;i++)for(int j=i+1;j<N;j++)S[i][j]=S[j][i]=fixedS[i][j]?fixedS[i][j]:(warm?bestS[i][j]:(rng()%2?1:-1));
   if(warm){int kicks=step==0?0:10+rng()%60;while(kicks--){auto e=edges[rng()%edges.size()];S[e.a][e.b]*=-1;S[e.b][e.a]=S[e.a][e.b];}}
   for(auto& e:edges)e.tabu=0;
   energy=uenergy(p,q);
   if(initial<0)initial=energy;
  }
  if(energy<best){
   best=energy;assert(uenergy(p,q)==energy);for(int i=0;i<N;i++)copy(S[i],S[i]+N,bestS[i]);save(argv[4],best,seed,step,p,q);if(best==0)break;
  }
  if(step%500==0)assert(uenergy(p,q)==energy);
  long long gain=LLONG_MAX;int chosen=-1;int start=rng()%edges.size();
  for(int trial=0;trial<(int)edges.size();trial++){
   int u=(start+trial)%edges.size();const auto &e=edges[u];
   long long g=delta(e.a,e.b);if(e.tabu>step && energy+g>=best)continue;
   if(g<gain || (g==gain && rng()%6==0)){gain=g;chosen=u;}
  }
  assert(chosen>=0);auto& c=edges[chosen];flip(c.a,c.b);energy+=gain;c.tabu=step+int(11+rng()%32);
 }
 cerr<<"steps "<<budget<<" free "<<edges.size()<<" initial "<<initial<<" best "<<best<<"\n";
}

// Enumerate cycle words within one 12-point row. Color labels 2*c and
// 2*c+1 are the two signs at column c. Counts include no quotient by
// permutations of the column labels or by reversing signs within a column.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdio>
#include <string>
#include <vector>
using std::array; using std::vector;
using Int=long long;
struct Search {
  vector<int> lengths, profile;
  int word[12]={}, left[8]={}, bal[4]={}, start[4]={};
  Int tested=0,passed=0,ranked[10]={}; std::string witness;
  Int det(const Int a[4][4],int mask) {
    int v[4],d=0;for(int j=0;j<4;j++)if((mask>>j)&1)v[d++]=j;
    int p[4]={0,1,2,3};Int r=0;
    do{Int t=1;for(int i=0;i<d;i++){t*=a[v[i]][v[p[i]]];for(int j=0;j<i;j++)if(p[j]>p[i])t=-t;}r+=t;}while(std::next_permutation(p,p+d));return r;
  }
  bool canonical(int offset,int n) {
    for(int rot=0;rot<n;rot++){
      for(int step : {1,-1}){
        if(!rot && step==1)continue;
        for(int j=0;j<n;j++){
          int u=word[offset+j],v=word[offset+(rot+step*j+n)%n];if(u<v)break;if(u>v)return false;
        }
      }
    }
    return true;
  }
  void check(){
    tested++; Int a[4][4]={};for(int i=0;i<4;i++)a[i][i]=96;
    for(int g=0;g<(int)lengths.size();g++){
      int n=lengths[g],s=start[g];
      for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
        int d=j-i,ci=word[s+i]/2,cj=word[s+j]/2;
        int off=24/n*d*(n-d)*((word[s+i]%2==word[s+j]%2)?1:-1);
        a[ci][cj]+=off;a[cj][ci]+=off;
      }
    }
    int rank=0;for(int bits=1;bits<16;bits++){Int d=det(a,bits);if(d<0)return;if(d>0)rank=std::max(rank,__builtin_popcount((unsigned)bits));}
    int gramrank=8-(int)lengths.size()+rank;if(gramrank>9)return;
    for(int v:profile)std::printf("%d",v);std::printf(" ");
    for(int n:lengths)std::printf("%d,",n);std::printf(" ");
    for(int k=0;k<12;k++)std::printf("%d",word[k]);std::printf(" %d\n",gramrank);
    passed++;ranked[gramrank]++;if(witness.empty()){for(int k=0;k<12;k++)witness+=char('0'+word[k]);}
  }
  void enumerate(int g,int pos){
    if(g==(int)lengths.size()){check();return;}
    int n=lengths[g],s=start[g];
    if(pos==n){
      for(int b:bal)if(b)return;
      if(!canonical(s,n))return;
      if(g&&lengths[g-1]==n&&std::lexicographical_compare(word+s,word+s+n,word+s-n,word+s))return;
      enumerate(g+1,0);return;
    }
    for(int a=0;a<8;a++){
      if(!left[a]||(pos && a<word[s]))continue;
      int k=a/2,d=a%2?-1:1;
      if(std::abs(bal[k]+d)>n-pos-1)continue;
      if(pos==n-1){bool ok=true;for(int j=0;j<4;j++)if(bal[j]+((j==k)?d:0))ok=false;if(!ok)continue;}
      left[a]--;bal[k]+=d;word[s+pos]=a;enumerate(g,pos+1);left[a]++;bal[k]-=d;
    }
  }
  void run() {
    for(int k=0;k<4;k++)left[2*k]=left[2*k+1]=profile[k];
    for(int j=1;j<(int)lengths.size();j++)start[j]=start[j-1]+lengths[j-1];
    enumerate(0,0);

  }
};
int main(){
    for(auto a:vector<vector<int>>{{4,2,0,0},{4,1,1,0},{3,3,0,0},{3,2,1,0},{3,1,1,1},{2,2,2,0},{2,2,1,1}}){
      for(auto l:vector<vector<int>>{{12},{8,4},{6,6},{4,4,4}}){Search x;x.profile=a;x.lengths=l;x.run();}
    }
}

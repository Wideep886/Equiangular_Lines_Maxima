# A finite search for 48-line cores with D8 projections

This is a necessary-condition and construction search for the particular 58-line spectrum with Seidel eigenvalues \(-5^{(40)},11^{(15)},15,10\pm\sqrt{33}\), conditional on the project's prior reduction to a 48-line core. Independently of that reduction, any core constructed here suffices for 58 equiangular lines in dimension 18. Up to row, column and transpose symmetry, the local tests below exclude 151 of 162 occupancy tables. The other group's transversal and centered-cell tests exclude four further tables among our eleven.

## A graph criterion

Write the 48 norm-five representatives as \((y_i,z_i)\), with \(y_i=e_r+\sigma f_c\), \(\sigma=\pm1\), and \(z_i\in\mathbb R^9\). Normalized frame operators give \(Y^TY=12I_8\), \(Z^TZ=16I_9\), and \(Y^TZ=0\), where the rows are the corresponding vectors. There are equally many signs at each cell, denoted \(a_{rc}\) of each sign. Every row and column of the occupancy table sums to six. Within a fixed signed cell all residual vectors have squared norm 3 and pair products -1 or -3. A pair attaining -3 is antipodal and excludes a third vertex. Otherwise positivity of the sum bounds the cell by four. This proves \(0\le a_{rc}\le4\).

With \(B=YY^T\) and \(S=J-I-2A\), the graph criterion is precisely
\[
 S Y=7Y,\qquad S^2=6S+55I-4B.
\]
Indeed \(S+5I=B+ZZ^T\) has frame eigenvalues 12 and 16. Conversely on \(\operatorname{im}Y\) the graph equations give eigenvalue 7, on its orthogonal complement the possible eigenvalues are -5 and 11, and trace zero fixes their multiplicities at 31 and 9. Thus \(S+5I-B\) is positive semidefinite of rank 9. After adjoining the ten lifted cube words described in the project one obtains an integer norm-five Gram matrix of order 58 and rank 18.

The eight columns of \(Y\) include the four row indicators, so \(S\mathbf1=7\mathbf1\). The graph has degree 20 and
\[
 A^2=10J+12I-4A-B.
\]
The code can export these graph constraints exactly as a pseudo-Boolean feasibility model. For a non-D8 positive control, deleting the zero point from the cyclic STS(19) of base blocks \(014,029,05(11)\) gives an actual 48-line core. Its primitive projection matrix is \(3Y\), and the graph in the natural switching has degree 26. The control checks its exact Seidel identities and the assignment to every auxiliary conjunction and pseudo-Boolean linear equality or inequality.

## Local enumeration without antipodality

The negative edges in any 12-point row give a 2-regular graph \(C\). Let \(W\) be the signed incidence matrix of its four column labels. The residual Gram there is
\[
   G=2L(C)-WW^T .
\]
For each cycle component \(H\), validity requires \(W^T\mathbf1_H=0\) because \(G\succeq0\). Thus each label is balanced in the cycle. The cycle partition is one of \(12,8+4,6+6,4+4+4\). The switched version of the same statement holds for each column.

The enumerator exhausts signed cyclic color words modulo each cycle's dihedral action and interchange of same-length cycles, for each partition of six into four cell occupancies bounded by four. Signs and labeled colors are retained. Let \(P=I-W^T(2L)^+W\). If \(h\) is the number of cycles, then \(G\succeq0\) iff \(P\succeq0\), and \(\operatorname{rank}G=8-h+\operatorname{rank}P\). This follows from the common nonzero singular values of \((2L)^{+1/2}W\) and its transpose. For a cycle of length \(m\), the resistance between positions at separation \(d\) is \(d(m-d)/m\). On zero-sum vectors the pseudoinverse of its Laplacian is minus one half of its resistance matrix. Thus \(96P\) is an integer matrix and is computed using these distances. All principal minors test positivity and rank. Exactly 2,275 local words pass.

## Candidate vectors extending an anchor row

Fix an anchor row with feasible residual Gram \(G\), choose a nonsingular principal basis \(R\) of size \(r\), and compute \(D G_{RR}^{-1}\) integrally. For any outer vector with signed column \((c,s)\), each inner product with an anchor residual must be
\[
 p_i=\epsilon_i-s\sigma_i\mathbf1_{c_i=c},\qquad \epsilon_i\in\{-1,1\}.
\]
On each anchor cycle the signs \(\epsilon_i\) sum to zero, since the anchor residual sum and signed column sum on that cycle both vanish. Exhaust these signs and impose
\[
 G_{\bullet R}G_{RR}^{-1}p_R=p,\qquad N=D p_R^TG_{RR}^{-1}p_R\le3D.
\]
For \(r=9\) equality is required. All \(6-a_{rc}\) external representatives in one signed column have distinct residual vectors with mutual products in \(\{-3,-2,-1,0\}\). Exhausting cliques up to the required size excludes every rank-nine row.

For \(r=8\), each possible extra coordinate has squared value \((3D-N)/D\). All residual pair products are integral and all projection products rational, so products of the numerators of any two nonzero squared extra coordinates are rational squares, hence integer squares. Their common squarefree part \(d\) divides \(16D\), since the residual frame is 16 times the identity and the anchor contributes zero in this normal direction. Try every such occurring \(d\) and both signs of each integer \(u\) with \(d u^2=3D-N\). The extra coordinate equals \(u\sqrt{d/D}\). The case of all zero extras would force the entire residual frame into eight dimensions. All square-root candidates are tested by integer squaring.

For each signed column the clique test above uses the actual lifted vectors. Additionally, after switching all signs to make the column coordinate positive, the complete column residual vectors sum to zero by \(Y^TZ=0\). The plus and minus outside groups now have the same candidate cloud: switching the minus group replaces its sign word by the negative word. The code enumerates cliques of size \(6-a_{rc}\) and asks if two of their sums cancel the signed anchored column sum, including cancellation in the normal direction. If the search reaches 100,000 leaves before settling a column, it allows that column conservatively. At ranks below eight, only existence of admissible individual projections is used. This leaves 143 feasible row words, including eleven of rank eight.

## Coupling rows to columns

Within any occupied cell the negative graph on the two sign groups obtained from the row and the graph obtained from the switched column agree on all same-sign pairs. On opposite-sign pairs they are complementary. The code compares the induced graph types up to arbitrary permutations within each sign group. Each row word gives a tuple of four such types. Intersect the row and column domains at all sixteen cells and branch exhaustively on the smallest remaining domain. Local feasibility is necessary for a genuine graph. Distinct row/column permutation orbits number 224, and adding transpose leaves 162. The eleven undeleted indices in the supplied sorted table list are **0, 7, 9, 19, 47, 81, 216, 217, 218, 222, 223**. These are feasible signatures; their full graphs remain to be found or excluded.

Run `python3 reproduce.py` to reconstruct the exact certificates and table results. This uses standard Python, an ordinary C++17 compiler, and no external solver. For an actual global Boolean search, use `core48.py model` for an OPB model, or use `glue.py` and `search.cpp` to perform a restartable local search on complete Seidel matrices with the chosen row/column signs fixed. The tabu score is \(\sum_{i<j}[(S^2-6S-55I+4B)_{ij}]^2+8\|SY-7Y\|_F^2\). Only a score of zero is a construction. `checkpoint.py` recomputes both terms independently and produces the 58-line Gram when the score is zero.

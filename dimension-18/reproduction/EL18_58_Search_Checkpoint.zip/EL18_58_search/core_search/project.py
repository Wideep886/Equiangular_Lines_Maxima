from pathlib import Path
from anchor import geom,integer_basis_and_inverse
from itertools import combinations
if __name__=='__main__':
    p=Path(__file__).parent;words=(p/'words.txt').read_text().splitlines()
    print(len(words))
    for line in words:
        prof,parts,w,rank=line.split(); labels,cycles,G=geom(prof,parts,w);R,D,Q=integer_basis_and_inverse(G)
        assert len(R)==int(rank)
        print(w,len(R),D,*(int(a) for a in prof),*(sum(1<<i for i in c) for c in cycles),*([0]*(3-len(cycles))))
        print(*R)
        for q in Q:print(*q)
        for g in G:print(*g)

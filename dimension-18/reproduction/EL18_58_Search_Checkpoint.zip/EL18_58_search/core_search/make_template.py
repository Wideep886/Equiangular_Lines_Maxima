"""Build one globally pair-compatible fixed Seidel template from explicit row words."""
from pathlib import Path
import argparse
from pair_csp import solve,word_states
from occupation import tables
from glue import words as library, glue
class One:
    def __init__(self,s):self.s=s
    def read_text(self):return self.s
class PerMargin:
    def __init__(self,lines):self.lines=iter(lines)
    def __getitem__(self,profile):
        return library(One(next(self.lines)))[profile]
def build(idx,wordpath,pairpath,whitelist,path,rng=None):
    lines=wordpath.read_text().splitlines()
    words=word_states(lines)
    ok=set(whitelist.read_text().splitlines()) if whitelist else set(lines)
    keep={i for i,l in enumerate(lines) if l in ok}
    closed=set()
    for l in pairpath.read_text().splitlines():
        u,a,v,b,yes=map(int,l.split())
        if not yes:closed.add((u,a,v,b));closed.add((v,b,u,a))
    if rng is not None:
        order=list(range(len(lines)))
        rng.shuffle(order)
        new={old:j for j,old in enumerate(order)}
        lines=[lines[j] for j in order]
        words=[words[j] for j in order]
        keep={new[j] for j in keep}
        closed={(new[u],a,new[v],b) for u,a,v,b in closed}
    table=tables()[idx]
    ids,stats=solve(table,words,closed,keep)
    if ids is None:return None
    states=[]
    for h,pr in enumerate((*table,*zip(*table))):
        order=sorted(range(4),key=lambda j:-pr[j]);states.append([words[ids[h]][1][order.index(j)] for j in range(4)])
        if h>=4:
            from occupation import complement
            states[-1]=[complement(n,z) for n,z in zip(pr,states[-1])]
    tags,S=glue(table,states,PerMargin([lines[i] for i in ids]),rng=rng)
    with path.open('w') as f:
        for i,j,s,z in tags:print(i,j,s,file=f)
        for row in S:print(*row,file=f)
    return [lines[i] for i in ids]
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('idx',type=int);p.add_argument('output',type=Path);p.add_argument('--words',default=Path('words_aug7.txt'),type=Path);p.add_argument('--pairs',type=Path,default=Path('pair200.out'));p.add_argument('--allowed',type=Path);a=p.parse_args();build(a.idx,a.words,a.pairs,a.allowed,a.output)

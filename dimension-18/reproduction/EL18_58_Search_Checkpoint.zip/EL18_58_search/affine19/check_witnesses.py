"""Check all eight witnesses and compare exact switching invariants."""
from collections import Counter
from pathlib import Path
import sys, json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from verify_gram import certify

def profile(G):
    # Relabeling and switching preserve the multiset of all rooted degree lists.
    return tuple(sorted(tuple(sorted(sum(k not in (i,j) and G[i][j]*G[j][k]*G[k][i]<0
                        for k in range(len(G))) for j in range(len(G)) if i!=j)) for i in range(len(G))))

def main():
    paths=[HERE.parent/'control_57.json',HERE.parent/'orbit_construction/reach/hex_control_57.json',*sorted(HERE.glob('gram_*.json'))]
    groups=[]
    invariants=[]
    for path in paths:
        G=json.loads(path.read_text())
        certify(G,57)
        value=profile(G)
        if value not in invariants:
            groups.append([])
            invariants.append(value)
        groups[invariants.index(value)].append(path.name)
    print(json.dumps(groups))
if __name__=='__main__': main()

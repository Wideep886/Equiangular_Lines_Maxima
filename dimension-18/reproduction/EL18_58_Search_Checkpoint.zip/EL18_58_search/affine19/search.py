"""Exhaust parity lifts of AG(2,3), deleting the extra point. Standard Python 3."""
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from math import isqrt
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'pasch19'))
from search import assignments, elimination, gram, signs

def third(x,y):
    return (-(x//3+y//3)%3)*3 + (-(x%3+y%3)%3)
lines=sorted({tuple(sorted((x,y,third(x,y)))) for x,y in combinations(range(9),2)})
switch={0}
for x in range(9):
    mask=sum(1<<i for i,t in enumerate(lines) if x in t)
    switch |= {v^mask for v in switch}
reps=sorted({min(w^v for v in switch) for w in range(4096)})
def core(rep):
    return [set(2*x+b for x,b in zip(t,bits)) for i,t in enumerate(lines)
            for bits in product(range(2),repeat=3) if sum(bits)%2==(rep>>i&1)]

def maximum(adj):
    best=[]
    def visit(rem,path):
        nonlocal best
        if len(path)>len(best): best=path[:]
        order=[]
        color=0
        left=rem
        while left:
            color+=1
            free=left
            while free:
                bit=free & -free
                v=bit.bit_length()-1
                order.append((v,color))
                free=(free^bit)&~adj[v]
                left^=bit
        for v,c in reversed(order):
            if c+len(path)<=len(best):return
            visit(rem&adj[v],path+[v])
            rem^=1<<v
    visit((1<<len(adj))-1,[])
    return best

def solve(rep):
    rows=core(rep)
    G=gram(rows)
    B,good=assignments(G)
    A=[[G[i][j] for j in B] for i in B]
    _,H=elimination(A,[[int(i==j) for j in range(17)] for i in range(17)],False)
    opts=[]
    for r in good:
        s=signs(r['mask'])
        c=[sum(k*l for k,l in zip(row,s)) for row in H]
        n=sum(k*l for k,l in zip(c,s))
        assert n==Fraction(r['norm'])
        if n<=5:
            opts.extend((s,c,5-n,sg,r['mask']) for sg in ([1] if n==5 else [1,-1]))
    def ip(a,b):
        s,c,h,e,m=a
        t,d,k,f,n=b
        v=sum(k*l for k,l in zip(t,c))
        return next((z for z in (-1,1) if (z-v)**2==h*k and (z-v)*e*f>=0),None)
    adj=[0]*len(opts)
    for i,a in enumerate(opts):
        for j,b in enumerate(opts[:i]):
            if ip(a,b) is not None:
                adj[i]|=1<<j
                adj[j]|=1<<i
    C=maximum(adj)
    assert all(adj[i]>>j&1 for i,j in combinations(C,2))
    N=48+len(C)
    K=[r[:] for r in G]+[[] for _ in C]
    for i in range(48):
        for j,v in enumerate(C):
            val=sum(h*G[i][k] for h,k in zip(opts[v][1],B))
            assert abs(val)==1
            K[i].append(int(val))
            K[48+j].append(int(val))
    for i,v in enumerate(C):
        K[48+i].extend(5 if j==i else ip(opts[v],opts[w]) for j,w in enumerate(C))
    assert all(len(row)==N for row in K)
    (ROOT/f'gram_{rep}.json').write_text(json.dumps(K)+'\n')
    return dict(mask=rep,basis=B,norms=dict(Counter(r['norm'] for r in good)),options=len(opts),
                edge_count=sum(bin(a).count('1') for a in adj)//2,omega=len(C),witness=[opts[v][3:] for v in C])
if __name__=='__main__':
    data=[]
    for r in reps:
        v=solve(r)
        print(r,v['norms'],v['options'],v['omega'],flush=True)
        data.append(v)
    (ROOT/'results.json').write_text(json.dumps(dict(lines=lines,switch_order=len(switch),cases=data),indent=1)+'\n')

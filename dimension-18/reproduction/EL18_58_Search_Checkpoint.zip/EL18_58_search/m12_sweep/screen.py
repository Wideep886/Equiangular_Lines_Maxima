"""One-deletion screening of normalized m=12 tails using the project verifier."""
from concurrent.futures import ProcessPoolExecutor
import argparse
import gzip
import json
from pathlib import Path
import os
import subprocess
import sys
import tempfile
from zipfile import ZipFile
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'m13'
sys.path.insert(0,str(BASE))
import anchor, fastdeck

def init(build):
    fastdeck.HERE=Path(build)

def screen(item):
    i,h=item
    n,rounds,k=anchor.anchor(12,h)
    return [i,h,n,rounds,k]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--grid',type=int,default=256,help='evaluate i=floor(j*N/grid), 0<=j<grid')
    ap.add_argument('--jobs',type=int,default=3)
    args=ap.parse_args()
    archive=HERE.parent.parent/'EL18_58_Research_20261121.zip'
    with ZipFile(archive) as z, gzip.open(z.open('EL18_58/combined/remaining.jsonl.gz'),'rt') as src:
        tails=sorted(p[:-12] for p in map(json.loads,src) if p[-12:]==[0]*12 and p[-13])
    assert len(tails)==len({tuple(p) for p in tails})
    n=len(tails)
    steps=min(n,args.grid)
    chosen=[j*n//steps for j in range(steps)]
    print('layer',n,'requested',steps,flush=True)
    outfile=HERE/'rows.jsonl'
    old={row[0]:row for row in map(json.loads,outfile.read_text().splitlines())} if outfile.exists() else {}
    assert all(row[1]==tails[i] for i,row in old.items())
    tasks=[(i,tails[i]) for i in chosen if i not in old]
    with tempfile.TemporaryDirectory() as work:
        subprocess.run([os.environ.get('CXX','c++'),'-O3','-std=c++17',str(BASE/'fastdeck.cpp'),'-o',str(Path(work)/'fastdeck')],check=True)
        with ProcessPoolExecutor(args.jobs,initializer=init,initargs=(work,)) as ex, outfile.open('a',buffering=1) as out:
            for row in ex.map(screen,tasks,chunksize=2):
                print(json.dumps(row,separators=(',',':')),file=out)
                old[row[0]]=row
    print('processed',len(old),'excluded',sum(x[-1]==0 for x in old.values()),flush=True)
if __name__=='__main__':main()

"""Apply the signed row test to survivors of the m=12 stratified screen."""
import json
from pathlib import Path
import sys
from concurrent.futures import ProcessPoolExecutor
from tempfile import TemporaryDirectory
import subprocess,os
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'audit_layer'))
import rows13
import fastdeck

def init(build):
    fastdeck.HERE=Path(build)

def main():
    rows=list(map(json.loads,(HERE/'rows.jsonl').read_text().splitlines()))
    outfile=HERE/'pairs.jsonl'
    old={r[0] for r in map(json.loads,outfile.read_text().splitlines())} if outfile.exists() else set()
    inputs=[[12,*r] for r in rows if r[0] not in old and r[-1]]
    with TemporaryDirectory() as work:
        subprocess.run([os.environ.get('CXX','c++'),'-O3','-std=c++17',str(HERE.parent/'m13/fastdeck.cpp'),'-o',str(Path(work)/'fastdeck')],check=True)
        with ProcessPoolExecutor(3,initializer=init,initargs=(work,)) as pool,outfile.open('a',buffering=1) as out:
            for result in pool.map(rows13.unit,inputs):
                print(json.dumps(result,separators=(',',':')),file=out)
if __name__=='__main__':main()

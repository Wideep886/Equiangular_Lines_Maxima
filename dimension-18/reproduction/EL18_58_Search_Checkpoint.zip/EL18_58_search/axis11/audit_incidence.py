"""Exact replay of hexad flags and pair-link induction. Python standard library only."""
from collections import Counter
from fractions import Fraction
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path
import json

WORDS = list(combinations_with_replacement(range(4), 4))
INDEX = {word: i for i, word in enumerate(WORDS)}
TRANS = ((0,1,2,3),(1,0,2,3),(1,0,3,2),(1,2,0,3),(1,2,3,0))
W321 = [83460985,41730543,27820457,20189618,33384439,27820210,20865261,
        44737579,37783187,45784250,46241565,63159235,71617731,80076009,
        88535082,96536278,67741611,76200542,84659291,84017819,96993644,
        113911144,122369940,130828779,139287097,147288943,118494089,
        126953098,135411507,134770051,84134872,92593972,101052376,100410249,84813262]
W384 = [99999847,49999933,33174399,20803414,39999968,33333340,24999966,
        67302715,58969898,75179119,49999415,72212168,89196761,77174262,
        88520721,105505187,34226193,47336937,64322248,60803157,102438896,
        136408402,153393295,135732521,152717061,169702176,94420166,
        111405273,128389779,120832176,27380894,29456781,46441282,38883009,21904705]


def hexad_rows():
    points = set(range(6))
    parts = [frozenset((0,) + t) for t in combinations(range(1,6),2)]
    pairs = list(combinations(points,2))
    same = [[i for i,s in enumerate(parts) if (a in s)==(b in s)] for a,b in pairs]
    maps = []
    for j in range(5):
        idx = []
        for s in parts:
            perm = {j+1 if x==j else j if x==j+1 else x for x in s}
            idx.append(parts.index(perm if 0 in perm else points-perm))
        def table(start):
            return [sum(((v>>(2*i))&3)<<(2*idx[start+i]) for i in range(5)) for v in range(1024)]
        maps.append((table(0),table(5)))
    seen = bytearray(1<<20)
    result = set()
    for seed in range(len(seen)):
        if seen[seed]:
            continue
        queue = [seed]
        seen[seed] = 1
        for v in queue:
            for lo,hi in maps:
                t = lo[v%1024] | hi[v//1024]
                if not seen[t]:
                    seen[t]=1
                    queue.append(t)
        v=[(seed>>(2*i))&3 for i in range(10)]
        h=[0]*35
        for p in same:
            h[INDEX[tuple(sorted(v[i] for i in p))]]+=1
        result.add(tuple(h+[sum(60//(x+2) for x in v)]))
    assert len(result)==2488
    return result


def graph_data(adj,threshold):
    n=len(adj)
    cnt=[0]*n
    for a,b,c in combinations(range(n),3):
        if (adj[a]>>b)&1 or (adj[a]>>c)&1 or (adj[b]>>c)&1:
            continue
        for x in (a,b,c):
            cnt[x]+=1
            if cnt[x]>=threshold:
                return None
    h=[0]*35
    for x in range(n):
        left=adj[x]
        sizes=[]
        while left:
            bit=left&-left
            y=bit.bit_length()-1
            piece=bit|(adj[y]&adj[x])
            if piece&~left or piece.bit_count()>3:
                return None
            for v in range(n):
                if (piece>>v)&1 and (adj[v]&adj[x])!=(piece^(1<<v)):
                    return None
            sizes.append(piece.bit_count())
            left^=piece
        if len(sizes)>4:
            return None
        word=tuple(sorted(sizes+[0]*(4-len(sizes))))
        h[INDEX[word]]+=1
    return tuple(h),sum(cnt)//3


def no_triple_rows():
    rows=set()
    def add(n,edges):
        adj=[0]*n
        for i,j in edges:
            adj[i]|=1<<j
            adj[j]|=1<<i
        row=graph_data(adj,1)
        if row is not None:
            rows.add(row[0])
    for n in range(6):
        edges=list(combinations(range(n),2))
        for mask in range(1<<len(edges)):
            add(n,[e for k,e in enumerate(edges) if (mask>>k)&1])
    for n in range(6,9):
        for a in (3,4):
            if n-a>a:
                continue
            internal=list(combinations(range(a),2))+list(combinations(range(a,n),2))
            for targets in combinations_with_replacement(range(-1,a),n-a):
                add(n,internal+[(i,j) for j,i in enumerate(targets,a) if i>=0])
    assert len(rows)==38
    return rows


def link_base_rows(threshold):
    rows=set()
    for perm in TRANS:
        strong=[(i,i,-1) for i in range(4)]+[(i,-1,i) for i in range(4)]
        strong += [(-1,i,perm[i]) for i in range(4)]+[(i,i,i) for i in range(4) if perm[i]==i]
        def extend(start,labels,adj,weak,depth):
            data=graph_data(adj,threshold)
            if data is None:
                return
            filling=depth<len(weak)
            if filling:
                candidates=[(0,weak[depth])]
            else:
                rows.add(data)
                candidates=enumerate(strong[start:],start)
            for j,mark in candidates:
                fixed=sum(1<<i for i,x in enumerate(mark) if x>=0)
                free=0
                for k,old in enumerate(labels,3):
                    shared=[(x,y) for x,y in zip(mark,old) if min(x,y)>=0]
                    if not shared:
                        free|=1<<k
                    elif any(x==y for x,y in shared):
                        if len(shared)>1:
                            break
                        fixed|=1<<k
                else:
                    sub=free
                    while True:
                        neigh=fixed|sub
                        n=len(adj)
                        enlarged=[e|(((neigh>>k)&1)<<n) for k,e in enumerate(adj)]+[neigh]
                        extend(0 if filling else j+1,labels+[mark],enlarged,weak,depth+int(filling))
                        if sub==0:
                            break
                        sub=(sub-1)&free
        for z in range((threshold-2)//2+1):
            budget=threshold-2-2*z
            for a in range(budget+1):
                for b in range(min(a,budget-a)+1):
                    for c in range(b+1):
                        mult=[combinations_with_replacement(range(4),q) for q in (a,b,c)]
                        for selection in product(*mult):
                            weak=[(-1,-1,-1)]*z
                            for k,marks in enumerate(selection):
                                for x in marks:
                                    sig=[-1]*3
                                    sig[k]=x
                                    weak.append(tuple(sig))
                            extend(0,[],[0,0,0],weak,0)
    return rows


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


def ceil(q):
    return -(-q.numerator//q.denominator)


def deletion_cap(weights):
    change=[0]
    for j in (1,2,3):
        differences=[]
        for word in WORDS:
            if j in word:
                reduced=list(word)
                reduced[reduced.index(j)]-=1
                differences.append(weights[INDEX[word]]-weights[INDEX[tuple(sorted(reduced))]])
        change.append(max(differences))
    return max(w+sum(x*change[x] for x in t) for w,t in zip(weights,WORDS))


def verify_induction(A,B,w,k,expected):
    extra=link_base_rows(k)
    assert Counter(d for row,d in extra)==expected
    lam=min(Fraction(dot(a,w),a[-1]) for a in A)
    g=max(dot(b,w) for b in B)
    gamma=max([Fraction(deletion_cap(w),k)]+[Fraction(dot(row,w)-g,d) for row,d in extra])
    assert gamma>0
    for excess in (4492,4496,4504,4508):
        bound=(30*excess*lam-1653*g)/gamma
        print(k,excess,bound,ceil(bound))
    if k==4:
        assert (lam,g,gamma)==(Fraction(21904705,8),200000311,100002005)
        assert ceil((30*4504*lam-1653*g)/gamma)==394
    return extra


def main():
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--dump-base',type=int,choices=(3,4,5))
    args=parser.parse_args()
    if args.dump_base:
        for row,d in sorted(link_base_rows(args.dump_base)):
            print(*row,d)
        return
    A,B=hexad_rows(),no_triple_rows()
    root=Path(__file__).resolve().parent
    pair=json.loads((root/'mass_cert.json').read_text())
    w=pair['weights']
    assert all(dot(a,w)>=1000*a[-1] for a in A)
    g=max(dot(b,w) for b in B)
    slope=max(wi/sum(Fraction(1,1+x) for x in t) for wi,t in zip(w,WORDS))
    assert g==73104 and slope==Fraction(80121,2)
    for n in range(57):
        x=Fraction(4)+Fraction(n,2)-16
        y=Fraction(6)+Fraction(56-n,3)-16
        if x*x+y*y+(2-x-y)**2/16<=84:
            max_n=n
    assert max_n==39
    pair_bound=(30*4492*1000-1653*g)/(slope*max_n-g)
    assert ceil(pair_bound)==10
    print('original pairs:',pair_bound,ceil(pair_bound))
    old=list(map(Fraction,json.loads((root/'triple_mass.json').read_text())))
    assert all(dot(a[:-1],old)>=old[-2]*a[-1] for a in A)
    assert max(dot(b,old) for b in B)<=old[-1]
    assert deletion_cap(old[:35])<=1
    assert ceil(30*4492*old[-2]-1653*old[-1])==107
    print('threshold, T-u, fraction, ceiling')
    verify_induction(A,B,W321,3,{1:10,2:23,3:6,4:10,6:1})
    verify_induction(A,B,W384,4,{1:10,2:23,3:23,4:20,5:16,6:11,7:3,8:6,9:1})


if __name__=='__main__':
    main()

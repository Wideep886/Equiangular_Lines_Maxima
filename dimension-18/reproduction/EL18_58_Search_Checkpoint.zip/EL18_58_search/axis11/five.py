"""All five-block cores with no three disjoint blocks (three disjoint is a separate branch)."""
from pair_cores import put,pairs,calc
from itertools import combinations,permutations
import json,warnings
from functools import lru_cache
warnings.filterwarnings('ignore',category=UserWarning)
def build(sets):
    E={}
    for s in sets:
        for i,j in pairs(s):assert put(E,i,j,-1)
    rem=[]
    for a,b in pairs(sets):
        if set(a)&set(b):
            for i in set(a)-set(b):
                for j in set(b)-set(a):
                    if not put(E,i,j,1):return
        else:rem.append((a,b))
    def rec(h,graph):
        if h==len(rem):
            n=max(x for s in sets for x in s)+1
            assert len(graph)==n*(n-1)//2
            yield tuple(graph[i,j] for i,j in pairs(range(n)));return
        a,b=rem[h]
        def swaps(s):
            def sig(x,y):return all((x in t)==(y in t) for t in sets) and all(graph.get(tuple(sorted((x,i))))==graph.get(tuple(sorted((y,i)))) for i in range(max(map(max,sets))+1) if i not in (x,y))
            return [(i,j) for i,j in pairs(s) if sig(i,j)]
        left=[(a.index(i),a.index(j)) for i,j in swaps(a)];right=swaps(b);seen=set()
        for p in permutations(b):
            if p in seen:continue
            orb=[p];seen.add(p)
            for q in orb:
                for i,j in left:
                    t=list(q);t[i],t[j]=t[j],t[i];t=tuple(t)
                    if t not in seen:seen.add(t);orb.append(t)
                for i,j in right:
                    t=tuple(j if x==i else i if x==j else x for x in q)
                    if t not in seen:seen.add(t);orb.append(t)

            G=graph.copy()
            if all(put(G,i,j,-1 if j==v else 1) for i,v in zip(a,p) for j in b):yield from rec(h+1,G)
    yield from rec(0,E)
def canon(n,edges,colors):
    adj=[0]*n
    for a,b in edges:adj[a]|=1<<b;adj[b]|=1<<a
    def visit(parts):
        while True:
            masks=[sum(1<<i for i in g) for g in parts];out=[]
            for g in parts:
                v={}
                for i in g:v.setdefault(tuple((adj[i]&m).bit_count() for m in masks),[]).append(i)
                out.extend(v[k] for k in sorted(v))
            if len(out)==len(parts):break
            parts=out
        s=next((k for k,g in enumerate(parts) if len(g)>1),None)
        if s is None:
            u=[g[0] for g in parts]
            return tuple(sum(((adj[i]>>j)&1)<<a for a,j in enumerate(u)) for i in u)
        g=parts[s];done=set();values=[]
        for i in g:
            if adj[i] in done or (adj[i]|(1<<i)) in done:continue
            done.add(adj[i]);done.add(adj[i]|(1<<i))
            values.append(visit(parts[:s]+[[i],[x for x in g if x!=i]]+parts[s+1:]))
        return min(values)
    return visit(colors)
def gen():
    edges=list(pairs(range(5)));seen=set()
    for mask in range(1<<10):
        e={edges[j] for j in range(10) if mask>>j&1}
        key=min(tuple(sorted(tuple(sorted((p[i],p[j]))) for i,j in e)) for p in permutations(range(5)))
        if key in seen:continue
        seen.add(key);E=set(key)
        if any(not any(p in E for p in pairs(s)) for s in combinations(range(5),3)):continue
        cl=[s for k in range(2,6) for s in combinations(range(5),k) if all(p in E for p in pairs(s))]
        cs=[s for s in cl if not any(set(s)<set(t) for t in cl)]
        if any(len(x)>4 for x in cs) or sum(len(x)*(len(x)-1)//2 for x in cs)!=len(e):continue
        sets=[[j for j,x in enumerate(cs) if i in x] for i in range(5)]
        n=len(cs)
        for s in sets:
            end=n+4-len(s);s.extend(range(n,end));n=end
        lookup={};raw=0
        for row in build(sets):
            raw+=1;neg=[(i,j) for (i,j),v in zip(pairs(range(n)),row) if v<0]
            neg.extend((n+i,j) for i,s in enumerate(sets) for j in s)
            code=canon(n+5,neg,[list(range(n)),list(range(n,n+5))])
            lookup.setdefault(code,row)
        label=''.join(str(i)+str(j) for i,j in key);ls=list(lookup.values());print(label,n,raw,len(ls),flush=True)
        for i,row in enumerate(ls):yield label+'_'+str(i),n,row,sets
if __name__=='__main__':
 out={}
 for name,n,row,sets in gen():out[name]={**calc(name,n,row),'sets':sets}
 json.dump(out,open('five.json','w'))

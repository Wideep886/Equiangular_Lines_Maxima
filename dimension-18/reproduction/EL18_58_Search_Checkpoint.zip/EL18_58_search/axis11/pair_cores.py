"""Classify three patterns forced through a pair. All points oriented against both anchors."""
from itertools import permutations,product,combinations
from collections import Counter
import numpy as np,json
from sympy import Matrix
def pairs(vertices):return combinations(vertices,2)
def put(E,i,j,z):
    if i==j:return False
    k=tuple(sorted((i,j)))
    if E.get(k,z)!=z:return False
    E[k]=z;return True
def build(sets):
    E={}
    for s in sets:
        for i,j in pairs(s):assert put(E,i,j,-1)
    rem=[]
    for a,b in pairs(sets):
        if set(a)&set(b):
            for i in set(a)-set(b):
                for j in set(b)-set(a):
                    if not put(E,i,j,1):return
        else:rem.append((a,b))
    def rec(h,graph):
        if h==len(rem):
            n=max(x for s in sets for x in s)+1
            assert len(graph)==n*(n-1)//2
            yield tuple(graph[i,j] for i,j in pairs(range(n)));return
        a,b=rem[h]
        for p in permutations(b):
            G=graph.copy()
            if all(put(G,i,j,-1 if j==v else 1) for i,v in zip(a,p) for j in b):yield from rec(h+1,G)
    yield from rec(0,E)
def patterns():
    # Relabel three disjoint K4s to fix two matchings to the identity.
    ss=[list(range(4*i,4*i+4)) for i in range(3)]
    for lengths in ((4,),(3,1),(2,2),(2,1,1),(1,1,1,1)):
        p=[];i=0
        for l in lengths:p.extend(list(range(i+1,i+l))+[i]);i+=l
        row=tuple(-1 if i//4==j//4 or (i%4==j%4 if i<4 else p[i%4]==j%4) else 1 for i,j in pairs(range(12)))
        yield 'D'+''.join(map(str,lengths)),12,row
    ss=[[0,1+3*i,2+3*i,3+3*i] for i in range(3)]
    row,=build(ss);yield 'star',10,row
    ss=[[(i-1)%5,i,5+2*i,6+2*i] for i in range(5)]
    raw=set(build(ss));print('labelled cycles',len(raw),flush=True)
    edges=list(pairs(range(15)));lookup={a:i for i,a in enumerate(edges)}
    actions=[]
    for off,sg,sw in product(range(5),(-1,1),product(range(2),repeat=5)):
        v=[(off+sg*i-(sg<0))%5 for i in range(5)]
        v.extend(5+2*((off+sg*i)%5)+(j^sw[i]) for i in range(5) for j in range(2))
        actions.append([lookup[tuple(sorted((v[i],v[j])))] for i,j in edges])
    k=0
    while raw:
        row=min(raw);o={tuple(row[i] for i in a) for a in actions};assert o<=raw
        raw-=o;k+=1
        yield 'C5_'+str(k),15,row
def calc(name,n,row):
    G=5*np.eye(n+2,dtype=int)-np.ones((n+2,n+2),dtype=int);np.fill_diagonal(G,5)
    for (i,j),s in zip(pairs(range(n)),row):G[i+2,j+2]=G[j+2,i+2]=s
    M=Matrix(G);idx=list(M.rref()[1]);r=len(idx);B=M.extract(idx,idx)
    if not B.is_positive_definite:return dict(psd=False)
    assert M[:,idx]*B.inv()*M[idx,:]==M
    return dict(psd=True,rank=r,gram=G.tolist())
if __name__=='__main__':
    obj={}
    for name,n,row in patterns():
        obj[name]=z=calc(name,n,row);print(name,z.get('rank'),flush=True)
    json.dump(obj,open('pair_cores.json','w'))

from fractions import Fraction as F
from math import isqrt
import json,itertools
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
import numpy as np
def lattice(m):
    M=Matrix(m);ids=list(M.rref()[1]);B=M.extract(ids,ids);C=hermite_normal_form(M[ids,:])
    # B is itself a short basis of the full lattice if the two images have equal covolume.
    if abs(B.det())==abs(C.det()):C=B
    G=C.T*B.inv()*C
    if C!=B: # choose a short integral basis from generators when possible
        U=C.inv()*M[ids,:];H=hermite_normal_form(U);assert abs(H.det())==1
    L,D=G.LDLdecomposition(hermitian=False);r=len(ids);L=[[F(v) for v in row] for row in L.tolist()];d=[F(D[i,i]) for i in range(r)]
    x=[0]*r;found=[]
    def rec(i,left):
        if i<0:
            s=5-left
            if s>0 and next(k for k in x if k)>0:found.append((int(s),x.copy()))
            return
        c=sum((L[j][i]*x[j] for j in range(i+1,r)),F());z=c.denominator
        rad=left*z*z/d[i];b=isqrt(rad.numerator//rad.denominator)
        for v in range(-((b+c.numerator)//z),(b-c.numerator)//z+1):
            x[i]=v;rec(i-1,left-d[i]*(v+c)**2)
    rec(r-1,F(5));Q=M[ids,:].T*B.inv()*C
    return [(k,list(map(int,Q*Matrix(u)))) for k,u in found],ids,B
def analyze(m):
    found,idx,B=lattice(m)
    bad=[q for q in found if q[0]!=5]
    if bad:return dict(forbid=bad)
    s=np.array([v for _,v in found],dtype=int);T=B.inv();D=int(T.as_numer_denom()[1]) if hasattr(T,'as_numer_denom') else 0
    from math import lcm
    D=lcm(*(int(v.q) for v in T));T=np.array(T*D,dtype=int)
    sig=s[:,idx];assert np.all(sig@T@sig.T%D==0);G=sig@T@sig.T//D
    A=[i for i,v in enumerate(s) if abs(v[0])==1 and v[0]==v[1]]
    signs=np.sign(s[A,0]);g=G[np.ix_(A,A)]*signs[:,None]*signs[None,:]
    cs=[frozenset(c) for c in itertools.combinations(range(len(A)),4) if all(g[i,j]==-1 for i,j in itertools.combinations(c,2))]
    ds=set()
    for a,b,c in itertools.combinations(cs,3):
        if a&b or b&c or a&c:continue
        def match(v,U):return next(j for j in U if g[v,j]<0)
        perm={i:match(match(match(i,b),c),a) for i in a};un=set(a);cy=[]
        while un:
            x=next(iter(un));n=0
            while x in un:un.remove(x);n+=1;x=perm[x]
            cy.append(n)
        ds.add('D'+''.join(map(str,sorted(cy,reverse=True))))
    return dict(lines=len(s),tetra=len(cs),disjoint=sorted(ds),signs=s.tolist())
if __name__=='__main__':
    out={}
    for k,v in json.load(open('five.json')).items():
        out[k]=q=analyze(v['gram'])
        print(k,len(q.get('forbid',[])),q.get('lines'),q.get('tetra'),q.get('disjoint'),flush=True)
        json.dump(out,open('five_shells.json','w'))

"""Exact pairwise residual tensor constraints on all distinct negative-triangle axes."""
from fractions import Fraction as Q
from itertools import combinations_with_replacement


def projected(k, l, h):
    # Cross product of <U_i,C_axis> and its counterpart for another axis.
    inner = Q(58,36)-Q(4,27)*(k+l)+Q(64,81)*h
    mean_k = Q(8*k,9*58)-Q(1,6)
    mean_l = Q(8*l,9*58)-Q(1,6)
    return inner/24 + 58*mean_k*mean_l*(Q(9,13)-Q(1,24))


def norm(k):
    return Q(17,18)-projected(k,k,k)


def residual(k,l,h,s):
    return Q(s*s,81)-Q(1,18)-projected(k,l,h)


def allowed(k,l,h,s):
    return residual(k,l,h,s)**2<=norm(k)*norm(l)


def main():
    total=kept=0
    for k,l in combinations_with_replacement(range(3,19),2):
        for h in range(k+1):
            for s in (1,3,5):
                total+=1
                kept+=allowed(k,l,h,s)
    surviving=[(h,s) for h in range(19) for s in (1,3,5) if allowed(18,18,h,s)]
    assert surviving==[(0,5)]
    assert all(not allowed(k,18,h,s) for k in (3,4,5) for h in range(k+1) for s in (1,3,5))
    assert norm(18)==Q(20,351) and residual(18,18,0,5)==-Q(44,1053)
    assert norm(18)+2*residual(18,18,0,5)==-Q(28,1053)
    print("abstract tuples checked, kept, removed",total,kept,total-kept)
    print("k=l=18 admits only (h,s)=(0,5); three such axes have negative residual row sum")


if __name__=="__main__":
    main()

from incidence import types
from fractions import Fraction as Q
from scipy.optimize import linprog
import numpy as np,json
A,B=[np.load('incidence_3.npz')[k] for k in ('A','B')]
cap=[sum(Q(1,x+1) for x in t) for t in types];nmax=0
for n in range(57):
 d=Q(4)+Q(n,2)-16;e=Q(6)+Q(56-n,3)-16
 if d*d+e*e+(2-d-e)**2/16<=84:nmax=n
out=[]
for bound in np.arange(73.1,80,.2):
 a=np.vstack([np.column_stack([-A[:,:-1],np.zeros(len(A))]),np.column_stack([B,np.zeros(len(B))]),np.column_stack([np.eye(len(cap)),-np.array(cap,float)])])
 b=np.r_[-A[:,-1],np.full(len(B),bound),np.zeros(len(cap))]
 res=linprog([0]*len(cap)+[1],A_ub=a,b_ub=b,bounds=[(0,None)]*(len(cap)+1))
 if not res.success:continue
 # Round up all weights to preserve the hex inequalities, reevaluate all bounds exactly.
 w=[int(np.ceil(z*1000)) for z in res.x[:-1]]
 assert (A[:,:-1]@w>=1000*A[:,-1]).all()
 U=int((B@w).max());C=max(Q(v,e) for v,e in zip(w,cap))
 low=(4492*30000-1653*U)/(C*nmax-U)
 out.append((low,U,str(C),w))
o=max(out);print('max n',nmax,'exceptional pairs >=',o[:3],flush=True)
json.dump(dict(weights=o[3],max_good=o[1],slope=o[2],max_n=nmax,lower=str(o[0])),open('mass_cert.json','w'))

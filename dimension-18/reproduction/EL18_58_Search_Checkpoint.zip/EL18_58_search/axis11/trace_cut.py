"""Short independent certificate excluding all even T <= 13498.

For C=G-16I, every k-th elementary coefficient is divisible by 2^(k-1):
subtract the first row from the others in each principal k-minor. Dividing
the characteristic polynomial by (x+16)^40 preserves this property, by
comparing coefficients in descending order. Thus if there are s+1 nonzero
shifted eigenvalues t, their product has absolute value at least 2^s.

Let h=max t. Cauchy gives 18h^2-4h-1424<=0. For K=901/100 above its
positive root, every (K-t)(t+2/5)^2 >= 0. A lower bound q for sum t^3
forces h>=q/84 and (K-h)(h+2/5)^2<=delta, yielding the recursion below.
For the s nonzero remaining t, square sum R<=84-h^2 and trace 2-h force
s*R >= (h-2)^2. Their product, together with h, is <=K*(R/s)^(s/2).
"""
from argparse import ArgumentParser
from fractions import Fraction as F

K=F(901,100)
shift=F(2,5)


def test_triangle_count(target):
    q=162680-12*target
    lower=F(q,84)
    if lower<=2:
        return False
    assert 18*K*K-4*K-1424>0
    delta=K*(84+4*shift+18*shift**2)-(q+2*shift*84+2*shift**2)
    if delta<0:
        return True
    for _ in range(2):
        lower=max(lower,K-delta/(lower+shift)**2)
    R=84-lower*lower
    if R<=0:
        return True
    for s in range(1,18):
        if s*R >= (lower-2)**2 and K**2 * (R/(4*s))**s >= 1:
            return False
    return True


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('target',nargs='?',type=int,default=13498)
    target=p.parse_args().target
    excluded=test_triangle_count(target)
    print('T <=',target,'excluded:',excluded)
    if excluded:
        minimum=(target//2+1)*2
        excess=minimum-9004
        witnesses=(30*excess*F(21904705,8)-1653*200000311)/100002005
        print('T >=',minimum,'T-u >=',excess,'witnesses >=',-(-witnesses.numerator//witnesses.denominator))
    assert test_triangle_count(13498)

"""Exact D-flat incidence verifier. All numbers are integers."""
import argparse
import json
from itertools import combinations
from math import comb
from pathlib import Path

DIR = Path(__file__).resolve().parent


def prime_rank(rows, p=101):
    a = [[x % p for x in row] for row in rows]
    k = 0
    for j in range(len(a[0])):
        i = next((i for i in range(k, len(a)) if a[i][j]), None)
        if i is None:
            continue
        a[i], a[k] = a[k], a[i]
        inv = pow(a[k][j], -1, p)
        for i in range(k+1, len(a)):
            f = inv * a[i][j] % p
            a[i] = [(x-f*y) % p for x,y in zip(a[i],a[k])]
        k += 1
        if k == len(a):
            break
    return k


def witnesses(g):
    terms = []
    for i,j in combinations(range(len(g)),2):
        layer = [x for x in range(len(g)) if x not in (i,j)
                 and g[i][x] == -g[i][j]*g[j][x]]
        tetra = [sum(1<<x for x in t) for t in combinations(layer,4)
                 if all(g[x][y]*g[i][x]*g[i][y] == -1
                        for x,y in combinations(t,2))]
        for a,b,c in combinations(tetra,3):
            if (a&b) == (a&c) == (b&c) == 0:
                terms.append(a|b|c|(1<<i)|(1<<j))
    return terms


def union_size(terms):
    mask = 0
    for x in terms:
        mask |= x
    return bin(mask).count('1')


def shell_cost(name, z):
    g = z['shell_gram']
    n = len(g)
    assert len(z['basis']) == 11
    assert all(prime_rank(g[:i]+g[i+1:]) == 11 for i in range(n))
    assert sum(g[0][x] == g[1][x] for x in range(n)) == n-2
    terms = witnesses(g)
    costs = [0]+[min(map(union_size,combinations(terms,k)))
                 for k in range(1,len(terms)+1)]
    print(name,'shell',n,'hyperplane',n-2,'witnesses',len(terms),'costs',costs[1:])
    return costs


def bound(cost, total):
    inf = 18*total+1
    dp = [0]+[inf]*total
    scores = []
    for b in range(1,total+1):
        dp = [min([inf]+[dp[t-k]+cost[k] for k in range(1,min(t,8)+1)])
              for t in range(total+1)]
        if dp[total] >= inf:
            continue
        s = dp[total]
        q,r = divmod(total-b,7)
        assert s == 14*b+4*q+(0,3,4,4,4,4,4)[r]
        d,r = divmod(s,58)
        scores.append((58*comb(d,2)+r*d-3*comb(b,2),b,s,d,r))
    e,b,s,d,r = min(scores)
    n = max(0,(e+12)//13)
    print('T',total,'b_range',[(total+7)//8,total],'min_E',e,'at',b,
          'incidences',s,'d,r',(d,r),'overlap_pairs_at_least',n)
    return n


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('thresholds',type=int,nargs='*',default=[384,394])
    args = parser.parse_args()
    data = json.loads((DIR.parent/'coredata'/'cores.json').read_text())
    family = [shell_cost(name,z) for name,z in data.items()]
    c = [min(s[k] for s in family if k < len(s)) for k in range(9)]
    assert c == [0,14,17,18,18,18,18,18,18]
    for total in args.thresholds:
        if total < 1:
            parser.error('threshold must be positive')
        bound(c,total)

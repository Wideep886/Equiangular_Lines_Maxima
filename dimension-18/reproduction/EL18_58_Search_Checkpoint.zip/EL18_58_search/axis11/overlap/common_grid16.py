"""Rebuild all possible D1111 anchor projections on its rank-ten grid."""
import json
import sys
from collections import Counter
from itertools import combinations, product
from math import lcm
from pathlib import Path
from overlap_flats import prime_rank, witnesses

DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(DIR/'coredata'))
from core import inv


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


g = json.loads((DIR/'coredata'/'cores.json').read_text())['D1111']['shell_gram']
exceptional = [pair for pair in combinations(range(18),2)
               if prime_rank([z for i,z in enumerate(g) if i not in pair]) < 11]
assert exceptional == [(0,1)]
grid = [z[2:] for z in g[2:]]
assert [[dot(x,y) for x in grid] for y in grid] == [[8*x for x in a] for a in grid]
basis = []
for i in range(16):
    if prime_rank([grid[j] for j in basis+[i]]) > len(basis):
        basis.append(i)
assert len(basis) == 10
a = inv([[grid[i][j] for i in basis] for j in basis])
D = lcm(*(x.denominator for r in a for x in r))
T = [[int(x*D) for x in r] for r in a]
signs = [[row[j] for j in basis] for row in grid]
valid = []
accept = []
for tail in product([1,-1],repeat=9):
    s = [1,*tail]
    u = [dot(row,s) for row in T]
    h = [dot(row,u) for row in signs]
    if any(abs(x) != D for x in h):
        continue
    assert dot(s,u) == 2*D
    valid.append(s)
    h = [x//D for x in h]
    z = [[5,-1,*h],[-1,5,*h]]+[[x,x,*row] for x,row in zip(h,grid)]
    w = witnesses(z)
    if w:
        accept.append((s,u,len(w)))
assert len(valid) == 70 and len(accept) == 10
assert {k for s,u,k in accept} == {8}
assert all(dot(s,u) == 0 for (s,_,n),(_,u,m) in combinations(accept,2))
print('exceptional omitted pair',exceptional,'rank',len(basis),'tight frame constant',8)
print('projective signatures',len(valid),'valid anchor projections',len(accept),
      'witness counts',dict(Counter(k for s,u,k in accept)),'orthogonal pairs',45)

"""Two exact, deterministic estimates of the number of high lines on one triangle axis."""
from fractions import Fraction as Q


def frame_test(k):
    low = 58 - k
    alpha = Q(8*k+58, 9)
    beta = (290-alpha)/17
    changed = (alpha-16)**2 + 17*(beta-16)**2
    if changed > 84:
        return changed
    variance = Q(3,2)-Q(k,17)
    assert variance > 0
    return changed + k*(6+Q(2*low,9)-beta)**2/variance


def tensor_test(k):
    # Gram of the traceless rank-one tensors is 24I - (7/18)J.
    m = (k*Q(13,18)+(58-k)*Q(-1,6))/58
    return (k*Q(13,18)**2 + (58-k)*Q(1,6)**2)/24 + 58*m*m*(Q(9,13)-Q(1,24))


if __name__ == "__main__":
    candidates = range(3,59)
    a = [k for k in candidates if frame_test(k)<=84]
    b = [k for k in candidates if tensor_test(k)<=Q(17,18)]
    print("frame", a, "tensor", b)
    assert a == b == list(range(3,19))
    print("k=19,20 frame", frame_test(19), frame_test(20))
    print("k=19,20 tensor", tensor_test(19), tensor_test(20))

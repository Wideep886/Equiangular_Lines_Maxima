"""Replay the isolated cubic tail at T=13510 using the archived exact deletion screen."""
import pathlib,sys,tempfile,subprocess

here=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'m13'))
import anchor,fastdeck
h=[1,-4,-1,1]
for _ in range(3):h=[a+b for a,b in zip([0]+h,h+[0])]
with tempfile.TemporaryDirectory() as dest:
 d=pathlib.Path(dest);fastdeck.HERE=d
 subprocess.run(['c++','-O3','-std=c++17',str(here.parent/'m13/fastdeck.cpp'),'-o',str(d/'fastdeck')],check=True)
 result=anchor.anchor(12,h);print(h,result);assert result==(20,[],0)

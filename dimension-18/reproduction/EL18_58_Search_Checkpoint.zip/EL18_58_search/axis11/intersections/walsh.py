"""For each local real Gram, bound signature supports in a nondegenerate binary symplectic space."""
import json
from itertools import product
from collections import Counter
from pathlib import Path
here=Path(__file__).resolve().parent
def rem(x,base):
 for y in base:x=min(x,x^y)
 return x
def base(seq):
 L=[]
 for s in seq:
  r=rem(s,L)
  if r:L.append(r);L.sort(reverse=True)
 return L
def dot(x,y):return sum(i*j for i,j in zip(x,y))
def mask(v):return sum((x<0)<<i for i,x in enumerate(v))
def solve(d):
 G=d['gram'];I=d['basis'];T=d['integral_inverse'];D=d['denominator'];B=[[G[i][j] for j in I] for i in I]
 C=d['shell_coefficients']
 C=[[v*(1 if dot(c,B[0])>0 else -1) for v in c] for c in C]
 core=base(mask(dot(c,[dot(q,b) for b in B]) for c in C) for q in C)
 counts=Counter()
 for z in product((-1,1),repeat=len(I)-1):
  s=(1,)+z
  if dot(s,[dot(t,s) for t in T])>=5*D:continue
  sig=[dot(c,s) for c in C]
  if all(abs(v)==1 for v in sig):counts[rem(mask(sig),core)]+=1
 k=len(core);spaces={frozenset([0])};maxima=[]
 while spaces:
  maxima.append(max(sum(counts.get(u,0) for u in g) for g in spaces))
  spaces={g|frozenset(u^v for u in g) for g in spaces for v in counts if v not in g}
 return [k,sum(counts.values()),[maxima[min((f-k)//2,len(maxima)-1)] for f in (10,12,14,16)]]
if __name__=='__main__':
 output={s:solve(d) for s,d in json.loads((here.parent/'coredata/cores.json').read_text()).items()}
 print(output);(here/'walsh.json').write_text(json.dumps(output,indent=1))

from incidence import types
from fractions import Fraction as Q
from scipy.optimize import linprog
import numpy as np,json
A,B=[np.load('incidence_3.npz')[h] for h in ('A','B')];n=len(types);M=[];rhs=[]
# Variables weights, three discrete changes, hex scaling and good-pair cap.
def eq(r,b=0):M.append(r);rhs.append(b)
for a in A:eq(list(-a[:-1])+[0,0,0,a[-1],0])
for b in B:eq(list(b)+[0,0,0,0,-1])
for k,t in enumerate(types):
 for j in set(t)-{0}:
  v=list(t);v[v.index(j)]-=1;q=[0]*(n+5);q[k]=1;q[types.index(tuple(sorted(v)))]=-1;q[n+j-1]=-1;eq(q)
 row=[0]*(n+5);row[k]=1
 for j in t:
  if j:row[n+j-1]+=j
 eq(row,1)
c=[0]*(n+3)+[-30*4492,1653]
res=linprog(c,A_ub=M,b_ub=rhs,bounds=[(None,None)]*(n+3)+[(0,None),(None,None)])
v=[Q(float(x)).limit_denominator(10000000) for x in res.x];assert all(sum(x*z for x,z in zip(row,v))<=h for row,h in zip(M,rhs))
value=-sum(x*z for x,z in zip(c,v));print(value,float(value));json.dump([str(x) for x in v],open('triple_mass.json','w'))

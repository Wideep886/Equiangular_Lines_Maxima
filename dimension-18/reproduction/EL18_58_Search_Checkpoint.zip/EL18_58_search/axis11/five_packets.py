import json
from packets import check
shells=json.load(open('five_domain.json'));cores=json.load(open('five.json'));out={}
for k,v in cores.items():
    s=shells[k]
    if any(not x[0] for x in s['groups']):
        print(k,'height zero',flush=True);continue
    out[k]=r=check(v['gram'],s);print(k,r['classes'],r['stats']['short_pass'],flush=True)
json.dump(out,open('five_packets.json','w'),separators=(',',':'))

"""Deterministic rational replay of the six-coaxial-triangles obstruction."""
from fractions import Fraction as Q
from itertools import combinations, product


def energy(k):
    a = Q(8*k+58,9)
    b = 72+Q(8,3)*(58-k)
    c = 290-a-b
    return (a-16)**2+(b-192)**2/12+(c-80)**2/5


def centered(table):
    total = sum(map(sum,table))
    return [[Q(table[i][j])-Q(sum(table[i]),3)-Q(sum(row[j] for row in table),3)
             +Q(total,9) for j in range(3)] for i in range(3)]


def mixed_differences(table):
    return [table[i][j]-table[k][j]-table[i][l]+table[k][l]
            for i,k in combinations(range(3),2) for j,l in combinations(range(3),2)]


def dot(a,b):
    return sum(i*j for i,j in zip(a,b))


def main():
    assert [k for k in range(18,59) if energy(k)<=84]==[18]
    assert Q(81,8)*(84-energy(18))==120
    occupancies=[(i,j,40-i-j) for i in range(41) for j in range(41-i)]
    assert len(occupancies)==861
    assert min(sum((Q(x)-Q(40,3))**2 for x in n) for n in occupancies)==Q(2,3)
    assert min(sum((x-y)%3!=0 for x,y in combinations(n,2)) for n in occupancies)==2
    # Polarized quadratics on a basis verify their identity for any real 3-by-3 table.
    basis=[[[int((i,j)==(k,l)) for j in range(3)] for i in range(3)]
           for k,l in product(range(3), repeat=2)]
    for a,b in product(basis,repeat=2):
        ca,cb=centered(a),centered(b)
        assert 9*sum(dot(x,y) for x,y in zip(ca,cb))==dot(mixed_differences(a),mixed_differences(b))
    for eps,m in product((-1,1),range(7)):
        v=Q(9*eps+11-6*m,2)
        assert v.denominator==1 and v%3==1
    # A nonconstant triple of integers always has sum of squared pair differences >=2.
    assert min(j for j in range(1,10) if j%2==0 and j%3==1)==4
    marginal=6*Q(81,8)*Q(8,27)*Q(2,3)
    table_term=15*2*2
    residual=Q(4,2)+6*2*4
    assert (marginal,table_term,residual)==(12,60,50)
    assert marginal+table_term+residual>120
    print("k=18, 861 marginals, 81 polarized table checks, 12+60+50=122>120")


if __name__=="__main__":
    main()

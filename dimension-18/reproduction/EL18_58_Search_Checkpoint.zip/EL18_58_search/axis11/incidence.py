"""Link-graph and hexad-partition flag counts under no three disjoint tetrahedra through any pair."""
from itertools import combinations,product,permutations
from math import comb
import json,numpy as np
from scipy.optimize import linprog
from fractions import Fraction as Q
from collections import Counter
P=list(combinations(range(6),2));parts=[set((0,)+s) for s in combinations(range(1,6),2)]
hits=np.array([[(a in s)==(b in s) for s in parts] for a,b in P],int)
types=list(combinations_with_replacement(range(4),4)) if False else sorted({tuple(sorted(v)) for v in product(range(4),repeat=4)})
def graphs():
    out={}
    for q in range(9):
        def add(e):
            cl=[set(x) for j in range(2,min(5,q)+1) for x in combinations(range(q),j) if all(a in e for a in combinations(x,2))]
            mx=[s for s in cl if not any(s<t for t in cl)]
            if any(len(s)>4 for s in mx) or sum(comb(len(s),2) for s in mx)!=len(e):return
            if any(not any(z in e for z in combinations(t,2)) for t in combinations(range(q),3)):return
            vs=[sorted([len(s)-1 for s in mx if j in s]) for j in range(q)]
            if any(len(v)>4 for v in vs):return
            key=tuple(sorted(tuple([0]*(4-len(v))+v) for v in vs));out[key]=[q,sorted(e)]
        if q<=5:
            es=list(combinations(range(q),2))
            for m in range(1<<len(es)):add({a for i,a in enumerate(es) if m>>i&1})
        else:
            # A triangle exists by R(3,3). Choose a maximum clique. Outside is a clique;
            # each outside vertex has at most one neighbor in the chosen clique.
            for a in range(3,5):
                if q-a>a:continue
                ins=set(combinations(range(a),2))|set(combinations(range(a,q),2))
                for m in product(range(-1,a),repeat=q-a):
                    add(ins|{(i,j) for j,i in enumerate(m,a) if i>=0})
    return out
def hexprofiles(e_max):
    base=e_max+1;ix=np.arange(base**10);V=(ix[:,None]//(base**np.arange(10)))%base
    # Unique local histograms, computed by blocks to avoid large intermediates.
    seen={}
    powers=np.array([1,4,16,64]);code={sum(p*i for p,i in zip(powers,t)):k for k,t in enumerate(types)}
    lookup=np.zeros(256,int)
    for a,j in code.items():lookup[a]=j
    for start in range(0,len(V),8000):
        X=V[start:start+8000];T=np.array([lookup[np.sort(X[:,row.astype(bool)],axis=1)@powers] for row in hits]).T
        Y=np.zeros((len(X),len(types)),np.int8);np.add.at(Y,(np.arange(len(X))[:,None],T),1)
        W=np.column_stack([Y,(60//(X+2)).sum(axis=1)])
        _,ids=np.unique(W,axis=0,return_index=True)
        for j in ids:seen[tuple(W[j])]=X[j].tolist()
    return seen
def solve(em):
    G={k:v for k,v in graphs().items() if all(max(t)<=em for t in k)}
    X=hexprofiles(em);A=np.array(list(X),dtype=int);B=np.array([[v.count(k) for k in types] for v in G],dtype=int)
    eq=np.vstack([np.column_stack([A[:,:-1].T,-B.T]),np.r_[np.zeros(len(A)),np.ones(len(B))]])
    c=np.r_[-A[:,-1],np.zeros(len(B))];rhs=[0]*len(types)+[1]
    rr=linprog(c,A_eq=eq,b_eq=rhs,bounds=(0,None))
    # Maximize sum_H sum_j 60/(2+e_j) per pair. Required >=30*4492/1653.
    print(em,len(X),len(G),-rr.fun,'required',30*4492/1653,flush=True)
    u=[Q(float(-z)).limit_denominator(100000) for z in rr.eqlin.marginals]
    if all(sum(int(b)*s for b,s in zip(row[:-1],u))>=int(row[-1]) for row in A) and all(u[-1]>=sum(int(b)*s for b,s in zip(row,u)) for row in B):
        json.dump(list(map(str,u)),open('incidence_dual_'+str(em)+'.json','w'))
    np.savez_compressed('incidence_'+str(em)+'.npz',A=A,B=B)
if __name__=='__main__':
 for em in (1,2,3):solve(em)

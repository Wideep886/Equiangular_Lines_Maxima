"""Three-shell distributions after conditioning on one original line. Average over the 58 anchors."""
import numpy as np
from fractions import Fraction as Q
from scipy.optimize import linprog
from itertools import combinations_with_replacement
from math import lcm
def harm(k,s,a,b,d):
    v,w=Q(1),s
    if k==0:return v
    for j in range(1,k):v,w=w,((2*j+d-2)*s*w-j*a*b*v)/(j+d-2)
    return w
def model(U,levels):
    # All shell quantities are normalized by U for axes and 57 for ordinary neighbors.
    h=[1,3,1];norm=[9,9,5];scale=[3,3,2]
    pairs=[]
    for i,j in combinations_with_replacement(range(3),2):
        signs=(1,3,5) if j<2 else (1,) if i==2 else (1,3)
        pairs.extend((i,j,s) for t in signs for s in (-t,t))
    # Variables pair entries (one orientation for i<j), then diagonal masses for low and high.
    N=len(pairs)+2;diag=[Q(1,U),Q(1,U),Q(1,57)]
    # Add homogeneous variable unit, fixed to 1 in LP.
    N+=1
    def null():return [Q(0)]*N
    p=[null() for _ in range(3)]
    p[0][-3]=p[1][-2]=p[2][-1]=1
    def add(a,b,c=1):return [v+c*w for v,w in zip(a,b)]
    E=[add(add(p[0],p[1]),p[2],-1)]
    A=[]
    # Rows sum separately over the whole axis set and over ordinary neighbors.
    for i in range(3):
        for kind in (0,1):
            row=null()
            for k,(x,y,s) in enumerate(pairs):
                if x==i and (y==2)==kind or y==i and (x==2)==kind:row[k]=1
            row=add(row,p[i],diag[i] if (i==2)==kind else 0)
            E.append(add(row,p[i],-1))
    row=null()
    for k,(i,j,s) in enumerate(pairs):
        if j==2 and i<2 and abs(s)==3:row[k]=1
    E.append(add(row,p[1],-1))
    # Swapping the anchor and its neighbor preserves the sign of the loop product,
    # so for each sign there are equally many mixed (1,3) and (3,1) incidences.
    for sign in (-1,1):
        row=null();row[pairs.index((0,2,3*sign))]=1;row[pairs.index((1,2,sign))]=-1;E.append(row)
    # The ordered probability of a negative original triangle lies in the known moment range.
    from math import comb
    k=pairs.index((2,2,-1))
    row=null();row[k]=1;row[-1]=-Q(13496,comb(58,3))*Q(56,57);A.append(row)
    def matrices(d,anchor):
        mats=[]
        for k in range(levels+1):
            H=[[null() for j in range(3)] for i in range(3)]
            for i in range(3):
                a=(Q(norm[i])-Q(h[i]**2,5)*anchor)/scale[i]**2
                H[i][i]=add(H[i][i],p[i],diag[i]*a**k)
            for u,(i,j,s) in enumerate(pairs):
                a=(Q(norm[i])-Q(h[i]**2,5)*anchor)/scale[i]**2;b=(Q(norm[j])-Q(h[j]**2,5)*anchor)/scale[j]**2
                t=(Q(s)-Q(h[i]*h[j],5)*anchor)/(scale[i]*scale[j])
                H[i][j][u]=H[j][i][u]=harm(k,t,a,b,d)
            mats.append(H)
        return mats
    mats=matrices(17,1)+matrices(18,0)
    return E,A,mats
def search(U,levels=9):
    E,A,H=model(U,levels);M=np.array(H,float);V=len(E[0]);eq=np.array(E,float)
    cuts=[];AR=np.array(A,float).tolist(); bounds=[(0,None)]*(V-1)+[(1,1)]
    for it in range(150):
        ar=np.array(AR);R=linprog([0]*V,A_ub=-ar,b_ub=np.zeros(len(ar)),A_eq=eq,b_eq=np.zeros(len(eq)),bounds=bounds,options={'primal_feasibility_tolerance':1e-9})
        if not R.success:return R.status,cuts
        ms=M@R.x;changed=False
        for j,g in enumerate(ms):
            eig,W=np.linalg.eigh(g)
            for z,v in zip(eig,W.T):
                if z>=-3e-9:continue
                vec=np.rint(v*100000).astype(int)
                row=np.einsum('i,ijv,j->v',vec,M[j],vec);row/=max(abs(row))
                AR.append(row.tolist());cuts.append([j,vec.tolist()]);changed=True
        if not changed:return 0,cuts
    return -1,cuts
if __name__=='__main__':
 import sys,json
 for U in map(int,sys.argv[1:]):
    status,c=search(U);print(U,status,len(c),flush=True)
    if status==2:json.dump([U,c],open('axis_cuts_'+str(U)+'.json','w'))

from shells import prep
import numpy as np,json,itertools
from collections import Counter
def domain(m,ss):
    ii,T,D,I,K=prep(m);r=len(ii);local=np.array(ss['signs'],dtype=np.int64)[:,ii]
    # Both orientations retained, each full packet has one common normal.
    R=np.array(list(itertools.product((-1,1),repeat=r)),dtype=np.int64)
    h=5*D-np.einsum('ij,ij->i',R@T,R);good=(np.abs(R@T@local.T)==D).all(axis=1)&(h>=0);H={}
    for s,z in zip(R[good],h[good]):H.setdefault((tuple((s@I.T)%K),int(z)),[]).append(tuple(map(int,s)))
    return dict(local=ss['lines'],D=D,groups=[[h,list(k),vs] for (k,h),vs in H.items()])
if __name__=='__main__':
    C=json.load(open('five.json'));S=json.load(open('five_shells.json'));data={}
    for k,v in C.items():
        o=domain(v['gram'],S[k]);data[k]=o
        print(k,o['D'],len(o['groups']),Counter(map(lambda g:len(g[2]),o['groups'])),flush=True)
    json.dump(data,open('five_domain.json','w'),default=int)

"""Deterministic normal-basis search. Finite beam, exact Gram checks, no exclusion inferred."""
from shells import prep
from collections import defaultdict
from itertools import combinations
from math import gcd
from functools import reduce
import numpy as np,json,sys
from sympy import Matrix
sys.path.insert(0,'../root_profiles')
from word16 import mask,clique
def run(name,core,sh,pack):
    ii,T,D,_,_=prep(core);r=len(ii);dim=18-r
    H=pack['groups'];m=[len(s) for h,k,s,f in H];K=defaultdict(list)
    for i,j,_,v in pack['edges']:
        K[i,j].append(v)
        if i!=j:K[j,i].append(v)
    best=0;bestG=[];nodes=0
    def flush(B,adj,det,chosen,fixed,rows):
        nonlocal best,bestG
        # Only vectors in the realized span of the chosen normal basis are used.
        q=len(B);Z=np.array(adj,dtype=object).reshape(q,q)
        points=chosen+fixed
        if not points:return
        V=np.array([x[1] for x in points],dtype=object).reshape(len(points),q)
        N=(V@Z@V.T);scale=det*D
        X=np.array([x for i,b in points for x in H[i][2]],dtype=np.int64)
        slices=np.repeat(np.arange(len(points)),[m[i] for i,v in points])
        G=(X@T@X.T).astype(object)*det+N[np.ix_(slices,slices)];good=np.array(abs(G)==scale,dtype=bool)
        graph=[mask(a) for a in good];g,ids,_=clique(graph,[1]*len(X),58)
        if len(sh['local_signs'])+g<=best:return
        P=np.array(sh['local_signs']);cross=P@T@X[ids].T
        assert (cross%D==0).all()
        cert=np.block([[P@T@P.T//D,cross//D],[(cross//D).T,G[np.ix_(ids,ids)]//scale]])
        M=Matrix(cert.tolist());assert M.is_positive_semidefinite and M.rank()<=18
        best=len(cert);bestG=M.tolist()
    def rec(B,adj,det,chosen,rows,level):
        nonlocal nodes
        nodes+=1
        alive=[x for x in rows if x[2]>0];fixed=[(i,v) for i,v,q in rows if not q]
        if not alive or len(B)==dim:
            flush(B,adj,det,chosen,fixed,rows);return
        if not level or not chosen:flush(B,adj,det,chosen,fixed,rows)
        seed=sorted(alive,key=lambda x:(-m[x[0]],x[2],x[0],x[1]))
        choices=[];used=set()
        for i,v,t in seed:
            # Try distinct heights and packet sizes first.
            code=(m[i],t)
            if code in used:continue
            used.add(code);choices.append((i,v,t))
            if len(choices)>=(5 if len(B)<1 else 2 if len(B)<3 else 1):break
        for i,v,t in choices:
            w=[sum(x*y for x,y in zip(z,v)) for z in adj];q=len(B);h=H[i][0]
            new=[[(t*adj[j][k]+w[j]*w[k])//det for k in range(q)]+[-w[j]] for j in range(q)]+[[-x for x in w]+[det]]
            # Keep adj/det as inverse; after cancellation use rational bordered recursion.
            # Here det and adj are true determinant and adjugate, including for the empty basis.
            if q:assert all((t*adj[j][k]+w[j]*w[k])%det==0 for j in range(q) for k in range(q))
            prev=[(j,u+[v[a]]) for a,(j,u) in enumerate(chosen)]+[(i,v+[h])]
            R=[]
            for j,u,s in rows:
                dot=sum(a*b for a,b in zip(w,u))
                for z in K[i,j]:
                    delta=t*s-(det*z-dot)**2
                    if delta<0 or delta and q+1==dim:continue
                    assert delta%det==0
                    R.append((j,u+[z],delta//det))
            rec(B+[i],new,t,prev,R,level+1)
    rec([],[],1,[],[(i,[],h) for i,(h,*_) in enumerate(H)],0)
    return best,bestG,nodes
if __name__=='__main__':
    C=json.load(open('pair_cores.json'));S=json.load(open('shells.json'));P=json.load(open('packets.json'))
    for n in C:
        b,G,nodes=run(n,C[n]['gram'],S[n],P[n]);print(n,b,nodes,flush=True)
        json.dump(G,open('built_'+n+'.json','w'),default=int)

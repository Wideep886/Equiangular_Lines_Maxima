from fractions import Fraction as Q
from math import ceil
import numpy as np
from scipy.optimize import linprog
from functools import lru_cache
@lru_cache(None)
def P(k,u):
 a,b=Q(1),Q(1)
 for j in range(1,k):a,b=b,((2*j+16)*(u if j%2 else 1)*b-j*a)/(j+16)
 return b
def rows(k,p):
 s=P(k,Q(1,45));v=P(k,Q(9,45))-s;g=58/(1+57*P(k,Q(1,25)));x=s+p*v
 return [1]+[P(k,Q(d,81)) for d in (1,9,25)]+[-2*g*x*v],g*(2*x*s-x*x)
def search():
 for m in (6,8,10,12,16,24):
    rr=[rows(j,Q(a,100)) for j in range(2,m+1,2) for a in range(10,31)]
    A=np.array([v for v,h in rr],float);b=np.array([h for v,h in rr],float)
    res=linprog([1,0,0,0,0],A_ub=-A,b_ub=-b,A_eq=[[1,1,1,1,0]],b_eq=[1])
    print(m,1/res.fun,res.x,[(j,round(v,5)) for j,v in enumerate(res.ineqlin.marginals) if v<-1e-9])
if __name__=='__main__':search()

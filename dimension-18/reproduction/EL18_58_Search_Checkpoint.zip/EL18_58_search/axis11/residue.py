import json,numpy as np
from sympy import factorint
from math import gcd
from shells import prep
def rank(A,p):
 A=A.copy()%p;b=[]
 for j in range(A.shape[1]):
    k=len(b);ix=np.flatnonzero(A[k:,j])
    if not len(ix):continue
    h=k+ix[0];A[[k,h]]=A[[h,k]];A[k]=A[k]*pow(int(A[k,j]),-1,p)%p
    ix=np.flatnonzero(A[:,j]);ix=ix[ix!=k]
    A[ix]=(A[ix]-A[ix,j,None]*A[k])%p;b.append(j)
    if len(b)==A.shape[0]:break
 return b
def stats(c,packs):
 n=len(c);idx,T,D,I,K=prep(c);V=np.array([z[2][0] for z in packs]);M=D-V@T@V.T;unit=int(np.gcd.reduce(M.ravel(),initial=2*D));N=2*D//unit;M//=unit
 return len(idx),N,[(p,len(rank(M,p))) for p in factorint(N)]
if __name__=='__main__':
 for f,g in [('pair_cores','packets'),('five','five_packets')]:
    C=json.load(open(f+'.json'));P=json.load(open(g+'.json'))
    for n,v in P.items():print(n,*stats(C[n]['gram'],v['groups']))

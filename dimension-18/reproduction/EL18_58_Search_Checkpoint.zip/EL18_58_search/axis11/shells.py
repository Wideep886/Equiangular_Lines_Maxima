from itertools import product,combinations
from math import lcm
from collections import Counter
import numpy as np,json
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
def prep(m):
    M=Matrix(m);ii=list(M.rref()[1]);B=M.extract(ii,ii);C=hermite_normal_form(M[ii,:]);bi=B.inv();ci=C.inv()
    D=lcm(*(int(v.q) for v in bi));K=lcm(*(int(v.q) for v in ci));return ii,np.array(D*bi,dtype=int),D,np.array(K*ci,dtype=int),K
def run(m):
    ii,T,D,I,K=prep(m);r=len(ii);G=np.array(m,dtype=int);orig=G[:,ii]
    for alph,norm in [((-1,1),1),((-2,0,2),4)]:
        for first in alph:
            if first<0:continue
            X=np.array([(first,)+v for v in product(alph,repeat=r-1)],dtype=np.int64)
            ok=((X@T*X).sum(axis=1)==D*norm)&((X@I.T%K)==0).all(axis=1)
            if ok.any():return {'forbidden':int(norm),'vector':list(map(int,X[ok][0]))}
    base=np.array(list(product((-1,1),repeat=r)),dtype=int)
    def canon(x):return min(tuple(x),tuple(-x))
    norm=(base@T*base).sum(axis=1)
    add=base[(norm==5*D)&((base@I.T%K)==0).all(axis=1)]
    X=np.array(sorted(set(map(canon,np.vstack((orig,add))))),dtype=int);assert (X@T@X.T%D==0).all()
    # Count other points compatible with the entire local shell, constrain the local lattice copy of the same coset.
    vals=base@T@X.T;ss=base[(abs(vals)==D).all(axis=1)&(norm<=5*D)]
    groups={}
    for v in ss:
        h=int(5*D-v@T@v);key=(tuple(v@I.T%K),h)
        groups.setdefault(key,[]).append(tuple(map(int,v)))
    return dict(local=len(X),basis=ii,local_signs=X.tolist(),D=D,groups=[[int(h),list(a),rows] for (a,h),rows in groups.items()])
if __name__=='__main__':
    out={}
    for n,v in json.load(open('pair_cores.json')).items():
        q=run(v['gram']);out[n]=q
        print(n,q.get('forbidden'),q.get('local'),Counter((h,len(s)) for h,k,s in q.get('groups',[])),flush=True)
    json.dump(out,open('shells.json','w'),default=int)

from fractions import Fraction as Q
from math import comb
from scipy.optimize import linprog
import numpy as np
def K(n,d,i,q):
 return sum((-1)**j*(q-1)**(i-j)*comb(d,j)*comb(n-d,i-j) for j in range(max(0,i-(n-d)),min(i,d)+1))
def P(n,x,s):
 a,b=Q(1),x
 if s==0:return a
 for j in range(1,s):a,b=b,((2*j+n-2)*x*b-j*a)/(j+n-2)
 return b
for t in range(1,7):
 n=17-2*t;h=44-4*t
 dom=[(d,Q(9*e-1-4*t+6*d,h)) for d in range(t+1) for e in (-1,1) if abs(9*e-1-4*t+6*d)<=h]
 A=[[float(K(t,d,j,3)*P(n,x,s)) for d,x in dom] for j in range(t+1) for s in range(13) if j+s];bb=[K(t,0,j,3) for j in range(t+1) for s in range(13) if j+s]
 res=linprog(-np.ones(len(dom)),A_ub=-np.array(A),b_ub=bb,bounds=(0,None));print(t,1-res.fun,flush=True)

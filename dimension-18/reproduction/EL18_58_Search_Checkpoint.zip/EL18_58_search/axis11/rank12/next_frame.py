"""Exact feasible projected frame relaxation for each pair of D-flats."""
from fractions import Fraction as F
from census import HERE,signatures
import json,numpy as np
def solve(G):
    m=len(G);n=58-m;I,D,rows,_,_=signatures(G)
    s=np.array([a for a,t,h,c in rows],dtype=np.int64);t=np.array([t for a,t,h,c in rows],dtype=np.int64)
    h=np.array([h for a,t,h,c in rows],dtype=np.int64);z=5*D-h
    caps=np.array([min(n,4*D//(int(v)-D)) if v>D else n for v in z],dtype=np.int64)
    K=6*(s@t.T)**2+np.outer(h,h)
    b=(2*m*D-32*z)*6*D-192*D*h
    c=(m*m-136*m+3072+1536)*6*D**2
    kf=K/(6.*D**2);bf=b/(6.*D**2)
    x=np.ones(len(rows))*(n/len(rows));g=bf+2*kf@x
    for u in range(30000):
        a=int(np.argmin(np.where(x<caps-1e-9,g,np.inf)));e=int(np.argmax(np.where(x>1e-9,g,-np.inf)))
        diff=g[e]-g[a]
        if diff<1e-7:break
        curv=2*(kf[a,a]+kf[e,e]-2*kf[a,e]);v=min(diff/curv if curv>1e-16 else n,caps[a]-x[a],x[e])
        x[a]+=v;x[e]-=v;g+=2*v*(kf[a]-kf[e])
    den=100000;p=np.floor(x*den+1e-8).astype(np.int64);left=n*den-int(p.sum())
    for i in np.argsort(p-x*den)[:left]:p[i]+=1
    assert p.sum()==n*den and (p>=0).all() and (p<=caps*den).all()
    qp=K@p;g=2*qp+den*b
    obj=sum(int(pi)*int(q) for pi,q in zip(p,qp))+den*sum(int(pi)*int(bi) for pi,bi in zip(p,b))+int(c)*den**2
    cost=0;l=n
    for i in np.argsort(g):
        take=min(l,int(caps[i]));cost+=take*int(g[i]);l-=take
        if not l:break
    gap=sum(int(pi)*int(gi) for pi,gi in zip(p,g))-den*cost
    upper=F(obj,6*D**2*den**2);lower=F(obj-gap,6*D**2*den**2)
    return dict(denominator=den,weights=[[i,int(v)] for i,v in enumerate(p) if v],upper=str(upper),lower=str(lower))
def main():
    data=json.loads((HERE/'census.json').read_text());out={}
    for k in ['D22','D211','D1111']:
        for j,rep in enumerate(data[k]['grids'][k]):
            key=f'{k}-{j+1}';r=solve(rep['gram']);out[key]=r
            print(key,float(F(r['lower'])),float(F(r['upper'])),flush=True)
    (HERE/'next_frame.json').write_text(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()

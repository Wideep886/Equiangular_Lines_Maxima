"""Exact integral row lattice and sphere enumeration for all six marked unions."""
from census import HERE,pivots
from core import sphere
from collections import Counter
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
import json
def short(G):
    I=pivots(G);M=Matrix(G);H=hermite_normal_form(M[:,I].T).T
    B=H*M[I,I].inv()*H.T;n=B.rows
    assert n==len(I) and all(v.is_Integer for v in B)
    while True:
        p=sorted(range(n),key=lambda i:B[i,i]);B=B[p,p];ch=False
        for i in range(1,n):
            for j in range(i):
                a=round(B[i,j]/B[j,j])
                if 2*abs(B[i,j])>B[j,j]:
                    assert a
                    B[i,:]=B[i,:]-a*B[j,:];B[:,i]=B[:,i]-a*B[:,j];ch=True
        if not ch:break
    g=[[int(B[i,j]) for j in range(n)] for i in range(n)]
    return g,dict(Counter(h for h,c in sphere(g)))
def main():
    data=json.loads((HERE/'census.json').read_text());out={}
    for k in ['D22','D211','D1111']:
        for j,r in enumerate(data[k]['grids'][k]):
            B,h=short(r['gram']);key=f'{k}-{j+1}'
            print(key,h,flush=True);out[key]=dict(basis_gram=B,short=h)
    (HERE/'lattices.json').write_text(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()

"""Complete one-normal extensions of finite Gram shells; exact integer search."""
import json,sys
from itertools import combinations,product
from pathlib import Path
from collections import Counter
from math import isqrt,lcm
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'coredata'))
from core import inv
from compare import bits
def pivots(G):
    A=[list(map(F,r)) for r in G];I=[]
    for k in range(len(G)):
        if A[k][k]==0:
            assert all(v==0 for v in A[k][k:])
            continue
        assert A[k][k]>0;I.append(k)
        for i in range(k+1,len(G)):
            c=A[i][k]/A[k][k]
            for j in range(i,len(G)):
                A[i][j]-=c*A[k][j];A[j][i]=A[i][j]
    return I
def dot(x,y):return sum(i*j for i,j in zip(x,y))
def squareclass(h):
    for r in range(isqrt(h),0,-1):
        if h%(r*r)==0:return h//(r*r),r
def cliques(A):
    def sub(m,P,X):
        if not P:
            if not X:yield tuple(bits(m))
            return
        p=max(bits(P|X),key=lambda i:(P&A[i]).bit_count())
        for k in bits(P&~A[p]):
            v=1<<k
            yield from sub(m|v,P&A[k],X&A[k])
            P^=v;X|=v
    yield from sub(0,(1<<len(A))-1,0)
def signatures(G,I=None,required=None):
    if I is None:I=pivots(G)
    B=[[G[i][j] for j in I] for i in I];U=inv(B);D=lcm(*(x.denominator for r in U for x in r))
    T=[[int(x*D) for x in r] for r in U];R=[[r[j] for j in I] for r in G]
    if required is None:required=R
    rows=[];failed=0;zero=0
    for tail in product((-1,1),repeat=len(I)-1):
        s=(1,)+tail;t=[dot(s,c) for c in T];h=5*D-dot(s,t)
        if h<0 or any(abs(dot(t,r))!=D for r in required):continue
        c=[dot(t,r) for r in R]
        if any(abs(v)!=D for v in c):
            failed+=int(h>0);continue
        if not h:zero+=1;continue
        rows.append((s,t,h,[v//D for v in c]))
    return I,D,rows,failed,zero
def one_normal(rows,D,G):
    packets={}
    for i,(s,t,h,c) in enumerate(rows):
        q,r=squareclass(h);packets.setdefault(q,[]).extend([(i,r),(i,-r)])
    for q,V in sorted(packets.items()):
        A=[0]*len(V)
        def entry(k,l):
            i,r=V[k];j,u=V[l]
            return dot(rows[i][0],rows[j][1])+q*r*u
        for k in range(len(V)):
            for l in range(k):
                if abs(entry(k,l))==D:A[k]|=1<<l;A[l]|=1<<k
        pools=Counter(len(G)+1+A[i].bit_count() for i in range(0,len(V),2));mx=[0]*(len(V)//2)
        sizes=Counter();allcl=[]
        for cl in cliques(A):
            if cl>tuple(sorted(x^1 for x in cl)):continue
            sizes[len(G)+len(cl)]+=1
            for k in cl:mx[k//2]=max(mx[k//2],len(G)+len(cl))
            C=[[rows[V[k][0]][3][i] for k in cl] for i in range(len(G))]
            M=[r+c for r,c in zip(G,C)]+[list(c)+[entry(k,l)//D for l in cl] for k,c in zip(cl,zip(*C))]
            allcl.append(M)
        yield q,dict(anchored_signatures=len(mx),maximal_sizes=dict(sizes),anchor_pool=dict(pools),anchor_max=dict(Counter(mx))),allcl
def witnesses(G,m):
    for i,j in combinations(range(len(G)),2):
        U=[k for k in range(len(G)) if G[i][k]*G[j][k]*G[i][j]==-1]
        if len(U)<12:continue
        A=[sum(1<<l for l,y in enumerate(U) if G[x][y]*G[i][x]*G[i][y]==-1) for x in U]
        def grow(p,mask,t):
            if p.bit_count()<t:return
            if t==0:yield mask;return
            while p:
                b=p&-p;p^=b
                yield from grow(p&A[b.bit_length()-1],mask|b,t-1)
        C=list(grow((1<<len(U))-1,0,4))
        for a,b,c in combinations(C,3):
            if a&b or a&c or b&c:continue
            if max([i,j]+[U[z] for z in bits(a|b|c)])<m:continue
            def mate(x,y):
                z=A[x]&y
                assert z and z&(z-1)==0
                return z.bit_length()-1
            v={x:mate(x,b) for x in bits(a)};w={x:mate(x,c) for x in bits(a)}
            back={y:x for x,y in w.items()};p={x:back[mate(v[x],c)] for x in v}
            left=set(v);cycles=[]
            while left:
                x=min(left);cy=[]
                while x in left:left.remove(x);cy.append(x);x=p[x]
                cycles.append(cy)
            cycles.sort(key=lambda c:(-len(c),c))
            name='D'+''.join(str(len(cy)) for cy in cycles)
            aa=[x for cy in cycles for x in cy];order=[i,j]+[U[x] for x in aa+[v[x] for x in aa]+[w[x] for x in aa]]
            yield name,order,[1]+[-G[i][k] for k in order[1:]]
def same(G,c,H,d):
    # Switch a distinguished first axis positive; exact color-refinement + individualization.
    def normalize(A,k):
        s=[1 if i==k else A[k][i] for i in range(len(A))]
        return [[x*s[i]*s[j] for j,x in enumerate(r)] for i,r in enumerate(A)]
    def test(A,a,B,b):
        while True:
            patterns=[[ (x[i],tuple(sorted(Counter(x[j] for j,v in enumerate(row) if v==-1).items()))) for i,row in enumerate(M)] for M,x in ((A,a),(B,b))]
            if Counter(patterns[0])!=Counter(patterns[1]):return False
            cl={p:i for i,p in enumerate(sorted(set(patterns[0])))}
            aa,bb=[[cl[p] for p in pp] for pp in patterns]
            if len(cl)==len(set(a)):break
            a,b=aa,bb
        a,b=aa,bb
        if len(cl)==len(a):
            perm=[b.index(v) for v in a]
            return all(x==B[perm[i]][perm[j]] for i,r in enumerate(A) for j,x in enumerate(r))
        _,h=min((n,k) for k,n in Counter(a).items() if n>1)
        i=a.index(h);a=a[:];a[i]=len(cl)
        for j,z in enumerate(b):
            if z==h:
                cp=b[:];cp[j]=len(cl)
                if test(A,a,B,cp):return True
        return False
    M=normalize(G,0);cc=c[:];cc[0]=4
    for k,x in enumerate(d):
        if x!=c[0]:continue
        dd=d[:];dd[k]=4
        if test(M,cc,normalize(H,k),dd):return True
    return False
def run(name,K):
    d=K[name];shell=d['shell_gram'];m=len(shell);coeff=d['shell_coefficients'];I=d['basis']
    origR=[[r[j] for j in I] for r in d['gram']]
    B=[[d['gram'][i][j] for j in I] for i in I]
    rows_sig=[[dot(row,c) for row in B] for c in coeff]
    # Reuse the canonical marked basis of the supplied core. Shell vectors are given in it.
    G0=[r+[dot(r,c) for c in coeff] for r in B]
    G0.extend(r+g for r,g in zip(rows_sig,shell))
    _,D,rows,failed,zero=signatures(G0,list(range(11)),origR)
    rows=[(s,t,h,c[11:]) for s,t,h,c in rows]
    cos={};tested=Counter();valid=Counter();classes={}
    for q,hist,graphs in one_normal(rows,D,shell):
        cos[q]=hist
        for G in graphs:
            for typ,o,sgn in witnesses(G,m):
                second=K[typ];tested[typ]+=1
                assert [[G[i][j]*x*y for j,y in zip(o,sgn)] for i,x in zip(o,sgn)]==second['gram']
                J=second['basis']
                cross=[[sum(c[z]*sgn[k]*G[l][o[k]] for z,k in enumerate(J)) for c in second['shell_coefficients']] for l in range(m)]
                if any(abs(x) not in (1,5) for r in cross for x in r):continue
                common=sum(abs(x)==5 for r in cross for x in r);valid[typ,common]+=1
                jj=[j for j in range(len(cross[0])) if not any(abs(r[j])==5 for r in cross)]
                whole=[r+[v[j] for j in jj] for r,v in zip(shell,cross)]
                whole.extend([r[i] for r in cross]+[second['shell_gram'][i][j] for j in jj] for i in jj)
                colors=[3 if any(abs(x)==5 for x in r) else 1 for r in cross]+[2]*len(jj)
                reps=classes.setdefault(typ,[])
                for rep in reps:
                    if same(whole,colors,rep['gram'],rep['colors']):
                        rep['count']+=1;break
                else:reps.append(dict(gram=whole,colors=colors,count=1))
    return dict(grids=classes,signatures=len(rows),shell_discarded=failed,classes=cos,tested=dict(tested),compatible=[[k,n,v] for (k,n),v in sorted(valid.items())])
def main():
    K=json.loads((HERE.parent/'coredata'/'cores.json').read_text());out={}
    for k in ['D4','D31','D22','D211','D1111']:
        out[k]=r=run(k,K)
        print(k,r['signatures'],len(r['classes']),r['tested'],r['compatible'],[len(rs) for rs in r['grids'].values()],flush=True)
        (HERE/'census.json').write_text(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()

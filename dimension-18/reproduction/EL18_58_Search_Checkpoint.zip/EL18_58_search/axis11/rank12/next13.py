"""All dimension-thirteen extensions of the six marked glue shells, plus 26-ETF exterior signs."""
from census import HERE,pivots,dot,signatures,one_normal,same
from collections import Counter
import json

def main():
    base=json.loads((HERE/'census.json').read_text())
    out={};etfs=[]
    for k in ['D22','D211','D1111']:
        for j,rep in enumerate(base[k]['grids'][k]):
            key=f'{k}-{j+1}';G=rep['gram'];I,D,rows,_,zero=signatures(G);stats={}
            for q,hist,grams in one_normal(rows,D,G):
                stats[q]=hist
                for M in grams:
                    if len(M)!=26:continue
                    assert all(dot(M[i],M[j])==10*M[i][j] for i in range(26) for j in range(26))
                    for r in etfs:
                        if same(M,[1]*26,r['gram'],[1]*26):
                            r['marked_count']+=1;break
                    else:
                        ib,db,oo,_,z=signatures(M)
                        ext=[row[-1] for row in oo]
                        assert all(h*5==12*db for s,t,h,c in oo)
                        h=Counter(dot(s,t) for i,s in enumerate(ext) for t in ext[:i])
                        etfs.append(dict(gram=M,marked_count=1,signs=ext,dot=dict(h)))
            out[key]=dict(m=len(G),I=I,D=D,heights=dict(Counter(h for s,t,h,c in rows)),classes=stats,zero=zero)
            print(key,len(rows),len(stats),max(max(r['maximal_sizes']) for r in stats.values()),flush=True)
    print('ETFs',[(r['marked_count'],len(r['signs']),r['dot']) for r in etfs])
    for file,obj in [('next13.json',out),('next_etf.json',etfs)]:
        (HERE/file).write_text(json.dumps(obj,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()

"""Compulsory rank-thirteen ETF glue pair for each exterior sign."""
import json
from collections import Counter
from itertools import product,combinations
from fractions import Fraction as F
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
from census import HERE,pivots,dot,cliques

def main():
    etf=json.loads((HERE/'next_etf.json').read_text())[0];G=etf['gram'];I=pivots(G);ext=etf['signs']
    H=hermite_normal_form(Matrix(G)[:,I].T)
    U=H.inv()
    signs=[tuple(a*z for z in s) for s in ext for a in (1,-1)]
    classes={}
    for j,s in enumerate(signs):
        u=U*Matrix([s[i] for i in I]);glue=tuple(x%1 for x in u)
        classes.setdefault(glue,[]).append(j)
    hist=Counter(len(x) for x in classes.values());print('glue',hist,flush=True)
    assert all(len(v)==2 for v in classes.values())
    pairs=[tuple(sorted(a)) for a in classes.values()]
    pairs=[p for p in pairs if p<tuple(sorted(x^1 for x in p))]
    assert len(pairs)==65 and all(dot(signs[a],signs[b])==-14 for a,b in pairs)
    # Matrix of all admissible 10 times original residual inner products.
    opts=[[] for _ in pairs];A=[0]*len(pairs);HH=Counter()
    for i,aa in enumerate(pairs):
        for j,bb in enumerate(pairs[:i]):
            dots={dot(signs[a],signs[b]) for a,b in product(aa,bb)}
            V=[z for z in range(-24,25) if all(abs(z+w)==10 for w in dots)]
            opts[i].append(V);HH[tuple(V)]+=1
            if V:A[i]|=1<<j;A[j]|=1<<i
    print('degree',Counter(a.bit_count() for a in A),'options',HH,flush=True)
    # Exact all maximal sets of packet types compatible pairwise.
    hist=Counter();W=None
    for cl in cliques(A):
        hist[len(cl)]+=1
        if W is None or len(cl)>len(W):W=cl
    print('cliques',hist,'largest',len(W),flush=True)
    (HERE/'next_packets.json').write_text(json.dumps(dict(glue_count=len(classes),pairs=pairs,adjacency=A,options=opts,clique_hist=dict(hist),max_clique=W),sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()

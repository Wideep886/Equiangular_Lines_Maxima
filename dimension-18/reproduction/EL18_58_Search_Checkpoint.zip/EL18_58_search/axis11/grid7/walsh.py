"""Independent generation of exterior points, using grid Walsh words and seven residuals."""
from itertools import permutations, combinations, product
from math import lcm
from collections import Counter, defaultdict
from fractions import Fraction
from sympy import Matrix
import numpy as np
from check import H,clique,placements

def words():
    for p in permutations(range(4)):
        yield 0,tuple(-sum(u[i]*v[j] for i,j in enumerate(p))//4 for u in H for v in H)
    row_pairs=list(combinations(range(4),2))
    for rows in product(row_pairs,repeat=4):
        if not all(sum(j in row for row in rows)==2 for j in range(4)):continue
        yield 1,tuple(sum((1-2*(j in rows[i]))*u[i]*v[j] for i,j in product(range(4),repeat=2))//8 for u in H for v in H)

def residuals(graph):
    M=Matrix(7,7,lambda i,j:8 if i==j else -4 if tuple(sorted((i,j))) in graph else 2)
    A=M.inv();D=lcm(*(int(x.q) for x in A));Z=np.array(A*D,dtype=np.int64);res=defaultdict(list)
    for b in (0,1):
        raw=np.array(list(product((-1,0,1),repeat=7)),dtype=np.int64)
        d=3*raw-b;dual=d@Z;good=np.sum(d*dual,axis=1)==D*(9-b)
        for x,y,m in zip(d[good],dual[good],raw[good]):
            mask=sum(int(t==0)<<j for j,t in enumerate(m))
            res[(b,mask)].append((x,y))
    return D,res

def run(p,table,D,res):
    pts=[]
    for b,k in table:
        if any(abs(k[i])==2 for i in p):continue
        mask=sum(bool(k[i])<<j for j,i in enumerate(p))
        for d,v in res[b,mask]:pts.append((b,k,d,v))
    b,k,d,v=map(np.array,zip(*pts))
    # 6D times real inner products. All arrays are integral.
    P=3*D*(k@k.T)+D*(3*np.outer(1-b,1-b)+2*np.outer(b,b))+2*(d@v.T)
    assert np.all(P.diagonal()==30*D)
    adj=[int.from_bytes(np.packbits(r,bitorder='little').tobytes(),'little') for r in (abs(P)==6*D)]
    return len(pts),32+clique(adj)

if __name__=='__main__':
    table=list(words()); shapes=Counter((b,tuple(sorted(abs(t) for t in k if t))) for b,k in table)
    assert len(set(table))==114 and shapes==Counter({(0,(1,1,1)):24,(1,(1,1,1,1)):72,(1,(2,)):18})
    expected=[{49:2},{38:14,48:2},{38:5,48:1}]
    for i,graph in enumerate([(),((0,1),),tuple((j,6) for j in range(6))]):
        D,res=residuals(graph);stats=Counter()
        for p in placements(graph):
            size,best=run(p,table,D,res);stats[best]+=1
            print(i,'slots',p,'candidates',size,'exact',best,flush=True)
        assert stats==expected[i]
        print('summary',i,sorted(stats.items()),flush=True)

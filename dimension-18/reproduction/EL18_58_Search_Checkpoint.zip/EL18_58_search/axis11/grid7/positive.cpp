#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
using M=std::array<std::array<int64_t,7>,7>;
bool pd(M A){
    int64_t last=1;
    for(int k=0;k<7;++k){
        int64_t piv=A[k][k];if(piv<=0)return false;
        for(int i=k+1;i<7;++i)for(int j=i;j<7;++j){
            int64_t t=piv*A[i][j]-A[i][k]*A[k][j];assert(t%last==0);
            A[i][j]=A[j][i]=t/last;
        }
        last=piv;
    }return true;
}
int main(){
    std::array<int,3> counts{};
    for(int m=0;m<(1<<21);++m){
        M A{};std::array<int,7> deg{};int t=0,e=0;
        for(int i=0;i<7;++i){A[i][i]=8;
            for(int j=0;j<i;++j,++t){bool neg=(m>>t)&1;
                A[i][j]=A[j][i]=neg?-4:2;
                if(neg){++deg[i];++deg[j];++e;}
            }
        }
        bool star=false;for(int d:deg)if(d==6)star=true;
        int kind=e==0?0:e==1?1:e==6&&star?2:-1;
        assert(pd(A)==(kind>=0));if(kind>=0)++counts[kind];
    }
    assert((counts==std::array<int,3>{1,21,7}));
    std::cout<<"2097152 labelled graphs; positive definite: 1 empty, 21 single edges, 7 stars\n";
}

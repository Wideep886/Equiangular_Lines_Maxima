"""Exact complete extensions of the 24 grid doublet kernels. No randomness."""
from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations, product
from math import lcm
import numpy as np
from sympy import Matrix

H = ((1,1,-1,-1),(1,-1,1,-1),(1,-1,-1,1))
orders = [tuple(3*q[j]+p[i] if t else 3*p[i]+q[j] for i,j in product(range(3),repeat=2))
          for p,q,t in product(permutations(range(3)),permutations(range(3)),range(2))]

def placements(graph):
    seen=set()
    for missing in combinations(range(9),2):
        for p in permutations(sorted(set(range(9))-set(missing))):
            e=tuple(sorted(tuple(sorted((p[i],p[j]))) for i,j in graph))
            if (missing,e) in seen:continue
            for t in orders:
                seen.add((tuple(sorted(t[i] for i in missing)),
                          tuple(sorted(tuple(sorted((t[i],t[j]))) for i,j in e))))
            yield p

def core(p,edges):
    n=len(p);m=18+2*n
    G=np.full((m,m),-1,dtype=np.int64)
    np.fill_diagonal(G,5)
    for i,j in combinations(range(16),2):
        G[i+2,j+2]=G[j+2,i+2]=-1 if i//4==j//4 or i%4==j%4 else 1
    for i,s in enumerate(p):
        G[18+2*i,19+2*i]=G[19+2*i,18+2*i]=1
        for h,sgn in enumerate((1,-1)):
            x=18+2*i+h;G[0,x]=G[x,0]=1
            for a,b in product(range(4),repeat=2):
                j=2+4*a+b;G[x,j]=G[j,x]=sgn*H[s//3][a]*H[s%3][b]
            for j in range(i):
                for k in range(2):G[x,18+2*j+k]=G[18+2*j+k,x]=-1 if (j,i) in edges else 1
    return G

def clique(adjacency):
    best=0
    def search(P,size):
        nonlocal best
        best=max(size,best)
        left=P; seq=[];c=0
        while left:
            c+=1; independent=left
            while independent:
                b=independent&-independent;j=b.bit_length()-1
                independent^=b; independent&=~adjacency[j];left^=b;seq.append((j,c))
        for j,c in reversed(seq):
            if size+c<=best:return
            search(P&adjacency[j],size+1);P^=1<<j
    search((1<<len(adjacency))-1,0)
    return best

def run(p,edges):
    G=core(p,edges);I=[0,1]+[2+4*i+j for i,j in product(range(3),repeat=2)]+list(range(18,32,2))
    B=Matrix(G[np.ix_(I,I)]);A=B.inv();D=lcm(*(int(x.q) for x in A));T=np.array(D*A,dtype=np.int64)
    Gs=G[:,I]
    assert np.array_equal(Gs@T@Gs.T,G*D)
    assert 18**2*25*int(np.abs(T).max())<2**61
    sign=((1-2*((np.arange(1<<17)[:,None]>>np.arange(17))&1)))
    sign=np.column_stack([np.ones(1<<17,dtype=np.int64),sign])
    U=sign@T; keep=np.sum(U*sign,axis=1)==5*D
    V=sign[keep];W=U[keep]; valid=(np.abs(W@Gs.T)==D).all(axis=1);V=V[valid];W=W[valid]
    compatible=(np.abs(V@W.T)==D)
    adj=[int.from_bytes(np.packbits(r,bitorder='little').tobytes(),'little') for r in compatible]
    assert all(not a>>i&1 for i,a in enumerate(adj))
    return len(V),32+clique(adj)

if __name__=='__main__':
    graphs=[(),((0,1),),tuple((i,6) for i in range(6))]
    for i,graph in enumerate(graphs):
        stats=Counter();mx=0
        for p in placements(graph):
            n,best=run(p,set(graph));stats[best]+=1;mx=max(mx,n)
            print(i,'slots',p,'candidates',n,'exact',best,flush=True)
        expected=[{49:2},{38:14,48:2},{38:5,48:1}]
        assert stats==expected[i]
        print('summary',i,sorted(stats.items()),'max candidates',mx,flush=True)

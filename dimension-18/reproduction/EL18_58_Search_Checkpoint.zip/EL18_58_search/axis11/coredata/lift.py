"""Exact hyperplane section completions in dimension eighteen, anchored at marked D cores."""
import json,subprocess,tempfile
from pathlib import Path
from math import isqrt,lcm
from core import DIR,Q,inv
from compare import pos_rank
def submat(G,idx):return [[G[i][j] for j in idx] for i in idx]
def solve(G,seed,exe):
    I=[];core=seed.copy()
    for j in seed+[a for a in range(len(G)) if a not in seed]:
        if pos_rank(submat(G,I+[j]))>len(I):
            I.append(j)
            if j not in core:core.append(j)
        if len(I)==17:break
    B=submat(G,I);A=inv(B);D=lcm(*(x.denominator for row in A for x in row));T=[[int(x*D) for x in row] for row in A]
    for j in range(len(G)):
        s=[G[j][i] for i in I];u=[sum(x*y for x,y in zip(row,s)) for row in T]
        if sum(x*y for x,y in zip(u,s))==5*D and j not in core:core.append(j)
    signature=[[G[j][i] for i in I] for j in core]
    vals=[len(core),D]+[x for row in T+signature for x in row]
    raw=subprocess.check_output([str(exe)],input=' '.join(map(str,vals)).encode()).decode()
    rows=[list(map(int,s.split())) for s in raw.splitlines()];p,n,best,nodes,*winner=max(rows,key=lambda s:s[2])
    V=[];Y=[];dot=lambda a,b:sum(x*y for x,y in zip(a,b))
    sig=[[1-2*(a>>i&1) for i in range(17)] for a in winner]
    for s in sig:
        u=[dot(row,s) for row in T];V.append(u);h=5*D-dot(s,u);y=isqrt(h//p);assert h==p*y*y;Y.append(y)
    def exact_entry(a):
        out,rem=divmod(a,D);assert rem==0;return out
    mat=submat(G,core)
    for i,s in enumerate(signature):mat[i].extend(exact_entry(dot(s,b)) for b in V)
    for i,u in enumerate(V):
        mat.append([exact_entry(dot(s,u)) for s in signature]+[exact_entry(dot(s,u)+p*Y[i]*y) for s,y in zip(sig,Y)])
    assert all(mat[i][i]==5 and all(abs(mat[i][j])==1 and mat[i][j]==mat[j][i] for j in range(i)) for i in range(best))
    rank=pos_rank(mat);assert rank<=18
    return dict(core=core,basis=I,denominator=D,best=best,real_rank=rank,classes=[s[:4] for s in rows],normal_class=p,winner=winner),mat
def main():
    G=json.loads((DIR/'source57.json').read_text());D=json.loads((DIR/'comparison.json').read_text())['original57']['first']
    out={}
    with tempfile.TemporaryDirectory() as tmp:
        exe=Path(tmp)/'lift';subprocess.run(['c++','-O3','-std=c++17',str(DIR/'lift.cpp'),'-o',str(exe)],check=True)
        for name,ls in sorted(D.items()):
            seed=ls[:2]+sum(ls[2:],[]);rec,mat=solve(G,seed,exe);out[name]=rec
            print(name,rec['best'],rec['real_rank'],len(rec['classes']),sum(c[3] for c in rec['classes']),flush=True)
            (DIR/('saturated_'+name+'.json')).write_text(json.dumps(mat,separators=(',',':')))
            (DIR/'saturated_lift.json').write_text(json.dumps(out,indent=1))
if __name__=='__main__':main()

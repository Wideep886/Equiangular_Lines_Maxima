"""Count marked pairs and triples of equiangular simplices in each comparison matrix."""
from itertools import combinations
from collections import Counter
import json
from core import DIR,Q
def bits(p):
    while p:
        i=p&-p;p^=i;yield i.bit_length()-1
def pos_rank(G):
    A=[list(map(Q,row)) for row in G];n=len(A);r=0
    for j in range(n):
        val=A[j][j]
        if val==0:
            assert not any(A[j][j:]);continue
        assert val>0;r+=1
        for i in range(j+1,n):
            k=A[i][j]/val
            if k:
                for h in range(i,n):
                    A[i][h]-=k*A[j][h];A[h][i]=A[i][h]
    return r
def count(G):
    n=len(G);total=Counter();across=Counter();witnesses={}
    for i,j in combinations(range(n),2):
        U=[k for k in range(n) if k not in (i,j) and G[i][k]*G[j][k]*G[i][j]==-1]
        A=[sum(1<<b for b,y in enumerate(U) if G[x][y]*G[i][x]*G[i][y]==-1) for x in U]
        C=[]
        def expand(mask,m,need):
            if not need:C.append(m);return
            while mask:
                b=mask&-mask;mask^=b
                expand(mask&A[b.bit_length()-1],m|b,need-1)
        expand((1<<len(U))-1,0,4);pair=set()
        for u,v,w in combinations(C,3):
            if (u&v)|(v&w)|(w&u):continue
            for left,right in ((u,v),(v,w),(w,u)):
                assert all(bin(A[x]&right).count('1')==1 for x in bits(left))
                assert all(bin(A[x]&left).count('1')==1 for x in bits(right))
            p={x:(A[(A[(A[x]&v).bit_length()-1]&w).bit_length()-1]&u).bit_length()-1 for x in bits(u)}
            left=set(p);cy=[]
            while left:
                x=next(iter(left));s=0
                while x in left:left.remove(x);s+=1;x=p[x]
                cy.append(s)
            name='D'+''.join(map(str,sorted(cy,reverse=True)));total[name]+=1;pair.add(name)
            if name not in witnesses:witnesses[name]=[i,j]+[[U[h] for h in bits(c)] for c in (u,v,w)]
        across.update(pair)
    return {'triples':dict(total),'pairs_per_type':dict(across),'first':witnesses}
def main():
    base=DIR.parents[1]
    files={'F1':base/'control_57.json','original57':DIR/'source57.json','affine57':base/'affine44_first/gram_57.json','affine56':base/'affine19_other/gram56.json'}
    D={}
    for k,s in files.items():
        G=json.loads(s.read_text());d=count(G);d['order']=len(G);d['rank']=pos_rank(G);D[k]=d;print(k,d['order'],d['rank'],d['triples'],flush=True)
    (DIR/'comparison.json').write_text(json.dumps(D,indent=1))
if __name__=='__main__':main()

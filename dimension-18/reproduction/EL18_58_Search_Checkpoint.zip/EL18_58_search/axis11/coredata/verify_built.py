"""Verify order-57 Gram matrices and distinguish all six by switching-invariant incidence."""
from core import DIR,Q,inv
from compare import count,pos_rank
from lift import submat
import json
def main():
    records=json.loads((DIR/'saturated_lift.json').read_text())
    source=json.loads((DIR/'source57.json').read_text())
    expected={'source':[63,65,58,56,4], 'D4':[93,56,44,56,3], 'D31':[195,180,149,152,4],
              'D22':[68,60,67,33,6], 'D211':[71,66,59,42,4], 'D1111':[87,60,65,38,4]}
    output={}
    for typ in ['source']+sorted(records):
        M=source if typ=='source' else json.loads((DIR/('saturated_'+typ+'.json')).read_text())
        assert len(M)==57 and pos_rank(M)==18
        assert all(len(row)==57 and row[i]==5 and all(abs(M[i][j])==1 and M[i][j]==M[j][i] for j in range(i)) for i,row in enumerate(M))
        if typ!='source':
            rec=records[typ];C=rec['core'];I=rec['basis'];assert all(M[i][:len(C)]==row for i,row in enumerate(submat(source,C)))
            R=[C.index(i) for i in I];B=submat(M,R);T=inv(B)
            O=[tuple(row[i] for i in R) for row in M];P=[[sum(u*v for u,v in zip(t,s)) for t in T] for s in O]
            E=[[Q(v)-sum(a*b for a,b in zip(p,t)) for v,t in zip(row,O)] for row,p in zip(M,P)]
            j=next(i for i in range(57) if E[i][i]>0)
            assert all(E[j][j]*E[i][k]==E[i][j]*E[j][k] for i in range(57) for k in range(57))
        output[typ]=count(M);counts=[output[typ]['triples'].get(k,0) for k in ['D4','D31','D22','D211','D1111']]
        assert counts==expected[typ];print(typ,counts,flush=True)
    assert len(output)==len(expected)==6 and len({tuple(sorted(s['triples'].items())) for s in output.values()})==6
    (DIR/'saturated_census.json').write_text(json.dumps(output,indent=1))
if __name__=='__main__':main()

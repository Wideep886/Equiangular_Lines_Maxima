#include <array>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <map>
#include <numeric>
#include <vector>
using namespace std;
using ll=long long;
const int r=17;
struct Line{array<int,r>s; array<ll,r>b; ll y,h;int mask;};
int main(){
 int m;ll D;cin>>m>>D;
 array<array<ll,r>,r>T{}; ll mx=0;
 for(auto&row:T)for(auto&x:row){cin>>x;mx=max(mx,abs(x));}
 if(10000.L*mx+10.L*D >= 1e16L)return 2;
 vector<array<int,r>>orig(m);for(auto&row:orig)for(auto&x:row)cin>>x;
 vector<Line>zero;map<ll,vector<Line>>groups;
 for(int a=0;a<(1<<r);++a){
  Line u{};u.mask=a;
  for(int j=0;j<r;++j)u.s[j]=1-2*((a>>j)&1);
  for(int j=0;j<r;++j)for(int h=0;h<r;++h)u.b[j]+=u.s[h]*T[h][j];
  u.h=5*D-inner_product(u.s.begin(),u.s.end(),u.b.begin(),0LL);
  if(u.h<0||(!u.h&&(a&1)))continue;
  bool ok=true;for(auto&v:orig)if(abs(inner_product(v.begin(),v.end(),u.b.begin(),0LL))!=D){ok=false;break;}
  if(!ok)continue;
  if(!u.h){zero.push_back(u);continue;}
  ll p=u.h;u.y=1;
  for(ll f=2;f*f<=p;f++)while(p%(f*f)==0){u.y*=f;p/=f*f;}
  groups[p].push_back(u);
 }
 if(groups.empty())groups[1]={};
 for(auto&kv:groups){
  ll p=kv.first;vector<Line>V=kv.second;V.insert(V.end(),zero.begin(),zero.end());int n=V.size();
  vector<vector<bool>>adj(n,vector<bool>(n));
  for(int i=0;i<n;++i)for(int j=0;j<i;++j){
    ll a=inner_product(V[i].b.begin(),V[i].b.end(),V[j].s.begin(),0LL)+p*V[i].y*V[j].y;
    adj[i][j]=adj[j][i]=abs(a)==D;
  }
  vector<int>best,cur;ll nodes=0;
  auto search=[&](auto&&self,vector<int>cand)->void{
   ++nodes;if(cur.size()>best.size())best=cur;if(cand.empty())return;
   vector<int>order,col;int colors=0;
   while(!cand.empty()){
    ++colors;vector<int>picked,left;
    for(int x:cand){
     bool ok=true;for(int y:picked)if(adj[x][y]){ok=false;break;}
     if(ok){picked.push_back(x);order.push_back(x);col.push_back(colors);}else left.push_back(x);
    }
    swap(cand,left);
   }
   for(int k=int(order.size())-1;k>=0;--k){
    if(cur.size()+col[k]<=best.size())return;
    int x=order[k];vector<int>sub;for(int j=0;j<k;j++)if(adj[x][order[j]])sub.push_back(order[j]);
    cur.push_back(x);self(self,sub);cur.pop_back();
   }
  };
  vector<int>cand(n);iota(cand.begin(),cand.end(),0);search(search,cand);
  cout<<p<<" "<<n<<" "<<best.size()+m<<" "<<nodes;for(int j:best)cout<<" "<<V[j].mask;cout<<"\n";
 }
}

"""Batch test integral coefficients near the trace maximum. No list of parent spectra."""
from math import comb,isqrt
from fractions import Fraction as F
from trace_multiplicity import bound,D
from sympy import Poly, symbols, intervals
X=symbols('x')
def run(target):
  seen=set()
  def check(i,m,minus,plus,Q,upper):
    if upper<(162680-12*target)*D**3:return
    if not m:raise RuntimeError
    # normalized x=t/2.  Strip x and x±1.  Largest residual root lies in [i/(2D),(i+1)/(2D)].
    a=F(i,2*D);b=F(i+1,2*D)
    n=m+1; s1=F(1+minus-plus);s2=F(21-minus-plus);s3=F(162680-12*target,8)+minus-plus
    c=[F(1),-s1,(s1*s1-s2)/2,-(s1**3-3*s1*s2+2*s3)/6]
    if any(q.denominator!=1 for q in c):return
    # Qstar coefficients of prod(x - other roots), bounded using Maclaurin for |roots|.
    B=[0]+[comb(m,k)*F(isqrt((Q**k*10**12)//((4*m*D**2)**k))+1,10**6) for k in range(1,m+1)]+[0]
    def branch(poly,lo,hi):
      k=len(poly)
      if k==n+1:
        if n<3 and c[3]!=0:return
        if any(sum(e*j**(n-k) for k,e in enumerate(poly))==0 for j in [-1,0,1]):return
        seen.add(tuple(poly));return
      lower=min(a*lo,a*hi,b*lo,b*hi);higher=max(a*lo,a*hi,b*lo,b*hi)
      left=-B[k]-higher;right=B[k]-lower
      start=-(-left.numerator//left.denominator);end=right.numerator//right.denominator
      if k<4:start=max(start,int(c[k]));end=min(end,int(c[k]))
      for v in range(start,end+1):
        branch(poly+[v],max(-B[k],lower+v),min(B[k],higher+v))
    branch([1],F(1),F(1))
  bound(check)
  valid=[]
  for row in sorted(seen):
    P=Poly.from_list(list(row),gens=X)
    if sum(e for _,e in intervals(P))==P.degree():valid.append(row)
  return len(seen),valid
if __name__=='__main__':
 for T in (13508,13510):
  n,v=run(T);print(T,n,len(v),v[:2])

"""Rational supporting planes for frame Frobenius energy on one full-shell triangle axis."""
import json
from fractions import Fraction as Q
from math import sqrt
from scipy.optimize import minimize
import numpy as np
def model(N,t,l):
    m=N-3*t-l;c=17-2*t-l
    if c<0:return None
    keys=[];cols=[]
    for k in range(l+1):
        h=44-4*t-l-3*k
        if h<0 or (c==0 and h):continue
        vals=[Q(3*t+l-16)+Q(m,9),Q(6)-16+Q(2*m,9)]
        mult=[1,2*t]
        if l:
            vals.extend([Q(4-16)+Q(m*(l-3*k)**2,9*l),Q(2*l)+Q(m*(l-3*k),9)]);mult.extend([1,Q(2,l)])
            if l>1:
                vals.append(-12+Q(m*((l+3*k)*l-(l-3*k)**2),9*l*(l-1)));mult.append(l-1)
        if c:vals.append(Q(m*h,9*c)-16);mult.append(c)
        keys.append(k);cols.append(vals)
    return keys,cols,mult if cols else []
def run(N,t,l):
    keys,V,w=model(N,t,l)
    if not V:return {'empty':True}
    X=np.array(V,float);d=np.array(w,float);n=len(V)
    R=minimize(lambda p:sum(d*(p@X)**2),np.ones(n)/n,jac=lambda p:2*X@(d*(p@X)),bounds=[(0,1)]*n,constraints=[dict(type='eq',fun=lambda p:p.sum()-1,jac=lambda p:np.ones(n))],method='SLSQP',options={'ftol':1e-10,'maxiter':100})
    b=[round(x*10000) for x in R.x@X];v=list(map(lambda x:Q(x,10000),b))
    bound=min(sum(a*(2*x*z-x*x) for a,x,z in zip(w,v,row)) for row in V)
    if bound>N*(N+24)-160*N+4608:return dict(b=b,lower=str(bound))
def main():
    out={}
    for N in (58,59):
        out[N]={}
        for t in range(1,7):
            good=[]
            for l in range(18-2*t):
                z=run(N,t,l)
                if z:out[N][str((t,l))]=z
                else:good.append(l)
            print(N,t,good)
    json.dump(out,open('frame_axis.json','w'))
if __name__=='__main__':main()

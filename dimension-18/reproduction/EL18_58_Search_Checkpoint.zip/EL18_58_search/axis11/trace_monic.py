"""Uniform trace-cube bound. Each bin is certified by outward integer arithmetic."""
from math import isqrt
D=1000
def ceil_sqrt(x):
 a=isqrt(x)
 return a+(a*a<x)
def bound(visitor=None):
 best=6700*84*D**2;att=None
 for i in range(6700,9166):
  # i/D <= max(t) <= (i+1)/D; sum(t^2)=84.  m counts OTHER nonzero roots.
  a=i;b=i+1
  Q=84*D*D-a*a
  if Q<0:continue
  Q0=Q
  for minus in range(18):
   for plus in range(18-minus):
    Q=Q0-4*(minus+plus)*D**2
    if Q<0:continue
    for m in range(0,18-minus-plus):
     # trace of remaining roots is in [l,u]/D; Q is an upper bound for sum of squares (scaled)
     l=(2+2*minus-2*plus)*D-b;u=l+1;near=max(0,l,-u)
     known=8*(plus-minus)*D**3
     if not m:
      if l<=0<=u and Q>=0 and Q<=2*b:
       best=max(best,b**3+known)
      continue
     if near**2>m*Q or (b*b*Q**m < 4*D**2*(4*m*D**2)**m):continue
     # After dividing all factors x, x+1, x-1, evaluate at each integer j.
     possible=True
     for z in (-2,2):
      rsum=u if z<0 else l
      shifted=Q-2*z*D*rsum+m*z*z*D*D
      if shifted<0 or max((a-z*D)**2,(b-z*D)**2)*shifted**m < 4*D**2*(4*m*D**2)**m:
       possible=False;break
     if not possible:continue
     # Use sum of cubes of centered numbers, <= sqrt(sum of squares)^3.
     # Exact sharper centered bound (m-2)/sqrt(m(m-1)) when m>=2.
     V=m*Q-near**2
     # sum r^3 = (sum r)^3/m²+3(sum r)*V'/m²+centered third.
     # lower bound for V' from b^2 upper and extremes of the residual sum
     Vmin=max(0,m*((84-4*(minus+plus))*D*D-b*b)-max(l*l,u*u))
     mixed=3*u*(V if u>=0 else Vmin)
     cubic=0 if m<3 else (m-2)*ceil_sqrt((V**3+m-2)//(m-1))
     upper=min((b*84*D*D),((b**3+known)*m*m+u**3+mixed+cubic+m*m-1)//(m*m))
     if visitor is not None:visitor(i,m,minus,plus,Q,upper)
     if upper>best:best=upper;att=(i,m,minus,plus)
 return best,att
if __name__=='__main__':
 from fractions import Fraction
 n,p=bound(); B=Fraction(n,D**3)
 t=(162680-B)/12
 # T even since product of all triangle signs = product of edge signs^56=1
 minimum=-(-t.numerator//(2*t.denominator))*2
 print('upper centered cube',B,'bin',p,'negative triangles >=',minimum)

"""Complete single-generator short-shell and bounded two-generator root tests, in a fixed core lattice."""
from shells import prep
from itertools import product
from math import isqrt
import numpy as np,json
from collections import Counter,defaultdict
def tables(m):
    ii,T,D,I,K=prep(m);r=len(ii);tab=set();five=defaultdict(list)
    for alphabet in [(-1,1),(-2,0,2)]:
        from sympy import Matrix
        from math import lcm
        B=Matrix(m).extract(ii,ii);X=np.zeros((1,0),dtype=int)
        for j in range(len(ii)):
            X=np.concatenate([np.column_stack([X,np.full(len(X),a,dtype=int)]) for a in alphabet])
            inv=B[:j+1,:j+1].inv();den=lcm(*(int(v.q) for v in inv));mat=np.array(den*inv,dtype=int)
            assert max(abs(int(mat.min())),abs(int(mat.max())))*4*(j+1)**2<2**62
            X=X[((X@mat)*X).sum(axis=1)<=5*den]
        nn=(X@T*X).sum(axis=1);R=(X@I.T)%K
        for x,k,s in zip(X,R,nn):
            key=(tuple(k.tolist()),int(s));tab.add(key)
            if alphabet==(-1,1):five[key].append(x.tolist())
    return D,K,T,tab,five
def check(m,shell):
    D,K,T,tab,five=tables(m);groups={};occupied=set()
    for h,k,s in shell['groups']:
        nk=tuple(-v%K for v in k)
        if (nk,h) in occupied:continue
        key=tuple(k);occupied.add((key,h))
        g=np.array(s);z=g@T@g.T+h
        if not np.all((abs(z)==D)|(z==5*D)):raise ValueError('unexpected non-equiangular packet')
        bad=False;forced=0;assert h>0
        for a in range(1,isqrt(5*D//h)+1):
            y=tuple(a*v%K for v in k);f=a*a*h
            if any((y,b*D-f) in tab for b in (1,4)):bad=True
            forced+=len(five.get((y,5*D-f),[]))
        if not bad:groups[len(groups)]=(h,key,s,forced)
    stats=Counter();edges=[]
    # All pairs of positive-height witness vectors, oriented by their packets.
    # Distinct normals are allowed also within one packet label, and parallel
    # or antiparallel normal coincidences are tested without assuming independence.
    for i,(h,k,s,f) in groups.items():
        for j in range(i+1):
            g,l,v,ff=groups[j];delta=np.array(s)@T@np.array(v).T
            base=int(delta[0,0])
            for e in (-1,1):
                z=e*D-base;stats['labels_sign']+=1
                if z*z>h*g:continue
                stats['cauchy']+=1
                # If the two full vectors coincide up to sign, absolute dot 5 is legitimate.
                if not np.all((abs(delta+z)==D)|(abs(delta+z)==5*D)):continue
                stats['packets']+=1
                good=True
                for a,b in [(1,1),(1,-1),(2,1),(2,-1),(1,2),(1,-2),(2,2),(2,-2)]:
                    n=a*a*h+b*b*g+2*a*b*z
                    if n>4*D:continue
                    y=tuple((a*u+b*w)%K for u,w in zip(k,l))
                    if any((y,q*D-n) in tab for q in (1,4)):good=False;break
                if good:stats['short_pass']+=1;edges.append([i,j,e,z])
    return dict(raw_signed=len(shell['groups']),classes=len(groups),forced_hist=dict(Counter(q[-1] for q in groups.values())),stats=dict(stats),groups=list(groups.values()),edges=edges)
if __name__=='__main__':
    shells=json.load(open('shells.json'));cores=json.load(open('pair_cores.json'));result={}
    for k,v in cores.items():
        r=check(v['gram'],shells[k]);result[k]=r;print(k,r['raw_signed'],r['classes'],r['forced_hist'],r['stats'],flush=True)
    json.dump(result,open('packets.json','w'),separators=(',',':'))

from itertools import combinations
from collections import Counter
from shells import prep
import numpy as np,json
def spectrum(G):
    cnt=Counter();links=Counter()
    for i,j in combinations(range(len(G)),2):
        # Orient the pair to negative dot. Select points that orient to -1 with both.
        ids=[a for a in range(len(G)) if a not in (i,j) and G[i,a]==-G[i,j]*G[j,a]]
        z=G[i,ids];F=G[np.ix_(ids,ids)]*z[:,None]*z[None,:]
        tetra=[frozenset(c) for c in combinations(range(len(ids)),4) if all(F[h,k]<0 for h,k in combinations(c,2))]
        hit=set()
        for a,b,c in combinations(tetra,3):
            if a&b or a&c or b&c:continue
            def match(x,U):return next(y for y in U if F[x,y]<0)
            pi={x:match(match(match(x,b),c),a) for x in a};left=set(a);ls=[]
            while left:
                y=next(iter(left));n=0
                while y in left:left.remove(y);y=pi[y];n+=1
                ls.append(n)
            code='D'+''.join(map(str,sorted(ls,reverse=True)));cnt[code]+=1;hit.add(code)
        links.update(hit)
    return dict(cnt),dict(links)
if __name__=='__main__':
    C=json.load(open('pair_cores.json'));S=json.load(open('shells.json'))
    for k,v in C.items():
        ii,T,D,_,_=prep(v['gram']);X=np.array(S[k]['local_signs']);print(k,spectrum(X@T@X.T//D))

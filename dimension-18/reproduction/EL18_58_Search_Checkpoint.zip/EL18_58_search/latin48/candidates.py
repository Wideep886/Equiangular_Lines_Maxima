from itertools import product
from collections import Counter,defaultdict
from pathlib import Path
I=[(0,2,4),(0,3,5),(1,2,5),(1,3,4)]
A=[]
for p in product(range(-3,4),repeat=6):
    e=sum(i*i for i in p)
    if sum(p) or e>54:continue
    v=[sum(p[i] for i in row) for row in I]
    for t in (3-v[0],-3-v[0]):
        if all(abs(t+x)==3 for x in v):A.append((e,t,p))
m=defaultdict(list)
for e,t,p in A:m[e,t].append(p)
out=[]
for e,t,p in A:
 for f,u,q in A:
    for r in m[54-e-f,-t-u]:
        dotlist=p+q+r
        if next(w for w in dotlist if w)<0:continue
        v=-t-u; H=54-(t*t+u*u+v*v)
        if H<0:continue
        vals=[abs(w+y+z)==3 for w in p for y in q for z in r]
        if any(not any(vals[6*i:6*i+6])for i in range(36)):continue
        if any(not any(vals[36*i+k::6][0:6]) for i in range(6) for k in range(6)):continue
        if any(not any(vals[6*j+k::36])for j in range(6)for k in range(6)):continue
        masks=[sum(1<<(i%64) for i in range(64*b,min(216,64*b+64)) if vals[i]) for b in range(4)]
        for sign in ([1] if H==0 else [1,-1]):out.append((*dotlist,t,u,v,H,sign,*masks))
print('universal vectors',len(out),'heights',Counter(x[21]for x in out))
with Path(__file__).with_name('candidates.dat').open('w') as fp:
  print(len(out),file=fp)
  for row in out:print(*row,file=fp)

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <string>
#include <vector>
using namespace std;
using W = uint64_t;
using L = array<int, 36>;
using P = array<int, 6>;
const int NA = 2880, NW = (NA + 63) / 64;
using BB = array<W, NW>;
using Short = array<W, 4>;
BB compat[NA], at[216];
struct V {
  int x[18], t[3], h, ep;
  Short m;
};
V vs[NA];
vector<P> perms, pasch;
vector<L> reduced, reps;
int idx(int i, int j, int k) { return 36 * i + 6 * j + k; }
void read_cand(string path) {
  ifstream in(path);
  int n;
  in >> n;
  if (n != NA)
    throw runtime_error("count");
  for (int i = 0; i < n; i++) {
    auto &v = vs[i];
    for (int &x : v.x)
      in >> x;
    for (int &x : v.t)
      in >> x;
    in >> v.h >> v.ep;
    for (auto &q : v.m)
      in >> q;
    for (int k = 0; k < 216; k++)
      if ((v.m[k / 64] >> (k % 64)) & 1)
        at[k][i / 64] |= W(1) << (i % 64);
  }
  for (int i = 0; i < n; i++)
    for (int j = 0; j < i; j++) {
      auto &a = vs[i], &b = vs[j];
      if (a.h != b.h)
        continue;
      int u = 3 * inner_product(a.x, a.x + 18, b.x, 0) +
              2 * inner_product(a.t, a.t + 3, b.t, 0) + 2 * a.h * a.ep * b.ep;
      if (abs(u) == 54) {
        compat[i][j / 64] |= W(1) << (j % 64);
        compat[j][i / 64] |= W(1) << (i % 64);
      }
    }
}
void latin() {
  P base{0, 1, 2, 3, 4, 5};
  do {
    perms.push_back(base);
  } while (next_permutation(base.begin(), base.end()));
  const int c1[][3] = {{0, 2, 4}, {0, 3, 5}, {1, 2, 5}, {1, 3, 4}};
  set<array<int, 4>> configs;
  for (auto &p : perms) {
    array<int, 4> signature;
    for (int i = 0; i < 4; i++) {
      int mask = 0;
      for (int x : c1[i])
        mask |= 1 << p[x];
      signature[i] = mask;
    }
    sort(signature.begin(), signature.end());
    if (configs.insert(signature).second)
      pasch.push_back(p);
  }
  if (pasch.size() != 30)
    throw runtime_error("pasches");
  L l{};
  int rowbit[6]{}, colbit[6]{};
  for (int i = 0; i < 6; i++) {
    l[i] = l[6 * i] = i;
    rowbit[0] |= 1 << i;
    colbit[0] |= 1 << i;
    rowbit[i] |= 1 << i;
    colbit[i] |= 1 << i;
  }
  function<void(int)> fill = [&](int k) {
    if (k == 25) {
      reduced.push_back(l);
      return;
    }
    int r = 1 + k / 5, c = 1 + k % 5, open = (~(rowbit[r] | colbit[c])) & 63;
    while (open) {
      int b = open & -open;
      open ^= b;
      rowbit[r] ^= b;
      colbit[c] ^= b;
      l[6 * r + c] = __builtin_ctz(b);
      fill(k + 1);
      rowbit[r] ^= b;
      colbit[c] ^= b;
    }
  };
  fill(0);
  if (reduced.size() != 9408)
    throw runtime_error("latin count");
  set<L> todo(reduced.begin(), reduced.end());
  while (!todo.empty()) {
    L a = *todo.begin();
    reps.push_back(a);
    // Choice of first row, first column and relabelling of symbols uniquely
    // determines a reduced isotope.
    for (int i = 0; i < 6; i++)
      for (int j = 0; j < 6; j++)
        for (const P &p : perms) {
          if (p[a[6 * i + j]] != 0)
            continue;
          L h{};
          for (int r = 0; r < 6; r++)
            for (int c = 0; c < 6; c++)
              h[6 * p[a[6 * r + j]] + p[a[6 * i + c]]] = p[a[6 * r + c]];
          todo.erase(h);
        }
  }
  if (reps.size() != 22)
    throw runtime_error("isotopy count");
}
int localnw;
struct Node {
  array<W, 16> b{};
  void set(int i) { b[i / 64] |= W(1) << (i % 64); }
  void erase(int i) { b[i / 64] &= ~(W(1) << (i % 64)); }
  int first() const {
    for (int i = 0; i < localnw; i++)
      if (b[i])
        return 64 * i + __builtin_ctzll(b[i]);
    return -1;
  }
};
int clique(const vector<int> &verts, vector<int> &answer) {
  if (verts.size() > 1024)
    throw runtime_error("local graph too large");
  Node ns[1024], all;
  int n = verts.size();
  localnw = (n + 63) / 64;
  for (int i = 0; i < n; i++) {
    all.set(i);
    for (int j = 0; j < n; j++)
      if (compat[verts[i]][verts[j] / 64] >> (verts[j] % 64) & 1)
        ns[i].set(j);
  }
  int chosen[1025]{}, best = 0;
  function<void(Node, int)> visit = [&](Node p, int dep) {
    if (dep > best) {
      best = dep;
      if (dep >= 10) {
        answer.clear();
        for (int i = 0; i < dep; i++)
          answer.push_back(verts[chosen[i]]);
        return;
      }
    }
    Node unc = p;
    int order[1024], cs[1024], sz = 0, col = 0;
    while (unc.first() >= 0) {
      Node rem = unc;
      col++;
      int v;
      while ((v = rem.first()) >= 0) {
        rem.erase(v);
        unc.erase(v);
        for (int j = 0; j < localnw; j++)
          rem.b[j] &= ~ns[v].b[j];
        order[sz] = v;
        cs[sz++] = col;
      }
    }
    for (int i = sz - 1; i >= 0; i--) {
      if (dep + cs[i] <= best || best >= 10)
        return;
      int v = order[i];
      Node np = p;
      for (int j = 0; j < localnw; j++)
        np.b[j] &= ns[v].b[j];
      chosen[dep] = v;
      visit(np, dep + 1);
      p.erase(v);
    }
  };
  visit(all, 0);
  return best;
}
map<int, long long> counts, choices;
map<BB, int> cache;
long long total = 0;
void inspect(const L &a) {
  BB opts;
  opts.fill(~W(0));
  for (int r = 0; r < 6; r++)
    for (int c = 0; c < 6; c++) {
      const auto &v = at[idx(r, c, a[6 * r + c])];
      for (int w = 0; w < NW; w++)
        opts[w] &= v[w];
    }
  int n = 0;
  for (auto w : opts)
    n += __builtin_popcountll(w);
  choices[n]++;
  auto it = cache.find(opts);
  int maxc = 0;
  if (it != cache.end())
    maxc = it->second;
  else {
    vector<int> sel;
    for (int w = 0; w < NW; w++) {
      W z = opts[w];
      while (z) {
        sel.push_back(64 * w + __builtin_ctzll(z));
        z &= z - 1;
      }
    }
    vector<int> answer;
    maxc = clique(sel, answer);
    if (maxc >= 10) {
      cout << "FOUND ";
      for (auto x : a)
        cout << x;
      cout << " additions";
      for (int v : answer)
        cout << " " << v;
      cout << endl;
      exit(0);
    }
    if (cache.size() < 250000)
      cache.emplace(opts, maxc);
    if (cache.size() <= 2) {
      cout << "representative " << n << " ";
      for (auto t : a)
        cout << t;
      cout << " max " << maxc << endl;
    }
  }
  counts[maxc]++;
  total++;
}
void report() {
  cout << "tested " << total << " cache " << cache.size() << " maxima";
  for (auto [a, b] : counts)
    cout << " " << a << ":" << b;
  cout << " shell";
  for (auto [a, b] : choices)
    cout << " " << a << ":" << b;
  cout << endl;
}
int main(int argc, char **argv) {
  read_cand(argv[1]);
  latin();
  cout << "reduced " << reduced.size() << " isotopy " << reps.size()
       << " Pasch " << pasch.size() << endl;
  if (string(argv[2]) == "reduced") {
    for (auto &l : reduced)
      inspect(l);
    report();
    return 0;
  }
  int begin = argc > 3 ? atoi(argv[3]) : 0, end = argc > 4 ? atoi(argv[4]) : 22;
  for (int ind = begin; ind < end; ind++) {
    const L &a = reps[ind];
    for (auto &x : pasch)
      for (auto &y : pasch)
        for (auto &z : pasch) {
          L l{};
          P inv;
          for (int i = 0; i < 6; i++)
            inv[z[i]] = i;
          // pull back the three independent Pasch images x(C), y(C), z(C) to
          // the standard C.
          for (int i = 0; i < 6; i++)
            for (int j = 0; j < 6; j++)
              l[6 * i + j] = inv[a[6 * x[i] + y[j]]];
          inspect(l);
        }
    cout << "class " << ind << " ";
    report();
  }
}

# Order-six Latin/Pasch 48-line cores have extension maximum 57 in dimension 18

For every 48-line core from Remark 6.2 of Munemasa, Szöllősi and Yoshino, arXiv:2606.10421v2, the largest set of equiangular lines in real dimension 18 containing that core has exactly 57 lines. Permuting each of the three Pasch quadruples is allowed. The calculation takes all ambient real extensions into account. It leaves open cores outside this particular construction.

## Reproduce

Run `python3 verify.py` with a C++17 compiler available (set CXX if desired). The verifier regenerates every input. The only library dependencies are the compiler's standard library and Python's standard library. The final check directly uses a 17-dimensional Gram basis to verify representatives of both outcomes.

## The core and its coordinates

Write W for the sum-zero subspace in real six-space. Work in W³ ⊕ R³, of dimension 18. If e_i are the coordinate unit vectors and 1 is the all-ones vector, write u_i=1/6·1−e_i and w_I=1/2·1−1_I. Let L be a Latin square on six symbols. Use the 36 vectors

    √2 (u_i, u_j, u_{L(i,j)}, 0).

The other 12 vectors are organized in three groups, indexed by h=1,2,3. In group h put √2 w_I in the h-th W block with zero in the other two W blocks, and put P_h in the last three coordinates. Here

    P_1=(0,−1,1),   P_2=(1,0,−1),   P_3=(−1,1,0).

Each I is drawn from the four triples 135,146,236,245 of {1,2,3,4,5,6}. These are precisely the four entries of (5.1) in the cited paper. All core squared lengths are five and all pairwise inner products are ±1.

Each of these 48-line cores also has Seidel spectrum (−5)³¹, 7⁸, 11⁹. Indeed the 36 Latin vectors alone have frame operator 12 times the identity on W³, by the orthogonal row, column and symbol sums. The four vectors √2 w_I in any one W block have Gram 4I−J, sum zero and contribute four times the projector onto a three-dimensional subspace. In the last three coordinates the Pasch vectors contribute 4Σ P_h P_hᵀ, equal to 12 times the projector onto (1,1,1)⊥. All cross terms vanish. The complete frame has nonzero eigenvalues 16 on nine dimensions and 12 on eight dimensions. As none of these cores admits ten additions, none satisfies the sufficient projected-coordinate condition for a 48-to-58 construction in the accompanying project.

## Finite alphabet for an arbitrary additional line

For an additional squared-norm-five vector x, denote its last three coordinates by z and write its first three W blocks as −p/(3√2), −q/(3√2), −r/(3√2). Its inner product against the (i,j)-th Latin line is (p_i+q_j+r_{L(i,j)})/3. Summing this equation over a row, column, and symbol class shows each coordinate of p,q,r is half the sum of six signs. Thus p,q,r have integer entries in [−3,3] and each sums to zero. Squaring the 36 equalities and adding eliminates the cross terms by the Latin-square property, giving

    ||p||²+||q||²+||r||²=54,    ||z||²=2.

Put T_h=3(z,P_h). For group one, the four Pasch conditions become

    |T_1 + Σ_{i∈I} p_i| = 3,

and similarly for q and r. Thus all T_h are integers, and T_1+T_2+T_3=0. These inner products determine the component of z perpendicular to (1,1,1). The remaining component, measured along a unit normal, is ±√(H/27), for H=54−Σ T_h². Discard H<0, and identify simultaneous sign reversal using the first nonzero coordinate of (p,q,r). The Latin conditions further require each row-column pair, row-symbol pair, and column-symbol pair to have some compatible third coordinate. These exact necessary tests leave 2,880 vectors, with H=36 or 54. The program then checks all 36 signs of each specific Latin square; every survivor is an actual extension line.

For two surviving vectors, let J be the dot product of their concatenated 18-tuples (p,q,r), T and T′ their three Pasch data, and ε and ε′ their normal signs. Their actual inner product multiplied by 54 is

    3J + 2(T,T′) + 2 εε′ √(H H′).

When H and H′ differ, the last term is irrational, so they are incompatible. For equal heights the condition that this expression is ±54 is an integer test. The graph with these compatible pairs as edges describes simultaneous additions.

## Exhaustiveness and results

Every labelled Latin square can be reduced by permuting rows, columns, and symbols. Exhaustively filling reduced Latin squares produces 9,408. The code partitions them into 22 isotopy classes. To generate every reduced isotope of one square, choose its initial row and column and any permutation of symbols taking the corner symbol to zero. The first row and column of a reduced square then uniquely determine all remaining row and column labels.

The image of the fixed Pasch quadruple under all 720 permutations has 30 possibilities. For each isotopy representative the three coordinate blocks therefore require only 30³ Pasch choices. Choices of relabelling that give the same quadruple differ by an isometry preserving that quadruple. The 22·30³=594,000 cases form a covering family of representatives which may repeat isometric cases.

In the chosen coordinates this computation produces two extension vertex sets, of sizes 72 and 288. Their exact maximum clique sizes both equal nine. In this sweep 593,984 representatives give the first cardinality and 16 the second. These counts refer to the chosen parametrization. The clique computation uses exhaustive branch and bound with a proper coloring at each node. A separate exact Gram-basis enumeration for a core of each type gives (72,9) and (288,9), respectively. Adding nine lines attains 57, and a 58-system would require ten. The common angle of any extension is fixed by the core.

Source: A. Munemasa, F. Szöllősi and K. Yoshino, *Sets of equiangular lines in dimension 18 constructed from A₅³ ⊕ A₁⁴*, Proposition 5.2 and Remark 6.2. https://arxiv.org/abs/2606.10421

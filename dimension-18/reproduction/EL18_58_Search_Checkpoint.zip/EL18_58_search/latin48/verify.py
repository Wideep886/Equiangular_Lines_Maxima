"""Recompute the full order-six Latin/Pasch sweep. Python >=3.9 and C++17."""
from pathlib import Path
from tempfile import TemporaryDirectory
from subprocess import run
from shutil import copy
from sys import executable
import os

def main():
    here=Path(__file__).resolve().parent
    with TemporaryDirectory() as temp:
        work=Path(temp)
        for name in ('candidates.py','latin.cpp','control.py'):
            copy(here/name,work/name)
        generation=run([executable,str(work/'candidates.py')],capture_output=True,text=True,check=True)
        print(generation.stdout.strip())
        assert 'universal vectors 2880' in generation.stdout
        compiler=os.environ.get('CXX','c++')
        run([compiler,'-std=c++17','-O3',str(work/'latin.cpp'),'-o',str(work/'latin')],check=True)
        for mode,expected in [('reduced','tested 9408 cache 2 maxima 9:9408 shell 72:9392 288:16'),
                              ('all','class 21 tested 594000 cache 2 maxima 9:594000 shell 72:593984 288:16')]:
            out=run([str(work/'latin'),str(work/'candidates.dat'),mode],capture_output=True,text=True,check=True)
            lines=out.stdout.splitlines()
            assert lines[0]=='reduced 9408 isotopy 22 Pasch 30' and lines[-1]==expected
            print(expected)
        run([executable,str(work/'control.py')],check=True)

if __name__=='__main__':main()

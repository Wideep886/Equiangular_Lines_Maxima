"""Independent full Gram-matrix and orthogonal-complement verification for two representative 48-line cores."""
from collections import Counter
from fractions import Fraction
from functools import reduce
from math import lcm
from itertools import product

def dot(a,b):
    return sum(x*y for x,y in zip(a,b))

def maximum_clique(vertices, compatible):
    graph = [sum(1<<j for j,y in enumerate(vertices) if j!=i and compatible(x,y))
             for i,x in enumerate(vertices)]
    best = 0
    def visit(mask, size):
        nonlocal best
        best = max(best,size)
        # A proper coloring of the remaining graph bounds each branch.
        colors,order=[],[]
        uncolored=mask
        color=0
        while uncolored:
            independent=uncolored
            color+=1
            while independent:
                bit=independent&-independent
                v=bit.bit_length()-1
                independent=(independent^bit)&~graph[v]
                uncolored^=bit
                order.append(v)
                colors.append(color)
        for v,c in zip(reversed(order),reversed(colors)):
            if size+c<=best:return
            visit(mask&graph[v],size+1)
            mask^=1<<v
    visit((1<<len(vertices))-1,0)
    return best

def check_rank_seventeen(G,B):
    C=list(range(48))
    assert len(C)==48 and len(set(B))==17 and set(B)<=set(C)
    # Simultaneously invert G_B and find the coordinates of each retained line.
    M=[[Fraction(G[i][j]) for j in B+C]+[Fraction(k==j) for j in range(17)]
       for k,i in enumerate(B)]
    for j in range(17):
        p=next(i for i in range(j,17) if M[i][j])
        M[p],M[j]=M[j],M[p]
        u=M[j][j]
        M[j]=[x/u for x in M[j]]
        for i,r in enumerate(M):
            if i!=j and r[j]:
                u=r[j]
                r[:]=[x-u*y for x,y in zip(r,M[j])]
    D=reduce(lcm,(x.denominator for r in M for x in r[17:]))
    coeff=[tuple(int(x*D) for x in col) for col in zip(*(row[17:65] for row in M))]
    inv=[tuple(int(x*D) for x in row[65:]) for row in M]
    # The residual Gram matrix vanishes, proving that the core has rank exactly 17.
    assert all(dot([G[i][b] for b in B],col)==D*G[i][j] for i in C for j,col in zip(C,coeff))
    tests=sorted([[(i,v) for i,v in enumerate(col) if v] for j,col in zip(C,coeff) if j not in B],key=len)
    options=[]
    for tail in product([-1,1],repeat=16):
        s=(1,)+tail
        if any(abs(sum(v*s[i] for i,v in eq))!=D for eq in tests):continue
        c=[dot(w,s) for w in inv]
        h=5*D-dot(c,s)
        if h<0:continue
        options.extend((s,c,h,e) for e in ([1] if h==0 else [-1,1]))
    def comp(a,b):
        s,c,h,e=a;t,f,g,j=b
        v=dot(s,f)
        # D (x,y) = v + e*j*sqrt(h*g). Sign and square tests are exact.
        return any((z*D-v)**2==h*g and (z*D-v)*e*j>=0 for z in [-1,1])
    return len(options), maximum_clique(options,comp)

def independent_basis(coords):
    matrix=[[Fraction(v) for v in row] for row in zip(*coords)]
    B=[]
    for j in range(len(coords)):
        k=len(B)
        pivot=next((i for i in range(k,len(matrix)) if matrix[i][j]),None)
        if pivot is None:continue
        matrix[k],matrix[pivot]=matrix[pivot],matrix[k]
        p=matrix[k]
        for i in range(k+1,len(matrix)):
            row=matrix[i]
            if row[j]:
                u=row[j]/p[j]
                row[j:]=[x-u*y for x,y in zip(row[j:],p[j:])]
        B.append(j)
    assert len(B)==17
    return B

def core(digits):
    lat=[int(x) for x in digits]; S=set(range(6))
    assert all(set(lat[6*i:6*i+6])==S and set(lat[i::6])==S for i in range(6))
    # 26 integral coordinates, inner product scaled down by 72.
    a=[[1-6*(i==j)for j in range(6)] for i in range(6)]
    q=[3,-3];nq=[-3,3];z=[0]*2;zero=[0]*6;root=[0]*24+[6,-6]
    vec=[a[i]+a[j]+a[lat[6*i+j]]+z+z+z+q for i in range(6) for j in range(6)]
    for block in range(3):
        for I in [(0,2,4),(0,3,5),(1,2,5),(1,3,4)]:
            v=[3-6*(i in I) for i in range(6)]
            vec.append([v+zero+zero+z+nq+q+q,zero+v+zero+q+z+nq+q,zero+zero+v+nq+q+z+q][block])
    coords=[tuple(2*x-y for x,y in zip(v,root)) for v in vec]
    raw=[[dot(x,y) for y in coords] for x in coords]
    assert all(raw[i][i]==360 and all(abs(raw[i][j])==72 for j in range(i)) for i in range(48))
    return [[x//72 for x in row] for row in raw],independent_basis(coords)

if __name__=='__main__':
    cases = {'012345103254234501325410450123541032':288,
             '012435104253243501425310350124531042':72}
    for L,n in cases.items():
        G,B=core(L)
        answer=check_rank_seventeen(G,B)
        print('independent control',L,answer,flush=True)
        assert answer==(n,9)

"""Sample glued D8 core templates and run exact rank-nine completion on each new template."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import fcntl
import hashlib
import io
import json
import os
import random
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
CORE=ROOT/'core_search'
sys.path.insert(0,str(CORE))
from make_anchor import export
from make_template import build
from occupation import tables
from core48 import extension
from verify_gram import certify

# All previous occupancy IDs are paused pending integration of the single-row proof.
OPEN=()
# The four explicitly checked files t217, t222, fix217, fix222, respectively.
# Digests identify complete signed templates, never a whole occupancy table.
KNOWN_INFEASIBLE={
    '0634ad714e7543edba73d01e1d4fb37a04016dd1a732a820c7d42e63e3b9eafc',
    '6df9e07f7fdec8138e65d98a3171e370a4c05c95aa343f0df08b306e30f652b4',
    '5ffe9970fe78c006c826243dc33a3ba1d99d07b1ffd620ca97be002c6a8209cd',
    'b4954400bc6ed07bf68060e514b49664c3403284c86f5eb353b78429fac46cef',
}

def atomic(path,text):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(text)
    os.replace(tmp,path)

def digest(text):
    return hashlib.sha256(' '.join(text.split()).encode()).hexdigest()

def validate(S,table,job):
    assert len(S)==48 and all(len(row)==48 for row in S)
    assert all(S[i][i]==0 and all(S[i][j] in (-1,1) and S[i][j]==S[j][i] for j in range(i)) for i in range(48))
    G=extension(table,[[int(v<0) for v in row] for row in S])
    proof=certify(G)
    atomic(job/'witness58.json',json.dumps(G))
    print(proof,flush=True)

def complete(exe,template,nodes,seconds):
    stream=io.StringIO()
    export(template,stream)
    try:
        result=subprocess.run([str(exe),str(nodes)],input=stream.getvalue(),text=True,
                              capture_output=True,check=True,timeout=seconds)
    except subprocess.TimeoutExpired:
        return {'status':'TIMEOUT'},None
    lines=result.stdout.splitlines()
    status,nlabel,count,rlabel,rank=lines[0].split()
    assert status in ('CONSTRUCTION','INFEASIBLE','INDETERMINATE')
    assert (nlabel,rlabel)==('nodes','anchor_rank')
    answer=[list(map(int,line.split())) for line in lines[1:]] if status=='CONSTRUCTION' else None
    return {'status':status,'nodes':int(count),'anchor_rank':int(rank)},answer

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--batches',type=int,default=7)
    p.add_argument('--steps',type=int,default=24000,help='Tabu steps only if exact completion reaches a budget.')
    p.add_argument('--exact-nodes',type=int,default=100000)
    p.add_argument('--exact-seconds',type=float,default=5.0)
    a=p.parse_args()
    if min(a.batches,a.steps,a.exact_nodes,a.exact_seconds)<=0:raise ValueError('Use positive budgets.')
    job=ROOT/'trials';job.mkdir(exist_ok=True)
    cursor=job/'progress.json'
    with (job/'search.lock').open('a') as lock,TemporaryDirectory() as tmp:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if (job/'witness58.json').exists():
            print(certify(json.loads((job/'witness58.json').read_text())));return
        if not OPEN:
            print("No D8 occupancy tables are enabled. The independent basis search is reference_bases/continue_bases.py.")
            return
        state=json.loads(cursor.read_text()) if cursor.exists() else {'next':0,'runs':[]}
        seen=KNOWN_INFEASIBLE|{v['template_sha256'] for v in state['runs'] if 'template_sha256' in v}
        tmp=Path(tmp)
        for name,source in [('exact','complete.cpp'),('tabu','search.cpp')]:
            subprocess.run([os.environ.get('CXX','c++'),'-std=c++17','-O3',str(CORE/source),'-o',str(tmp/name)],check=True)
        wordfile=CORE/'words_aug7.txt';pairfile=CORE/'pair3000.out';allowed=CORE/'words_moment.txt'
        open_tables=list(OPEN);occupations=tables()
        for _ in range(a.batches):
            turn=state['next'];seed=1010003+turn;rng=random.Random(seed)
            template=tmp/'template'
            record={'round':turn,'seed':seed,'exact_node_budget':a.exact_nodes,'exact_seconds':a.exact_seconds}
            for attempt in range(100):
                if not open_tables:break
                occupancy=open_tables[rng.randrange(len(open_tables))]
                margins=build(occupancy,wordfile,pairfile,allowed,template,rng=rng)
                if margins is None:
                    # solve() exhausts only the specific word and pair input lists.
                    open_tables.remove(occupancy)
                    continue
                content=template.read_text();key=digest(content)
                if key in seen:continue
                record.update(occupancy=occupancy,template_sha256=key,generation_attempts=attempt+1,
                              margin_words=margins,template_seed=seed,template_attempt=attempt)
                # Recording the small fixed matrix gives exact replay even if the input word list changes.
                folder=job/'exact_templates';folder.mkdir(exist_ok=True)
                atomic(folder/f'{key}.dat',content)
                exact,answer=complete(tmp/'exact',template,a.exact_nodes,a.exact_seconds)
                record['exact']=exact
                if answer is not None:
                    validate(answer,occupations[occupancy],job)
                elif exact['status'] in ('INDETERMINATE','TIMEOUT'):
                    incumbent=tmp/'incumbent';incumbent.unlink(missing_ok=True)
                    subprocess.run([str(tmp/'tabu'),str(seed),str(a.steps),str(template),str(incumbent)],check=True)
                    lines=incumbent.read_text().splitlines();score=int(lines[0].split()[0])
                    record.update(steps=a.steps,exact_residual=score)
                    if score==0:validate([list(map(int,r.split())) for r in lines[1:]],occupations[occupancy],job)
                    else:
                        best=job/f'row_{occupancy}_best.json'
                        if not best.exists() or score<json.loads(best.read_text())['score']:
                            atomic(best,json.dumps({'score':score,'seed':seed,'step_budget':a.steps,
                                                   'template':content,'incumbent':incumbent.read_text()}))
                seen.add(key)
                break
            else:record['generation_status']='no_new_template_in_attempt_budget'
            if not open_tables and 'exact' not in record:record['generation_status']='no_compatible_margin_assignment_in_input_library'
            state['runs'].append(record);state['next']+=1
            atomic(cursor,json.dumps(state,indent=2)+'\n')
            if 'exact' in record:
                ans=record['exact']
                print(f"round {turn} table {record['occupancy']} {record['template_sha256'][:12]} {ans['status']} nodes={ans.get('nodes','-')}",flush=True)
            else:
                print(f"round {turn} {record['generation_status']}",flush=True)
            if (job/'witness58.json').exists() or not open_tables:return

if __name__=='__main__':main()

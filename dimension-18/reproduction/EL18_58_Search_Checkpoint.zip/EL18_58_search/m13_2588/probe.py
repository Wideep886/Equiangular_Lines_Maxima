"""Rational rank-one coordinate constraints for parent 2588 using pair moments."""
from pathlib import Path
import json,sys,subprocess
from itertools import product
from functools import lru_cache
from concurrent.futures import ProcessPoolExecutor,as_completed
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'audit_layer'));sys.dont_write_bytecode=True
from polynomial13 import SOURCE,factors,native,poly_types,val,mul,rem,deriv,phase_one
PARENT=2588
EXTRA=None
def data():
    ids=next(r[2] for r in map(json.loads,(HERE.parent/'audit_layer'/'poly13_final.jsonl').read_text().splitlines()) if r[0]==PARENT)
    fs=[([1,0],13)]+factors(json.loads((SOURCE/'parents.json').read_text())[PARENT])
    g,t,deck=native([([1,8],40)]+fs)
    _,_,pairs=poly_types({i:sum(1<<j for j in ids)for i in ids},fs,g,deck,ids)
    h=[tuple(deck[v]) for v in ids]
    pairs={(i,j):pairs.get((a,b),[]) for i,a in enumerate(ids) for j,b in enumerate(ids) if i<=j}
    return ids,tuple(g),t,h,pairs,fs[-1][0]
IDS,G,T,H,PAIRS,QUARTIC=data()
N=len(IDS)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
@lru_cache(None)
def enc(q):return tuple(rem(list(q),QUARTIC))
@lru_cache(None)
def pro(a,b):return tuple(rem(mul(a,b),QUARTIC))
# Fix any admitted relative quartic sign against type 0.
R=[enc(PAIRS[0,i][0]) for i in range(N)]
REF=enc(H[0])
def neg(a):return tuple(-x for x in a)
def sgn(x):return (x>0)-(x<0)
def tags(i,j,q):
    a,b=pro(enc(q),REF),pro(R[i],R[j])
    assert a==b or a==neg(b)
    return (0 if not any(b) else 1 if a==b else -1,sgn(val(q,2)))
@lru_cache(None)
def ev(q,z):return val(q,z)
@lru_cache(None)
def kernel(q,z,w):
    if z==w:return 2*(val(deriv(G),z)*ev(q,z)-val(G,z)*val(deriv(q),z))
    n=2*(val(G,w)*ev(q,z)-val(G,z)*ev(q,w));assert not n%(w-z);return n//(w-z)
@lru_cache(None)
def opts(i,j):
    if i>j:i,j=j,i
    return [(q,*tags(i,j,q)) for q in PAIRS[i,j]]
def matrix(i,j,p,A):
    Z=(-2,0,2)
    def signrow(h,z):return (2*z+11)*ev(h,z)-4*val(G,z)
    rhs=tuple(x-a-b for x,a,b in zip((58,*T[3:]),(1,*H[i][3:]),(1,*H[j][3:])))
    rhs+=tuple(signrow(H[l],z)-ev(p,z) for l in (i,j) for z in Z)
    rhs+=tuple(kernel(H[l],z,z)-ev(H[l],z)**2-ev(p,z)**2 for l in (i,j) for z in Z)
    rhs+=tuple(kernel(p,z,w)-ev(H[i],z)*ev(p,w)-ev(p,z)*ev(H[j],w) for z in Z for w in Z)
    cols=set();pu,pv=tags(i,j,p)
    for k in range(N):
        for (r,ru,rv),(s,su,sv),e in product(opts(i,k),opts(j,k),(-1,1)):
            if (min(i,k),max(i,k),r) not in A or (min(j,k),max(j,k),s) not in A:continue
            if pu*ru*su and pu*ru*su!=e:continue
            # W(2) is negative semidefinite on its simple support.
            if pv*rv*sv and pv*rv*sv!=-e:continue
            okay=True
            for z,orientation in ((0,-1),(-8,1)):
                x,y,b=ev(H[i],z),ev(H[j],z),ev(H[k],z)
                u,v,w=ev(p,z),ev(r,z),ev(s,z)
                if orientation*(x*y*b+2*e*u*v*w-x*w*w-y*v*v-b*u*u)<0:okay=False;break
            if not okay:continue
            if EXTRA is not None and not EXTRA(i,j,k,p,r,s,e):continue
            c=(1,*H[k][3:])+tuple(ev(q,z) for q in (r,s) for z in Z)
            c+=tuple(ev(q,z)**2 for q in (r,s) for z in Z)
            c+=tuple(e*ev(r,z)*ev(s,w) for z in Z for w in Z)
            cols.add(c)
    return sorted(cols),rhs
def modular(cols,b,p):
    basis={}
    def reduce(row):
        z=list(row)
        for i,t in sorted(basis.items()):
            if z[i]%p:
                w=z[i]
                z=[(x-w*y)%p for x,y in zip(z,t)]
        return z
    for c in cols:
        r=reduce(c);i=next((i for i,v in enumerate(r) if v%p),None)
        if i is not None:
            s=pow(r[i]%p,-1,p)
            basis[i]=[v*s%p for v in r]
    return not any(v%p for v in reduce(b))
def work(job):
    i,j,p,A=job;cols,rhs=matrix(i,j,p,A)
    if not cols:return i,j,p,'empty'
    for m in (37,2,3,5,7,11):
        if not modular(cols,rhs,m):return i,j,p,'mod'+str(m)
    # LP on reduced linearly independent coordinate rows. Choose a spanning
    # subset modulo a prime. Every chosen coordinate equation is necessary.
    prime=1009;basis={};idx=[]
    for j0,col in enumerate(zip(*cols)):
        z=[x%prime for x in col]
        for k,t in sorted(basis.items()):
            if z[k]:
                fac=z[k];z=[(a-fac*b)%prime for a,b in zip(z,t)]
        k=next((k for k,x in enumerate(z) if x),None)
        if k is not None:
            s=pow(z[k],-1,prime);basis[k]=[v*s%prime for v in z];idx.append(j0)
    rows=sorted({tuple(c[k] for k in idx) for c in cols})
    cert=phase_one(rows,tuple(rhs[k] for k in idx))
    if cert['kind']=='primal':return i,j,p,None
    return i,j,p,[idx,cert]
def generate():
    A={(i,j,q) for (i,j),ps in PAIRS.items() for q in ps}; logs=[];out=HERE/'result.json'
    if out.exists():
        old=json.loads(out.read_text());logs=old['rounds']
        for r in logs:
            for i,j,q,_ in r:A.discard((i,j,tuple(q)))
    while A:
        bad=[]
        with ProcessPoolExecutor(4) as ex:
            for i,j,q,c in ex.map(work,[(i,j,p,A) for i,j,p in sorted(A)],chunksize=3):
                if c is not None:bad.append([i,j,q,c])
        print('remaining pairs',len(A),'removed',len(bad),flush=True)
        if not bad:break
        logs.append(bad)
        for i,j,q,_ in bad:A.remove((i,j,q))
        out.write_text(json.dumps(dict(ids=IDS,rounds=logs,remaining=len(A)),separators=(',',':'))+'\n')
if __name__=='__main__':generate()

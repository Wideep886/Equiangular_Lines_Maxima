"""Labelled and S4 x S4 enumeration of the two four-point anchor classes."""
import json,sys
from pathlib import Path
from itertools import permutations,product
from fractions import Fraction as F
from collections import Counter
from math import lcm
from oriented_frames import U,L,E,H,IDS,ev,kernel,G,phase_one,lat
from probe import HERE,val
stored=json.loads((HERE/'oriented_frames.json').read_text())['remaining']
opts={(u,v):[(s,tuple(q))for s,q in o]for u,v,o in stored}
def key(i,j):return opts[min(i,j),max(i,j)]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def local(u,v):
    zrange=range(-2,3)
    i=U[u][0];N=[n-(u==k)for k,(_,_,n) in enumerate(U)]
    rhs=tuple(N)+tuple((2*z+11)*ev(H[i],z)-4*val(G,z) for z in zrange)
    rhs+=tuple(kernel(H[i],z,w)-ev(H[i],z)*ev(H[i],w)for z in zrange for w in zrange if z<=w)
    rhs+=tuple(E[u])+tuple(-ev(H[i],0)*x for x in L[u])
    basis=[];variable=None
    for k,n in enumerate(N):
        if n==0:continue
        for s,q in key(u,k):
            c=tuple(int(k==j)for j in range(len(U)))+tuple(ev(q,z)for z in zrange)+tuple(ev(q,z)*ev(q,w)for z in zrange for w in zrange if z<=w)+tuple(s*x for x in L[k])+tuple(s*ev(q,0)*x for x in L[k])
            if k==v and -s*q[-1]==-32:variable=c
            else:basis.append(c)
    assert variable is not None
    counts=[]
    for k in range(5):
        target=tuple(x-k*y for x,y in zip(rhs,variable))
        if lat(basis,target) and phase_one(basis,target)['kind']=='primal':counts.append(k)
    return counts
def orbits():
    perms=list(permutations(range(4)))
    maps=[[sum((1<<j) for j,k in enumerate(p) if r>>k&1)for r in range(16)]for p in perms]
    unseen=set(range(1<<16))
    while unseen:
        x=min(unseen);rows=[(x>>(4*j))&15 for j in range(4)]
        orb=set()
        for m in maps:
            v=[m[r]for r in rows]
            for p in perms:orb.add(sum(v[k]<<(4*j)for j,k in enumerate(p)))
        unseen-=orb
        yield x,len(orb)
def schur(K):
    """Exact Schur elimination, recording independent indices for projection."""
    C=[list(map(F,row))for row in K];B=[]
    for i,row in enumerate(C):
        v=row[i]
        if v<0 or (not v and any(row[i+1:])):return None
        if v:
            B.append(i)
            for j in range(i+1,len(row)):
                if C[j][i]:
                    d=C[j][i]/v
                    C[j]=[x-d*y for x,y in zip(C[j],row)]
    return B
def inverse(K):
    n=len(K);m=[[F(x)for x in row]+[F(i==j)for j in range(n)]for i,row in enumerate(K)]
    for i in range(n):
        d=m[i][i];m[i]=[x/d for x in m[i]]
        for j,r in enumerate(m):
            if i!=j and r[i]:m[j]=[x-r[i]*y for x,y in zip(r,m[i])]
    return [r[n:]for r in m]
def matrix(mask):
    K=[[80 if i==j else -16 for j in range(8)]for i in range(8)]
    for i,j in product(range(4),repeat=2):
        K[i][j+4]=K[j+4][i]=(-32 if mask>>(4*i+j)&1 else 16)
    return K
def outer(K,B):
    Hinv=inverse([[K[i][j] for j in B]for i in B])
    D=lcm(*(v.denominator for row in Hinv for v in row))
    Q=[[int(x*D) for x in row]for row in Hinv]
    counts={}
    for k,(t,s,n) in enumerate(U):
        if k in (0,3):continue
        choices=[sorted({-sg*q[-1]for sg,q in key(u,k)})for u in (0,3)]
        mx=-H[t][-1]
        good=0
        for a,b in product(product(choices[0],repeat=4),product(choices[1],repeat=4)):
            x=a+b;y=[x[i]for i in B];c=[dot(row,y) for row in Q]
            if dot(c,y)>mx*D:continue
            if any(sum(K[i][j]*z for j,z in zip(B,c))!=D*x[i] for i in range(8) if i not in B):continue
            good+=1
        counts[k]=good
        if not good:break
    return counts
def main():
    c0=local(0,3);c3=local(3,0);print('row/column counts',c0,c3,flush=True)
    counts=Counter();cases=[]
    for x,n in orbits():
        K=matrix(x);rows=[sum(a==-32 for a in q)for q in K]
        def mark(k):counts[k,'orbits']+=1;counts[k,'labelled']+=n
        mark('all')
        B=schur(K)
        if B is None:continue
        mark('PSD')
        if not all(y in c0 for y in rows[:4]) or not all(y in c3 for y in rows[4:]):continue
        mark('row counts')
        d=outer(K,B)
        if not all(d.values()):continue
        mark('one extension per class')
        cases.append(dict(mask=x,orbit_size=n,rank=len(B),counts=d))
    print(counts)
    (HERE/'cross4.json').write_text(json.dumps(dict(row=c0,column=c3,summary={k:[counts[k,'orbits'],counts[k,'labelled']]for k in ('all','PSD','row counts','one extension per class')},cases=cases),separators=(',',':'))+'\n')
if __name__=='__main__':main()

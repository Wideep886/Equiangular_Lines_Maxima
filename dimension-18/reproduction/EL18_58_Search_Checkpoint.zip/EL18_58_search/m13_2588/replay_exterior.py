"""Integer dual verification, with an independent rational reverse-pivot Gram factorization."""
import json
from fractions import Fraction as F
from itertools import product
from math import lcm
from cross4 import HERE,U,L,H,key,matrix

def scalar(a,b):return sum(x*y for x,y in zip(a,b))

def enumerate_words(K):
    # Project on one orthogonal coordinate at a time, selecting pivots in descending index order.
    M=[list(map(F,r)) for r in K];pivots=[]
    for j in reversed(range(8)):
        n=M[j][j]
        if n==0:
            assert not any(M[j]);continue
        assert n>0
        u=M[j][:];pivots.append((j,u,n))
        M=[[w-a*b/n for b,w in zip(u,r)] for a,r in zip(u,M)]
    # Build every reverse-pivot linear functional on x once, then clear denominators.
    coord=[];residue=[]
    for a in range(8):
        vals=[F(int(i==a))for i in range(8)];row=[]
        for j,u,n in pivots:
            x=vals[j];row.append(x);vals=[z-w*x/n for z,w in zip(vals,u)]
        coord.append(row);residue.append(vals)
    q=lcm(*(x.denominator for row in coord+residue for x in row))
    Q=[[int(x*q)for x in r]for r in zip(*coord)]
    R=[[int(x*q)for x in r]for r in zip(*residue) if any(r)]
    ss=[F(1,n)for j,u,n in pivots]
    p=lcm(*(s.denominator for s in ss));weights=[int(s*p)for s in ss];den=q*q*p
    kinds=[k for k in range(len(U)) if k not in [0,3]];words=[]
    for k in kinds:
        pools=[sorted({-sg*z[-1]for sg,z in key(a,k)}) for a in [0]*4+[3]*4]
        for v in product(*pools):
            if any(scalar(row,v) for row in R):continue
            c=[scalar(row,v) for row in Q]
            rem=-H[U[k][0]][-1]*den-sum(t*x*x for t,x in zip(weights,c))
            if rem>=0:words.append((k,v,c,rem))
    return kinds,words,weights,den

def replay(mask,kernel):
    tag='kernel' if kernel else 'exterior';d=json.loads((HERE/f'{tag}_{mask}.json').read_text())
    K=matrix(mask);kinds,W,weights,den=enumerate_words(K)
    active=set(range(len(W)))
    for stage in d:
        checked=set()
        for i,y in stage:
            assert i in active and i not in checked;checked.add(i)
            k,v,c,n=W[i];types=[0]*4+[3]*4+[k]
            G=[r+[z]for r,z in zip(K,v)]+[list(v)+[-H[U[k][0]][-1]]]
            t=[49]+[U[a][2]-int(k==a) for a in kinds]
            for a in range(9):
                for b in range(a,9):t.append(384*G[a][b]-scalar(G[a],G[b]))
            if kernel:
                for a in range(9):
                    for b in range(5):t.append(-sum(G[a][h]*L[vv][b] for h,vv in enumerate(types)))
            if y:assert len(t)==len(y) and all(type(w)==int for w in y) and scalar(t,y)<0
            for j in active:
                k2,v2,c2,n2=W[j]
                if k==k2 and U[k][2]==1:continue
                m=sum(a*b*w for a,b,w in zip(c,c2,weights))
                for h in {-sg*q[-1]for sg,q in key(k,k2)}:
                    if (den*h-m)**2>n*n2:continue
                    x=v2+(h,)
                    col=[1]+[int(rr==k2) for rr in kinds]+[x[a]*x[b]for a in range(9)for b in range(a,9)]
                    if kernel:col.extend(a*b for a in x for b in L[k2])
                    assert y and scalar(col,y)>=0
        active-=checked
    return len(W),len(active),[k for k in kinds if all(W[j][0]!=k for j in active)]
if __name__=='__main__':
    out=[]
    for c in json.loads((HERE/'cross4.json').read_text())['cases']:
        m=c['mask'];n,a,miss=replay(m,False)
        b=a
        if not miss:_,b,miss=replay(m,True)
        out.append(dict(mask=m,labelled=c['orbit_size'],initial=n,frame=a,kernel=b,missing_types=miss))
    print(sum(not a['missing_types'] for a in out),sum(a['labelled']for a in out if not a['missing_types']))
    (HERE/'exterior_summary.json').write_text(json.dumps(out,indent=1))

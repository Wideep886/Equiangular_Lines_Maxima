from probe import *
from second import maxc,bits
from lattice import lat

def main():
    r=json.loads((HERE/'result.json').read_text())
    D={(i,j,q) for (i,j),ps in PAIRS.items() for q in ps}
    for rr in r['rounds']:
        for i,j,q,_ in rr:D.remove((i,j,tuple(q)))
    graph=[0]*N
    for i,j,p in D:
        if i!=j:graph[i]|=1<<j;graph[j]|=1<<i
    full=(1<<N)-1
    loops={i for i,j,p in D if i==j}
    b=(58,*T[3:])
    proofs=[];decks=[]
    for mask in maxc(graph,full):
        types=list(bits(mask));caps=[i for i in types if i not in loops]
        cols=[(1,*H[i][3:],*(int(i==j) for j in caps)) for i in types]
        cols.extend((*(0 for _ in b),*(int(i==j) for j in caps)) for i in caps)
        target=(*b,*(1 for i in caps))
        proof={'kind':'lattice'} if not lat(cols,target) else phase_one(cols,target)
        proofs.append((types,caps,proof))
        if proof['kind']=='primal':decks.append((types,caps,proof))
    print('surviving edges',len(D),'clique count',len(proofs),'feasible',len(decks),decks[:3],flush=True)
    (HERE/'global.json').write_text(json.dumps(proofs,separators=(',',':'))+'\n')
if __name__=='__main__':main()

"""Aggregate the exterior vectors' exact frame and simple-eigenvector moments."""
from cross4 import *
from probe import modular
from itertools import combinations_with_replacement
from concurrent.futures import ProcessPoolExecutor
def stabilizer(M):
    perms=list(permutations(range(4)))
    return [p+tuple(j+4 for j in q)for p in perms for q in perms
            if all(M[i][j+4]==M[p[i]][q[j]+4] for i,j in product(range(4),repeat=2))]
def orb(groups,indices):
    X=set(indices);out=[]
    while X:
        u=min(X);q={tuple(sorted(p[i] for i in u))for p in groups}
        X-=q;out.append(sorted(q))
    return out
def unit(case):
    mask=case['mask'];K=matrix(mask);B=schur(K);G0=inverse([[K[i][j]for j in B]for i in B])
    d=lcm(*(x.denominator for r in G0 for x in r));Q=[[int(d*x)for x in r]for r in G0]
    stabil=stabilizer(K);single=orb(stabil,[(i,)for i in range(8)])
    double=orb(stabil,combinations_with_replacement(range(8),2))
    anchors=[0]*4+[3]*4
    S=[[0 if i==j else next(s for s,p in key(anchors[i],anchors[j]) if -s*p[-1]==K[i][j]) for j in range(8)]for i in range(8)]
    exterior=[u for u in range(len(U)) if u not in (0,3)]
    rhs=tuple(U[k][2]for k in exterior)
    rhs+=tuple(sum(384*K[i][j]-dot(K[i],K[j]) for i,j in pairs)for pairs in double)
    for typ in ('kernel','adj'):
        for component in range(5):
            rhs+=tuple(sum(((0 if typ=='kernel' else E[anchors[i]][component])-sum(a*L[u][component] for a,u in zip((K if typ=='kernel' else S)[i],anchors))) for (i,) in o)for o in single)
    cols=set()
    for k in exterior:
        i,_,n=U[k];mx=-H[i][-1]
        options=[sorted({(-s*p[-1],s)for s,p in key(u,k)})for u in anchors]
        for word in product(*options):
            x,s=zip(*word);y=[x[j]for j in B];c=[dot(row,y)for row in Q]
            if dot(c,y)>d*mx or any(sum(K[i][j]*a for j,a in zip(B,c))!=d*x[i] for i in range(8) if i not in B):continue
            col=tuple(int(k==v)for v in exterior)+tuple(sum(x[i]*x[j] for i,j in o)for o in double)
            xs=[sum(x[i]for i, in o)for o in single];ss=[sum(s[i]for i, in o)for o in single]
            col+=tuple(a*b for vs in (xs,ss) for a in L[k] for b in vs)
            cols.add(col)
    cols=sorted(cols)
    for p in (2,3,5,7,101):
        if not modular(cols,rhs,p):return mask,len(cols),{'kind':'modular','p':p}
    # Each retained equality is necessary. Large row systems are screened using
    # a subset of 32 independent coordinates for a short, reproducible pass.
    basis={};eqs=[]
    for j,c in enumerate(zip(*cols)):
        v=[x%1009 for x in c]
        for i,r in sorted(basis.items()):
            if v[i]:
                w=v[i];v=[(x-w*y)%1009 for x,y in zip(v,r)]
        i=next((i for i,x in enumerate(v) if x),None)
        if i is not None:
            inv=pow(v[i],-1,1009);basis[i]=[inv*x%1009 for x in v];eqs.append(j)
        if len(eqs)==32:break
    reduced=sorted({tuple(c[j]for j in eqs)for c in cols})
    T=tuple(rhs[j]for j in eqs)
    if not lat(reduced,T):return mask,len(cols),{'kind':'lattice','eqs':eqs}
    cert=phase_one(reduced,T);cert['eqs']=eqs
    return mask,len(cols),cert
if __name__=='__main__':
    cases=json.loads((HERE/'cross4.json').read_text())['cases']
    dest=HERE/'cross_frame.jsonl'
    seen={json.loads(l)[0] for l in dest.read_text().splitlines()} if dest.exists() else set()
    from concurrent.futures import as_completed
    with ProcessPoolExecutor(4) as ex,dest.open('a',buffering=1) as f:
        for fut in as_completed([ex.submit(unit,c)for c in cases if c['mask']not in seen]):
            r=fut.result();print(json.dumps(r,separators=(',',':')),file=f)
            print(r[0],r[1],r[2]['kind'],flush=True)

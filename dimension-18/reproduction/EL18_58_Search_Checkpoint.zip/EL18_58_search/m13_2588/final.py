"""Exact two-anchor row feasibility for the unique surviving global count vector."""
from probe import *
from lattice import lat
from third55 import valid55
import probe
def unit(job):
    i,j,p,A,U,C=job
    probe.EXTRA=valid55
    old,b=matrix(i,j,p,A);counts=dict(zip(U,C))
    ctx=tuple(counts[k]-(i==k)-(j==k) for k in U)
    lookup={(1,*H[k][3:]):k for k in U}
    rows=sorted({(*(int(k==lookup[row[:5]])for k in U),*row[5:]) for row in old if ctx[U.index(lookup[row[:5]])]>0})
    target=(*ctx,*b[5:])
    if not rows:proof={'kind':'empty'}
    elif not lat(rows,target):proof={'kind':'lattice'}
    else:proof=phase_one(rows,target)
    return (i,j,p,proof if proof['kind']!='primal' else None)
def main():
    d=json.loads((HERE/'decks.json').read_text());U=d['types'];C,=d['kept'];r=json.loads((HERE/'result.json').read_text())
    A={(i,j,q)for (i,j),ps in PAIRS.items() for q in ps if i in U and j in U}
    for rr in r['rounds']:
        for i,j,q,_ in rr:A.discard((i,j,tuple(q)))
    logs=[];stop=False
    while A and not stop:
        bad=[]
        with ProcessPoolExecutor(4) as ex:
            for i,j,p,c in ex.map(unit,[(i,j,p,A,U,C)for i,j,p in sorted(A)],chunksize=2):
                if c:bad.append((i,j,p,c))
        if not bad:break
        logs.append(bad)
        for i,j,p,c in bad:A.remove((i,j,p))
        missing=[(i,j)for i in U for j in U if i<=j and (i!=j or C[U.index(i)]>=2) and not any(l==i and m==j for l,m,q in A)]
        print('removed',len(bad),'remain',len(A),'missing',missing,flush=True)
        stop=bool(missing)
    (HERE/'final.json').write_text(json.dumps(dict(rounds=logs,remaining=sorted(A),missing=missing if logs else []),separators=(',',':'))+'\n')
if __name__=='__main__':main()

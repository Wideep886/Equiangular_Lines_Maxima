# 九個錨點的共同投影矩

這是 2588 的中間層證書，輸入是 cross4.json 的 25 個八點核心代表。寫整 Gram 為 B=384P₀，P₀ 為 Y=(S−11I)/2 在特徵值 0 的正交投影。給定一個八點核心 K 和第九點對它的內積列 x，指定九點主塊 M。令其餘 49 點在 M 上的內積列為 w，則

    Σ wwᵀ = 384M−M²。
    Σ w L_extᵀ = −M L_anchor。

第二式源於 BL=0，L 的五欄是另五個譜分量的實現或係數欄，見 oriented_frames.py。每個外點的有向類別總數已知。對任一可能的第十點，記其對原八點的列為 v，第九、第十點的原內積是 z。設 K_I 為滿秩獨立主塊，K_I⁻¹=Q/d，p=Qx_I、r=Qv_I。兩點法空間殘餘的半正定性要求

    (dz−v_Iᵀp)² ≤ (dB₉₉−x_Iᵀp)(dB₁₀,₁₀−v_Iᵀr)。

以上每個可行值貢獻一欄。不能以同一組非負係數滿足全部等式時，記錄整數證書 y；對每一欄 c 有 y·c≥0，對右側 t 有 y·t<0。去掉已分離的第九點列，重作直到不再刪點。唯一空型即可否定指定遮罩。未分離的列容許在不同點重用。

1. 生成時由 exterior_simplex.cpp 尋找浮點分離方向，cross_pair_anchor.py 將方向改為整向量、以常數欄校正，再對每一欄檢查。於此目錄可執行 c++ -O3 -std=c++17 exterior_simplex.cpp -o /tmp/el18extsimplex，然後 EL18_SIMPLEX=/tmp/el18extsimplex python3 -B cross_pair_anchor.py 51。完整代表清單在 cross4.json。已有證書時直接重播。
2. python3 -B replay_exterior.py 使用標準函式庫，以相反順序做有理正交消元，獨立列舉單點與雙點。每一筆外點刪除均由整數點積核對。結果寫入 exterior_summary.json。有向單列清單在 exterior_live_*.json。證書 exterior_*.json 和 kernel_*.json 是依各輪開始時的支援集合記錄。
3. 此中間層將 25 代表（3,582 個標號遮罩）降至 15 代表（2,058 個標號遮罩）。排除的是 51、53、291、358、362、854、4458、4660、4668、5804。剩餘遮罩僅表示通過本層，完整專案另有後續補全。

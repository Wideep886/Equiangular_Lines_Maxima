"""Nine-point covariance cuts on each of the 25 eight-point masks in case 2588."""
from cross4 import *
from itertools import combinations_with_replacement
import subprocess,os
oracle=None
def separate(cols,target):
    global oracle
    if not cols:return []
    if oracle is None:
        oracle=subprocess.Popen([os.environ['EL18_SIMPLEX']],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    oracle.stdin.write(f'{len(target)} {len(cols)}\n'+' '.join(map(str,target))+'\n'+'\n'.join(' '.join(map(str,c)) for c in cols)+'\n');oracle.stdin.flush()
    out=oracle.stdout.readline().split()
    if not out or out==['?']:return None
    values=list(map(float,out))
    if sum(x*y for x,y in zip(values,target))>=-1e-7:return None
    for scale in (10**12,10**18):
        y=[int(round(v*scale)) for v in values];y[0]-=min(dot(c,y) for c in cols)
        if dot(target,y)<0 and all(dot(y,c)>=0 for c in cols):return y
    return None
def prepare(mask):
    K=matrix(mask);B=schur(K);G=inverse([[K[i][j] for j in B]for i in B])
    D=lcm(*(x.denominator for r in G for x in r));Q=[[int(D*x)for x in r]for r in G]
    kinds=[k for k in range(len(U)) if k not in (0,3)];out=[]
    for k in kinds:
        h=-H[U[k][0]][-1]
        for x in product(*[sorted({-s*q[-1]for s,q in key(t,k)}) for t in [0]*4+[3]*4]):
            v=[x[i] for i in B];p=[dot(r,v) for r in Q];h0=h*D-dot(v,p)
            if h0<0 or any(sum(K[i][j]*z for j,z in zip(B,p))!=D*x[i] for i in range(8)):continue
            out.append((k,x,h,p,h0))
    return K,B,D,kinds,out
def run(mask,kernel=False):
    K,B,D,kinds,opts=prepare(mask)
    assert len(opts)==sum(next(r['counts'] for r in json.loads((HERE/'cross4.json').read_text())['cases'] if r['mask']==mask).values())
    active=set(range(len(opts)));path=HERE/f'{"kernel" if kernel else "exterior"}_{mask}.json'
    replay=path.exists();ledger=json.loads(path.read_text()) if replay else [];step=0
    while active:
        bad=[]
        for i in sorted(active):
            if replay:
                hit=next((e for e in (ledger[step] if step<len(ledger) else []) if e[0]==i),None)
                if not hit:continue
            k,x,h,p,h0=opts[i];M=[r+[v]for r,v in zip(K,x)]+[list(x)+[h]]
            ij=list(combinations_with_replacement(range(9),2))
            t=[49]+[U[j][2]-int(j==k) for j in kinds]+[384*M[a][b]-dot(M[a],M[b]) for a,b in ij]
            if kernel:t.extend(-sum(M[a][j]*L[tj][b] for j,tj in enumerate([0]*4+[3]*4+[k])) for a in range(9) for b in range(5))
            cols=set()
            for j in active:
                l,v,g,q,g0=opts[j]
                if k==l and U[k][2]==1:continue
                inner=dot(p,[v[u]for u in B])
                for z in {-s*w[-1] for s,w in key(l,k)}:
                    if (D*z-inner)**2>h0*g0:continue
                    w=v+(z,);col=(1,)+tuple(int(j==l) for j in kinds)+tuple(w[a]*w[b] for a,b in ij)
                    if kernel:col+=tuple(u*v for u in w for v in L[l])
                    cols.add(col)
            cols=sorted(cols)
            if replay:
                y=hit[1];assert (not cols and not y) or (len(y)==len(t) and dot(y,t)<0 and all(dot(y,c)>=0 for c in cols))
            else:y=separate(cols,t)
            if y is not None:bad.append([i,y])
        if not bad:break
        if replay:assert bad==ledger[step]
        else:ledger.append(bad)
        active-=set(i for i,_ in bad);step+=1
    if replay:assert step==len(ledger)
    else:path.write_text(json.dumps(ledger,separators=(',',':')))
    miss=[k for k in kinds if not any(opts[i][0]==k for i in active)]
    if kernel:(HERE/f'exterior_live_{mask}.json').write_text(json.dumps([[opts[i][0],opts[i][1]]for i in sorted(active)],separators=(',',':')))
    print(mask,'kernel' if kernel else 'frame',len(opts),len(active),miss,flush=True)
    return len(opts),len(active),miss
if __name__=='__main__':
    for m in map(int,sys.argv[1:]):
        _,_,miss=run(m)
        if not miss:run(m,True)

"""Enumerate global one-deletion multiplicities and impose third-point marginals."""
from probe import *
from itertools import combinations
from fractions import Fraction as F
from math import prod,lcm
def invert(M):
    n=len(M);a=[[F(x)for x in r]+[F(i==j)for j in range(n)]for i,r in enumerate(M)]
    for i in range(n):
        k=next((k for k in range(i,n) if a[k][i]),None)
        if k is None:return
        a[k],a[i]=a[i],a[k];f=a[i][i];a[i]=[v/f for v in a[i]]
        for k,r in enumerate(a):
            if k!=i and r[i]:a[k]=[u-r[i]*v for u,v in zip(r,a[i])]
    return [r[n:] for r in a]
def counts(U):
    C=[(1,*H[i][3:])for i in U];B=(58,*T[3:]);n=len(U)
    maxs=[]
    for c in C:
        lo,hi=0,59
        while hi-lo>1:
            mid=(hi+lo)//2
            if phase_one(C,tuple(v-mid*w for v,w in zip(B,c)))['kind']=='primal':lo=mid
            else:hi=mid
        maxs.append(lo)
    for free in sorted(combinations(range(n),n-len(B)),key=lambda s:prod(maxs[i]+1 for i in s)):
        piv=[i for i in range(n) if i not in free]
        inv=invert(list(zip(*(C[i]for i in piv))))
        if inv:break
    den=lcm(*(v.denominator for row in inv for v in row));inv=[[int(x*den)for x in row]for row in inv]
    rhs=[dot(row,B)for row in inv]
    terms=[[dot(row,C[i])for row in inv]for i in free]
    out=[];sol=[0]*n
    def visit(k,b):
        if k==len(free):
            if all(v>=0 and v%den==0 for v in b):
                for i,x in zip(piv,b):sol[i]=x//den
                assert all(dot(sol,row)==v for row,v in zip(zip(*C),B))
                out.append(tuple(sol))
            return
        i=free[k];d=terms[k]
        for j in range(maxs[i]+1):
            sol[i]=j;visit(k+1,b);b=[a-x for a,x in zip(b,d)]
    visit(0,rhs)
    return out
def congruences(cols,rhs,X,prime):
    B={}
    def rd(v):
        v=[x%prime for x in v]
        for i,b in sorted(B.items()):
            if v[i]:
                a=v[i];v=[(x-a*y)%prime for x,y in zip(v,b)]
        return v
    for c in cols:
        v=rd(c);i=next((i for i,x in enumerate(v) if x),None)
        if i!=None:
            inv=pow(v[i],-1,prime);B[i]=[x*inv%prime for x in v]
    rows=list(zip(rd(rhs),*(rd(v) for v in X)))
    return [(prime,tuple(r))for r in rows if any(r)]
def constraints(U,i,j,p,A):
    # First part of the stored third-point column identifies the type uniquely.
    old,rhs=matrix(i,j,p,A);lookup={(1,*H[k][3:]):k for k in U};d=len(rhs)
    by={k:[]for k in U}
    for col in old:by[lookup[col[:5]]].append(col)
    X=[];B=[]
    for k in U:
        c=tuple(int(k==t) for t in U)
        X.append((*(0 for _ in rhs),*c))
        for v in by[k]:B.append((*v,*c))
    base=(*rhs,*(0 for _ in U));masks=[k for k in U if not by[k]]
    mods=set()
    for prime in (2,3,5,7,101):
        mods.update(congruences(B,base,X,prime))
    bounds=[]
    for l in range(5,d):
        s=[min([q[l]for q in by[k]],default=0) for k in U];t=[max([q[l]for q in by[k]],default=0)for k in U]
        bounds.append((rhs[l],s,t))
    return masks, sorted(mods),bounds
def main():
    r=json.loads((HERE/'result.json').read_text());A={(i,j,p) for (i,j),ps in PAIRS.items() for p in ps}
    for z in r['rounds']:
        for i,j,p,_ in z:A.remove((i,j,tuple(p)))
    U=next(a for a,c,p in json.loads((HERE/'global.json').read_text()) if p['kind']=='primal');C=counts(U)
    print('unfiltered decks',len(C),flush=True);orig=len(C)
    pairs={}
    for i,j,p in sorted(A):
        masks,mods,bounds=constraints(U,i,j,p,A)
        pairs.setdefault((i,j),[]).append((set(masks),mods,bounds))
    counts_by_pair=[]
    for (i,j),tests in sorted(pairs.items(),key=lambda item:len(item[1])):
        kept=[]
        for c in C:
            n=[v-(k==i)-(k==j) for k,v in zip(U,c)]
            if min(n)<0:kept.append(c);continue
            for masks,mods,bounds in tests:
                if any(v and k in masks for k,v in zip(U,n)):continue
                if any((a[0]+dot(a[1:],n))%p for p,a in mods):continue
                if any(not dot(s,n)<=v<=dot(t,n) for v,s,t in bounds):continue
                kept.append(c);break
        C=kept;counts_by_pair.append((i,j,len(C)))
    output=dict(types=U,ids=[IDS[k]for k in U],initial=orig,stages=counts_by_pair,kept=C)
    (HERE/'decks.json').write_text(json.dumps(output,separators=(',',':'))+'\n')
    print('after third point marginals',len(C),'first',C[:3])
if __name__=='__main__':main()

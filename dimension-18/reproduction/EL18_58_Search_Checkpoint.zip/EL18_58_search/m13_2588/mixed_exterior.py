from itertools import combinations
"""Joint equations from B²=384B, SB=11B, BL=0 and SL=E for nine fixed vertices."""
from cross_pair_anchor import prepare,separate
from cross_frame import *
from functools import lru_cache
def run(mask,square=False):
    K,basis,D,kinds,W=prepare(mask)
    words={tuple([k,*x]) for k,x in json.loads((HERE/f'exterior_live_{mask}.json').read_text())}
    live={i for i,(k,x,h,p,r) in enumerate(W) if tuple([k,*x]) in words}
    initial=len(live)
    ztypes=[0]*4+[3]*4
    @lru_cache(None)
    def allowed_s(a,b,w):return sorted({s for s,q in key(a,b) if -s*q[-1]==w})
    stab=stabilizer(K)
    internal=[[0 if i==j else allowed_s(ztypes[i],ztypes[j],K[i][j])[0] for j in range(8)] for i in range(8)]
    assert all(i==j or len(allowed_s(ztypes[i],ztypes[j],K[i][j]))==1 for i in range(8) for j in range(8))
    dic={(k,x):i for i,(k,x,*_) in enumerate(W)}
    signs={}
    for i in live:
        k,x,*_=W[i];a=[allowed_s(t,k,u) for t,u in zip(ztypes,x)]
        assert all(len(l)==1 for l in a);signs[i]=tuple(l[0] for l in a)
    tag='square' if square else 'mixed'
    proof=HERE/f'{tag}_{mask}.json'
    replay=proof.exists();ledger=json.loads(proof.read_text()) if replay else [];step=0
    while live:
        rest=set(live);bad=set();cuts=[]
        while rest:
            i=min(rest);k,x,h,p,R=W[i]
            orbit={dic[k,tuple(x[b] for b in perm)] for perm in stab}
            assert orbit<=rest
            rest-=orbit
            if replay:
                hit=next((e for e in (ledger[step] if step<len(ledger) else []) if e[0]==i),None)
                if hit is None:continue
            group=[perm+(8,) for perm in stab if all(x[j]==x[b]for j,b in enumerate(perm))]
            def orbs(indices,ordered):
                allset=set(indices);lst=[]
                while allset:
                    t=min(allset)
                    ps={tuple(g[j]for j in t) for g in group}
                    if not ordered:ps={tuple(sorted(p))for p in ps}
                    allset-=ps;lst.append(sorted(ps))
                return lst
            ss=orbs([(a,)for a in range(9)],True)
            mm=orbs(list(combinations_with_replacement(range(9),2)),False)
            sm=orbs(list(product(range(9),repeat=2)),True)
            Z=[r+[a] for r,a in zip(K,x)]+[list(x)+[h]]
            S=[r+[a] for r,a in zip(internal,signs[i])]+[list(signs[i])+[0]]
            T=ztypes+[k]
            if square:
                # W=2g(t)(tI-Y)^(-1). The second off-diagonal coefficient determines S².
                S2=[[57]*9 for _ in T]
                for a,b in combinations(range(9),2):
                    values={s*(2*q[1]+22-2*G[1]) for s,q in key(T[a],T[b]) if s==S[a][b] and -s*q[-1]==Z[a][b]}
                    assert len(values)==1
                    S2[a][b]=S2[b][a]=next(iter(values))
            tar=[49]+[U[q][2]-int(k==q) for q in kinds]
            tar.extend(sum(384*Z[a][b]-dot(Z[a],Z[b]) for a,b in o)for o in mm)
            tar.extend(sum(11*Z[a][b]-dot(S[a],Z[b]) for a,b in o)for o in sm)
            if square:tar.extend(sum(S2[a][b]-dot(S[a],S[b])for a,b in o)for o in mm)
            for M in (Z,S):
                for o in ss:
                    for v in range(5):tar.append(sum((E[T[a]][v] if M is S else 0)-sum(w*L[u][v] for u,w in zip(T,M[a])) for a, in o))
            cols=set()
            for j in live:
                b,v,g,_,R2=W[j]
                if b==k and U[k][2]==1:continue
                proj=dot(p,[v[t]for t in basis])
                for s,q in key(k,b):
                    h1=-s*q[-1]
                    if (D*h1-proj)**2>R*R2:continue
                    y=v+(h1,);zs=signs[j]+(s,)
                    c=[1]+[int(t==b)for t in kinds]
                    c.extend(sum(y[a]*y[t]for a,t in o)for o in mm)
                    c.extend(sum(zs[a]*y[t]for a,t in o)for o in sm)
                    if square:c.extend(sum(zs[a]*zs[t]for a,t in o)for o in mm)
                    for a0 in (y,zs):
                        for o in ss:
                            z=sum(a0[a]for a, in o);c.extend(z*u for u in L[b])
                    cols.add(tuple(c))
            cols=sorted(cols)
            if replay:
                y=hit[1];assert (not y and not cols) or (len(y)==len(tar) and dot(tar,y)<0 and all(dot(c,y)>=0 for c in cols))
            else:y=separate(cols,tar)
            if y is not None:cuts.append([i,y]);bad|=orbit
        if not bad:break
        if replay:assert ledger[step]==cuts
        else:ledger.append(cuts)
        step+=1;live-=bad
    if replay:assert step==len(ledger)
    else:proof.write_text(json.dumps(ledger,separators=(',',':')))
    print(mask,initial,len(live),[a for a in kinds if all(W[i][0]!=a for i in live)],flush=True)
    (HERE/f'{tag}_live_{mask}.json').write_text(json.dumps([[W[i][0],W[i][1]]for i in sorted(live)],separators=(',',':')))
if __name__=='__main__':
    from itertools import combinations
    for m in map(int,sys.argv[1:]):run(m,square=True)

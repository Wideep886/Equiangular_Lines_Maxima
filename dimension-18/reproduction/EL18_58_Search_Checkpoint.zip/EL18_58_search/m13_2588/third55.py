from probe import *
import probe
from check import fails_at,shift
from math import comb
F=mul([1,-2],QUARTIC)
DEN=mul(F,F)
COMMON=[1]
for _ in range(37):COMMON=mul(COMMON,[1,8])
COMMON=mul(COMMON,[1]+[0]*10)
COMMON=[v%4 for v in shift(COMMON,-6)]
@lru_cache(None)
def t3(a,b,c):
    return tuple(mul(mul(a,b),c))
def triple(a,b,c):return t3(*sorted((a,b,c)))
@lru_cache(None)
def permitted_mod(coeff):
    L=[v%4 for v in shift(coeff,-6)]
    c=[v%4 for v in mul(COMMON,L)]
    return c[:3]==[2,1,0] and not fails_at(c)
@lru_cache(None)
def parity55(diag_and_labels,e):
    (a,s),(b,r),(c,p)=diag_and_labels
    # det(W[{i,j,k}]), pairing each omitted diagonal with the opposite pair.
    HHH=triple(a,b,c);Q=triple(p,r,s)
    terms=(HHH,(0,0,0)+tuple(2*e*x for x in Q))
    neg=((0,0)+triple(a,s,s),(0,0)+triple(b,r,r),(0,0)+triple(c,p,p))
    D=[sum(u)-sum(v) for u,v in zip(zip(*terms),zip(*neg))]
    for i in range(len(D)-len(DEN)+1):
        w=D[i]
        for j in range(1,len(DEN)):D[i+j]-=w*DEN[j]
    assert not any(D[-(len(DEN)-1):]),'rank-one triple product mismatch'
    q=D[:-(len(DEN)-1)]
    if any(v%4 for v in q):return False
    return permitted_mod(tuple((v//4)%4 for v in q))
def valid55(i,j,k,p,r,s,e):
    return parity55(tuple(sorted(((H[i],s),(H[j],r),(H[k],p)))),e)
def main():
    probe.EXTRA=valid55
    g=json.loads((HERE/'global.json').read_text())
    feasible=[set(a) for a,cap,pf in g if pf['kind']=='primal']
    assert len(feasible)==1; keep=feasible[0]
    old=json.loads((HERE/'result.json').read_text())
    A={(i,j,q) for (i,j),ps in PAIRS.items() for q in ps if i in keep and j in keep}
    for rr in old['rounds']:
        for i,j,q,_ in rr:A.discard((i,j,tuple(q)))
    logs=[];out=HERE/'third.json'
    while A:
        bad=[]
        with ProcessPoolExecutor(4,initializer=init) as ex:
            for i,j,q,c in ex.map(work,[(i,j,p,A) for i,j,p in sorted(A)],chunksize=3):
                if c is not None:bad.append([i,j,q,c])
        print('set size',len(A),'removed',len(bad),flush=True)
        if not bad:break
        logs.append(bad)
        for i,j,q,_ in bad:A.remove((i,j,q))
        out.write_text(json.dumps(dict(types=sorted(keep),rounds=logs,remaining=len(A)),separators=(',',':'))+'\n')
def init():probe.EXTRA=valid55
if __name__=='__main__':main()

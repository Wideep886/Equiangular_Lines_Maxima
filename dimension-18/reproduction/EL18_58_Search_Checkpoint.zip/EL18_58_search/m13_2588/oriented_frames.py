"""Jointly orient the quartic eigenspaces and the rational simple eigenspace."""
from probe import *
from math import isqrt
from lattice import lat
from third55 import valid55
D=json.loads((HERE/'decks.json').read_text());counts=dict(zip(D['types'],D['kept'][0]))
ret=[(i,j,tuple(p)) for i,j,p in json.loads((HERE/'final.json').read_text())['remaining']]
both=[i for i in counts if any(R[i]) and ev(H[i],2)]
def classes():
    allowed=[]
    for ss in product(*(range(-counts[i],counts[i]+1,2) for i in both)):
        if all(sum(v*isqrt(-ev(H[i],2))*R[i][k] for v,i in zip(ss,both))==0 for k in range(4)):
            allowed.append(ss)
    # For #1313 the two quartic-oriented vertices have opposite signs in
    # the simple rational eigenspace, by their unique surviving pair.
    ii=IDS.index(1313);pp=[p for i,j,p in ret if i==ii and j==ii]
    assert len(pp)==1 and tags(ii,ii,pp[0])==(1,1) and counts[ii]==2
    allowed=[s for s in allowed if s[both.index(ii)]==0]
    assert allowed==[(0,)*len(both)]
    return [(i,s,counts[i]//2 if i in both else counts[i]) for i in counts for s in ((-1,1) if i in both else ((1,)if ev(H[i],2) else (0,)))]
U=classes()
L=[(*R[i],s*isqrt(-ev(H[i],2))) for i,s,n in U]
E=[(*pro((2,11),R[i]),15*s*isqrt(-ev(H[i],2))) for i,s,n in U]
def keys(A,i,j):
    if i>j:i,j=j,i
    return A.get((i,j),[])
def first():
    opts={}
    for u,(i,a,n) in enumerate(U):
        for v,(j,b,m) in enumerate(U[u:],u):
            if u==v and n<2:continue
            out=[]
            for ii,jj,p in ret:
                if (ii,jj)!=(min(i,j),max(i,j)):continue
                x,y=tags(ii,jj,p)
                for s in (-1,1):
                    if x and s*x!=1:continue
                    if y and s*y!=-a*b:continue
                    out.append((s,p))
            opts[u,v]=out
    return opts
Z=(-2,0,2)
def work(job):
    u,v,sg,p,A=job;i,a,n=U[u];j,b,m=U[v]
    # Use physical orientation on all rows; each pair's polynomial is raised
    # to signed form by multiplying by its Seidel entry.
    NN=tuple(n0-(u==x)-(v==x)for x,(k,t,n0) in enumerate(U))
    T=NN+tuple((2*z+11)*ev(H[l],z)-4*val(G,z)-ev(p,z) for l in (i,j) for z in Z)
    T+=tuple(kernel(H[l],z,z)-ev(H[l],z)**2-ev(p,z)**2 for l in (i,j) for z in Z)
    T+=tuple(kernel(p,z,w)-ev(H[i],z)*ev(p,w)-ev(p,z)*ev(H[j],w) for z in Z for w in Z)
    for a0,b0,h0 in ((u,v,i),(v,u,j)):
        T+=tuple(x-sg*y for x,y in zip(E[a0],L[b0]))
        T+=tuple(-ev(H[h0],0)*x-sg*ev(p,0)*y for x,y in zip(L[a0],L[b0]))
    cols=set()
    for x,(k,t,n0) in enumerate(U):
        if not NN[x]:continue
        for (s,r),(d,h) in product(keys(A,u,x),keys(A,v,x)):
            e=sg*s*d
            okay=True
            for z,ori in [(0,-1),(-8,1)]:
                l0,l1,l2=ev(H[i],z),ev(H[j],z),ev(H[k],z)
                p0,p1,p2=ev(p,z),ev(r,z),ev(h,z)
                if ori*(l0*l1*l2+2*e*p0*p1*p2-l0*p2*p2-l1*p1*p1-l2*p0*p0)<0:okay=False;break
            if not okay or not valid55(i,j,k,p,r,h,e):continue
            col=tuple(int(y==x)for y in range(len(U)))+tuple(ev(q,z)for q in (r,h)for z in Z)
            col+=tuple(ev(q,z)**2 for q in (r,h)for z in Z)
            col+=tuple(e*ev(r,z)*ev(h,w) for z in Z for w in Z)
            for sign,q in ((s,r),(d,h)):
                col+=tuple(sign*t for t in L[x])+tuple(sign*ev(q,0)*t for t in L[x])
            cols.add(col)
    rows=sorted(cols)
    if not rows:c={'kind':'empty'}
    elif any(not modular(rows,T,p0) for p0 in (37,2,3,5,7)):c={'kind':'modular'}
    else:
        z={};basis=[]
        for j0,v0 in enumerate(zip(*rows)):
            v=[x%1009 for x in v0]
            for k,t in sorted(z.items()):
                if v[k]:
                    b0=v[k];v=[(a-b0*b)%1009 for a,b in zip(v,t)]
            k=next((k for k,a in enumerate(v) if a),None)
            if k is not None:
                t=pow(v[k],-1,1009);z[k]=[x*t%1009 for x in v];basis.append(j0)
        reduced=sorted({tuple(col[k] for k in basis) for col in rows})
        target=tuple(T[k]for k in basis)
        c={'kind':'lattice'} if not lat(reduced,target) else phase_one(reduced,target)
        if c['kind']=='farkas':c['basis']=basis
    return u,v,sg,p,None if c['kind']=='primal' else c
def main():
    A={(u,v):[(s,tuple(p))for s,p in opts]for u,v,opts in json.loads((HERE/'ordered.json').read_text())['remaining']};logs=[];missing=[]
    while True:
        bad=[]
        with ProcessPoolExecutor(4) as ex:
            for u,v,s,p,c in ex.map(work,[(u,v,s,p,A)for (u,v),opts in A.items() for s,p in opts],chunksize=2):
                if c:bad.append((u,v,s,p,c))
        if not bad:break
        logs.append(bad)
        for u,v,s,p,c in bad:A[u,v].remove((s,p))
        missing=[k for k,v in A.items() if not v]
        print('removed',len(bad),'missing',missing,flush=True)
        if missing:break
    (HERE/'oriented_frames.json').write_text(json.dumps(dict(classes=U,rounds=logs,remaining=[(u,v,r)for (u,v),r in A.items()],missing=missing),separators=(',',':'))+'\n')
if __name__=='__main__':main()

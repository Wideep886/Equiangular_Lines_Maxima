// A numerical phase-I oracle. Every returned separator must be rechecked in integers.
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>
using namespace std;
int main() {
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int m,n;
    while(cin>>m>>n){
        vector<double> rhs(m),scale(m,1),coef(m);
        for(auto& b:rhs)cin>>b;
        int N=n+m;
        vector<vector<double>> A(m,vector<double>(N+1));
        for(int j=0;j<n;j++)for(int i=0;i<m;i++){
            cin>>A[i][j]; scale[i]=max(scale[i],abs(A[i][j]));
        }
        vector<int> basis(m);
        vector<double> rc(N+1);
        for(int i=0;i<m;i++){
            coef[i]=(rhs[i]>=0?1:-1)/scale[i];
            A[i][N]=rhs[i]*coef[i];
            for(int j=0;j<n;j++){A[i][j]*=coef[i];rc[j]-=A[i][j];}
            A[i][n+i]=1;basis[i]=n+i;
        }
        bool done=false;
        for(int iter=0;iter<1400;iter++){
            int ent=-1;
            for(int j=0;j<N;j++)if(rc[j]<-1e-8 && (ent<0|| (iter<400 && rc[j]<rc[ent])))ent=j;
            if(ent<0){done=true;break;}
            double minratio=1e200;int p=-1;
            for(int i=0;i<m;i++)if(A[i][ent]>1e-8){
                double q=max(0.,A[i][N])/A[i][ent];
                if(q<minratio-1e-9 || (abs(q-minratio)<1e-9 && (p<0||basis[i]<basis[p]))){minratio=q;p=i;}
            }
            if(p<0)break;
            basis[p]=ent;double div=A[p][ent];
            for(int j=0;j<=N;j++)A[p][j]/=div;
            for(int i=0;i<=m;i++){
                if(i==p)continue;
                auto& row=i==m?rc:A[i];
                double k=row[ent];
                if(abs(k)<1e-12){row[ent]=0;continue;}
                for(int j=0;j<=N;j++)row[j]-=k*A[p][j];
                row[ent]=0;
            }
        }
        if(!done)cout<<"?\n";
        else{
            cout<<setprecision(17);
            for(int i=0;i<m;i++)cout<<(rc[n+i]-1)*coef[i]<<" ";
            cout<<"\n";
        }
        cout.flush();
    }
}

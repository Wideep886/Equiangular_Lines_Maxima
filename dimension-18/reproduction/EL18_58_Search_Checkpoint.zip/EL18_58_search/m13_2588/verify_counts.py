"""Independent verification of all one-point global decks in the surviving clique."""
from pathlib import Path
from collections import defaultdict
import json
from probe import IDS,H,T
HERE=Path(__file__).resolve().parent
def partitions(s,d):
    if d==1:
        yield (s,);return
    for a in range(s+1):
        for b in partitions(s-a,d-1):yield (a,*b)
def main():
    D=json.loads((HERE/'decks.json').read_text())
    U=D['types'];A=[H[i][3:] for i in U];target=T[3:]
    assert len(U)==10
    totals=0;matched=set()
    for x in range(11):
        # The unique class with h(2)=-16 occurs x times. Five classes
        # have h(2)=-4 and four have h(2)=0.
        B=40-4*x;Z=58-B-x
        if B<0 or Z<0:continue
        left=defaultdict(list)
        for u in partitions(Z,4):
            v=tuple(sum(z*a[k] for z,a in zip(u,A[:4])) for k in range(4))
            left[v].append(u)
        for u in partitions(B,5):
            v=tuple(z-x*A[4][k]-sum(y*a[k] for y,a in zip(u,A[5:])) for k,z in enumerate(target))
            for l in left.get(v,()):
                totals+=1;matched.add((*l,x,*u))
    assert totals==len(matched)==2130 and set(tuple(u)for u in D['kept'])<=matched
    print('Verified all 2130 distinct global decks by independent composition sums.')
if __name__=='__main__':main()

// Search for a proper 39-coloring. The caller verifies every returned coloring.
#include <algorithm>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>
using namespace std;
int main() {
    int n, colors=39;
    cin>>n;
    vector<vector<int>> adj(n);
    for(int i=0;i<n;++i){
        string row;cin>>row;
        for(int j=0;j<n;++j) if(row[j]=='1') adj[i].push_back(j);
    }
    mt19937 rng(184058);
    vector<int> perm(n);
    iota(perm.begin(),perm.end(),0);
    for(int restart=0;restart<3;++restart){
        shuffle(perm.begin(),perm.end(),rng);
        vector<int> color(n,-1),count(n*colors),tabu(n*colors);
        int conflicts=0;
        for(int v:perm){
            int a=rng()%colors;
            for(int b=0;b<colors;++b)if(count[v*colors+b]<count[v*colors+a])a=b;
            color[v]=a;
            conflicts+=count[v*colors+a];
            for(int w:adj[v])++count[w*colors+a];
        }
        int best=conflicts;
        for(int iter=1;iter<=12000;++iter){
            if(!conflicts){for(int x:color)cout<<x<<' ';cout<<'\n';return 0;}
            int delta=n+1,selected=-1,to=-1,ties=0,bad=0;
            for(int v=0;v<n;++v){
                int a=color[v],loss=count[v*colors+a];
                if(!loss)continue;
                ++bad;
                for(int b=0;b<colors;++b){
                    if(b==a)continue;
                    int diff=count[v*colors+b]-loss;
                    if(diff>delta||(tabu[v*colors+b]>=iter && conflicts+diff>=best))continue;
                    if(diff<delta){delta=diff;ties=0;}
                    if(rng()%++ties==0){selected=v;to=b;}
                }
            }
            if(selected<0)break;
            int old=color[selected];
            for(int w:adj[selected]){--count[w*colors+old];++count[w*colors+to];}
            tabu[selected*colors+old]=iter+bad/2+1+rng()%10;
            color[selected]=to;conflicts+=delta;best=min(best,conflicts);
        }
    }
}

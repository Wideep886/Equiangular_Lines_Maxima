"""Exhaust all single-line extensions and decide 40-clique on specified 18-point Grams."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REF = HERE.parent / "reference_bases"
sys.path.insert(0, str(REF))
sys.path.insert(0, str(HERE.parent))
sys.dont_write_bytecode = True
from verify_seed import basis_inverse
from verify_gram import certify

def run(records):
    results = []
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        for name in ("basis_candidates", "exact_clique"):
            subprocess.run([os.getenv("CXX","c++"), "-O3", "-std=c++17", str(REF/(name+".cpp")), "-o", str(work/name)], check=True)
        for data in records:
            G = data["gram"]
            B, den = basis_inverse(G)
            encoded = str(den)+"\n"+"\n".join(" ".join(map(str,row)) for row in B)
            out = subprocess.check_output([work/"basis_candidates"],input=encoded,text=True)
            masks = sorted(map(int,out.split()))
            signs = [[1]+[1-2*((m>>i)&1) for i in range(17)] for m in masks]
            z = [[sum(a*b for a,b in zip(s,row)) for row in B] for s in signs]
            assert all(sum(a*b for a,b in zip(s,c))==5*den for s,c in zip(signs,z))
            adj = [{j for j,t in enumerate(signs) if abs(sum(a*b for a,b in zip(c,t)))==den} for c in z]
            remaining = set(range(len(signs)))
            # If N(a) is contained in N(b) on the live graph and a,b are nonadjacent,
            # substituting b for a preserves every clique containing a.
            for a in sorted(remaining):
                if any(a!=b and b not in adj[a] and not ((adj[a]-adj[b]) & remaining) for b in remaining):
                    remaining.remove(a)
            V = sorted(remaining)
            graph = work/"graph"
            graph.write_text(f"{len(V)} 40\n"+"\n".join("".join("1" if j in adj[i] else "0" for j in V) for i in V))
            assert len(V)<=256
            out = subprocess.check_output([work/"exact_clique",graph,str(data["budget"])],text=True).split()
            verdict,nodes = map(int,out[1:3])
            row = dict(round=data["round"],pool=len(signs),after_dominance=len(V),verdict=verdict,nodes=nodes)
            if verdict==1:
                clique = [V[int(k)] for k in out[3:]]
                K = [r+[signs[k][i] for k in clique] for i,r in enumerate(G)]
                K.extend(signs[k]+[sum(a*b for a,b in zip(z[k],signs[j]))//den for j in clique] for k in clique)
                row["gram58"] = K
                row["check"] = certify(K)
            results.append(row)
            print(row,flush=True)
            (HERE/"results.json").write_text(json.dumps(results,indent=1)+"\n")

if __name__ == "__main__":
    run(json.loads((HERE/"inputs.json").read_text()))

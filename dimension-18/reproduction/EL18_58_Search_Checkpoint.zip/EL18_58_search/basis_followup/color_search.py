"""Replay a 39-color certificate campaign for all still open rounds after replay.py."""
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
from replay import HERE,REF,basis_inverse

def main():
    cases=json.loads((HERE/'color_inputs.json').read_text())
    results=[]
    with TemporaryDirectory() as folder:
        work=Path(folder)
        for src,exe in [(REF/'basis_candidates.cpp','signs'),(HERE/'color.cpp','color')]:
            subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(src),'-o',str(work/exe)],check=True)
        for case in cases:
            G=case['gram']
            B,den=basis_inverse(G)
            encoded=str(den)+'\n'+'\n'.join(' '.join(map(str,row)) for row in B)
            masks=sorted(map(int,subprocess.check_output([work/'signs'],input=encoded,text=True).split()))
            signs=[[1]+[1-2*((m>>i)&1) for i in range(17)] for m in masks]
            z=[[sum(a*b for a,b in zip(s,row)) for row in B] for s in signs]
            assert all(sum(a*b for a,b in zip(s,c))==5*den for s,c in zip(signs,z))
            adj=[''.join('1' if abs(sum(a*b for a,b in zip(c,t)))==den else '0' for t in signs) for c in z]
            graph=str(len(masks))+'\n'+'\n'.join(adj)+'\n'
            classes=list(map(int,subprocess.check_output([work/'color'],input=graph,text=True).split()))
            if classes:
                assert len(classes)==len(masks) and all(0<=v<39 for v in classes)
                assert all(a!=b or adj[i][j]=='0' for i,a in enumerate(classes) for j,b in enumerate(classes))
            r=dict(round=case['round'],compatible=len(masks),coloring=classes or None)
            print(case['round'],len(masks),len(set(classes)) or 'open',flush=True)
            results.append(r)
            (HERE/'color_results.json').write_text(json.dumps(results)+'\n')
if __name__=='__main__':main()

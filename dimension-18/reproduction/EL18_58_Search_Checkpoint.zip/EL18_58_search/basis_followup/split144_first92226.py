"""Partition all 40-cliques by first vertex for input #144. Emit a checkable restart cursor."""
import json
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
from replay import HERE,REF,basis_inverse

def main():
    G=next(t['gram'] for t in json.loads((HERE/'color_inputs.json').read_text()) if t['round']==144)
    B,den=basis_inverse(G)
    encoded=str(den)+'\n'+'\n'.join(' '.join(map(str,row)) for row in B)
    with TemporaryDirectory() as folder:
        work=Path(folder)
        for name in ('basis_candidates','exact_clique'):
            subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(REF/(name+'.cpp')),'-o',str(work/name)],check=True)
        masks=sorted(map(int,subprocess.check_output([work/'basis_candidates'],input=encoded,text=True).split()))
        signs=[[1]+[1-2*((m>>i)&1) for i in range(17)] for m in masks]
        z=[[sum(a*b for a,b in zip(s,row)) for row in B] for s in signs]
        adj=[{j for j,t in enumerate(signs) if abs(sum(a*b for a,b in zip(c,t)))==den} for c in z]
        first=min(range(len(masks)),key=lambda i:(len(adj[i]),i))
        assert masks[first]==92226
        live=set(adj[first]);counts=[]
        for _ in range(len(live)):
            v=min(live,key=lambda i:(len(adj[i]&live),i))
            live.remove(v)
            neighbors=adj[v]&live
            reduced=set(neighbors)
            for a in sorted(neighbors):
                if any(a!=b and b not in adj[a] and not ((adj[a]-adj[b])&reduced) for b in reduced):
                    reduced.remove(a)
            V=sorted(reduced)
            graph=work/'graph'
            graph.write_text(f'{len(V)} 38\n'+'\n'.join(''.join('1' if j in adj[i] else '0' for j in V) for i in V))
            res=subprocess.check_output([work/'exact_clique',graph,'500000'],text=True).split()
            verdict,n=map(int,res[1:3])
            counts.append(dict(first=masks[v],neighbors=len(neighbors),after_dominance=len(V),status=verdict,nodes=n))
            if verdict==1:
                from verify_gram import certify
                chosen=[first,v]+[V[int(i)] for i in res[3:]]
                K=[r+[signs[k][i] for k in chosen] for i,r in enumerate(G)]
                K.extend(signs[k]+[sum(a*b for a,b in zip(z[k],signs[j]))//den for j in chosen] for k in chosen)
                print(certify(K))
                (HERE/'witness58.json').write_text(json.dumps(K))
                break
        (HERE/'split144_first92226.json').write_text(json.dumps(counts))
        print({v:sum(c['status']==v for c in counts) for v in [-1,0,1]})

if __name__=='__main__':main()

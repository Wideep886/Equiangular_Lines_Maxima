from pair14 import *
from itertools import combinations_with_replacement
pairs=list(combinations_with_replacement(range(4),2))
def moments(v,q):
    diag=[i(0)]*4;total=[i(0)]*7
    for w,(t,l) in zip(v.weights(q),v.info):
        diag=[add(u,times(w,f)) for u,f in zip(diag,l)]
        e=times(w,times(l[0],l[0]))
        for m in range(7):
            total[m]=add(total[m],e);e=times(e,times(t,i(2)))
    a=[contained(x) for x in diag];b=[contained(x) for x in total];assert None not in a+b
    return [b[u+z]-a[u]*a[z] for u,z in pairs]
def hull(columns,t):
    from verify_high import F
    # Drop linearly dependent equations before exact simplex.
    c=[list(z) for z in zip(*columns)];basis={};keep=[]
    for row,(g,tgt) in enumerate(zip(c,t)):
        v=list(map(F,[*g,tgt]))
        for i,h in basis.items():
            f=v[i]
            if f:v=[x-f*y for x,y in zip(v,h)]
        p=next((j for j,x in enumerate(v[:-1]) if x),None)
        if p is None:
            if v[-1]:return False
            continue
        z=v[p];basis[p]=[x/z for x in v];keep.append(row)
    sub=[tuple(a[j] for j in keep) for a in columns]
    target=[t[j] for j in keep]
    return phase_one(sub,target)['kind']=='primal'
def branch(v,target,d,inds):
    active=set(inds);rounds=[]
    while active:
        discard=[]
        for a in sorted(active):
            q=d[a];tar=[x-y for x,y in zip(target,q)]+moments(v,q)
            cols=[]
            for b in sorted(active):
                for s in v.options(q,d[b]):
                    x=tuple(d[b])+tuple(s[u]*s[z] for u,z in pairs)
                    if x not in cols:cols.append(x)
            if not cols or not lat(cols,tar) or not hull(cols,tar):discard.append(a)
        if not discard:break
        active-=set(discard);rounds.append(discard)
    surviving=sorted(active)
    if surviving and (not lat([d[a] for a in surviving],target)or not hull([d[a] for a in surviving],target)):surviving=[]
    return surviving,rounds
def main():
    rs=json.loads((P/'quartic_results.json').read_text());ws=json.loads((P/'quartic_integer_witnesses.json').read_text());ans={};open_=[]
    for k in sorted(map(int,ws)):
        v,target,res=run(k,rs[k]);out=[]
        for d,sets in res:
            for g in sets:
                s,r=branch(v,target,d,g);out.append((s,r))
        alive=[s for s,r in out if s]
        if alive:open_.append(k)
        ans[k]=out
        print(k,'branches',len(out),'remain',len(alive),list(map(len,alive)),flush=True)
        (P/'energy_results.json').write_text(json.dumps(ans,separators=(',',':'))+'\n')
    print('open',open_)
if __name__=='__main__':main()

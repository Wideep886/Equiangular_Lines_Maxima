"""Rebuild the complete m_11=14 two-vertex ledger using exact arithmetic."""
from pathlib import Path
import json
from pair14 import P,run
from energy import branch as unsigned
from signed import branch as signed
from repeat import Repeated
def control():
    # S=J-I of order 58. Its top eigenspace is rank one, H=J, and
    # H(S-11I)^m has all entries 46^m. Exercises both eigenvalue signs
    # and the shared Seidel-sign row identities used on the real inputs.
    from pair14 import Pair,i,divi
    class Example(Pair):
        def __init__(self):
            self.info=[(i(23),[i(58*46**m) for m in range(4)])]
        def weights(self,q):return [divi(i(1),i(58))]
    z=Example();q=(1,)
    assert z.options(q,q)==tuple(tuple(s*46**m for m in range(4)) for s in (-1,1))
    assert signed(z,[58],[q],[0])[0]==[0]
def main():
    control()
    rs=json.loads((P/'quartic_results.json').read_text());ws=json.loads((P/'quartic_integer_witnesses.json').read_text())
    out=[];survivors=[]
    for k in sorted(map(int,ws)):
        v,target,stages=run(k,rs[k])
        records=[]
        for d,cliques in stages:
            for g in cliques:
                u,ur=unsigned(v,target,d,g)
                s,sr=signed(v,target,d,g) if u else ([],[])
                if s and v.repeated:
                    z=Repeated(rs[k]);s,rr=signed(z,target,d,s)
                else:rr=[]
                records.append(dict(deck=d,clique=g,unsigned=u,unsigned_rounds=ur,signed=s,signed_rounds=sr,repeated_rounds=rr))
        status=any(r['signed'] for r in records)
        if status:survivors.append(k)
        out.append(dict(index=k,tail=rs[k]['tail'],status='open' if status else 'excluded',branches=records))
    assert survivors==[169,369]
    assert [r['index'] for r in out if any(b['unsigned'] for b in r['branches'])]==[24,40,100,130,145,169,192,208,238,307,369]
    f=P/'ledger.json'
    if f.exists():assert json.loads(f.read_text())==json.loads(json.dumps(out))
    else:f.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print('27 input spectra; 11 pass unsigned moments; 2 pass Seidel-signed moments:',survivors)
if __name__=='__main__':main()

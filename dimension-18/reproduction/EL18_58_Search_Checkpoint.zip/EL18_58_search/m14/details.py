from pair14 import *
def details(v,q):
    diag=[i(0)]*5;tot=[i(0)]*7
    for w,(t,l) in zip(v.weights(q),v.info):
        e=times(w,l[0])
        for m in range(5):diag[m]=add(diag[m],e);e=times(e,times(t,i(2)))
        e=times(w,times(l[0],l[0]))
        for m in range(7):tot[m]=add(tot[m],e);e=times(e,times(t,i(2)))
    a=[contained(x) for x in diag];b=[contained(x) for x in tot];assert None not in a+b
    return a,b,[a[j+1]+11*a[j] for j in range(4)]

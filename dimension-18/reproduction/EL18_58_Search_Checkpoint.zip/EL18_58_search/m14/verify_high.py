"""Enumerate and screen the complete multiplicity-at-least-15 branch.
Run next to verify_no11.py; no external data or dependencies.
A surviving deck pattern is only a solution to necessary conditions.
"""
import argparse, json
from fractions import Fraction as F
from itertools import product
from math import comb,gcd,isqrt,lcm
from pathlib import Path
from functools import lru_cache,reduce
import sys

from verify_no11 import mul, shift, val, real, ds, div, rem, isol, dN, positive_tests
@lru_cache(None)
def weighted_divisors(m):
    return [(d,sum(gcd(i,m//d)==1 for i in range(1,m//d+1)))
            for d in range(1,m+1) if m%d==0]

def fails_at(c):
    """c[0]=2, c[j]=a_j/2^(j-1) mod 4 for chi_(S+I)."""
    n=len(c)-1
    assert n%2 and c[:3]==[2,-n%4,0]
    # Cor. 3.8 additionally demands c_j even for even j.
    if any(x%2 for x in c[2::2]):
        return -1
    b=[1]
    for m in range(2,n,2):
        b.append((2*c[m+1]+c[m]+2*c[m-1]*c[3])%4)
        b.append((-n*c[m+1])%4)  # n is its own inverse mod 4
    if b[1] or any(x%2 for x in b[1::2]):
        return -2
    # Integer power sums of a representative with these coefficients mod 4.
    # Traces at d are well-defined mod 2^(2+v2(d)) for such lifts.
    p=[0]
    for m in range(1,n):
        p.append(-m*b[m]-sum(b[i]*p[m-i] for i in range(1,m)))
        if m>=4 and m%2==0:
            val=sum(phi*p[d] for d,phi in weighted_divisors(m))
            if val%(2*(m & -m)):
                return m
    return 0

def dot(a,b): return sum(x*y for x,y in zip(a,b))

def phase_one(cols,b):
    dim=len(b);n=len(cols)
    # Use signed unit artificials to build a feasible starting basis.
    signs=[1 if t>=0 else -1 for t in b]
    Z=cols+[tuple(signs[i]*int(i==j) for j in range(dim)) for i in range(dim)]
    inv=[[F(signs[i]*int(i==j)) for j in range(dim)] for i in range(dim)]
    basis=list(range(n,n+dim));seen=set();bland=False
    while True:
        state=tuple(basis)
        if state in seen: bland=True
        seen.add(state)
        val=[dot(r,b) for r in inv]
        assert min(val)>=0
        if all(v==0 for v,k in zip(val,basis) if k>=n):
            cert=[(k,str(v)) for k,v in zip(basis,val) if v]
            assert all(sum(F(v)*Z[k][i] for k,v in cert)==b[i] for i in range(dim))
            return dict(kind='primal',support=cert)
        dual=[-sum(r[j] for r,k in zip(inv,basis) if k>=n) for j in range(dim)]
        den=reduce(lcm,(F(v).denominator for v in dual),1)
        y=[int(v*den) for v in dual]
        if bland:
            ent=next((k for k,col in enumerate(Z) if dot(y,col)+(den if k>=n else 0)<0),None)
        else:
            rc,ent=min((dot(y,col)+(den if k>=n else 0),k) for k,col in enumerate(Z))
            if rc>=0: ent=None
        if ent is None:
            assert dot(y,b)<0 and all(dot(y,col)>=0 for col in cols)
            return dict(kind='farkas',y=y)
        direction=[dot(r,Z[ent]) for r in inv]
        _,_,ind=min((v/d,basis[i],i) for i,(v,d) in enumerate(zip(val,direction)) if d>0)
        pivot=[v/direction[ind] for v in inv[ind]]
        inv=[[a-k*z for a,z in zip(row,pivot)] if i!=ind else pivot for i,(row,k) in enumerate(zip(inv,direction))]
        basis[ind]=ent

def deriv(p):
    return [a*(len(p)-1-i) for i,a in enumerate(p[:-1])]
def parts(p):
    out=[]
    for i,f in enumerate(p):
        q=[1]
        for j,h in enumerate(p):
            if i!=j:q=mul(q,h)
        out.append(q)
    return out

def prunes(c):
    if any(z%2 for z in c[2::2]):return True
    b=[1]
    for m in range(2,len(c)-1,2):
        b.extend([(2*c[m+1]+c[m]+2*c[m-1]*c[3])%4,(-57*c[m+1])%4])
    if len(b)>1 and b[1]:return True
    if any(v%2 for v in b[1::2]):return True
    p=[0]
    for m in range(1,len(b)):
        p.append(-m*b[m]-sum(b[i]*p[m-i] for i in range(1,m)))
        if m>=4 and m%2==0 and sum(w*p[d] for d,w in weighted_divisors(m))%(2*(m & -m)):return True
    return False

def monic_product(fs):
    a=[1]
    for f in fs:a=mul(a,f)
    return a

def allowed_deck(factors):
    polys,mults=zip(*factors)
    g=monic_product(polys);deg=len(g)-2
    common=monic_product([f for f,m in factors for i in range(m-1)])
    terms=[mul(part,deriv(f)) for part,f in zip(parts(polys),polys)]
    target=[2*sum(m*term[i] for m,term in zip(mults,terms)) for i in range(deg+1)]
    coords=[[0]*j+mul(shift(common,-6),shift([1]+[0]*(deg-j),-6)) for j in range(deg+1)]
    @lru_cache(None)
    def admissible(h):
        m=len(h)
        c=[sum(z*col[k] for z,col in zip(h,coords))%4 for k in range(58 if m==deg+1 else m)]
        return not (fails_at(c) if m==deg+1 else prunes(c))
    opts=[[2,2*g[1]-11,2*g[2]-11*g[1]+89]]
    B=2**28
    for k in range(3,deg+1):
        ell=deg-k
        weights=[comb(deg-i,ell) for i in range(k)]
        roots=[(int(l*B),int(h*B)) for l,h in isol(dN(g,ell))]
        assert len(roots)==k+1
        from fractions import Fraction as F
        D=1<<32
        bounds=[]
        for j,(l,h) in enumerate(roots):
            terms=[]
            for pos,w in enumerate(weights):
                exponent=k-pos
                vs=[F(l,B)**exponent,F(h,B)**exponent]
                if l<=0<=h:vs.append(0)
                lower=min(vs)*w*D; upper=max(vs)*w*D
                terms.append((lower//1,-((-upper)//1)))
            bounds.append((bool((j-k)%2),terms))
        nxt=[]
        for q in opts:
            lo=hi=None
            for negative,terms in bounds:
                if negative:
                    low=sum(a*(mins if a>=0 else maxs) for a,(mins,maxs) in zip(q,terms))
                    t=(-low)//D
                    hi=t if hi is None else min(hi,t)
                else:
                    high=sum(a*(maxs if a>=0 else mins) for a,(mins,maxs) in zip(q,terms))
                    t=-(high//D)
                    lo=t if lo is None else max(lo,t)
            qr=tuple(x%4 for x in q)
            for residue in range(4):
                begin=lo+(residue-lo)%4
                if begin<=hi and admissible(qr+(residue,)):
                    nxt.extend(q+[v] for v in range(begin,hi+1,4))
        opts=nxt
    return g,target,[q for q in opts if val(q,-8)!=0]

def sf(v):
    a=1;d=2
    while d*d<=v:
        while v%(d*d)==0:v//=d*d
        d+=1
    return v

def screen(row):
    factors=[([1,8],40)]+row['factors']
    g,target,deck=allowed_deck(factors)
    single=[-f[1] for f,m in factors if m==1 and len(f)==2]
    choices=[]
    for t in single:
        c=2*abs(val(deriv(g),t))
        classes=sorted({sf(abs(val(h,t))) for h in deck if val(h,t)}-{0})
        choices.append([a for a in classes if c%a==0])
    branches=[]
    for pars in product(*choices):
        active=[i for i,h in enumerate(deck) if all(val(h,t)==0 or sf(abs(val(h,t)))==v for t,v in zip(single,pars))]
        cert=phase_one([(1,*deck[i][3:]) for i in active],(58,*target[3:])) if active else {'kind':'empty'}
        if cert['kind']=='primal':cert['support']=[[active[j],coeff] for j,coeff in cert['support']]
        branches.append({'classes':pars,'cert':cert})
    return {'factors':row['factors'],'g':g,'target':target,'deck':deck,'simple_roots':single,'options':choices,'branches':branches}

def reduce_row(r):
    results=[]
    for b in r['branches']:
        if b['cert']['kind']!='primal':continue
        deck=r['deck'];target=(58,*r['target'][3:]); simple=r['simple_roots']
        inds=tuple(i for i,h in enumerate(deck) if all(val(h,t)==0 or sf(abs(val(h,t)))==a for t,a in zip(simple,b['classes'])))
        subsets={frozenset(inds)}
        splits=[]
        for f,m in r['factors']:
            if m!=1 or len(f)<=2:continue
            for p in range(3,260,2):
                if any(p%v==0 for v in range(2,isqrt(p)+1)):continue
                for x in range(p):
                    if val(f,x)%p or val([v*(len(f)-1-j) for j,v in enumerate(f[:-1])],x)%p==0:continue
                    symbol=[pow(val(h,x),(p-1)//2,p) for h in deck]
                    if all(s in (0,1) for s in symbol) or all(s in (0,p-1) for s in symbol):continue
                    left=frozenset(i for i in inds if symbol[i] in (0,1));right=frozenset(i for i in inds if symbol[i] in (0,p-1))
                    new={s&k for s in subsets for k in (left,right)}
                    new={s for s in new if not any(s<t for t in new)}
                    if new!=subsets:splits.append((f,p,x))
                    subsets=new
        leaves=[]
        for ss in sorted(map(sorted,subsets)):
            c=phase_one([(1,*deck[i][3:]) for i in ss],target) if ss else {'kind':'empty'}
            if c['kind']=='primal':c['support']=[(ss[j],v) for j,v in c['support']]
            leaves.append({'types':ss,'cert':c})
        results.append({'classes':b['classes'],'splits':splits,'leaves':leaves})
    return results

def intsol(deck,target):
 mat=[[F(x) for x in col]+[F(t)] for col,t in zip(zip(*deck),target)]; n=len(deck)
 piv=[];k=0
 for j in range(n):
  ix=next((i for i in range(k,len(mat)) if mat[i][j]),None)
  if ix is None:continue
  mat[k],mat[ix]=mat[ix],mat[k]
  d=mat[k][j];mat[k]=[x/d for x in mat[k]]
  for i in range(len(mat)):
   if i!=k:
    d=mat[i][j];mat[i]=[x-d*y for x,y in zip(mat[i],mat[k])]
  piv.append(j);k+=1
 assert not any(any(r) for r in mat[k:])
 free=[i for i in range(n) if i not in piv]
 def traverse(j,remaining,u):
  if j<len(free):
   for v in range(remaining+1):yield from traverse(j+1,remaining-v,u+[v])
   return
  x=[0]*n
  for i,v in zip(free,u):x[i]=v
  for i,a in zip(piv,mat):
   v=a[-1]-sum(a[j]*x[j] for j in free)
   if v<0 or v.denominator>1:return
   x[i]=int(v)
  assert sum(x)==58
  yield x
 yield from traverse(0,58,[])
def tails_fixed(n):
 b0=21
 if n<2:return []
 opts=[[1,-1,-10]]
 for k in range(3,n+1):
  w=[comb(n-j,k-j) for j in range(k+1)]
  b=isqrt(comb(n,k)**2*b0**k//n**k)
  opts=[q+[v] for q in opts for v in range(-b,b+1) if real([x*y for x,y in zip(w,q+[v])])]
 return [p for p in opts if p[-1]]

def cubic_factors(h):
    factors=[]
    for t in range(-4,5):
        f=[1,-t]; m=0
        while len(h)>1 and val(h,t)==0:
            h=div(h,f);m+=1
        if m:factors.append((f,m))
    if len(h)>1:
        factors.append((h,1))
    return factors

def test():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    positive_tests()
    rows=[]
    for z in [16,15]:
        for h in tails_fixed(18-z):
            factors=[([1,0],z)]+cubic_factors(h)
            r=screen({'factors':factors})
            row={'zero_multiplicity':z,'tail':h,'data':r,'squares':reduce_row(r),'integer_solutions':[]}
            for k in row['squares']:
                for l in k['leaves']:
                    if l['cert']['kind']!='primal':
                        continue
                    ids=l['types'];deck=[r['deck'][i] for i in ids]
                    for sol in intsol(deck,r['target']):
                        good=True
                        for t,c in zip(r['simple_roots'],k['classes']):
                            lam=2*t+11
                            weights=[isqrt(abs(val(q,t))//c) for q in deck]
                            assert all(c*a*a==abs(val(q,t)) for a,q in zip(weights,deck))
                            for vi,ni in zip(weights,sol):
                                if not ni:continue
                                others=[w for w,nj in zip(weights,sol) for _ in range(nj)]
                                others.remove(vi)
                                v=sum(others)-lam*vi
                                if v<0 or v%2:good=False;break
                                mask=1
                                for w in others:mask|=mask<<w
                                if not ((mask>>(v//2))&1):good=False;break
                        if good:
                            row['integer_solutions'].append({'types':ids,'counts':sol,'classes':k['classes']})
            rows.append(row)
            print(z,h,len(row['integer_solutions']))
    survivor=[r for r in rows if r['integer_solutions']]
    assert len(rows)==26 and [r['tail'] for r in survivor]==[[1,-1,-10,12],[1,-1,-10,16]]
    assert [len(r['integer_solutions']) for r in survivor]==[7,7]
    if args.output:
        args.output.write_text(json.dumps(rows,separators=(',',':'))+'\n')

if __name__=='__main__':
    test()

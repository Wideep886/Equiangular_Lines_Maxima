"""Verify integer deck exclusions and witnesses after running verify_quartics.py.
Uses the cached, independently regenerable quartic_results.json and
quartic_integer_witnesses.json in the directory of the verifier.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
from math import gcd,lcm
from verify_high import monic_product,parts,deriv
from verify_no11 import mul
import json
def gcdex(a,b):
 x0,y0,x1,y1=1,0,0,1
 while b:
  q,r=divmod(a,b)
  a,b=b,r;x0,x1=x1,x0-q*x1;y0,y1=y1,y0-q*y1
 sgn=1 if a>0 else -1
 return abs(a),sgn*x0,sgn*y0
def lat(columns,target):
 a=[list(c) for c in columns]
 t=list(target);j=0
 for row in range(len(t)):
  cand=next((i for i in range(j,len(a)) if a[i][row]),None)
  if cand is None:
   if t[row]:return False
   continue
  a[j],a[cand]=a[cand],a[j]
  for i in range(j+1,len(a)):
   x,y=a[j][row],a[i][row]
   if not y:continue
   g,s,u=gcdex(x,y);assert s*x+u*y==g
   a[j],a[i]=([s*v+u*w for v,w in zip(a[j],a[i])],[(-y//g)*v+(x//g)*w for v,w in zip(a[j],a[i])])
  x=a[j][row]
  if t[row]%x:return False
  mult=t[row]//x;t=[v-mult*w for v,w in zip(t,a[j])];j+=1
 return not any(t)

def coefficient_bounds(deck,target):
    # For integer w and every i, n_i (w q_i - m) <= w target - 58m,
    # with m = min_j w q_j. Every bound used is a necessary upper bound.
    bounds=[58]*len(deck)
    for w in product(range(-8,9),repeat=len(target)-3):
        vals=[sum(y*z for y,z in zip(w,q[3:])) for q in deck]
        slack=sum(y*z for y,z in zip(w,target[3:]))-58*min(vals)
        for i,x in enumerate(vals):
            diff=x-min(vals)
            if diff:bounds[i]=min(bounds[i],slack//diff)
    return bounds

def integer_feasible(deck,target):
    bounds=coefficient_bounds(deck,target)
    idx=sorted(range(len(deck)),key=lambda i:-bounds[i])
    deck=[deck[i] for i in idx];bounds=[bounds[i] for i in idx]
    matrix=[[F(v) for v in row]+[F(y)] for row,y in zip(zip(*deck),target)]
    k=0;piv=[]
    for j in range(len(deck)):
        pos=next((i for i in range(k,len(matrix)) if matrix[i][j]),None)
        if pos is None:continue
        matrix[pos],matrix[k]=matrix[k],matrix[pos]
        p=matrix[k][j];matrix[k]=[x/p for x in matrix[k]]
        for i in range(len(matrix)):
            if i!=k:
                v=matrix[i][j];matrix[i]=[a-v*b for a,b in zip(matrix[i],matrix[k])]
        k+=1;piv.append(j)
    if any(any(r) for r in matrix[k:]):return False
    free=[j for j in range(len(deck)) if j not in piv]
    for v in product(*(range(bounds[j]+1) for j in free)):
        xs=[r[-1]-sum(r[j]*x for j,x in zip(free,v)) for r in matrix[:k]]
        if all(x.denominator==1 and 0<=x<=bounds[j] for j,x in zip(piv,xs)):return True
    return False

def main():
    p=Path(__file__).parent
    rows=json.loads((p/'quartic_results.json').read_text())
    witnesses=json.loads((p/'quartic_integer_witnesses.json').read_text())
    counts=[0,0,0]
    for ix,r in enumerate(rows):
        if not r['final_decks']:continue
        counts[0]+=1
        fs=[([1,8],40)]+r['factors']; polynomials,multiplicities=zip(*fs)
        pieces=[mul(q,deriv(f)) for q,f in zip(parts(polynomials),polynomials)]
        target=[2*sum(m*t[j] for m,t in zip(multiplicities,pieces)) for j in range(len(pieces[0]))]
        admissible=[d for d in r['final_decks'] if lat(d,target)]
        if not admissible:continue
        counts[1]+=1
        if str(ix) in witnesses:
            witness=witnesses[str(ix)]
            assert witness['tail']==r['tail']
            v=witness['support']
            assert any(all(q in d for q,n in v) for d in admissible)
            assert all(isinstance(n,int) and n>0 for q,n in v)
            assert all(sum(q[j]*n for q,n in v)==y for j,y in enumerate(target))
            counts[2]+=1
        else:
            assert all(not integer_feasible(d,target) for d in admissible)
    print('square-class LP, integer lattice, nonnegative integer:',*counts)
    assert counts==[78,30,27] and len(witnesses)==27
if __name__=='__main__':main()

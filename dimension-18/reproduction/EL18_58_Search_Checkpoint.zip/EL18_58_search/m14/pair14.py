"""Integral rank-four polynomial test with outward-rounded fixed-point intervals."""
from pathlib import Path
from itertools import product
from math import isqrt
from functools import lru_cache
from fractions import Fraction as F
import json,sys
from verify_high import monic_product,parts,deriv,phase_one
from verify_no11 import mul
from verify_quartic_integers import lat
P=Path(__file__).resolve().parent
D=1<<50
def i(k):return (k*D,k*D)
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[1],-a[0])
def sub(a,b):return add(a,neg(b))
def times(a,b):
    xs=[x*y for x in a for y in b];return min(xs)//D,-((-max(xs))//D)
def divi(a,b):
    assert b[0]*b[1]>0
    lo=min(x*D//y for x in a for y in b);hi=max(-((-x*D)//y) for x in a for y in b);return lo,hi
def sqr(a):
    assert a[1]>=0
    if a[1]==0:return (0,0)
    return (isqrt(D*max(0,a[0])),isqrt(D*a[1])+1)
def ev(p,x):
    r=i(0)
    for w in p:r=add(times(r,x),i(w))
    return r
def sign_poly(p,k):
    v=0;d=1
    for a in p:v=v*k+a*d;d*=D
    return (v>0)-(v<0)
def roots(p):
    if len(p)==2:return [i(-p[1])]
    pts=[k*(D//128) for k in range(-5*128,5*128+1)]
    q=[];s=sign_poly(p,pts[0])
    for a,b in zip(pts,pts[1:]):
        t=sign_poly(p,b)
        if s*t<0:
            while b-a>1:
                m=(a+b)//2;u=sign_poly(p,m)
                if not u:a=b=m;break
                if s*u<0:b=m
                else:a=m
            q.append((a,b))
        s=t
    assert len(q)==len(p)-1
    return q
def intinside(a):return -((-a[0])//D)<=a[1]//D
def contained(a):
    first=-((-a[0])//D);last=a[1]//D
    if last<first:return None
    assert first==last
    return first
def targets(row):
    fs=[([1,8],40)]+row['factors'];p,m=zip(*fs)
    pieces=[mul(q,deriv(f)) for q,f in zip(parts(p),p)]
    return [2*sum(v*t[j] for v,t in zip(m,pieces)) for j in range(len(pieces[0]))]
class Pair:
    def __init__(self,row):
        fs=[([1,8],40)]+row['factors'];self.poly=monic_product([f for f,m in fs]);self.dp=deriv(self.poly)
        self.info=[]
        self.repeated=[f for f,m in fs[2:] if m>1]
        for f,m in fs[2:]:
            if m>1:continue
            for t in roots(f):
                h=times(i(2),times(t,add(t,i(8))))
                for rep in self.repeated:
                    assert len(rep)==2;h=times(h,times(i(2),ev(rep,t)))
                vals=[h]
                for _ in range(3):vals.append(times(vals[-1],times(i(2),t)))
                self.info.append((t,vals))
    @lru_cache(None)
    def weights(self,q):
        return [divi(ev(q,t),times(i(2),ev(self.dp,t))) for t,w in self.info]
    @lru_cache(None)
    def options(self,q,p):
        w=self.weights(q);v=self.weights(p);coeff=[]
        for a,b,(_,vals) in zip(w,v,self.info):
            sq=sqr(times(a,b));coeff.append([times(sq,x) for x in vals])
        opts=set()
        for signs in product((0,1),repeat=len(coeff)):
            out=[i(0)]*4
            for c,s in zip(coeff,signs):out=[add(x,neg(y) if s else y) for x,y in zip(out,c)]
            vs=[contained(x) for x in out]
            if None not in vs:opts.add(tuple(vs))
        return tuple(sorted(opts))
def cliques(adj):
    def go(rs,ps,xs):
        if not ps and not xs:yield tuple(sorted(rs));return
        v=max(ps|xs,key=lambda v:len(adj[v]&ps))
        for a in sorted(ps-adj[v]):
            yield from go(rs|{a},ps&adj[a],xs&adj[a]);ps=ps-{a};xs=xs|{a}
    yield from go(set(),set(range(len(adj))),set())
def run(k,row):
    v=Pair(row);target=targets(row);result=[]
    for d in row['final_decks']:
        d=[tuple(q) for q in d]
        if not lat(d,target):continue
        n=len(d);adj=[set() for _ in d]
        for a in range(n):
            for b in range(a):
                if v.options(d[a],d[b]):adj[a].add(b);adj[b].add(a)
        feasible=[]
        for g in cliques(adj):
            qs=[d[j] for j in g]
            if lat(qs,target) and phase_one(qs,target)['kind']=='primal':feasible.append(g)
        result.append((d,feasible))
    return v,target,result
def main():
    rs=json.loads((P/'quartic_results.json').read_text());ws=json.loads((P/'quartic_integer_witnesses.json').read_text());open_=[]
    for k in sorted(map(int,ws)):
        v,b,res=run(k,rs[k]);branches=sum(len(gs) for d,gs in res)
        print(k,branches,[(len(d),[len(c) for c in gs]) for d,gs in res],flush=True)
        if branches:open_.append(k)
    print('open',open_)
if __name__=='__main__':main()

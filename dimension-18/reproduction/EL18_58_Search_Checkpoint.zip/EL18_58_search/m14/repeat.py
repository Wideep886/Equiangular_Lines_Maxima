from signed import branch
from pair14 import *
from details import details
def ceildiv(x):return -((-x)//D)
class Repeated(Pair):
    def __init__(self,row):
        super().__init__(row)
        fs=[([1,8],40)]+row['factors'];self.rs=[]
        for f,m in fs[2:]:
            for t in roots(f):
                h=times(i(2),times(t,add(t,i(8))));vals=[h]
                for _ in range(3):vals.append(times(vals[-1],times(i(2),t)))
                self.rs.append((t,vals,m))
        self.info=[(t,l) for t,l,m in self.rs]
    @lru_cache(None)
    def options(self,q,p):
        w=self.weights(q);v=self.weights(p);coeff=[];repeat=[]
        for a,b,(t,vals,m) in zip(w,v,self.rs):
            sq=sqr(times(a,b))
            if m>1:
                assert m==2 and t[0]==t[1]
                repeat.append((t,vals,sq))
            else:coeff.append([times(sq,x) for x in vals])
        assert len(repeat)==1
        t,lv,bound=repeat[0];r=t[0]//D;shift=times(lv[0],bound);amp=max(abs(x) for x in shift)
        opts=set()
        for signs in product((0,1),repeat=len(coeff)):
            out=[i(0)]*4
            for c,s in zip(coeff,signs):out=[add(x,neg(y) if s else y) for x,y in zip(out,c)]
            for N in range(ceildiv(out[0][0]-amp),(out[0][1]+amp)//D+1):
                v=sub(i(N),out[0]);vs=[contained(add(p,times(v,i((2*r)**m)))) for m,p in enumerate(out)]
                if None not in vs:opts.add(tuple(vs))
        return tuple(sorted(opts))
def main():
    rs=json.loads((P/'quartic_results.json').read_text());rec={}
    for k in [169,369]:
        _,t,ss=run(k,rs[k]);v=Repeated(rs[k]);sets=[]
        for d,gs in ss:
            for g in gs:
                s,r=branch(v,t,d,g);sets.append((s,r))
        print(k,sets,flush=True);rec[k]=sets
    (P/'repeated_results.json').write_text(json.dumps(rec,separators=(',',':'))+'\n')
if __name__=='__main__':main()

# Two-vertex row moments at multiplicity fourteen

For a possible 58-line Seidel matrix let T=S−11I and H=(S+5I)(S−11I)/2. All entries of H are integers: the diagonal is (57−55)/2, while on an off-diagonal the 56 terms in S² have even sum. The normalized variable is y=T/2. The eigenvalues y=−8 and y=0 vanish in H. Its remaining eigenvalue on a root t is h(t)=2t(t+8). If any remaining root has multiplicity greater than one, first multiply H by the integer polynomial 2(t−r)=T−2rI for every repeated rational root r. The two repeated-root inputs here have one double integral r each. Write H_m=H T^m with this initial choice of H.

Let g be the squarefree minimal polynomial of y, and let q_i be the established normalized one-point cofactor type. The spectral weight on root t is w_i(t)=q_i(t)/(2g'(t)). At a simple root E_t is a rank-one projector, so its (i,j) entry is one of the two signs of sqrt(w_i(t) w_j(t)). The signs at different roots are allowed to vary independently. For every pair of cofactor types, enumerate these signs and retain only the joint four-tuples o with
[
 o_m=sum_t (2t)^m h(t),epsilon_tsqrt{w_i(t)w_j(t)}inmathbb{Z},quad 0le m<4.
]
This is necessary because o_m=(H_m)_{ij}. For a repeated rational root retained in H, the optional final refinement uses the Cauchy bound on its unknown off-diagonal projector entry. It enumerates the integer o_0 in the resulting interval and uses this value to recover the possible four-tuples.

The isolating intervals use fixed-point endpoints scaled by 2^50. All polynomial evaluations, bisections, divisions, signed square roots and sums are integer operations with outward rounding. The code asserts disjoint sign-change isolators equal in count to the degree of each nonlinear irreducible factor. A computed interval unable to contain an integer excludes that sign choice. An interval containing more than one integer aborts the verifier.

On a row of type q_a, let d_m=(H_m)_{ii} and M_j=(H²T^j)_{ii}; the code computes them by the same projector weights and confirms their enclosing intervals contain unique integers. There is a nonnegative integer multiplicity for each (neighbor type b, allowed joint o, Seidel entry s=±1). It must satisfy the original cofactor sum with q_a removed and the simultaneous moment equations
[
 sum_{j
e i}o_u o_v=M_{u+v}-d_ud_v,qquad
 sum_{j
e i} S_{ij}o_m=(SH_m)_{ii}=d_{m+1}+11d_m.
]
All ten pairs 0≤u≤v≤3 and all four values 0≤m≤3 are used. A support failing these equations for a type cannot contain any vertex of that type. Iterate this deletion until stable and retest the unsigned full cofactor identity on the remaining types.

Linear tests are performed twice. First check membership in the integer lattice using extended gcd and unimodular column operations. Then remove linearly dependent equations by exact Fraction elimination, and check nonnegative feasibility using an exact rational simplex. The simplex returns and verifies an integer Farkas witness for every separated target. A final survivor denotes passage of necessary conditions only. Every combinatorial branch is included; finite compatible supports arise as maximal cliques and any subset co-occurs only within such a clique. The supplied two upstream JSON files are the prior quartic-screen output and its 27 positive-integer-deck cases.

Run python3 check.py. Python 3.9+ standard library is sufficient. A positive control first uses the actual order-58 Seidel J−I with the rank-one integer polynomial H=J. The full calculation then rebuilds the individual branch/type removals and confirms ledger.json exactly. There are 27 input quartics, 11 after unsigned row moments and two after the joint signed moments. The undecided original indices are 169 and 369. They correspond respectively to normalized tails (y+2)²(y−2)(y−3) and (y−2)²(y²+3y−2).

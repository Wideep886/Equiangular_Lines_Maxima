"""Exact lifts of each orbit of affine zero-parity 47-point subsets."""
from pathlib import Path
import itertools as it
import json
from importlib.util import spec_from_file_location, module_from_spec

here=Path(__file__).resolve().parent
def load(path):
    spec=spec_from_file_location(path.stem,path)
    mod=module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

solver=load(here.parent/'affine19_other'/'search.py')
certify=load(here.parent/'verify_gram.py').certify

def max_clique(adj):
    best=[]
    def visit(p,clique):
        nonlocal best
        if len(clique)>len(best):
            best=clique
        color=0
        rest=p
        order=[]
        while rest:
            color+=1
            avail=rest
            while avail:
                bit=avail & -avail
                v=bit.bit_length()-1
                rest^=bit
                avail=(avail^bit)&~adj[v]
                order.append((v,color))
        for v,c in reversed(order):
            if c+len(clique)<=len(best):
                break
            visit(p&adj[v],clique+[v])
            p^=1<<v
    visit((1<<len(adj))-1,[])
    return best

def run(blocks,orbit):
    code,k=orbit[0]
    C=blocks[:k]+blocks[k+1:]
    D,opts,B=solver.coords(C)
    adj=[0]*len(opts)
    inner={}
    for i,(x,h,e) in enumerate(opts):
        for j,(y,g,f) in enumerate(opts[:i]):
            dot=sum(a*b for a,b in zip(x,y))
            for z in (-1,1):
                delta=2*D*D*z-dot
                if delta**2==h*g and delta*e*f>=0:
                    adj[i]|=1<<j
                    adj[j]|=1<<i
                    inner[i,j]=inner[j,i]=z
                    break
    # Distinguish genuinely new lifts from the 288 old lifts and the deleted line.
    def product_with_deleted(opt):
        return abs(sum(opt[0][p] for p in blocks[k]))
    removed=[i for i,v in enumerate(opts) if product_with_deleted(v)==5*D]
    outsiders=[i for i,v in enumerate(opts) if product_with_deleted(v) not in (D,5*D)]
    assert len(removed)==1
    def forced(i):
        inds=[j for j in range(len(opts)) if adj[i]>>j&1]
        graph=[sum(((adj[a]>>b)&1)<<u for u,b in enumerate(inds)) for a in inds]
        return 1+len(max_clique(graph))
    outsider_maxima=[forced(i) for i in outsiders]
    best=max_clique(adj)
    gram=[[2*len(set(a)&set(b))-1 for b in C] for a in C]
    n=len(C)
    for row,t in zip(gram,C):
        for i in best:
            a=sum(opts[i][0][p] for p in t)
            assert abs(a)==D
            row.append(a//D)
    for j,i in enumerate(best):
        gram.append([row[n+j] for row in gram[:n]]+
                    [5 if i==l else inner[i,l] for l in best])
    file=here/('gram_%s_%d.json'%(k,len(gram)) if code==0 else 'gram_code_%s_block_%s_%d.json'%(code,k,len(gram)))
    file.write_text(json.dumps(gram))
    certificate=certify(gram,len(gram),18)
    if len(gram)>=58:print('CANDIDATE',k,flush=True)
    return dict(code=code,deleted=k,orbit=orbit,den=D,basis=B,
                new_lift_norms=[(product_with_deleted(opts[i]),D) for i in outsiders],new_lift_max=outsider_maxima,directions=len(opts),edges=len(inner)//2,maximum=len(best),
                gram_file=file.name,rank=certificate['rank'],
                clique_lifts=[opts[i] for i in best])

def orbits():
    # A bit for each of the twelve base lines. Switch 9 point groups, then
    # reduce the relabeled code and marked block under all 432 affine maps.
    from functools import reduce
    switch={reduce(int.__xor__,[solver.masks[i] for i in range(9) if mask>>i&1],0):mask
            for mask in range(512)}
    assert len(switch)==512
    reductions={r^v:(r,t) for r in solver.reps for v,t in switch.items()}
    assert len(reductions)==4096
    pts=solver.pts
    maps=[]
    for a,b,c,d in it.product(range(3),repeat=4):
        if (a*d-b*c)%3:
            for tx,ty in pts:
                pi=[pts.index(((a*x+b*y+tx)%3,(c*x+d*y+ty)%3)) for x,y in pts]
                lm=[solver.lines.index(tuple(sorted(pi[i] for i in t))) for t in solver.lines]
                maps.append((pi,lm))
    designs={r:solver.triples(r) for r in solver.reps}
    indices={r:{tuple(sorted(t)):i for i,t in enumerate(bl)} for r,bl in designs.items()}
    groups={}
    for r,blocks in designs.items():
        images=[set() for t in blocks]
        for pi,lm in maps:
            label=sum(((r>>i)&1)<<p for i,p in enumerate(lm))
            representative,flip=reductions[label]
            point_map=[2*pi[u//2]+((u%2)^((flip>>pi[u//2])&1)) for u in range(18)]
            for i,t in enumerate(blocks):
                block=tuple(sorted(point_map[u] for u in t))
                images[i].add((representative,indices[representative][block]))
        for i,orbit in enumerate(images):
            groups.setdefault(min(orbit),[]).append((r,i))
    for orbit in groups.values():
        orbit.sort()
    return sorted(groups.values())

if __name__=='__main__':
    results=[]
    classes=orbits()
    print('orbits',[(o[0],len(o)) for o in classes],flush=True)
    for orbit in classes:
        code,k=orbit[0]
        r=run(solver.triples(code),orbit)
        print(code,k,r['directions'],r['maximum'],r['rank'],flush=True)
        results.append(r)
    (here/'results.json').write_text(json.dumps(results))

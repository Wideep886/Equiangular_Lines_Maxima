"""All exact row degrees, plus per-cell Cauchy bounds and handshake of type pairs."""
from forced_rows import *
def runrows(k):
 f,_,d,t,op,_=load(k);g=gpoly(f);gp=pol.deriv(g)
 out=[]
 for entry in json.load(open(HERE/f'forced_{k}.json')):
    if entry['failed']:continue
    deck=entry['deck'];n=dict(deck);I=list(n);ref=I[0];h=red(d[ref],f)
    R={j:(h if j==ref else red(op[ref,j][0],f)) for j in n}
    pr={(i,j):times(times(R[i],R[j],f),inv(h,f),f) for i in I for j in I}
    so={(i,j):{s for q in op.get((min(i,j),max(i,j)),[]) for s in (-1,1) if red([s*v for v in q],f)==pr[i,j]} for i in I for j in I}
    e=times([1,8],inv(gp,f),f)
    L={(i,j):trace(times(e,pr[i,j],f),f) for i in I for j in I}
    sums={j:n[j]*(5-max(so[j,j],default=0))+n[j]**2*(max(so[j,j],default=0)-L[j,j]) for j in I}
    assert all(x>=0 for x in sums.values())
    pools={}
    for i in I:
        v=times([2,11],R[i],f)
        coeff=[];bounds=[];names=[];baseline={j:0 for j in I}
        for j in I:
            m=n[j]-(i==j)
            if not m:continue
            pos=[]
            for a in range(m+1):
                if a and 1 not in so[i,j] or a<m and -1 not in so[i,j]:continue
                net=2*a-m
                resid=net+(5 if j==i else 0)-n[j]*L[i,j]
                if resid**2<=(5-L[i,i])*sums[j]:pos.append(a)
            if not pos:break
            lo,hi=min(pos),max(pos)
            v=tuple(a-(2*lo-m)*b for a,b in zip(v,R[j]))
            baseline[j]=lo
            if hi>lo:coeff.append(tuple(2*b for b in R[j]));bounds.append(hi-lo);names.append(j)
        else:
            sols=feasible_counts(coeff,v,bounds) if coeff else ([()] if not any(v) else [])
            patterns=[]
            for s in sols:
                row=baseline.copy()
                for j,a in zip(names,s):row[j]+=a
                patterns.append(tuple(row[j] for j in I))
            pools[i]=patterns
    counts=[len(pools.get(i,[])) for i in I]
    # For each type, generate exact admissible joint sums of its n[i] row patterns?
    # Here first filter every pair separately by handshake and each diagonal by parity.
    changed=True
    if all(counts):
      while changed:
        changed=False
        for a,i in enumerate(I):
            for b,j in enumerate(I):
                ri={r[b] for r in pools[i]};rj={r[a] for r in pools[j]}
                if not ri or not rj:break
                def sums_of(xs,k):
                    s={0}
                    for _ in range(k):s={a+b for a in s for b in xs}
                    return s
                sj=sums_of(rj,n[j]) if i!=j else set(range(0,n[j]*(n[j]-1)+1,2))
                si=sums_of(ri,n[i]-1)
                ok={v for v in ri if any(v+w in sj for w in si)}
                if ok!=ri:
                    pools[i]=[r for r in pools[i] if r[b] in ok];changed=True
            if not pools[i]:break
        if not all(pools.values()):break
    after=[len(pools.get(i,[])) for i in I]
    rec=dict(deck=deck,counts=counts,after=after,patterns=[pools.get(i,[]) for i in I])
    out.append(rec)
    print(k,counts,after,flush=True)
 (HERE/f'patterns_{k}.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':
 for k in (2300,2689):runrows(k)

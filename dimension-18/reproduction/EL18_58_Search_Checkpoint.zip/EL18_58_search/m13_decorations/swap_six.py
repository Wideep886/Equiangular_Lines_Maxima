"""Remove four singleton anchors; realize the other 54 projections in an exact 6-space."""
from low_swap import *
def projected(k,n,I,L,i,x):
    # Rational Gram function in 5+1 coordinates; sixth is the product with the
    # residual of singleton i, divided in the Gram by its squared norm.
    D=5-L[i,i]
    left=[]
    for j,c,v in zip(I,n.values(),x):
        if c==1:continue
        for s,count in [(1,v),(-1,c-v)]:
            if count:left.append((j,s-L[i,j],count))
    def ip(x,y):return L[x[0],y[0]]+x[1]*y[1]/D
    B=[]
    for pt in left:
        cand=B+[pt]
        if matinv([[ip(a,b) for b in cand] for a in cand]):B=cand
    if len(B)!=6:return dict(rank=len(B))
    G=[[ip(a,b) for b in B] for a in B];H=matinv(G)
    qs=[([ip(p,a) for a in B],p[2]) for p in left]
    opts=[]
    for ss in product([-1,1],repeat=5):
        s=(1,)+ss;z=[sum(a*b for a,b in zip(r,s)) for r in H]
        if sum(a*b for a,b in zip(s,z))==5 and all(abs(sum(a*b for a,b in zip(z,q)))==1 for q,c in qs):opts.append((s,z))
    cards={};specs=[]
    for m in range(1,len(opts)+1):
        full=[]
        for C in combinations(opts,m):
            if all(abs(sum(a*b for a,b in zip(s,w)))==1 for (s,z),(t,w) in combinations(C,2)):full.append(C)
        if full:cards[m]=len(full)
        if m==4:
            for C in full:
                data=[(q,[sum(a*b for a,b in zip(q,row)) for row in H],c) for q,c in qs]+[(s,z,1) for s,z in C]
                A=[[sum(c*z[u]*s[v] for s,z,c in data)-16*(u==v) for v in range(6)] for u in range(6)]
                # Faddeev–LeVerrier for shifted 6x6 frame X−16I.
                powers=[];M=[[F(u==v) for v in range(6)] for u in range(6)]
                ch=[1]
                for l in range(1,7):
                    M=[[sum(a*b for a,b in zip(r,col)) for col in zip(*A)] for r in M]
                    powers.append(sum(M[t][t] for t in range(6)))
                    ch.append(-sum(a*b for a,b in zip(ch,reversed(powers)))/l)
                assert all(v==int(v) for v in ch)
                specs.append(list(map(int,ch)))
        if not full:break
    return dict(rank=len(B),vertices=len(opts),cliques=cards,shifted_polynomials=specs,basis=[(j,str(v),c) for j,v,c in B],extension_masks=[s for s,z in opts])
def run(k):
 f,_,d,t,op,_=load(k);g=gpoly(f);gp=pol.deriv(g);res=[]
 ds=json.load(open(HERE/f'triangles_{k}.json'));raw=json.load(open(HERE/f'patterns_{k}.json'))
 for r in ds:
    n=dict(r['deck']);I=list(n);ref=I[0];h=red(d[ref],f)
    coef=times(times([1,8],inv(gp,f),f),inv(h,f),f)
    R={j:(h if j==ref else red(op[ref,j][0],f)) for j in n}
    L={(i,j):trace(times(coef,times(R[i],R[j],f),f),f) for i in I for j in I}
    special=[i for i in I if n[i]==1 and L[i,i]!=5]
    assert len(special)==1 and sum(v==1 for v in n.values())==4
    i=special[0];idx=I.index(i)
    a=next(y for y in raw if y['deck']==r['deck'])
    for p in r['surviving_indices'][idx]:
        rp=a['patterns'][idx][p];rec=projected(k,n,I,L,i,rp);res.append(rec)
        print(k,rec['cliques'],rec['shifted_polynomials'],flush=True)
 (HERE/f'swap_six_{k}.json').write_text(json.dumps(res))
if __name__=='__main__':
 for k in (2300,2689):run(k)

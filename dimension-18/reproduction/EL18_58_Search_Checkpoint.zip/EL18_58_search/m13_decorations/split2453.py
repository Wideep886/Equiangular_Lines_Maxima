"""Separate the two conjugate orbits on the simple rank-five summand of #2453."""
from anchored_decks import *
def run():
 k=2453
 f,ids,d,t,op,cs=load(k);g=gpoly(f);ell,cap=cap_data(f,d,op,ids)
 assert f==pol.mul([1,0,-3],[1,-1,-7,8])
 brute=json.load(open(HERE/f'stage_{k}.json'));allsol=[];cases=[]
 for branch in brute:
    left=branch['support'][:]
    while left:
        i=left.pop(0);types=[i]+left
        rawmom=coefficient_gram(g,d[i],d[i],d[i],True)
        n=len(g)-2
        cov=dict(zip(combinations_with_replacement(range(n),2),rawmom))
        proj=[red([1]+[0]*a,f) for a in range(n)]
        goal=[sum(proj[u][a]*proj[v][b]*cov[min(u,v),max(u,v)] for u in range(n) for v in range(n)) for a,b in combinations_with_replacement(range(5),2)]
        target=[a-b for a,b in zip(t,d[i])]+goal
        labels=[];coords=[];ub=[]
        for j in types:
            pats=sorted({min(red(q,f),tuple(-v for v in red(q,f))) for q in op.get((min(i,j),max(i,j)),[])})
            for q in pats:
                labels.append(list(d[j])+[q[a]*q[b] for a,b in combinations_with_replacement(range(5),2)])
                coords.append((j,q))
                # Once each factor has a nonzero anchor coordinate, the label determines the
                # switched vector on both components up to one global sign. Otherwise allow
                # two projective lifts per label, each subject to the identical-vector bound.
                capped=cap[j] if any(pol.rem(d[i],[1,0,-3])) and any(pol.rem(d[i],[1,-1,-7,8])) else min(58,2*cap[j])
                anchor=red(d[i],f)
                ub.append(capped-int(i==j and q in (anchor,tuple(-z for z in anchor))))
        sols=feasible_counts(labels,target,ub);cases.append([i,len(sols)])
        for s in sols:
            allsol.append(dict(ref=i,cells=[(j,q,n) for (j,q),n in zip(coords,s) if n]))
 print(k,'solutions',len(allsol),'cases',cases,flush=True)
 (HERE/'decorated2453.json').write_text(json.dumps(dict(cases=cases,solutions=allsol)))
if __name__=='__main__':run()

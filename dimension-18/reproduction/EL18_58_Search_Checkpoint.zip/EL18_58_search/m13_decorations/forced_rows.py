from integer_rows import *
def test(k):
 f,_,d,t,op,_=load(k);g=gpoly(f);gp=pol.deriv(g)
 decks=json.load(open(HERE/f'rowdecks_{k}.json'))['survivors'];out=[]
 for deck in decks:
    n=dict(deck);I=list(n);ref=I[0];h=red(d[ref],f)
    R={j:(h if j==ref else red(op[ref,j][0],f)) for j in n}
    prod={(i,j):times(times(R[i],R[j],f),inv(h,f),f) for i in I for j in I}
    so={(i,j):{s for q in op.get((min(i,j),max(i,j)),[]) for s in (-1,1) if red([s*v for v in q],f)==prod[i,j]} for i in I for j in I}
    fixed=[i for i in I if all(len(so[i,j])==1 for j in I if n[j]>(i==j))]
    # S²-6S-55I = sum_{t root of f} (2t)(16+2t) P_t.
    coef=times([2,16,0],inv(gp,f),f)
    F2={(i,j):trace(times(coef,prod[i,j],f),f) for i in fixed for j in I}
    ok=True;record=[]
    # For any fully determined other row, use its two-walk product with this row.
    for i in I:
        D=[j for j in fixed if j!=i]
        v=times([2,11],R[i],f)+tuple(F2[i0,i]+6*next(iter(so[i0,i])) for i0 in D)
        basis=[];bounds=[]
        for j in I:
            count=n[j]-(j==i)
            if not count:continue
            col=R[j]+tuple(next(iter(so[i0,j])) if i0!=j or n[j]>1 else 0 for i0 in D)
            sign=min(so[i,j]);v=tuple(a-sign*count*b for a,b in zip(v,col))
            # The diagonal of each fixed row is zero, not its internal sign.
            if j in D and n[j]>1:
                ix=5+D.index(j);v=v[:ix]+(v[ix]+next(iter(so[i,j]))*next(iter(so[j,j])),)+v[ix+1:]
            if len(so[i,j])==2:basis.append(tuple(2*b for b in col));bounds.append(count)
        if not (any(v)==False if not basis else bool(feasible_counts(basis,v,bounds,first_only=True))):
            record.append(i);ok=False;break
    out.append(dict(deck=deck,forced=fixed,failed=record))
 (HERE/f'forced_{k}.json').write_text(json.dumps(out))
 print(k,'remain',sum(not r['failed'] for r in out),'of',len(decks),flush=True)
if __name__=='__main__':
 for k in QSET:
    if (HERE/f'rowdecks_{k}.json').exists():test(k)

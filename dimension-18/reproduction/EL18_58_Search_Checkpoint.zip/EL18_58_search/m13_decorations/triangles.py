from row_patterns import *
def prune(k):
 f,_,d,t,op,_=load(k);g=gpoly(f)
 raw=json.load(open(HERE/f'patterns_{k}.json'));out=[]
 for rec in raw:
    if not all(rec['after']):continue
    deck=rec['deck'];ns=[n for _,n in deck];I=[i for i,n in deck]
    ref=I[0];h=red(d[ref],f);u=inv(h,f);R=[h]+[red(op[ref,j][0],f) for j in I[1:]]
    c=times([2,16,0],inv(pol.deriv(g),f),f)
    M=[[trace(times(times(times(x,y,f),u,f),c,f),f) for y in R] for x in R]
    assert all(v.denominator==1 for r in M for v in r)
    rows=[list(map(tuple,ps)) for ps in rec['patterns']]
    # Use integer bitsets to track which partner row patterns remain at each type.
    allowed={}
    for a,ra in enumerate(rows):
        for b,rb in enumerate(rows):
            if b<a or (b==a and ns[a]<2):continue
            for x,p in enumerate(ra):
                for y,q in enumerate(rb):
                    if a==b and y<x:continue
                    for s in (-1,1):
                        e=int(s==1)
                        if not (0<=p[b]-e<=ns[b]-1-(a==b) and 0<=q[a]-e<=ns[a]-1-(a==b)):continue
                        # S²_ij equals equal signs minus opposite signs over 56 other points.
                        # Distances on those 56 positions come from intersections of + supports.
                        nh=[n-(t==a)-(t==b) for t,n in enumerate(ns)]
                        ph=[v-e*(t==b) for t,v in enumerate(p)]
                        qh=[v-e*(t==a) for t,v in enumerate(q)]
                        target=M[a][b]+6*s
                        num=target-56+2*(sum(ph)+sum(qh))
                        if num%4:continue
                        meet=int(num//4)
                        if sum(max(0,u+v-n) for u,v,n in zip(ph,qh,nh))<=meet<=sum(min(u,v) for u,v in zip(ph,qh)):
                            k1=(a,x,b,s);k2=(b,y,a,s)
                            allowed[k1]=allowed.get(k1,0)|(1<<y)
                            allowed[k2]=allowed.get(k2,0)|(1<<x)
    live=[(1<<len(r))-1 for r in rows]
    while all(live):
        new=[]
        for a,ra in enumerate(rows):
            cur=0
            for x,p in enumerate(ra):
                if live[a]>>x&1 and all(not need or allowed.get((a,x,b,s),0)&live[b] for b,n in enumerate(ns) for s,need in [(1,p[b]),(-1,n-(a==b)-p[b])]):
                    cur|=1<<x
            new.append(cur)
        if new==live:break
        live=new
    counts=[m.bit_count() if hasattr(int,'bit_count') else bin(m).count('1') for m in live]
    out.append(dict(deck=deck,counts=counts,surviving_indices=[[x for x in range(len(r)) if m>>x&1] for m,r in zip(live,rows)]))
    print(k,counts,flush=True)
 (HERE/f'triangles_{k}.json').write_text(json.dumps(out))
if __name__=='__main__':
 for k in (2300,2689):prune(k)

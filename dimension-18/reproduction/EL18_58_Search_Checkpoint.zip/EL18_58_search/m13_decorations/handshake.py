"""Global symmetric degree balance for the two surviving irreducible-quintic cell decks."""
from rows import *
from functools import reduce
def run(k):
 r,=json.load(open(HERE/f'triangles_{k}.json'));p=next(x for x in json.load(open(HERE/f'patterns_{k}.json')) if x['deck']==r['deck'])
 ps=[[p['patterns'][i][x] for x in v] for i,v in enumerate(r['surviving_indices'])];n=[v for _,v in r['deck']];d=len(n)
 constraints=[(i,j) for i in range(d) for j in range(i+1,d)]
 # For each cell pick the first pattern as a baseline and change other row counts.
 def col(i,row):return tuple((row[b] if a==i else -row[a] if b==i else 0) for a,b in constraints)+tuple(row[i] if a==i else 0 for a in range(d))
 h=len(constraints)+d
 c0=[col(i,arr[0]) for i,arr in enumerate(ps)];rawtarget=tuple(-sum(n[i]*a[j] for i,a in enumerate(c0)) for j in range(h))
 common=[]
 for i,arr in enumerate(ps):
    for row in arr[1:]:
        common.append(tuple(u-v for u,v in zip(col(i,row),c0[i])))
 common.extend(tuple(-2 if j==len(constraints)+i else 0 for j in range(h)) for i in range(d))
 status=lat(common,rawtarget)
 print(k,'global parity lattice',status,flush=True)
 (HERE/f'handshake_{k}.json').write_text(json.dumps(dict(integer_lattice=bool(status))))
if __name__=='__main__':
 for k in [2300,2689]:run(k)

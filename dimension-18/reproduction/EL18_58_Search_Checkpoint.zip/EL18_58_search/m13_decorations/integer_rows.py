from anchored_decks import *
def runidx(k):
    f,_,d,t,op,_=load(k)
    raw=json.load(open(HERE/f'decks_{k}.json'))['decks']
    survive=[];fails=[]
    for deck in raw:
        z=dict(deck);ref=deck[0][0];h=red(d[ref],f)
        R={j:(h if j==ref else red(op[ref,j][0],f)) for j in z}
        ok=True
        for i in z:
            # Each switched row has S R_i(t) = (11+2t)R_i(t) in the field.
            # Enumerate counts of + signs by cell, using every pair-polynomial sign test.
            v=times([2,11],R[i],f)
            coeff=[];bounds=[]
            for j in z:
                n=z[j]-(i==j)
                if n==0:continue
                sset={s for p in op[min(i,j),max(i,j)] for s in [-1,1]
                      if times([s*x for x in p],h,f)==times(R[i],R[j],f)}
                if not sset:ok=False;break
                s=min(sset)
                v=tuple(a-s*n*b for a,b in zip(v,R[j]))
                if len(sset)==2:coeff.append(tuple(2*b for b in R[j]));bounds.append(n)
            if ok:
                ok=(not any(v)) if not coeff else bool(feasible_counts(coeff,v,bounds,first_only=True))
            if not ok:fails.append((deck,i));break
        if ok:survive.append(deck)
    print(k,len(raw),'->',len(survive),flush=True)
    (HERE/f'rowdecks_{k}.json').write_text(json.dumps(dict(survivors=survive,rejections=fails)))
if __name__=='__main__':
 for k in QSET:
    if (HERE/f'decks_{k}.json').exists():runidx(k)

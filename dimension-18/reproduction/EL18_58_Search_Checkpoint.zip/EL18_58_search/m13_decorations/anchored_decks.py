from rows import *
from itertools import combinations_with_replacement
def bounded_decks(idx):
    f,ids,d,t,op,cs=load(idx);g=gpoly(f);norm,cap=cap_data(f,d,op,ids)
    raw=json.load(open(HERE/f'stage_{idx}.json'))
    decks=set();cases=[]
    for branch in raw:
        remaining=branch['support'][:]
        while remaining:
            i=remaining[0];types=remaining[:];remaining=remaining[1:]
            rawmom=coefficient_gram(g,d[i],d[i],d[i],True)
            dim=len(g)-2
            pairs=list(combinations_with_replacement(range(dim),2))
            cov={(a,b):v for (a,b),v in zip(pairs,rawmom)}
            proj=[red([1]+[0]*a,f) for a in range(dim)]
            goal=[]
            for a,b in combinations_with_replacement(range(5),2):
                goal.append(sum(proj[u][a]*proj[v][b]*cov[min(u,v),max(u,v)] for u in range(dim) for v in range(dim)))
            labels=[]
            for j in types:
                pools=op.get((min(i,j),max(i,j)),[])
                if pools:
                    r=red(pools[0],f)
                    assert all(red(q,f) in (r,tuple(-v for v in r)) for q in pools)
                else:
                    assert j==i
                    r=red(d[i],f)
                labels.append(list(d[j])+[r[a]*r[b] for a,b in combinations_with_replacement(range(5),2)])
            target=[a-b for a,b in zip(t,d[i])]+goal
            ub=[cap[j]-(j==i) for j in types]
            solutions=feasible_counts(labels,target,ub)
            for sol in solutions:decks.add(tuple(sorted((k,n+(k==i)) for k,n in zip(types,sol) if n or k==i)))
            cases.append((list(types),len(solutions)))
    answer=dict(decks=sorted(decks),cases=cases,caps=cap)
    (HERE/f'decks_{idx}.json').write_text(json.dumps(answer))
    print(idx,'decks',len(decks),'branches',len(cases),flush=True)
if __name__=='__main__':
 for k in QSET:
    if (HERE/f'stage_{k}.json').exists():bounded_decks(k)

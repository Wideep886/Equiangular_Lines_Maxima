from decor2453_rows import *
def replay():
 f,_,d,t,op,_=load(2453);g=gpoly(f);ell,cap=cap_data(f,d,op,d and sorted({j for i,j in op}|{i for i,j in op}))
 entries=json.load(open(HERE/'decor2453_rows.json'));out=[]
 for sol in entries:
    n=Counter({sol['ref']:1})
    for j,q,num in sol['cells']:n[j]+=num
    active=[i for i in n if all(any(pol.rem(d[i],p)) for p in ([1,0,-3],[1,-1,-7,8]))]
    i=next((j for j in active if n[j]==1),active[0])
    h=red(d[i],f);assert any(h)
    dim=len(g)-2;cov=dict(zip(combinations_with_replacement(range(dim),2),coefficient_gram(g,d[i],d[i],d[i],True)))
    pr=[red([1]+[0]*a,f) for a in range(dim)]
    goal=[sum(pr[u][a]*pr[v][b]*cov[min(u,v),max(u,v)] for u in range(dim) for v in range(dim)) for a,b in combinations_with_replacement(range(5),2)]
    Q=[];cols=[];ubs=[]
    for j in n:
        labels=sorted({min(red(q,f),tuple(-x for x in red(q,f))) for q in op.get((min(i,j),max(i,j)),[])})
        for r in labels:
            Q.append((j,r));cols.append([int(l==j) for l in n]+[r[a]*r[b] for a,b in combinations_with_replacement(range(5),2)])
            ubs.append(min(n[j]-int(i==j),cap[j]-int(i==j and r in (h,tuple(-x for x in h)))))
    result=feasible_counts(cols,[n[j]-(i==j) for j in n]+goal,ubs)
    unique=[]
    for v in result:
        row=dict(ref=i,cells=[(j,r,c) for (j,r),c in zip(Q,v) if c]);unique.append(row)
    print('original ref',sol['ref'],'new ref',i,'redecorations',len(unique))
    out.extend(unique)
 (HERE/'reanchor2453.json').write_text(json.dumps(out))
if __name__=='__main__':replay()

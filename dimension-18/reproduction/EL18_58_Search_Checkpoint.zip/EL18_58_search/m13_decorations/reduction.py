from quintic import *
from fractions import Fraction as F
from math import floor,lcm,gcd
from functools import reduce
from collections import Counter
def red(v,f):
    w=pol.rem(list(v),list(f))
    return (0,)*(len(f)-1-len(w))+tuple(w)
def times(u,v,f):return red(pol.mul(u,v),f)
def inv(u,f):
    n=len(f)-1; rows=[list(c)+[int(i==n-1)] for i,c in enumerate(zip(*[times(u,[1]+[0]*k,f) for k in reversed(range(n))]))]
    rows=[list(map(F,r)) for r in rows]
    for j in range(n):
        i=next(i for i in range(j,n) if rows[i][j]);rows[i],rows[j]=rows[j],rows[i]
        v=rows[j][j];rows[j]=[z/v for z in rows[j]]
        for k,r in enumerate(rows):
            if k!=j and r[j]:rows[k]=[a-r[j]*b for a,b in zip(r,rows[j])]
    return tuple(r[-1] for r in rows)
def trace(u,f):
    return sum(times(u,[1]+[0]*(4-k),f)[k] for k in range(5))
def gpoly(f):return pol.mul([1,8,0],f)
def cap_data(f,d,op,types):
    g=gpoly(f);dg=pol.deriv(g)
    e=times([1,8],inv(dg,f),f) # (16+2t)/(2g')
    norms={i:trace(times(d[i],e,f),f) for i in types}
    ans={}
    for i in types:
        pos=red(d[i],f)
        opts=op.get((i,i),[])
        signs={s for q in opts for s in (1,-1) if red([s*x for x in q],f)==pos}
        # Rank <=13 for the residual on vertices of a single switched type.
        bound=min(58,1 if not signs else 58,14 if len(signs)==1 else 58)
        if signs and norms[i]>max(signs):bound=min(bound,floor((5-max(signs))/(norms[i]-max(signs))))
        ans[i]=bound
    return norms,ans
if __name__=='__main__':
 for idx in QSET:
    f,ids,d,t,op,cs=load(idx);n,cap=cap_data(f,d,op,ids)
    print(idx,sorted(cap.values()),flush=True)

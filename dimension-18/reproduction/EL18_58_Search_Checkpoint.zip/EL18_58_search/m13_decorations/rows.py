from reduction import *
from verify_quadratic_0020 import coefficient_gram,gram_column
from lattice import lat
from lpscreen import phase_one
# Exact elimination to restrict to independent equations.
def feasible(cols,target):
    if not cols or not lat(cols,target):return False
    rows=[list(map(F,(*r,t))) for r,t in zip(zip(*cols),target)]
    piv=[];basis=[]
    for i,r in enumerate(rows):
        for j,b in piv:
            if r[j]:
                c=r[j];r=[x-c*y for x,y in zip(r,b)]
        j=next((j for j,v in enumerate(r[:-1]) if v),None)
        if j is None:
            if r[-1]:return False
            continue
        c=r[j];piv.append((j,[v/c for v in r]));basis.append(i)
    cols=[tuple(c[i] for i in basis) for c in cols]
    return phase_one(cols,[target[i] for i in basis])['kind']=='primal'
def run(k):
    f,ids,d,t,op,cs=load(k);norm,cap=cap_data(f,d,op,ids)
    stage=[]
    for cl in cs:
        act=list(cl);iterations=[]
        while act:
            drop=[]
            for i in act:
                col=[tuple(d[j]+gram_column(q)) for j in act for q in op.get((min(i,j),max(i,j)),[])]
                target=[a-b for a,b in zip(t,d[i])]+coefficient_gram(gpoly(f),d[i],d[i],d[i],True)
                if not feasible(col,target):
                    drop.append(i);continue
            if not drop:break
            iterations.append(drop)
            act=[i for i in act if i not in drop]
        if act and not feasible([d[i] for i in act],t):act=[]
        stage.append(dict(clique=cl,support=act,rounds=iterations))
    print(k,[len(c['support']) for c in stage],flush=True)
    (HERE/f'stage_{k}.json').write_text(json.dumps(stage))
if __name__=='__main__':
 for k in QSET+[2453]:run(k)

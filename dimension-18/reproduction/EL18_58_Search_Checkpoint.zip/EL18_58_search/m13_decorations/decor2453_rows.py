from split2453 import *
from functools import lru_cache
def solve():
 k=2453
 f,ids,d,t,op,cs=load(k);g=gpoly(f)
 solutions=json.load(open(HERE/'decorated2453.json'))['solutions']
 @lru_cache(None)
 def signs(i,j,r,s,h):
    a=times(r,s,f)
    return {b for p in op.get((min(i,j),max(i,j)),[]) for b in (-1,1) if tuple(b*z for z in times(p,h,f))==a}
 out=[]
 for sol in solutions:
    ref=sol['ref'];h=red(d[ref],f);cells={(ref,h):1}
    for j,q,n in sol['cells']:
        r=tuple(q)
        if j==ref and r==tuple(-z for z in h):r=h
        cells[j,r]=cells.get((j,r),0)+n
    ok=True
    for (i,r),n in cells.items():
        v=times([2,11],r,f);cols=[];ubs=[]
        for (j,s),m in cells.items():
            m-=(i,r)==(j,s)
            if not m:continue
            sg=signs(i,j,r,s,h)
            if not sg:ok=False;break
            z=min(sg)*m;v=tuple(a-z*b for a,b in zip(v,s))
            if len(sg)>1:cols.append(tuple(2*b for b in s));ubs.append(m)
        if not ok or not (any(v)==False if not cols else bool(feasible_counts(cols,v,ubs,first_only=True))):ok=False;break
    if ok:out.append(sol)
 print('2453 integer rows survive',len(out),flush=True)
 (HERE/'decor2453_rows.json').write_text(json.dumps(out))
if __name__=='__main__':solve()

from pathlib import Path
import sys,json,subprocess,tempfile,os
from itertools import combinations
HERE=Path(__file__).resolve().parent;P=HERE.parent
sys.path.insert(0,str(P/'audit_layer'));sys.dont_write_bytecode=True
import polynomial13 as pol
import fastdeck
sys.path.insert(0,str(P/'m15_upstream'/'source'/'output'))
from verify_quadratic_0020 import feasible_counts
QSET=[1378,2257,2300,2689]
def maximal(adj):
    def visit(c,p,x):
        if not p and not x:yield tuple(sorted(c));return
        v=max(p|x,key=lambda i:len(p&adj[i]))
        for j in sorted(p-adj[v]):
            yield from visit(c|{j},p&adj[j],x&adj[j])
            p-= {j};x|={j}
    yield from visit(set(),set(adj),set())
def load(index):
    ids=next(a[2] for a in map(json.loads,(P/'audit_layer'/'poly13_final.jsonl').read_text().splitlines()) if a[0]==index)
    f=json.loads((P/'m13'/'parents.json').read_text())[index]
    primes={1378:11,2257:3,2300:11,2689:13}
    if index in primes:
        p=primes[index]
        assert all(pol.val(f,x)%p for x in range(p))
        assert all(any(y%p for y in pol.rem(f,[1,a,b])) for a in range(p) for b in range(p))
    fs=[([1,0],13),(f,1)]
    g,t,d=pol.native([([1,8],40)]+fs)
    _,_,op=pol.poly_types({i:sum(1<<j for j in ids) for i in ids},fs,g,d,ids)
    adj={i:{j for j in ids if j!=i and (min(i,j),max(i,j)) in op} for i in ids}
    cs=list(maximal(adj));return f,ids,d,t,op,cs
if __name__=='__main__':
    for index in QSET:
        f,ids,d,t,op,cs=load(index)
        print(index,len(ids),len(cs),list(map(len,cs)),flush=True)

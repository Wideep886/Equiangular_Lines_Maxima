"""Enumerate every replacement in the exceptional five-space after removing its pure lines."""
from triangles import *
from itertools import product,combinations
def matinv(A):
 n=len(A);b=[[F(v) for v in r]+[F(j==i) for j in range(n)] for i,r in enumerate(A)]
 for j in range(n):
    r=next((r for r in range(j,n) if b[r][j]),None)
    if r is None:return None
    b[j],b[r]=b[r],b[j];p=b[j][j];b[j]=[v/p for v in b[j]]
    for i in range(n):
        if i!=j:b[i]=[x-b[i][j]*y for x,y in zip(b[i],b[j])]
 return [r[n:] for r in b]
def find(k):
 f,_,d,t,op,_=load(k);g=gpoly(f);gp=pol.deriv(g)
 ds=json.load(open(HERE/f'triangles_{k}.json'))
 for rr in ds:
    if not all(rr['counts']):continue
    n=dict(rr['deck']);I=list(n);ref=I[0];h=red(d[ref],f)
    R={j:(h if j==ref else red(op[ref,j][0],f)) for j in n}
    coef=times(times([1,8],inv(gp,f),f),inv(h,f),f)
    L={(i,j):trace(times(coef,times(R[i],R[j],f),f),f) for i in I for j in I}
    residual=[i for i in I if L[i,i]!=5];pure=[i for i in I if L[i,i]==5]
    def gram(C):return [[L[i,j] for j in C] for i in C]
    B=next(C for C in combinations(residual,5) if matinv(gram(C)));invB=matinv(gram(B))
    opts=[]
    for ss in product([-1,1],repeat=4):
        s=(1,)+ss;z=[sum(a*b for a,b in zip(row,s)) for row in invB]
        if sum(a*b for a,b in zip(s,z))!=5:continue
        dot=[sum(a*L[i,j] for a,i in zip(z,B)) for j in I]
        if all(abs(dot[j])==1 for j,i in enumerate(I) if i in residual):opts.append((s,z,dot))
    tr=[]
    for subset in combinations(opts,3):
        if any(abs(sum(a*b for a,b in zip(u[0],v[1])))!=1 for u,v in combinations(subset,2)):continue
        # Matrix of new low frame (in Gram basis) = rank one effects for retained + extensions.
        data=[]
        for i in residual:
            sv=[L[i,j] for j in B];z=[sum(a*b for a,b in zip(row,sv)) for row in invB]
            data.append((n[i],sv,z))
        data.extend((1,s,z) for s,z,_ in subset)
        X=[[sum(m*z[i]*s[j] for m,s,z in data)-16*(i==j) for j in range(5)] for i in range(5)]
        tr.append(dict(signs=[u[0] for u in subset],has16=matinv(X) is None))
    print(k,len(opts),len(tr),[r['has16'] for r in tr],flush=True)
    (HERE/f'low_swap_{k}.json').write_text(json.dumps(dict(pure=pure,basis=B,options=[u[0] for u in opts],triples=tr)))
if __name__=='__main__':
 for k in (2300,2689):find(k)

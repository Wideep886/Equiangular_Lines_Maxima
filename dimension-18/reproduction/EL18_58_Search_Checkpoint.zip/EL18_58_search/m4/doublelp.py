from double import *
import numpy as np
from numerical import phase1
def cert(eq,n,varcount):
 A=np.zeros((len(eq),n),dtype=float);b=np.array([int(y)for row,y in eq],dtype=float)
 for i,(row,y)in enumerate(eq):
  for j,x in row.items():A[i,j]=x
 scale=np.maximum(np.max(abs(A),axis=1),1)
 yes,y,nt=phase1(A/scale[:,None],b/scale,maxsteps=8500)
 if yes or y is None:return yes,nt
 y=-y/scale
 for k in (10**3,10**6,10**9,10**11):
  q=[int(v*k+(.5 if v>0 else -.5))for v in y];v=[0]*n;rhs=0
  for t,(row,z) in zip(q,eq):
   if t:
    rhs+=t*z
    for j,x in row.items():v[j]+=t*x
  lows=min(v[:varcount]),min(v[varcount:]);bound=58*lows[0]+1653*lows[1]
  if rhs<bound:return 'Farkas',dict(q=q,lower=lows,rhs=rhs)
 return 'unverified',nt
def solve(i):
 f=P/'full'/f'{i}.json'
 if not f.exists():return
 data=json.loads(f.read_text());r=json.loads((P/'results'/f'{i}.json').read_text());out=[]
 for row in data['rows']:
  ids=row['viable']
  if not ids:continue
  eq,n=systems(r,ids,data['coefficients']);k,s=cert(eq,n,len(ids));out.append([ids,k,s])
  print(i,len(ids),n,k,s if k!='Farkas' else s['rhs'],flush=True)
 (P/'double'/f'{i}.json').write_text(json.dumps(out))
if __name__=='__main__':
 import sys
 (P/'double').mkdir(exist_ok=True)
 for i in sys.argv[1:]:solve(i)

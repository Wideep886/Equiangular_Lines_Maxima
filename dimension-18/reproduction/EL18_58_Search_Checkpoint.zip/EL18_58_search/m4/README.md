# Exact order-58 spectrum screening at multiplicity four of eigenvalue 11

We use the normalization T=(S-11I)/2, chi_T=(t+8)^40 F(t). The original catalogue has 1226 polynomials with a quadruple zero. Exactly 419 of its 252910 post-resultant survivors have this multiplicity. `parents.json` contains these 419 full degree-18 polynomials, indexed by (degree of the squarefree residual, lexicographic integer coefficients). `build.py PATH_TO_survivors_full.jsonl.gz` extracts them and verifies squarefree factor division. A squarefree product of noninteger-root factors of the same multiplicity may be recorded as a single factor. The spectral tests below remain valid for such products.

Run `python3 status.py` for exact stage counts. A missing parent or uncomputed proof is counted open. The scripts use Python 3.9+, C++17, and checked native interval arithmetic. Exact rational calculations validate the final LP infeasibility bounds.

To regenerate from the supplied parent list in an empty unpacked copy, compile `c++ -O3 -std=c++17 fastdeck.cpp -o fastdeck`. The checkpoint can be resumed by running the following in its top directory. For a complete regeneration move results/, second/, third/, pairs/ and moment/span/ out of the directory first. Each completed parent is saved separately.

    python3 batch.py 4
    python3 second.py 3
    python3 third.py
    python3 moment/span.py
    python3 pairtrace.py 2
    python3 status.py

Stage 1 uses the exact normalized principal one-deletion polynomials h and the derivative-sum constraint. It uses the published order-57 modulo-four coefficients and closed-walk restrictions, real-root interlacing of every derivative, and simple integer projector squareclasses. The files fastdeck.py, fastdeck.cpp, check.py, lowmult.py and verify_no11.py are reused from the project's multiplicity-three reproducible package.

For M=(t+8)rad(F), define W(t)=2M(t)(tI-T)^(-1); it has integer polynomial entries. Its diagonal entries are the deletion types h. Any simple root alpha gives a rank-one matrix W(alpha), so W_ij(alpha)^2=h_i(alpha)h_j(alpha). Stage 2 evaluates this identity at simple finite-field roots of the relevant simple squarefree factors, rules out incompatible pairs and enumerates every maximal clique. Each clique must admit a nonnegative integral combination of the deletion polynomials with the required derivative sum. Stage 3 checks the lattice first, then uses exact LP branching on vertex counts. A returned integral vector only passes this necessary condition.

The projection span cuts in moment/span.py use the dimensional cost of simultaneously vanishing eigenspace components. For a repeated integer root, if the diagonal of an integral positive scalar multiple of its projector is in {0,1}, all nonzero projected vectors are parallel because their pairwise inner products are odd integers. The 2-by-2 principal-minor congruence modulo four ensures oddness. The relative bound floor(24r/(25-r)) bounds the cardinality of subsets lying in dimension r; the absolute bound r(r+1)/2 also applies. Every retained inequality is checked by integer Farkas coefficients.

In pairtrace.py the integer projector evaluations q_t of an off-diagonal W_ij, signed so S_ij=+1, satisfy q_t^2 <= h_i(t)h_j(t) and q_t^2 equals this product modulo four. At a simple integer root equality is necessary. Lagrange interpolation of the monic off-diagonal polynomial of degree deg(rad(F))-1 gives sum_alpha W_ij(alpha)/rad(F)'(alpha)=1. At a good odd prime splitting all noninteger simple roots, every such root gives the two possible square roots of h_i h_j. The code eliminates a candidate integer tuple only when interpolation is impossible; a finite set of splitting primes is sufficient for this necessary test. Parents with repeated noninteger roots skip this stage. Cliques are screened by the lattice and Farkas criteria again.

The later `python3 moment/lev.py` and `python3 row.py` stages check additional projection capacities and row equations. For the latter, write D(a)=W(a) at an integer eigenvalue t=a. Sign each off-diagonal polynomial using S_ij, with Q leading coefficient +1. For every proposed vertex of deletion type h, the off-diagonal neighbors must satisfy
`sum Q_j(a)=(11+2a)h(a)` and
`sum Q_j(a)Q_j(b)=delta_ab 2 M'(a) h(a)-h(a)h(b)`.
They must also have deletion-polynomial sum equal to the global target minus h. The polynomial Q is integral. Its parity is uniquely determined by the pair of vertex types through Q²=h_i h_j modulo four. Newton interpolation at the distinct integer roots checks that the value tuple is consistent with integral polynomial coefficients, including the parity of the monic interpolation remainder. The row LP eliminates a vertex type only by a lattice obstruction, an empty neighborhood, or an exact Farkas certificate. After a deletion it tests the remaining global types again. Each file in row/ records all the successive supports tested.

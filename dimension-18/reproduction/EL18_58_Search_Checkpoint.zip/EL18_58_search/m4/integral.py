"""Branch exactly on one fractional vertex count."""
from lpscreen import phase_one
from fractions import Fraction
from pathlib import Path
import json,sys
def integer_deck(deck,active,target):
    columns=[(1,*deck[i][3:]) for i in active]
    def rec(lower,upper):
        if any(l>u for l,u in zip(lower,upper)):return {'kind':'bounds'}
        b=[v-sum(col[j]*v0 for col,v0 in zip(columns,lower)) for j,v in enumerate(target)]
        caps=[i for i,u in enumerate(upper) if u<58 and u!=lower[i]]; free=[i for i,u in enumerate(upper) if u!=lower[i]]
        cc=[(*columns[i],*(int(i==j) for j in caps)) for i in free]
        cc.extend((*([0]*len(b)),*(int(i==j) for j in caps)) for i in caps)
        rhs=(*b,*(upper[i]-lower[i] for i in caps))
        cert=phase_one(cc,rhs)
        if cert['kind']!='primal':return cert
        out=lower[:]
        for j,v in cert['support']:
            if j<len(free):out[free[j]]+=Fraction(v)
        frac=next((i for i,v in enumerate(out) if Fraction(v).denominator>1),None)
        if frac is None:return {'kind':'integral','counts':[(k,int(v)) for k,v in zip(active,out) if v]}
        q=int(out[frac]);up=upper[:];up[frac]=q
        left=rec(lower,up)
        if left['kind']=='integral':return left
        lo=lower[:];lo[frac]=q+1
        right=rec(lo,upper)
        if right['kind']=='integral':return right
        return {'kind':'split','index':active[frac],'floor':q,'left':left,'right':right}
    return rec([0]*len(active),[58]*len(active))
if __name__=='__main__':
    a=[json.loads(x) for x in Path(sys.argv[1]).read_text().splitlines()]
    cl=json.loads(Path(sys.argv[2]).read_text())
    certs={}
    for k,sets in cl.items():
        q=[]
        for j,s in enumerate(sets):
            for l,leaf in enumerate(s['leaves']):
                if leaf['cert']['kind']!='primal':continue
                d=a[int(k)]
                cert=integer_deck(d['deck'],leaf['types'],(58,*d['target'][3:]))
                print(k,j,l,cert['kind'],cert.get('counts'),flush=True)
                q.append([j,l,cert])
        if q:certs[k]=q
    Path(sys.argv[3]).write_text(json.dumps(certs))

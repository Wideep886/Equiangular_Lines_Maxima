from pathlib import Path
from math import isqrt
from itertools import product,combinations_with_replacement
from pairtrace import primes,splits,deriv,val,mul
from row import compatible,rem,certificate
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,sys,time
P=Path(__file__).resolve().parent
def gram(M,H):
 m=M[::-1];h=H[::-1]+[0];n=len(m)-1;A=[[0]*(n+1)for _ in m]
 for l in range(n+1):
  for t in range(l+1,n+1):
   a=2*(h[l]*m[t]-h[t]*m[l])
   for k in range(t-l):A[l+k][t-1-k]+=a
 return [[A[i][j]-h[i]*h[j]for j in range(n-2,-1,-1)]for i in range(n-2,-1,-1)]
def linquo(H,t):
 q=[H[0]]
 for c in H[1:]:q.append(c+t*q[-1])
 assert not q[-1]
 return q[:-1]
def run(i):
 path=P/'full'/f'{i}.json'
 if path.exists():return
 r=json.loads((P/'results'/f'{i}.json').read_text());p0=P/'pairs'/f'{i}.json';u0=P/'row'/f'{i}.json'
 if not p0.exists() or not u0.exists():return
 rows=json.loads(u0.read_text());ids=sorted(set(j for row in rows for j in row['viable']))
 if not ids:return
 data=json.loads(p0.read_text());ls=data['linear'];nodes=tuple(t for t,m in ls);f=data['nonlinear'];L=[1];H=linquo(r['g'],-8);mats={v:gram(r['g'],r['deck'][v]) for v in ids}
 bound=max(isqrt(matrices[k][k]) for matrices in mats.values() for k in range(len(matrices)))
 for t in nodes:L=mul(L,[1,-t])
 for p in primes(250000):
  if p<=2*bound+2 or not splits(f,p):continue
  roots=[z for z in range(p) if val(f,z)%p==0]
  if len(roots)==len(f)-1 and len({v%p for v in list(nodes)+roots})==len(nodes)+len(roots):break
 else:return i,'no prime',bound
 alphas=list(nodes)+roots;N=len(alphas);dh=deriv(H)
 # Lagrange basis in F_p, integer division over linearly split H via synthetic division mod p.
 pol=[]
 for t in alphas:
  q=[1]
  for z in H[1:]:q.append((z+t*q[-1])%p)
  assert q.pop()==0
  w=pow(val(dh,t)%p,-1,p)
  pol.append([z*w%p for z in q])
 sq={j*j%p:j for j in range((p+1)//2)}
 Q={}
 for i1,j1,ts in data['pairs']:
  if i1 not in ids or j1 not in ids:continue
  a=r['deck'][i1];b=r['deck'][j1];ts=compatible(a,b,ts,nodes,L);opts=[];ret=set()
  for t in roots:
   w=val(a,t)*val(b,t)%p
   opts.append([] if w not in sq else sorted({sq[w],-sq[w]%p}))
  for z in product(*opts):
   for tu in ts:
    v=tu+list(z)
    if sum(x*y[0] for x,y in zip(v,pol))%p!=1:continue
    out=tuple((sum(a*b for a,b in zip(v,u))+p//2)%p-p//2 for u in zip(*pol))
    if any(out[k]**2>min(mats[i1][k][k],mats[j1][k][k])for k in range(N)):continue
    err=[a-b for a,b in zip(mul(r['deck'][i1],r['deck'][j1]),[0,0]+mul(out,out))]
    if any(x%4 for x in err) or any(rem(err,f)):continue
    if any(val(out,t)!=v0 for t,v0 in zip(nodes,tu)):continue
    ret.add(out)
  Q[i1,j1]=sorted(ret)
 ans=[]
 ix=list(combinations_with_replacement(range(N),2))
 for row in rows:
  active=row['viable'][:];cuts=[]
  while active:
   reject=None
   for a in active:
    C=mats[a];tar=[57]+[t-v for t,v in zip(r['target'][3:],r['deck'][a][3:])]+[C[j][k] for j,k in ix]
    cols=[(1,*r['deck'][b][3:],*(w[j]*w[k] for j,k in ix)) for b in active for w in Q.get(tuple(sorted((a,b))),())]
    c=certificate(cols,tar)
    if c['kind']!='primal':reject=a;cuts.append((list(active),a,c));break
   if reject is None:break
   active.remove(reject)
   c=certificate([(1,*r['deck'][b][3:])for b in active],(58,*r['target'][3:]))
   if c['kind']!='primal':cuts.append((active[:],None,c));active=[];break
  ans.append(dict(viable=active,cuts=cuts))
 out={'rows':ans,'prime':p,'bound':bound,'coefficients':[[i,j,q] for (i,j),q in Q.items()]}
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(out));tmp.replace(path)
 return i,p,bound,[len(a['viable'])for a in ans],sum(map(len,Q.values()))
if __name__=='__main__':
 (P/'full').mkdir(exist_ok=True)
 with ProcessPoolExecutor(max_workers=3) as ex:
  fs=[ex.submit(run,int(x))for x in sys.argv[1:]]
  for f in as_completed(fs):
   v=f.result()
   if v:print(*v,flush=True)

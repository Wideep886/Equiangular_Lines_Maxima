from fully import gram,Path,P,json
from itertools import combinations_with_replacement
from fractions import Fraction as F
def mod2(eq,n):
 base={}
 for l,(row,b) in enumerate(eq):
  v=sum(1<<i for i,x in row.items() if x%2)|(b%2)<<n
  while v:
   k=(v&-v).bit_length()-1
   if k==n:return False,l
   if k not in base:base[k]=v;break
   v^=base[k]
 return True,len(base)
def mod3(eq,n):
 base={}
 for rowid,(r,b) in enumerate(eq):
  a=sum(1<<i for i,x in r.items() if x%3==1)|int(b%3==1)<<n
  c=sum(1<<i for i,x in r.items() if x%3==2)|int(b%3==2)<<n
  while a|c:
   bit=(a|c)&-(a|c);k=bit.bit_length()-1
   if k==n:return False,rowid
   if c&bit:a,c=c,a
   if k not in base:base[k]=(a,c);break
   y,x=base[k];a,c=(a&~(x|y))|(x&~(a|c))|(c&y),(c&~(x|y))|(y&~(a|c))|(a&x)
 return True,len(base)
def systems(r,ids,labels):
 idx={a:j for j,a in enumerate(ids)};cs=[(a,b,q) for a,b,qs in labels if a in idx and b in idx for q in qs]
 D=len(r['g'])-2;ks=list(combinations_with_replacement(range(D),2))
 deck=r['deck'];G={a:gram(r['g'],deck[a]) for a in ids}
 eq=[];n=len(ids)+len(cs);deltas=[[1,*h[3:]]for h in deck]
 for t,tar in enumerate((58,*r['target'][3:])):
  eq.append(({idx[a]:deltas[a][t]for a in ids},tar))
 for a in ids:
  aopts=[(j,b if i==a else i,q,int(i==a)+int(b==a))for j,(i,b,q) in enumerate(cs,len(ids))if i==a or b==a]
  for k,g in enumerate((58,*r['target'][3:])):
   co={j:w*deltas[b][k]for j,b,q,w in aopts};co[idx[a]]=-(g-deltas[a][k]);eq.append((co,0))
  for i,j in ks:
   co={h:w*q[i]*q[j] for h,b,q,w in aopts};co[idx[a]]=-G[a][i][j];eq.append((co,0))
 return eq,n
def check(i):
 f=P/'full'/f'{i}.json'
 if not f.exists():return
 dat=json.loads(f.read_text());r=json.loads((P/'results'/f'{i}.json').read_text())
 for row in dat['rows']:
  ids=row['viable']
  if not ids:continue
  eq,n=systems(r,ids,dat['coefficients'])
  print(i,len(ids),n,len(eq),mod2(eq,n),mod3(eq,n),flush=True)
if __name__=='__main__':
 import sys
 for i in sys.argv[1:]:check(i)

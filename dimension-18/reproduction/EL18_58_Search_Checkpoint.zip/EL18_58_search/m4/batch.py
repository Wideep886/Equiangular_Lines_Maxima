from fastdeck import native
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import sys,json,lowmult,os,time
P=Path(__file__).parent
def work(q):
 i,row=q;f=P/'results'/f'{i}.json'
 if f.exists():return None
 lowmult.allowed_deck=native
 t=time.monotonic();r=lowmult.screen(row);tmp=f.with_suffix('.tmp');tmp.write_text(json.dumps(r));tmp.replace(f)
 return i,len(r['deck']),sum(b['cert']['kind']=='primal' for b in r['branches']),round(time.monotonic()-t,3)
if __name__=='__main__':
 from concurrent.futures import as_completed
 qs=json.loads((P/'parents.json').read_text());(P/'results').mkdir(exist_ok=True)
 with ProcessPoolExecutor(max_workers=int(sys.argv[1]) if len(sys.argv)>1 else 3) as pool:
  fs=[pool.submit(work,x) for x in enumerate(qs)]
  for f in as_completed(fs):
   q=f.result()
   if q:print(*q,flush=True)

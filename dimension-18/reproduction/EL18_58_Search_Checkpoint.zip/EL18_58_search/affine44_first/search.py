"""Two independent exact computations of selected four deletions in the affine lift."""
from pathlib import Path
import itertools,json
import sys
from importlib.util import spec_from_file_location,module_from_spec
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
s=spec_from_file_location('aff45',HERE.parent/'affine45'/'search.py')
aff=module_from_spec(s);s.loader.exec_module(aff)
solver=aff.solver
from math import lcm
from functools import reduce
from fractions import Fraction
import subprocess,os,tempfile
def main():
    blocks=solver.triples(0);dels=(0,1,2,3)
    assert len({tuple(p//2 for p in blocks[j]) for j in dels})==1
    C=[t for i,t in enumerate(blocks) if i not in dels]
    eq=[[int(k in t)-int(17 in t) for k in range(17)] for t in C]
    B=aff.basis_indices(eq)
    assert len(B)==17
    mat=solver.inv([eq[i] for i in B]);mat.append([-sum(col) for col in zip(*mat)])
    D=reduce(lcm,(a.denominator for r in mat for a in r),1);M=[[int(v*D) for v in r] for r in mat]
    original=(HERE.parent/'affine45'/'scan.cpp').read_text()
    assert original.count('array<array<int,3>,45>')==1
    with tempfile.TemporaryDirectory() as t:
        tmp=Path(t)
        (tmp/'scan.cpp').write_text(original.replace('array<array<int,3>,45>','array<array<int,3>,44>'))
        subprocess.run([os.getenv('CXX','c++'),'-O3','-std=c++17',str(tmp/'scan.cpp'),'-o',str(tmp/'scan')],check=True)
        inp=str(D)+'\n'+'\n'.join(' '.join(map(str,r)) for r in M+C)+'\n'
        lines=subprocess.check_output([tmp/'scan'],input=inp,text=True).splitlines()
    n,edges,m=map(int,lines[0].split());ext=[tuple(map(int,r.split())) for r in lines[1:]]
    assert len(ext)==m
    chosen=ext[:14]
    H=[[2*len(set(a)&set(b))-1 for b in C] for a in C]
    for r,a in zip(H,C):
        for v in chosen:
            val=sum(v[i] for i in a)
            assert abs(val)==D
            r.append(val//D)
    def ip(u,v):
        dot=sum(a*b for a,b in zip(u[:18],v[:18]))
        h,e=u[18:];g,f=v[18:]
        return next(z for z in [-1,1] if (2*D**2*z-dot)**2==h*g and (2*D**2*z-dot)*e*f>=0)
    for i,x in enumerate(chosen):
        H.append([H[k][44+i] for k in range(44)]+[5 if j==i else ip(x,y) for j,y in enumerate(chosen)])
    certificate=aff.common.certify(H,len(H),18)
    # Independently rebuild every vertex, edge, and the clique using the Python rational routines.
    d2,opts,B2=solver.coords(C);adj=[0]*len(opts)
    for i,(x,h,e) in enumerate(opts):
        for j,(y,g,f) in enumerate(opts[:i]):
            v=sum(a*b for a,b in zip(x,y))
            if any((2*d2*d2*z-v)**2==h*g and (2*d2*d2*z-v)*e*f>=0 for z in (-1,1)):
                adj[i]|=1<<j;adj[j]|=1<<i
    assert (len(opts),sum(bin(x).count("1") for x in adj)//2,len(aff.common.max_clique(adj)))==(n,edges,m)
    out=dict(parity=0,deletions=dels,deleted_blocks=blocks[:4],orbit_size_under_affine_group=12,
             core_blocks=C,basis=B,denominator=D,orientations=2**16,candidates=n,edges=edges,maximum=m,
             witness_order=len(H),witness_rank=18,certificate=certificate)
    (HERE/'results.json').write_text(json.dumps(out,indent=1));(HERE/f'gram_{len(H)}.json').write_text(json.dumps(H))
    print(n,edges,m,len(H),certificate)
if __name__=='__main__':main()

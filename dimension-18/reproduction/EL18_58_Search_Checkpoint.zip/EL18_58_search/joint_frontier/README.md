# 有限點對列矩證書

沿用 CHECKPOINT_STATUS.json 的母譜編號。令 Y=(S−11I)/2，g 為其最小多項式，W(t)=2g(t)(tI−Y)⁻¹ 由多項式延拓。q_a=W_ii 是定點 i 的類型，Q_ij=S_ij W_ij。對每個鄰點類型及完整帶號多項式 Q 的非負整數次數 x，同時施加刪點和、一次矩及二次矩：

    Σ x Q(t) = (2t+11)q_a(t)−4g(t)
    Σ x Q(t)Q(u) = 2[g(u)q_a(t)−g(t)q_a(u)]/(u−t)−q_a(t)q_a(u).

相等取極限。簡單根上以一階投影的秩一條件限制帶號值，其他整數根使用二階主子式和模四條件。證書以整數分離向量或整格成員檢查排掉不可能頂點型。對 5≤m≤12 新增排除 203 案，累計 1779/248859。其餘 247080 個未測。

* m=6..11 先前零根列矩剩 6、2、8、3、8、2 案，共 29 案全排。
* m=12 新增 124 個，取 128..255 並略過原格狀樣本的 4 案。120 個錨點排除、另 156、227、241、252 以四取值點的列矩排除。
* m=5 新增 46 個，範圍為 173、203、206 及 209..254 除 228、238、248。44 個錨點排除、235 與 241 進入點對檢查；舊的 129、140、179、185 亦納入。t=−2,−1,0,1 的四點測試排掉五個，179 尚餘 11 型。取 t=−2..3 及 21 個混合二次矩，依序再排掉 2、2、7 型。
* check_cuts.py 用有理二變數插值及獨立的模素數 Lagrange 插值逐張驗算全部 40 份檔案（39 案，其中 179 有兩份）。原有零根支撐的上游重播見 global_resume/verify_zero.py。

以下指令從專案根目錄執行，重建母譜索引、證書及總表。已保存之固定索引與原計算一致，可免用機器速度決定搜尋分界。

    python3 -B joint_frontier/frontier.py anchors
    python3 -B joint_frontier/frontier.py prefix
    python3 -B joint_frontier/frontier.py rows
    python3 -B joint_frontier/check_cuts.py
    python3 -B joint_frontier/frontier.py pure12
    python3 -B m5_scan/status.py --summary
    python3 -B checkpoint_status.py

重建 m=5 的 46 組單點資料另可執行 frontier.py pure5；純 Python 的少數高次根分枝可能較久。最前未測 m=5 為 228，m=6..11 均為 128，m=12 為 256。

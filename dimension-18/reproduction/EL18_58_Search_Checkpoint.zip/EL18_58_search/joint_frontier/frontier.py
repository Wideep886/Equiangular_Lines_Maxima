"""Reproduce the disjoint batches by their canonical indices, then replay exact row certificates."""
import argparse,json,subprocess,sys
from concurrent.futures import ProcessPoolExecutor
from tempfile import TemporaryDirectory
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'global_resume'))
from screen import group_parents,task,init
from degree12 import solve
from rows13 import compatible,possible,indices,factors,native
from lowmult import allowed_deck
FIVE=sorted({173,203,206}|(set(range(209,255))-{228,238,248}))
TWELVE=sorted(set(range(128,256))-{154,185,216,247})
def read(p):return json.loads(p.read_text())
def seeds():
    for f in sorted((P.parent/'global_resume/zero').glob('*/*.json')):
        case=read(f);m,i=case['m'],case['i']
        if 6<=m<=11 and case['open']:
            h=read(P.parent/'global_resume/norms'/str(m)/f'{i}.json')['tail']
            assert len(case['cover'])==1
            yield m,i,h,case['cover'][0][0]
def recover(r,pure=False):
    m,i,h,n,rounds,last=r
    fs=[([1,0],m)]+factors(h)
    g,target,deck=(allowed_deck if pure else native)([([1,8],40)]+fs)
    assert len(deck)==n
    graph=compatible(deck,fs);live=(1<<n)-1
    cs=[(1,*q[3:]) for q in deck];b=(58,*target[3:])
    for count in rounds:
        bad=[a for a in indices(live) if not possible([cs[j] for j in indices(live&graph[a])],tuple(x-y for x,y in zip(b,cs[a])))]
        assert len(bad)==count
        live-=sum(1<<j for j in bad)
    ids=list(indices(live));assert len(ids)==last
    return ids
def selected_rows():
    rows=read(P/'next12.json')
    rows += [json.loads(s) for s in (P.parent/'m5_scan/rows.jsonl').read_text().splitlines()]
    return [r for r in rows if r[-1] and (r[0]==12 or r[1] in [129,140,179,185,235,241])]
def work(job):
    m,i,h,ids=job
    return m,solve((i,h,ids),m,P/str(m))
def work_row(row):return work((*row[:3],recover(row)))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['anchors','prefix','rows','pure5','pure12']);args=ap.parse_args()
    with TemporaryDirectory() as d:
        subprocess.run(['c++','-O3','-std=c++17',str(P.parent/'m13/fastdeck.cpp'),'-o',d+'/fastdeck'],check=True)
        init(d)
        with ProcessPoolExecutor(4,initializer=init,initargs=(d,)) as pool:
            if args.mode=='prefix':
                for x in pool.map(work,seeds()):print(x,flush=True)
            elif args.mode=='rows':
                for x in pool.map(work_row,selected_rows()):print(x,flush=True)
                rec=read(P/'5/179.json')
                print(solve((179,rec['tail'],rec['active']),5,P/'full179',range(-2,4)))
            else:
                gs=group_parents()
                if args.mode=='anchors':
                    for m,which in [(12,TWELVE),(5,FIVE)]:
                        results=list(pool.map(task,[(m,i,gs[m][i],False) for i in which]))
                        if m==12:(P/'next12.json').write_text(json.dumps(results))
                        else:
                            f=P.parent/'m5_scan/rows.jsonl'
                            old={r[1]:r for r in map(json.loads,f.read_text().splitlines())}
                            with f.open('a') as out:
                                for r in results:
                                    if r[1] in old:assert r==old[r[1]]
                                    else:print(json.dumps(r,separators=(',',':')),file=out)
                        print(m,len(results),flush=True)
                else:
                    m=5 if args.mode=='pure5' else 12
                    f=P.parent/'m5_scan/rows.jsonl';rows=list(map(json.loads,f.read_text().splitlines())) if m==5 else read(P/'next12.json')
                    rows=sorted((r for r in rows if r[1] in (FIVE if m==5 else TWELVE)),key=lambda r:r[1])
                    for expect,got in zip(rows,pool.map(task,[(m,r[1],gs[m][r[1]],True) for r in rows])):
                        assert expect==got;print(m,got[1],flush=True)
if __name__=='__main__':main()

"""Reconstruct polynomial labels by rational and modular Lagrange interpolation, then check every cut."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import product, combinations_with_replacement
from math import isqrt
import json,sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'m4_126'))
from verify import at,gram,lagrange,rem,prodpoly,dot
sys.path.insert(0,str(P.parent/'m13'))
from lowmult import allowed_deck
from lattice import lat
from build import factors

def check(path):
    cert=json.loads(path.read_text());full=path.parent.name=='full179'
    m=5 if full else int(path.parent.name);i=cert['index']
    if m in (5,12):
        from frontier import selected_rows,recover
        row=next(r for r in selected_rows() if r[:2]==[m,i]);assert row[2]==cert['tail']
        ids=recover(row,True)
    else:
        base=P.parent/'global_resume'
        case=json.loads((base/'zero'/str(m)/f'{i}.json').read_text())
        assert len(case['cover'])==1 and cert['tail']==json.loads((base/'norms'/str(m)/f'{i}.json').read_text())['tail']
        ids=case['cover'][0][0]
    if full:
        first=json.loads((P/'5/179.json').read_text());assert first['tail']==cert['tail'];ids=first['active']
    fs=[([1,0],m)]+factors(cert['tail'])
    g,target,deck=allowed_deck([([1,8],40)]+fs)
    simple,=[f for f,k in fs if len(f)>2 and k==1]
    integers=[(-f[1],k) for f,k in fs if len(f)==2]
    p=cert['prime']
    assert p>2 and all(p%j for j in range(2,isqrt(p)+1))
    roots=[x for x in range(p) if at(simple,x)%p==0]
    points=[x for x,k in integers]+roots;n=len(points)
    assert n==len(g)-2 and len(set(x%p for x in points))==n
    grams={a:gram(deck[a],g,n) for a in ids}
    assert all(4*row[j]<p*p for G in grams.values() for j,row in enumerate(G))
    basis=[[v.numerator*pow(v.denominator,-1,p)%p for v in row] for row in lagrange(points)]
    square={x*x%p:{x,-x%p} for x in range(p//2+1)}
    points_test=range(-2,4 if full else 2)
    moments=list(combinations_with_replacement(points_test,2))
    labels={}
    for a,b in combinations_with_replacement(sorted(ids),2):
        u,v=deck[a],deck[b]
        z=[at(u,x)*at(v,x) for x in points]
        choices=[]
        for w,(x,k) in zip(z,integers):
            choices.append({t%p for t in range(-isqrt(w),isqrt(w)+1) if (t*t-w)%4==0 and (k>1 or t*t==w)})
        choices += [square.get(w%p,set()) for w in z[len(integers):]]
        result=set();labels[a,b]=result
        if not all(choices):continue
        pivot=max(range(n),key=lambda j:len(choices[j]))
        ix=[j for j in range(n) if j!=pivot]
        inv=pow(basis[pivot][0],-1,p)
        for vals in product(*(choices[j] for j in ix)):
            s=(1-sum(x*basis[j][0] for j,x in zip(ix,vals)))*inv%p
            if s not in choices[pivot]:continue
            vec=list(zip(ix,vals))+[(pivot,s)]
            q=[(sum(x*basis[j][h] for j,x in vec)+p//2)%p-p//2 for h in range(n)]
            if any(t*t>min(grams[a][j][j],grams[b][j][j]) for j,t in enumerate(q)):continue
            def bad(x,k):
                d=at(u,x)*at(v,x)-at(q,x)**2
                return d<0 or d%4 or (k==1 and d!=0)
            if any(bad(x,k) for x,k in integers+[(-8,40)]):continue
            delta=[x-y for x,y in zip(prodpoly(u,v),[0,0]+prodpoly(q,q))]
            if any(x%4 for x in delta) or any(rem(delta,simple)):continue
            ev={x:at(q,x) for x in points_test}
            result.add((*ev.values(),*(ev[x]*ev[y] for x,y in moments)))
    live=set(ids)
    for step in cert['ledger']:
        assert len({a for a,c in step})==len(step)
        for a,c in step:
            assert a in live
            cols={(1,*deck[b][3:],*v) for b in live for v in labels[min(a,b),max(a,b)]}
            G=grams[a];q=deck[a]
            rhs=(57,*(x-y for x,y in zip(target[3:],q[3:])),*((2*x+11)*at(q,x)-4*at(g,x) for x in points_test),
                 *(sum(G[j][k]*x**(n-j-1)*y**(n-k-1) for j in range(n) for k in range(n)) for x,y in moments))
            if c['kind']=='empty':assert not cols
            elif c['kind']=='lattice':assert not lat(sorted(cols),rhs)
            else:
                w=c['y'];assert len(w)==len(rhs) and dot(w,rhs)<0 and all(dot(w,v)>=0 for v in cols)
        live.difference_update(a for a,c in step)
    assert sorted(live)==cert['active'] and bool(live)==cert['open']
    return m,i,len(ids)
if __name__=='__main__':
    files=sorted(P.glob('[0-9]*/*.json'))+[P/'full179/179.json']
    assert len(files)==40
    with ProcessPoolExecutor(4) as pool:
        for row in pool.map(check,files):print(*row,flush=True)

"""Verify the fixed-Latin-core maximum of 57 in real dimension 18."""
from itertools import product
from pathlib import Path
from tempfile import TemporaryDirectory
from subprocess import run
from shutil import copy
from sys import executable
from collections import Counter
import os

def dot(a,b): return sum(x*y for x,y in zip(a,b))
def size(mask): return bin(mask).count('1')
def vertices(mask):
    while mask:
        bit=mask&-mask
        mask^=bit
        yield bit.bit_length()-1

def maximal_cliques(graph):
    def visit(clique,possible,past):
        if not possible and not past:
            yield clique
            return
        if not possible:return
        pivot=max(vertices(possible|past),key=lambda v:size(possible&graph[v]))
        for v in vertices(possible&~graph[pivot]):
            yield from visit(clique|(1<<v),possible&graph[v],past&graph[v])
            possible^=1<<v
            past|=1<<v
    yield from visit(0,(1<<len(graph))-1,0)

def components(graph,mask):
    while mask:
        group=front=mask&-mask
        mask^=group
        while front:
            bit=front&-front
            front^=bit
            next_set=graph[bit.bit_length()-1]&mask
            mask^=next_set
            group|=next_set
            front|=next_set
        yield group

def verify_integer_groups(path):
    alphabets=[]
    with path.open() as f:
        for line in f:
            _,n=map(int,line.split())
            alpha={tuple(map(int,next(f).split())) for _ in range(n)}
            assert len(alpha)==n and all(dot(x,x)==54 for x in alpha)
            alphabets.append(frozenset(alpha))
    assert len(alphabets)==22 and Counter(map(len,alphabets))==Counter({30:20,84:2})
    assert len(set(alphabets))==2
    V=sorted(set.union(*(set(a) for a in alphabets)))
    assert len(V)==84 and frozenset(V) in alphabets
    gram=[[dot(x,y) for y in V] for x in V]
    g=[sum(1<<j for j,v in enumerate(row) if i!=j and v%18==0) for i,row in enumerate(gram)]
    nonorth=[sum(1<<j for j,v in enumerate(row) if i!=j and v) for i,row in enumerate(gram)]
    families=list(maximal_cliques(g))
    assert len(families)==4 and all(size(z)==30 for z in families)
    for family in families:
        blocks=list(components(nonorth,family))
        assert len(blocks)==3
        for block in blocks:
            rows=list(vertices(block))
            assert len(rows)==10 and all(abs(gram[i][j])==18 for i in rows for j in rows if i!=j)
            opts=list(product(rows,(0,1),(-1,1)))
            graph=[]
            for i,h,a in opts:
                graph.append(sum(1<<k for k,(j,t,b) in enumerate(opts) if abs(gram[i][j]+36*(h==t)*a*b)==18))
            assert max(size(z) for z in maximal_cliques(graph))==7
    print('Maximal integral projection sets: four of size 30. All twelve 40-vertex graphs have clique number 7.')

def verify_lower_bound():
    # A common choice of 21 directions from MSY Proposition 5.2.
    C=[((0,2,4),-1),((0,3,5),-1),((1,2,5),-1),((1,3,4),-1),
       ((0,1,2),1),((2,3,4),1),((0,4,5),1)]
    add=[]
    for b in range(3):
        for I,e in C:
            p=[0]*18
            for i in range(6):p[6*b+i]=3 if i in I else -3
            z=[(0,e,1),(1,0,e),(e,1,0)][b]
            add.append((p,z))
    for i,(p,z) in enumerate(add):
        assert dot(p,p)+18*dot(z,z)==90
        for q,w in add[:i]:
            assert abs(dot(p,q)+18*dot(z,w))==18
        assert all(abs(p[r]+p[6+c]+p[12+k])==3 for r,c,k in product(range(6),repeat=3))
    print('21 explicit compatible additions to every Latin core verified.')

def main():
    here=Path(__file__).resolve().parent
    verify_lower_bound()
    with TemporaryDirectory() as temp:
        work=Path(temp)
        for name in ['latin_reps.cpp','check_anchors.cpp','projected_signatures.py']:
            copy(here/name,work/name)
        for name in ['latin_reps','check_anchors']:
            run([os.environ.get('CXX','c++'),'-std=c++17','-O3',str(work/f'{name}.cpp'),'-o',str(work/name)],check=True)
        with (work/'reps.txt').open('w') as f:run([str(work/'latin_reps')],stdout=f,check=True)
        run([executable,str(work/'projected_signatures.py')],check=True,capture_output=True)
        verify_integer_groups(work/'signatures.dat')
        proc=run([str(work/'check_anchors'),str(work/'signatures.dat')],check=True,capture_output=True,text=True)
        print(proc.stdout.splitlines()[-2])
        print(proc.stdout.splitlines()[-1])

if __name__=='__main__':main()

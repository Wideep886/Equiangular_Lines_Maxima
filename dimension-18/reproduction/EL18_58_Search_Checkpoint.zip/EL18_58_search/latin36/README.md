# All 36-line cores from order-six Latin squares extend to at most 57 in real dimension 18

**Theorem.** For every Latin square L of order six, the maximum cardinality of a real equiangular line set in dimension 18 containing its 36-line core is exactly 57. The 36 required vectors are the Latin part of the construction in Munemasa, Szöllősi and Yoshino, Theorem 6.1, equation (6.1), arXiv:2606.10421v2. The other lines can lie anywhere in real dimension 18. The lower bound comes from the cited construction. The upper bound allows all 22 proposed additions to vary simultaneously. General 58-line sets that do not contain such a core remain open.

Run `python3 verify.py` with Python 3.9+ and a C++17 compiler. All inequalities, Gram tests, membership tests, clique decisions and row operations are exact. The verifier regenerates every input from the coordinate and Latin-square definitions. The coordinate formula and enumeration below explain how the finitely many checks cover arbitrary real vectors.

## 1. What the 36 lines already determine

Let W be the sum-zero subspace of real six-space and let u_i=(1/6)1−e_i for i=1,…,6. Work in W³ ⊕ R³. The 36 core vectors are

    √2 (u_i, u_j, u_{L(i,j)}, 0),     1 ≤ i,j ≤ 6.

They have squared norm five and pairwise inner products ±1. A further line has a squared-norm-five representative x=(U,z) with z in R³ and U=−(p,q,r)/(3√2) in W³. Its inner product with cell (i,j) is s_ij=(p_i+q_j+r_{L(i,j)})/3. Compatibility means s_ij is a sign.

Summing the six signs in each row, column or symbol class gives twice the corresponding entry of p,q,r. Thus each entry is an integer in [−3,3]. In the sum of the 36 squared equations the cross terms vanish by the Latin-square property and the zero sums. Hence

    ||(p,q,r)||²=54,     ||U||²=3,     ||z||²=2.

Let a=(p,q,r) and orient x by choosing its first nonzero coordinate in a positive. For two lines with triples a,b and respective final components z,w, the inner product is

    (x,y) = (a,b)/18 + (z,w).

## 2. All possible 15-dimensional projections

Enumerate the 9,408 reduced Latin squares by filling each cell subject to its row and column. Group them by isotopy. Given a square, any reduced isotope is determined by the original first row, original first column, and a relabelling of the symbols that sends their common entry to zero. This gives 22 representatives. Isotopies act by orthogonal permutations of the coordinates in W³.

For each representative, the additive functions p_i+q_j+r_{L(i,j)} on the 36 cells span a subspace of dimension 15, as verified by rational row reduction. Signs on any 15 independent cells determine the function on all 36. Fix one sign up to simultaneous reversal and enumerate 2¹⁴ assignments, requiring all cell values after normalization to be signs. Recover a by the half-sums above and verify all 36 sums. In the chosen coordinates 20 representatives yield the same 30 projection directions, and two yield the same 84 directions containing those 30. Write A for this 84-vector alphabet. It suffices to use A for all subsequent upper bounds.

## 3. An extension of size 58 would force integral projected pairings

Suppose a proposed 58-line set uses two additions with triples a,b and full inner product s=±1 for which (a,b)/18 is nonintegral. Put d=18s−(a,b), so (z_a,z_b)=d/18. Values with |d|>36 violate Cauchy–Schwarz. If |d|=36, the projected product s−(z_a,z_b) is already an integer. For all remaining possibilities the two residual vectors are independent. Up to isometry their Gram matrix is

    (1/18) [ 36  d ]
           [  d 36 ],

with Δ=1296−d² positive. A third addition with projected triple c must have full inner products s_1,s_2 in {−1,1} with these anchors. Set

    v=(18s_1−(a,c),18s_2−(b,c)),       M=[ 36  −d ].
                                            [ −d   36 ]

Then v/18 is the pair of its residual inner products with the anchors. Solving its orthogonal projection onto their plane leaves squared normal height H/(18Δ), where H=36Δ−vᵀMv. Retain H≥0 and consider both normal signs ε, counting a zero height only once.

For two candidate additions (c,v,H,ε) and (c′,v′,H′,ε′), their full inner product multiplied by 18Δ equals

    Δ(c,c′) + vᵀMv′ + εε′ √(HH′).

The verifier tests equality with ±18Δ by comparing signs and integer squares. Thus its graph describes exactly which additions are simultaneously compatible. After the two anchors, a 58-line set would require a 20-clique.

The direct verifier loops through all 6,972 unordered distinct projected-pair/sign combinations of A and selects all 3,348 nonintegral combinations with |d|<36. Equal projected triples have integral projected product 3. Every one of the 3,348 resulting graphs has clique number below 20, certified by branch and bound with a proper coloring upper bound at every node. The numbers of graphs on 276,386,388,436,440,460 vertices are respectively 864,432,108,432,216,1296. This test uses no orbit pruning or exclusions transferred from other graphs. Consequently every two added vectors in a 58-line set must satisfy (a,b)/18 integral.

## 4. Integral projected triples cannot provide 22 additions

Join a,b in A if (a,b) is divisible by 18. A direct enumeration of maximal cliques finds four, all of size 30. Each splits into three mutually orthogonal blocks of 10 projected directions. Inside a block, any two distinct directions have absolute projected inner product 1. These structural checks use the integer dot products of the explicit triples.

If only one block is occupied, at most 20 additions are possible. Indeed, each fixed projected triple can occur on at most two different lines: its projected squared norm is 3, and compatibility of two copies forces the corresponding norm-two residuals to be opposite.

If more than one block is occupied, the residual directions within each occupied block are either parallel or orthogonal. For distinct projections in that block, the full and projected inner products are each ±1, so the residual inner product is 0 or ±2. For identical projections the residuals are opposite. A block cannot use three orthogonal residual axes when another block is occupied: a residual from the other block has absolute inner product 1 with each of the three squared-norm-two axis vectors, yielding squared norm 3/2 instead of its required 2. Thus each block uses at most two orthogonal axes.

Choose two such axes per block. Each of the ten projected directions can have either sign along either axis, giving 40 possible additions there. Their compatibility is an integer test independent of the choice of axes. Each of the twelve block graphs, three for each of the four 30-cliques, has clique number 7. Hence the three blocks together provide at most 21 additions, contradicting the required 22.

Finally, Proposition 5.2 and Theorem 6.1 of the cited paper give 21 compatible Pasch additions to every Latin core. The verifier checks the same 21 explicit vectors against all 216 possible Latin triples and against one another. The minimum and maximum therefore agree at 57.

Source: A. Munemasa, F. Szöllősi and K. Yoshino, *Sets of equiangular lines in dimension 18 constructed from A₅³ ⊕ A₁⁴*, arXiv:2606.10421v2. https://arxiv.org/abs/2606.10421

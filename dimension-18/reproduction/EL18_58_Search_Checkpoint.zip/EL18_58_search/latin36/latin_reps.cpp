#include <algorithm>
#include <array>
#include <functional>
#include <iostream>
#include <set>
#include <stdexcept>
#include <vector>
using namespace std;
using L = array<int, 36>;
using P = array<int, 6>;
vector<P> perms;
vector<L> reduced, reps;
void latin() {
  P base{0, 1, 2, 3, 4, 5};
  do {
    perms.push_back(base);
  } while (next_permutation(base.begin(), base.end()));
  L l{};
  int rowbit[6]{}, colbit[6]{};
  for (int i = 0; i < 6; i++) {
    l[i] = l[6 * i] = i;
    rowbit[0] |= 1 << i;
    colbit[0] |= 1 << i;
    rowbit[i] |= 1 << i;
    colbit[i] |= 1 << i;
  }
  function<void(int)> fill = [&](int k) {
    if (k == 25) {
      reduced.push_back(l);
      return;
    }
    int r = 1 + k / 5, c = 1 + k % 5, open = (~(rowbit[r] | colbit[c])) & 63;
    while (open) {
      int b = open & -open;
      open ^= b;
      rowbit[r] ^= b;
      colbit[c] ^= b;
      l[6 * r + c] = __builtin_ctz(b);
      fill(k + 1);
      rowbit[r] ^= b;
      colbit[c] ^= b;
    }
  };
  fill(0);
  if (reduced.size() != 9408)
    throw runtime_error("latin count");
  set<L> todo(reduced.begin(), reduced.end());
  while (!todo.empty()) {
    L a = *todo.begin();
    reps.push_back(a);
    // Choice of first row, first column and relabelling of symbols uniquely
    // determines a reduced isotope.
    for (int i = 0; i < 6; i++)
      for (int j = 0; j < 6; j++)
        for (const P &p : perms) {
          if (p[a[6 * i + j]] != 0)
            continue;
          L h{};
          for (int r = 0; r < 6; r++)
            for (int c = 0; c < 6; c++)
              h[6 * p[a[6 * r + j]] + p[a[6 * i + c]]] = p[a[6 * r + c]];
          todo.erase(h);
        }
  }
  if (reps.size() != 22)
    throw runtime_error("isotopy count");
}
int localnw;
int main() {
  latin();
  for (const auto &l : reps) {
    for (auto t : l)
      cout << t;
    cout << '\n';
  }
}

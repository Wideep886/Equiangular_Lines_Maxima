from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import lcm
from functools import reduce
p=Path(__file__).resolve().parent
def signature(L):
    # Each of the three effect vectors has six coordinates and sums to zero.
    cells=[[int(q==v)-int(v==5) for v in [i,j,L[6*i+j]] for q in range(5)] for i in range(6) for j in range(6)]
    A=[list(map(F,col))for col in zip(*cells)]
    B=[]
    for j in range(36):
        k=len(B);pi=next((i for i in range(k,15) if A[i][j]),None)
        if pi is None:continue
        A[k],A[pi]=A[pi],A[k]
        u=A[k][j];A[k]=[x/u for x in A[k]]
        for i in range(15):
            if i!=k and A[i][j]:
                u=A[i][j];A[i]=[x-u*y for x,y in zip(A[i],A[k])]
        B.append(j)
        if len(B)==15:break
    assert len(B)==15
    D=reduce(lcm,(x.denominator for row in A for x in row))
    tests=sorted([[(i,int(v*D)) for i,v in enumerate(c) if v]for j,c in enumerate(zip(*A)) if j not in B],key=len)
    out=[]
    cols=[tuple(int(x*D)for x in col) for col in zip(*A)]
    for bits in product([-1,1],repeat=14):
        s=(1,)+bits
        if any(abs(sum(s[i]*v for i,v in line))!=D for line in tests):continue
        raw=[sum(x*y for x,y in zip(c,s)) for c in cols]
        assert all(x in [-D,D] for x in raw)
        full=[x//D for x in raw]
        rows=[sum(full[i*6:i*6+6])//2 for i in range(6)]
        cs=[sum(full[i::6])//2 for i in range(6)]
        ss=[sum(x for x,y in zip(full,L)if y==i)//2 for i in range(6)]
        assert all(rows[i]+cs[j]+ss[L[i*6+j]]==3*full[i*6+j] for i in range(6)for j in range(6))
        data=rows+cs+ss
        if next(x for x in data if x)<0:data=[-x for x in data]
        out.append(data)
    return out
with (p/'signatures.dat').open('w') as out:
    for i,row in enumerate((p/'reps.txt').read_text().splitlines()):
        sig=signature(list(map(int,row)))
        print(i,len(sig),file=out)
        for q in sig:print(*q,file=out)
        print(i,len(sig),flush=True)

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <numeric>
#include <set>
#include <stdexcept>
#include <vector>
using namespace std;
using W = uint64_t;
using L = long long;
using Weight = array<int, 18>;
map<int, int> sizes;
struct Pt {
  int k, a, b, H, sign, adj0, adj1;
};
const int cap = 704, words = 11;
struct Bits {
  array<W, words> b{};
  void set(int i) { b[i >> 6] |= W(1) << (i & 63); }
  void erase(int i) { b[i >> 6] &= ~(W(1) << (i & 63)); }
};
int first(const Bits &p, int width) {
  for (int j = 0; j < width; j++)
    if (p.b[j])
      return 64 * j + __builtin_ctzll(p.b[j]);
  return -1;
}
bool feasible20(const vector<vector<int>> &neighbors, vector<int> &witness) {
  int n = neighbors.size(), width = (n + 63) / 64;
  if (n < 20)
    return false;
  if (n > cap)
    throw runtime_error("local graph too large");
  vector<int> order(n), place(n);
  iota(order.begin(), order.end(), 0);
  sort(order.begin(), order.end(),
       [&](int i, int j) { return neighbors[i].size() > neighbors[j].size(); });
  for (int i = 0; i < n; i++)
    place[order[i]] = i;
  vector<Bits> adj(n);
  Bits all;
  for (int i = 0; i < n; i++) {
    all.set(i);
    for (int j : neighbors[order[i]])
      adj[i].set(place[j]);
  }
  int cur[21];
  function<bool(Bits, int)> dfs = [&](Bits p, int dep) {
    if (dep == 20) {
      witness.clear();
      for (int i = 0; i < 20; i++)
        witness.push_back(order[cur[i]]);
      return true;
    }
    Bits free = p;
    int vs[cap], cs[cap], cnt = 0, col = 0;
    while (first(free, width) >= 0) {
      Bits blk = free;
      col++;
      int v;
      while ((v = first(blk, width)) >= 0) {
        blk.erase(v);
        free.erase(v);
        for (int j = 0; j < width; j++)
          blk.b[j] &= ~adj[v].b[j];
        vs[cnt] = v;
        cs[cnt++] = col;
      }
    }
    for (int i = cnt - 1; i >= 0; i--) {
      if (dep + cs[i] < 20)
        return false;
      int v = vs[i];
      Bits q = p;
      for (int j = 0; j < width; j++)
        q.b[j] &= adj[v].b[j];
      cur[dep] = v;
      if (dfs(q, dep + 1))
        return true;
      p.erase(v);
    }
    return false;
  };
  return dfs(all, 0);
}
int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  ifstream in(argv[1]);
  int id, n;
  set<set<Weight>> alphabets;
  set<Weight> sup;
  while (in >> id >> n) {
    set<Weight> a;
    for (int i = 0; i < n; i++) {
      Weight w;
      for (int &x : w)
        in >> x;
      a.insert(w);
    }
    if ((int)a.size() != n)
      throw runtime_error("duplicate");
    alphabets.insert(a);
    sup.insert(a.begin(), a.end());
  }
  if (alphabets.size() != 2 || alphabets.begin()->empty() || sup.size() != 84 ||
      !alphabets.count(sup))
    throw runtime_error("uncovered projected alphabet");
  vector<Weight> ps(sup.begin(), sup.end());
  n = ps.size();
  int K[85][85];
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      K[i][j] = inner_product(ps[i].begin(), ps[i].end(), ps[j].begin(), 0);
  int count = 0, total = 0, calls = 0;
  int start = 0, stop = n;
  // H <= 36*1296 = 46656; cap is small enough for signed 64-bit radical
  // products.
  for (int i = start; i < stop; i++) {
    for (int j = 0; j < i; j++)
      for (int sign : {-1, 1}) {
        total++;
        int d = 18 * sign - K[i][j];
        if (abs(d) >= 36 || d % 18 == 0)
          continue;

        count++;
        int det = 1296 - d * d;
        vector<Pt> options;
        for (int k = 0; k < n; k++)
          for (int s : {-1, 1})
            for (int t : {-1, 1}) {
              int a = 18 * s - K[i][k], b = 18 * t - K[j][k];
              int aa = 36 * a - d * b, bb = 36 * b - d * a;
              int h = 36 * det - (a * aa + b * bb);
              if (h < 0)
                continue;
              options.push_back({k, a, b, h, 1, aa, bb});
              if (h)
                options.push_back({k, a, b, h, -1, aa, bb});
            }
        sizes[(int)options.size()]++;
        int m = options.size();
        if (m < 20)
          continue;

        vector<vector<int>> edges(m);
        for (int k = 0; k < m; k++)
          for (int l = 0; l < k; l++) {
            auto x = options[k], y = options[l];
            L q = L(det) * K[x.k][y.k] + x.a * y.adj0 + x.b * y.adj1;
            L prod = L(x.H) * y.H;
            int orient = x.sign * y.sign;
            bool okay = false;
            for (int target : {-18, 18}) {
              L t = target * det - q;
              if (t * orient >= 0 && t * t == prod) {
                okay = true;
                break;
              }
            }
            if (okay) {
              edges[k].push_back(l);
              edges[l].push_back(k);
            }
          }
        vector<int> witness;
        calls++;
        if (feasible20(edges, witness)) {
          cout << "FOUND 58 anchors " << i << " " << j << " orientation "
               << sign << " det " << det << endl;
          cout << "projections" << endl;
          for (int v : {i, j}) {
            for (auto u : ps[v])
              cout << u << " ";
            cout << endl;
          }
          for (int v : witness) {
            auto x = options[v];
            for (auto u : ps[x.k])
              cout << u << " ";
            cout << " residual " << x.a << " " << x.b << " " << x.H << " "
                 << x.sign << endl;
          }
          return 5;
        }
      }
    if (i % 10 == 0) {
      cout << "index " << i << " examined " << count << endl;
    }
  }
  if (total != 6972 || count != calls)
    throw runtime_error("coverage mismatch");
  cout << "completed pair signs " << total << " independent pairs " << count
       << " tested graphs " << calls << endl;
  cout << "graph sizes";
  for (auto [k, s] : sizes)
    cout << " " << k << ":" << s;
  cout << endl;
}

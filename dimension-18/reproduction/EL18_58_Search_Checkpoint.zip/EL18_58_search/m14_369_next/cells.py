"""Enumerate joint coordinates on the rational rank-two plane and both conjugate simple eigenlines."""
from itertools import product
from functools import lru_cache
from verify import *
T=[0,1,3,4,5,6]
R={0:(3,2),1:(1,-2),3:(5,-2),4:(0,0),5:(2,-4),6:(4,0)}
Z={0:[(0,0)],1:[(1,0),(-1,0)],3:[(2,0),(-2,0),(0,2),(0,-2)],4:[(0,1)],5:[(0,1),(0,-1)],6:list(product((1,-1),repeat=2))}
d=json.load(open(P/'m14'/'quartic_results.json'))[369]['final_decks'][0]
@lru_cache(None)
def signs(i,x,j,y):
    out=set()
    for p,c in options(d[i],d[j]):
        if c not in (0,1):continue
        rem=remainder(mul(d[1],p));pair=remainder(mul(R[i],R[j]))
        for s in (-1,1):
            if [s*a for a in rem]==pair and s*ev(p,2)==8*sum(a*b for a,b in zip(x,y)):out.add(s)
    return out
def splits(n,k):
    if k==1:yield (n,);return
    for a in range(n+1):
        for rest in splits(n-a,k-1):yield (a,)+rest
def decorations(counts):
    n=dict(zip(T,counts))
    horizontal=(40-n[1]-n[6])//4
    if not 0<=horizontal<=n[3] or 4*horizontal+n[1]+n[6]!=40:return
    for d6 in splits(n[6],4):
        if sum(a*x*y for a,(x,y) in zip(d6,Z[6])):continue
        for u in range(horizontal+1):
            for v in range(n[3]-horizontal+1):
                d3=(u,horizontal-u,v,n[3]-horizontal-v)
                for t in range(n[5]+1):
                    d5=(t,n[5]-t)
                    for a in range(n[1]+1):
                        dd={0:(n[0],),1:(a,n[1]-a),3:d3,4:(n[4],),5:d5,6:d6}
                        cells=[(i,z,k) for i in T for z,k in zip(Z[i],dd[i]) if k]
                        if any(sum(k*R[i][p]*z[h] for i,z,k in cells) for p,h in product(range(2),repeat=2)):continue
                        yield cells
def possible(cells):
    for i,x,n in cells:
        # For a row of this cell, solve both conjugate eigenvector equations,
        # and both real coordinate equations on the eigenvalue 15 plane.
        a,b=R[i]
        goal=(5*a+2*b,4*a+11*b,15*x[0],15*x[1])
        spans=[]
        for j,y,k in cells:
            k-=int((i,x)==(j,y))
            if not k:continue
            s=signs(i,x,j,y)
            if not s:return False
            if len(s)==1:
                u=next(iter(s))*k
                goal=tuple(t-u*v for t,v in zip(goal,R[j]+y))
            else:
                spans.append((k,R[j]+y))
        # Feasible net sign counts for all cells with two allowed signs.
        if not solve(spans,goal):return False
    return True
def solve(spans,goal):
    # Set u=2p-k with 0<=p<=k.
    from verify_quadratic_0020 import feasible_counts
    t=[g+sum(k*v[i] for k,v in spans) for i,g in enumerate(goal)]
    if any(v%2 for v in t):return False
    if not spans:return not any(t)
    return bool(feasible_counts([v for k,v in spans],[v//2 for v in t],[k for k,v in spans],first_only=True))
def main():
    # All decks entering this geometry contain both axis-defining types.
    ds=json.load(open(HERE/'remaining_decks.json'));result=[]
    assert all(n[1]>0 and n[3]>0 for n in ds)
    for i in T:
        assert remainder(mul(R[i],R[i]))==remainder(mul(d[1],d[i]))
        def axis_values(j):
            return {s*ev(p,2) for p,c in options(d[i],d[j]) if c in (0,1) for s in (-1,1)}
        implied={(x//8,y//8) for x in axis_values(1) for y in axis_values(4)
                 if x*x+y*y==8*ev(d[i],2)}
        assert all(v%8==0 for j in (1,4) for v in axis_values(j))
        allowed=set(Z[i]) if i!=4 else {(0,1),(0,-1)}
        assert implied==allowed

    for counts in ds:
        dec=list(decorations(counts))
        survive=[x for x in dec if possible(x)]
        print(counts,len(dec),len(survive),flush=True)
        result.append(dict(counts=counts,decorations=len(dec),survivors=survive))
    (HERE/'cells.json').write_text(json.dumps(result))
if __name__=='__main__':main()

"""Exhaust normalized two-point cofactors for spectrum 369 and the rank-two square class."""
from pathlib import Path
import json,sys
from math import isqrt
from itertools import combinations_with_replacement
HERE=Path(__file__).resolve().parent
P=HERE.parent
sys.path.insert(0,str(P/'m14'))
sys.path.insert(0,str(P/'m15_upstream'/'source'/'output'))
from verify_quadratic_0020 import coefficient_gram,gram_column,evaluate as ev
from signed import hull
from pair14 import lat,targets
from verify_no11 import mul
F=[1,3,-2]
M=[1,9,0,-60,32,0]
def remainder(q):
    q=list(q)
    for i in range(len(q)-2):
        a=q[i]
        q[i+1]-=3*a
        q[i+2]+=2*a
    return q[-2:]
def sqclass(n):
    d=2
    while d*d<=n:
        while n%(d*d)==0:n//=d*d
        d+=1
    return n

def options(q,r):
    h=mul(q,r)
    U,V=remainder(h)
    # (a*t+b)^2 = (2ab-3a²)t + (b²+2a²).
    pairs=[]
    for a in range(-isqrt(V//2),isqrt(V//2)+1):
        m=V-2*a*a
        b=isqrt(m)
        if b*b!=m:continue
        for b in {b,-b}:
            if a*(2*b-3*a)!=U:continue
            for c in range(-30,27):
                # t³ ≡ 11t−6, t² ≡ −3t+2 modulo F.
                p=[1,c,a-11+3*c,b+6-2*c]
                assert remainder(p)==[a,b]
                hh=mul(p,p); sub=[x-y for x,y in zip(h,[0,0]+hh)]
                if any(x%4 for x in sub):continue
                if any(ev(p,t)**2>ev(q,t)*ev(r,t) for t in (-8,0,2)):continue
                delta=ev(q,2)*ev(r,2)-ev(p,2)**2
                pairs.append((p,sqclass(delta) if delta else 0))
    return pairs

def main():
    profile=json.load(open(P/'m14'/'quartic_results.json'))[369]
    rec=next(r for r in json.load(open(P/'m14'/'ledger.json')) if r['index']==369)
    branch,=rec['branches']
    d=branch['deck'];alive=branch['signed'];target=targets(profile)
    op={(i,j):options(d[i],d[j]) for i in alive for j in alive}
    classes=sorted({z for t in op.values() for _,z in t})
    print('classes',classes)
    log=[]
    for c in classes:
        support=alive[:];rounds=[]
        while support:
            drop=[]
            for i in support:
                x=[a-b for a,b in zip(target,d[i])]+coefficient_gram(M,d[i],d[i],d[i],True)
                cols=[tuple(d[j]+gram_column(p)) for j in support for p,h in op[i,j] if h in (0,c)]
                if not cols or not lat(cols,x) or not hull(cols,x):drop.append(i)
            if not drop:break
            rounds.append(drop);support=[i for i in support if i not in drop]
        feasible=bool(support and lat([d[i] for i in support],target) and hull([d[i] for i in support],target))
        print(c,support,feasible,rounds,flush=True)
        log.append(dict(squareclass=c,support=support,feasible=feasible,rounds=rounds))
    (HERE/'results.json').write_text(json.dumps(log,indent=1))
if __name__=='__main__':main()

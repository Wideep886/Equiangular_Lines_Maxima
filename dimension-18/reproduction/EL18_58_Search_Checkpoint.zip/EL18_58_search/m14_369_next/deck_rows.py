from verify import *
from verify_quadratic_0020 import feasible_counts
def main():
    R=json.load(open(P/'m14'/'quartic_results.json'))[369]
    d=R['final_decks'][0];I=[0,1,3,4,5,6];t=targets(R)
    ds=feasible_counts([d[i] for i in I],t,[58]*6)
    opt={(i,j):[p for p,c in options(d[i],d[j]) if c in (0,1)] for i in I for j in I}
    keep=[]
    for num,counts in enumerate(ds):
        cert=[]
        for i,ni in zip(I,counts):
            if not ni:continue
            columns=[];bounds=[];marks=[]
            ts=[n-(i==j) for j,n in zip(I,counts)]
            target=ts+coefficient_gram(M,d[i],d[i],d[i],True)
            # Subtract the compulsory base contribution for each neighboring type.
            residual=target[len(I):]
            for j,n in zip(I,ts):
                if not n:continue
                gs=[gram_column(p) for p in opt[i,j]]
                if not gs:
                    cert.append(i);break
                g=gs[0]
                residual=[x-n*y for x,y in zip(residual,g)]
                if len(gs)>1:
                    for h in gs[1:]:
                        cols=tuple(u-v for u,v in zip(h,g))
                        columns.append(cols);bounds.append(n);marks.append(j)
            else:
                if not columns:
                    if any(residual):cert.append(i)
                else:
                    if not lat(columns,residual):cert.append(i)
                    elif not feasible_counts(columns,residual,bounds,first_only=True):cert.append(i)
            if cert:break
        if not cert:
            keep.append(counts)
            print(len(keep),counts,flush=True)
    print('final',len(keep))
    (HERE/'remaining_decks.json').write_text(json.dumps(keep))
if __name__=='__main__':main()

"""Check the exact low-dimensional products, the ten anchor pairs' residual geometry, and lift."""
from fractions import Fraction as Q
from cells import *
from itertools import product
def div_in_field(u,v):
    a,b=remainder(v);p,q=remainder(u)
    den=b*(b-3*a)-2*a*a
    return Q(p*b-q*a,den), Q(q*(b-3*a)-2*a*p,den)
def low(i,x,j,y):
    # Tr_{K/Q} [(16+2t) R_i R_j / (2 M'(t) q_1(t))] + 20(P15)_ij
    deriv=[(len(M)-1-k)*v for k,v in enumerate(M[:-1])]
    a,b=div_in_field(mul([2,16],mul(R[i],R[j])),[2*h for h in mul(deriv,d[1])])
    return -3*a+2*b+Q(sum(u*v for u,v in zip(x,y)),2)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def main():
    survivors=[c for deck in json.load(open(HERE/'cells.json')) for c in deck['survivors']]
    cells,=survivors
    cells=[(i,tuple(z),n) for i,z,n in cells]
    mat=[[low(i,x,j,y) for j,y,m in cells] for i,x,n in cells]
    expected=[[3,-1,-1,1,1,1,1,0],[-1,1,0,1,-1,0,0,0],[-1,0,1,-1,1,0,0,0],[1,1,-1,3,-1,1,1,0],[1,-1,1,-1,3,1,1,0],[1,0,0,1,1,3,-1,1],[1,0,0,1,1,-1,3,-1],[0,0,0,0,0,1,-1,Q(1,2)]]
    assert mat==expected and [n for i,z,n in cells]==[2,12,12,2,2,2,2,24]
    anchors=[0,3,4,5,6]
    for a in anchors:
        i,x,n=cells[a];assert signs(i,x,i,x)=={1} and mat[a][a]==3
        for b in anchors:
            if b!=a:assert abs(mat[a][b])==1
    for b in (1,2,7):
        assert {k for k in anchors if mat[k][b]==0}==({5,6} if b<7 else {0,3,4})
    # Rotate within pairs of axes. Store normalized y in 8 dimensions after rotation.
    cubewords=[]
    for group in range(2):
        for a,b,c in product([1,-1],repeat=3):
            rotated=[(1+a)//2,(1-a)//2,(b+c)//2,(b-c)//2]
            word=[0]*8
            word[2*group:2*group+2]=rotated[:2];word[4+2*group:6+2*group]=rotated[2:]
            cubewords.append(word)
    lift=[]
    for off in (0,4):
        for k in range(5):
            w=[0]*8
            w[off:off+4]=[1 if j!=k and k<4 else -1 for j in range(4)]
            lift.append(w+[1])
    assert all(abs(dot(w,word+[0]))==1 for w in lift for word in cubewords)
    assert all(dot(w,w)==5 and all(abs(dot(w,v))==1 for v in lift[:i]) for i,w in enumerate(lift))
    # Multiply the updated 9-dimensional block on an explicit integral eigenbasis.
    A=[[sum(w[i]*w[j] for w in lift)+12*(i==j and i<8) for j in range(9)] for i in range(9)]
    for off in (0,4):
        for k in range(1,4):
            u=[0]*9;u[off]=1;u[off+k]=-1
            assert [dot(r,u) for r in A]==[16*t for t in u]
    u=[[Q(i//4==j,2) if i<8 else 0 for i in range(9)] for j in (0,1)]+[[0]*8+[1]]
    assert [[dot(x,[dot(r,y) for r in A]) for y in u] for x in u]==[[20,0,2],[0,20,2],[2,2,10]]
    print('Ten-anchor geometry and replacement reproduce the excluded m=15 spectrum.')
if __name__=='__main__':main()

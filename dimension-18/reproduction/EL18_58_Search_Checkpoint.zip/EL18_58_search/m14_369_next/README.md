# Multiplicity fourteen, profile 369

Assume the existing multiplicity-fourteen one-point and signed row sieve in ../m14. We rule out its survivor with normalized tail (t−2)²(t²+3t−2) by a reduction to the multiplicity-fifteen core exclusion. All new computations use standard Python exact integers and fractions. Run the following here, in order.

    python3 -B verify.py
    python3 -B deck_rows.py
    python3 -B cells.py
    python3 -B geometry.py

The existing modules required are m14/{verify_high,verify_no11,verify_quartic_integers,pair14,details,signed}.py, its ledger.json and quartic_results.json, and m15_upstream/source/output/verify_quadratic_0020.py. Type numbers refer to the ordered deck in the 369 entry of m14/ledger.json. All cofactor polynomials below use descending coefficients.

## Possible pairs

Write Y=(S−11I)/2 and M(t)=(t+8)t(t−2)(t²+3t−2). The matrix polynomial U(t)=2M(t)(tI−Y)^{-1} has diagonal entries q_i and off-diagonal entries S_ij p_ij(t), where p_ij is monic cubic. The coefficients are integers. Indeed Y=J/2−A−6I, and all minors of tI−Y have coefficients in (1/2)Z by the rank-one update. Divide twice the adjugate by the monic integral chi_Y/M to obtain U. Its t² coefficient in p is −2+(S²)_ij/(2S_ij), between −30 and 26.

Let f=t²+3t−2. On its two roots the eigenspaces are simple. Thus p²≡q_i q_j modulo f. For p modulo f equal to a t+b, its square has coefficients (2ab−3a², b²+2a²). This enumerates all possible remainders and leaves just 57 choices for the cubic's second coefficient. For each pair we also impose Cauchy's inequality at −8,0,2. The coefficients of q_i q_j−p² are divisible by 4. To see this, Jacobi's complementary minor formula gives the difference as 4 M² chi_(Y with i,j deleted)/chi_Y. The order-56 numerator characteristic polynomial is integral. For an even-order adjacency A of a simple graph, over F2 one has 1^T A^k 1=0 for all k: even k reduces to k/2 by squaring, odd k is an alternating quadratic form, and k=0 gives zero. The identity holds also after shifting A by 6I. Consequently 1^T adj(tI+A+6I)1 has all coefficients even. The determinant lemma now gives integrality after subtracting J/2. Monic polynomial division proves the asserted divisibility by 4.

The rational rank-two projector E at t=2 has scaled diagonal q_i(2) and scaled off-diagonal S_ij p_ij(2), with common scale 2M'(2)=320. All its positive two-point determinants belong to a common rational square class: choose two independent Gram vectors as rational coordinate basis using their rational invertible minor; each determinant is its determinant times a rational square. Thus all nonzero integers q_i(2)q_j(2)−p_ij(2)² have the same squarefree part. Test every such part (and zero alone). For each row require the remaining diagonal cofactor sum and coefficient Gram from the resolvent identity U(t)U(u)=2[M(u)U(t)−M(t)U(u)]/(u−t). Lattice membership and rational nonnegativity leave just square class 1, with types 0,1,3,4,5,6.

Exhausting nonnegative integer counts on these six types gives 76 decks. For each row and neighboring type j, fix one possible coefficient Gram as baseline and enumerate the other label multiplicities against its known count. For efficiency the check allows the sum of nonbaseline multiplicities to exceed the count, an enlarged feasible set. Even in this relaxation just eight decks survive. They are in remaining_decks.json.

## Joint coordinates of the two exceptional spectral parts

Scale the t=2 projector by 40 and realize it by vectors z_i in the Euclidean plane, with z_i·z_j=S_ij p_ij(2)/8. All eight decks contain both types 1 and 4. The two-point lists force each type to lie on a single line with squared length 1, and those two lines are orthogonal. Choose them as axes. Allowed vectors are now

|type|0|1|3|4|5|6|
|---|---|---|---|---|---|---|
|z|(0,0)|±(1,0)|±(2,0), ±(0,2)|(0,1)|±(0,1)|(±1,±1)|

In the quadratic field K=Q[t]/(f), choose any reference vertex of type 1. The rank-one property lets us switch each vertex of a type i other than 4 so that its U(entry against the reference) modulo f is the polynomial R_i. In type order, the R_i are 3t+2, t−2, 5t−2, 0, 2t−4, 4t. They are globally realizable sign conventions for a hypothetical system: their squares are q_i q_1 modulo f, so in a field these are the only two signs. The reference has R_1=q_1 modulo f. For type 4 the residue is zero and its sign is free, permitting z=(0,1). For any pair in cells (i,x),(j,y) the common Seidel sign s and some monic p must satisfy

    q_1 s p ≡ R_i R_j mod f,      s p(2) = 8 x·y.

The two columns of z form a tight frame with sum zz^T=40I. Their dot products with both coefficients of R_i(t) also sum to zero, by spectral orthogonality. The eigenvector equations are S z=15z and S R(t)=(11+2t)R(t) modulo f. For each occupied cell apply both equations to a row of that type, counting how many signs in each neighboring cell equal +1. The enumeration of integral cell sizes and row counts gives exactly one possibility. In the order of cells listed below its sizes are

    (0,0)×2, (1,+e₁)×12, (1,−e₁)×12,
    (3,+2e₁)×2, (3,−2e₁)×2, (3,+2e₂)×2, (3,−2e₂)×2, (4,e₂)×24.

## Replacing ten lines

Write G=S+5I, realize it by vectors of squared norm five. Decompose physical space into its four exceptional frame coordinates (two for t=2, one for each root of f) and the 14-space of frame eigenvalue 16. The Gram L of the exceptional coordinates in cells (i,x),(j,y) is

    (x·y)/2 + Tr_K/Q [(16+2t) R_i R_j / (2 M'(t) q_1(t))].

For the eight cells in the displayed order it is the following matrix (entries constant even within the same cell).

    3 -1 -1  1  1  1  1   0
   -1  1  0  1 -1  0  0   0
   -1  0  1 -1  1  0  0   0
    1  1 -1  3 -1  1  1   0
    1 -1  1 -1  3  1  1   0
    1  0  0  1  1  3 -1   1
    1  0  0  1  1 -1  3  -1
    0  0  0  0  0  1 -1  1/2

Call the five cells of size two the anchor pairs. Their Seidel sign within each pair is forced to +1. The residuals after removing their exceptional coordinates have squared norm 2 and within each pair inner product 1−3=−2, so they are ±r_k. Between distinct pairs the exceptional product is ±1; both signs of r_k occur and both total products must be ±1. Thus r_1,...,r_5 are mutually perpendicular. For a remaining line, its inner products with a pair force its residual product with r_k to be zero if its exceptional product is ±1, and to be ±1 if the exceptional product is zero.

Let W be the 9-dimensional complement of the five roots within the 14-space. Of the other 48 lines, 24 have type 1 and 24 type 4. Type 1 has exceptional projection (v±w)/sqrt(2), where v,w are orthonormal (the two possible exceptional projections have norm 1 and inner product 0). Type 4 has a single exceptional projection u/sqrt(2), perpendicular to v,w. The nonzero root components of type 1 use precisely the two roots corresponding to (3,±2e₂); those of type 4 use the other three roots. With the roots normalized, each nonzero component is ±1/sqrt(2). Therefore the projections outside W of the 48 lines occupy two disjoint four-dimensional coordinate spaces. In each they are of the form (1,a,b,c)/sqrt(2), with a,b,c signs. There is one unused exceptional direction.

The frame of these 48 lines equals 16I on W and 12I on the eight cube coordinates, with zero cross terms. Indeed, the ten removed lines have no W coordinates, and all frame cross terms between W and the roots or the exceptional space vanish in the original system. Each normalized root initially has total energy 16; its own anchor pair contributes 4, leaving 12. The anchor products cancel in cross terms between roots and exceptional coordinates. Distinct roots have disjoint anchor support. On v,w,u each diagonal is 12, and the two orientations on w occur 12 times each, giving zero cross terms.

Apply the real two-dimensional Hadamard transform separately to the first and last pair of coordinates of each four-space. The transformed projection has exactly one entry ±1 in the first pair and one entry ±1 in the last pair. Pool the two first pairs into E of dimension four and the two last pairs into F of dimension four. Every projected word has one signed unit coordinate in each of E and F. Let e be the remaining perpendicular unit direction. In each of E,F take the four words with a single minus sign and the all-negative word, and append +e to each. All ten new lines have squared norm 5. Two words within a group have distances 2 or 3; across the groups they have product 1 from e. Every old line has product ±1 with every new line.

This replacement gives a hypothetical second system of 58 lines. Its frame is 16I on W and on the two dimension-three zero-sum subspaces of E,F. On the normalized two all-ones vectors and e its matrix is

    20  0  2
     0 20  2
     2  2 10

Thus its Seidel spectrum is (−5)^40, 11^15, 15, 10−√33, 10+√33. The existing m15_upstream and single_row proof excludes precisely this system. This proves the conditional reduction and excludes 369 given that existing exclusion. The geometric check geometry.py recomputes L by exact field arithmetic and checks all cube words, all lift signs and the final three-dimensional block.

"""Independent complete extension search by exact bordered Bareiss elimination."""
import json,sys
from itertools import product
from pathlib import Path
from functools import lru_cache
from collections import Counter
P=Path(__file__).resolve().parent
from interface import U,off,h
def matrix(mask):
    M=[[80 if i==j else -16 for j in range(8)] for i in range(8)]
    for i,j in product(range(4),repeat=2):M[i][j+4]=M[j+4][i]=16-48*((mask>>(4*i+j))&1)
    return M
@lru_cache(None)
def ips(a,b):
    vs=off(a,b);assert all(v%4==0 for v in vs)
    return tuple(v//4 for v in vs)
def norm(a):return h(a)//4

def pivots(M):
    A=[r[:] for r in M];D=1;stages=[];rank=0
    for i in range(len(M)):
        d=A[i][i]
        if not d:
            assert not any(A[i][i:])
            stages.append((0,(),D));continue
        assert d>0
        trail=A[i][i+1:];stages.append((d,trail,D))
        for j in range(i+1,len(M)):
            v=A[j][i]
            for k in range(j,len(M)):
                u=d*A[j][k]-v*A[i][k]
                assert u%D==0;A[j][k]=A[k][j]=u//D
        D=d;rank+=1
    return rank,stages

def bordered(stages,w,h):
    row=list(w)
    for i,(d,col,D) in enumerate(stages):
        v=row[i]
        if d:
            u=d*h-v*v;assert u%D==0
            h=u//D
            if h<0:return -1
            for j,z in enumerate(col,i+1):
                b=d*row[j]-v*z
                assert b%D==0;row[j]=b//D
        elif v:return -1
    return h

def run(mask,depth,limit=100000):
    core=[[v//4 for v in r] for r in matrix(mask)];A=[0]*4+[3]*4
    N={k:q[2] for k,q in enumerate(U) if k not in A}
    choices={k:list(product(*(ips(a,k) for a in A))) for k in N}
    nodes=Counter();leaves=Counter()
    def rec(M,N,pools,level):
        nodes[level]+=1
        if sum(nodes.values())>=limit:leaves['budget']+=1;return
        r,st=pivots(M);assert r<=13
        live={}
        for k,pool in pools.items():
            good=[]
            for w in pool:
                D=bordered(st,w,norm(k))
                if D>=0 and (D==0 or r<13):good.append((w,D))
            if not good:return
            live[k]=good
        if level==depth:leaves['depth']+=1;return
        ts=[t for t,v in live.items() if any(D for w,D in v)] or list(live)
        if not ts:leaves['whole']+=1;return
        a=min(ts,key=lambda t:(len(live[t]),-max(v for w,v in live[t]),t))
        rem={t:n-(t==a) for t,n in N.items() if n>(t==a)}
        for w,_ in live[a]:
            ext={t:[u+(j,) for u,_ in live[t] for j in ips(a,t)] for t in rem}
            rec([z+[x] for z,x in zip(M,w)]+[list(w)+[norm(a)]],rem,ext,level+1)
    rec(core,N,choices,0)
    return dict(mask=mask,depth=depth,nodes=sorted(nodes.items()),leaves=dict(leaves))
if __name__=='__main__':
    mask,depth=map(int,sys.argv[1:3]);r=run(mask,depth)
    print(r,flush=True)
    f=P/f'bareiss_{mask}_d{depth}.json'
    if f.exists():assert json.loads(f.read_text())==json.loads(json.dumps(r))
    else:f.write_text(json.dumps(r,separators=(',',':'))+'\n')

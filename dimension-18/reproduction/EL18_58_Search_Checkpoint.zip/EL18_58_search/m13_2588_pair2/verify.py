"""Check the complete proof forest, independent of LP, inverse matrices, and branch heuristics."""
import json
import sys
from pathlib import Path
from itertools import permutations,product
from collections import Counter
from functools import lru_cache
from bareiss import pivots,bordered
P=Path(__file__).resolve().parent
D=P.parent/'m13_2588'
from interface import U,L,off,h
def dot(x,y):return sum(a*b for a,b in zip(x,y))

def check(mask):
    entries=json.loads((P/f'tree_{mask}.json').read_text());forest={}
    for e in entries:
        path=tuple((t,tuple(x)) for t,x in e['path'])
        assert path not in forest
        forest[path]=e
    K=[[h(0) if i==j else -16 for j in range(8)] for i in range(8)]
    for i,j in product(range(4),repeat=2):K[i][j+4]=K[j+4][i]=16-48*((mask>>(4*i+j))&1)
    A=(0,)*4+(3,)*4;perms=[]
    for f,g in product(permutations(range(4)),repeat=2):
        p=f+tuple(j+4 for j in g)
        if all(K[i][j]==K[p[i]][p[j]] for i,j in product(range(8),repeat=2)):perms.append(p)
    N={k:n for k,(_,_,n) in enumerate(U) if k not in A}
    pools={k:list(product(*(off(a,k) for a in A))) for k in N}
    stats=Counter(); visited=set()
    def rec(M,A,N,pool,path,perm):
        # Enlarge each possible word independently and test that entire bordered
        # matrix by fraction-free elimination, including its zero pivots.
        rank,steps=pivots(M)
        assert rank<=13
        valid={}
        for t in N:
            live=[]
            for x in pool[t]:
                d=bordered(steps,x,h(t))
                if d>=0 and (rank<13 or d==0):live.append(x)
            if not live:stats['impossible extension']+=1;return
            valid[t]=live
        assert path in forest,(mask,path)
        e=forest[path];visited.add(path)
        if 'y' in e:
            ix=e['ix'];ys=e['y'];n=len(A);assert all(type(y)==int for y in ys)
            ij=[(a,b) for i,a in enumerate(ix) for b in ix[i:]]
            rhs=[58-n]+list(N.values())+[384*M[a][b]-dot(M[a],M[b]) for a,b in ij]+[-sum(w*L[t][v] for w,t in zip(M[a],A)) for a in ix for v in range(5)]
            assert len(rhs)==len(ys) and dot(ys,rhs)<0
            for t,words in valid.items():
                for w in words:
                    col=[1]+[int(t==u) for u in N]+[w[a]*w[b] for a,b in ij]+[w[a]*v for a in ix for v in L[t]]
                    assert dot(ys,col)>=0
            stats['integer cut']+=1;return
        if 'coordinate' in e:
            # Each class contributes exactly N[t] values of each moment.
            for i in range(len(A)):
                for j in range(len(A)+5):
                    rows=[(N[t],[(x[i]*x[j] if j<len(A) else x[i]*L[t][j-len(A)]) for x in xs]) for t,xs in valid.items()]
                    target=(384*M[i][j]-dot(M[i],M[j]) if j<len(A) else -sum(w*L[t][j-len(A)] for w,t in zip(M[i],A)))
                    if target<sum(n*min(v) for n,v in rows) or target>sum(n*max(v) for n,v in rows):
                        stats['coordinate cut']+=1;return
            raise AssertionError('coordinate certificate failed')
        t=e['split'];assert N[t]>=1
        child={p[-1][1] for p in forest if len(p)==len(path)+1 and p[:-1]==path and p[-1][0]==t}
        todo=set(valid[t])
        while todo:
            x=min(todo)
            orbit={tuple(x[j] for j in f)+x[8:] for f in perm}
            assert orbit<=set(valid[t])
            represented=orbit&child
            if represented:x=min(represented)
            todo-=orbit
            M1=[row+[v] for row,v in zip(M,x)]+[list(x)+[h(t)]]
            nn={j:v-(j==t) for j,v in N.items() if v>(j==t)}
            pp={j:[w+(z,) for w in valid[j] for z in off(t,j)] for j in nn}
            rec(M1,A+(t,),nn,pp,path+((t,x),),[f for f in perm if all(x[i]==x[j] for i,j in enumerate(f))])
    rec(K,A,N,pools,(),perms)
    # All actual splits and Farkas leaves should be used. Extra empty nodes
    # represent failures already detected by the direct bordered check.
    assert all('empty' in e for p,e in forest.items() if p not in visited)
    return dict(mask=mask,tree=len(forest),integer_cuts=stats['integer cut'],**({'coordinate_cuts':stats['coordinate cut']} if stats['coordinate cut'] else {}),psd_failures=stats['impossible extension'])
if __name__=='__main__':
    cases=json.loads((D/'cross4.json').read_text())['cases']
    selected=set(map(int,sys.argv[1:])) if len(sys.argv)>1 else {a['mask'] for a in cases}
    rows=[]
    for case in cases:
        if case['mask'] in selected:
            r=check(case['mask']);r['labelled']=case['orbit_size'];print(r,flush=True);rows.append(r)
    if len(rows)==len(cases):
        assert len(rows)==25 and sum(r['labelled'] for r in rows)==3582
        path=P/'verified.json'
        if path.exists():assert json.loads(path.read_text())==rows
        else:path.write_text(json.dumps(rows,indent=1)+'\n')

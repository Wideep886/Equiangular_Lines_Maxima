"""Branch on compulsory exterior types of the 2588 core; all operations are integer/rational."""
import argparse,json,sys
from collections import Counter
from functools import lru_cache
from itertools import product
from math import lcm
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'m13_2588'))
from cross4 import matrix,schur,inverse,H,U,L,key,dot

@lru_cache(None)
def values(t,u):
    return tuple(sorted({-s*q[-1] for s,q in key(t,u)}))

def h(t):return -H[U[t][0]][-1]

def projected(M,pools):
    ix=schur(M);assert ix is not None
    F=inverse([[M[i][j] for j in ix] for i in ix])
    den=lcm(*(q.denominator for row in F for q in row))
    Q=[[int(den*q) for q in row] for row in F]
    result={}
    for t,xs in pools.items():
        proj=[]
        for x in xs:
            b=tuple(x[i] for i in ix); c=tuple(dot(row,b) for row in Q)
            rem=h(t)*den-dot(b,c)
            if rem<0 or (rem and len(ix)>=13):continue
            if any(dot([row[j] for j in ix],c)!=v*den for row,v in zip(M,x)):continue
            proj.append((x,b,c,rem))
        result[t]=proj
    return ix,den,result

def coord_test(M,A,N,groups):
    # Every column w is an outside point; sum ww^T = 384 M - M^2, sum wL= -M L_A.
    n=len(A)
    tests=[(384*M[i][j]-dot(M[i],M[j]),i,j,False) for i in range(n) for j in range(i,n)]
    tests += [(-sum(w*L[t][k] for w,t in zip(row,A)),i,k,True) for i,row in enumerate(M) for k in range(5)]
    for target,i,j,linear in tests:
        lo=hi=0
        for t,g in groups.items():
            if linear:
                f=L[t][j]
                if not f:continue
                vals=[x[0][i]*f for x in g]
            else:vals=[x[0][i]*x[0][j] for x in g]
            lo+=N[t]*min(vals);hi+=N[t]*max(vals)
        if not lo<=target<=hi:return False
    return True

def search(mask,depth,limit):
    stats=Counter();fail=Counter(); frontier=[];nodes=0
    core=matrix(mask);anchors=[0]*4+[3]*4
    need={t:n for t,(_,_,n) in enumerate(U) if t not in (0,3)}
    pools={t:list(product(*(values(a,t) for a in anchors))) for t in need}
    def visit(M,A,N,xs,path):
        nonlocal nodes
        level=len(path);stats[level]+=1
        if nodes>=limit:frontier.append([path,'budget']);return
        nodes+=1
        ix,den,grp=projected(M,xs)
        if any(not g for g in grp.values()):fail[level,'empty']+=1;return
        if not coord_test(M,A,N,grp):fail[level,'coordinate']+=1;return
        if level==depth:frontier.append([path,'depth']);return
        # Choose an informative nonzero exterior type. The second antipode of a
        # known vector has zero residual and need never be branched on here.
        ts=[t for t,g in grp.items() if any(w[3] for w in g)] or list(grp)
        if not ts:frontier.append([path,'full']);return
        t=min(ts,key=lambda t:(len(grp[t]),-max(w[3] for w in grp[t]),t))
        NN={u:n-(u==t) for u,n in N.items() if n>(u==t)}
        for x,b,c,v in grp[t]:
            nxt={}
            for u in NN:
                allowed=values(t,u)
                z=[]
                for y,by,cy,r in grp[u]:
                    cen=dot(c,by)
                    for j in allowed:
                        if (den*j-cen)**2<=v*r:z.append(y+(j,))
                nxt[u]=z
                if not z:break
            if len(nxt)!=len(NN) or not all(nxt.values()):
                fail[level+1,'pair']+=1;continue
            B=[row+[a] for row,a in zip(M,x)]+[list(x)+[h(t)]]
            visit(B,A+[t],NN,nxt,path+[[t,list(x)]])
    visit(core,anchors,need,pools,[])
    return dict(mask=mask,limit=limit,depth=depth,nodes=nodes,visits=sorted(stats.items()),failures=[[i,r,k] for (i,r),k in sorted(fail.items())],open_count=len(frontier),first_open=frontier[:1])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mask',type=int,nargs='+');p.add_argument('--depth',type=int,default=8);p.add_argument('--limit',type=int,default=10000);a=p.parse_args()
    for m in a.mask:
        r=search(m,a.depth,a.limit); print(m,r['nodes'],r['open_count'],r['failures'],flush=True)
        f=P/f'm{m}_d{a.depth}_n{a.limit}.json'
        if f.exists():assert json.loads(f.read_text())==json.loads(json.dumps(r))
        else:f.write_text(json.dumps(r,separators=(',',':'))+'\n')

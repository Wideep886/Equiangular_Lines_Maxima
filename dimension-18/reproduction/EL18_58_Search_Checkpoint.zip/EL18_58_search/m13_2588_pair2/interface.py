import json
from pathlib import Path
P=Path(__file__).resolve().parent
data=json.loads((P/'interface.json').read_text())
U=data['classes'];L=data['kernel_rows'];norms=data['norms']
IP={(a,b):tuple(vals) for a,b,vals in data['pairs']}
def off(a,b):return IP[min(a,b),max(a,b)]
def h(a):return norms[a]
assert sum(n for _,_,n in U)==58 and U[0][2]==U[3][2]==4
assert h(0)==h(3)==80 and off(0,0)==off(3,3)==(-16,) and off(0,3)==(-32,16)

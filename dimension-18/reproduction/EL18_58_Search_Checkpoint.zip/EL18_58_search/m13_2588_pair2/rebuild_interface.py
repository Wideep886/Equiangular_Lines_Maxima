"""Regenerate the small exact interface from the original oriented 2588 classification."""
import json,sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'m13_2588'))
from oriented_frames import U,H,L
r=json.loads((P.parent/'m13_2588'/'oriented_frames.json').read_text())
out=dict(classes=U,norms=[-H[i][-1] for i,s,n in U],kernel_rows=L,pairs=[[a,b,sorted({-s*q[-1] for s,q in choices})] for a,b,choices in r['remaining']])
f=P/'interface.json';out=json.loads(json.dumps(out))
if f.exists():assert json.loads(f.read_text())==out
else:f.write_text(json.dumps(out,indent=1)+'\n')
print(len(U),sum(n for _,_,n in U),len(out['pairs']))

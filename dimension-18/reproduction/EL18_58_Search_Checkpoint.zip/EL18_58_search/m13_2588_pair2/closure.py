"""Exhaust compulsory anchors with frame and eigenspace annihilation on the entire enlarged principal block."""
from extend import *
from cross_frame import stabilizer
from cross_pair_anchor import separate
from itertools import combinations_with_replacement

def scan(mask,depth,limit):
    core=matrix(mask);anchors=[0]*4+[3]*4
    N={i:n for i,(_,_,n) in enumerate(U) if i not in anchors}
    pools={i:list(product(*(values(a,i) for a in anchors))) for i in N}
    stats=Counter();fail=Counter();unresolved=[];nodes=0
    dest=P/f'closure_{mask}_{depth}_{limit}.json'
    replay=dest.exists();data=json.loads(dest.read_text()) if replay else {}
    certs=data.get('cuts',{});used=set();tree=[]
    def visit(M,A,N,pool,group,path):
        nonlocal nodes
        lev=len(path)
        if nodes>=limit:unresolved.append(path);return
        seq=str(nodes);nodes+=1;stats[lev]+=1
        entry={'path':path};tree.append(entry)
        ix,D,ws=projected(M,pool)
        if any(not v for v in ws.values()):entry['empty']=True;fail['empty']+=1;return
        if lev:
            # Use independent anchor indices. The full M is checked for rank and PSD before this reduction.
            ij=list(combinations_with_replacement(ix,2))
            ts=list(N)
            target=[sum(N.values())]+[N[t] for t in ts]+[384*M[i][j]-dot(M[i],M[j]) for i,j in ij]+[-sum(w*L[t][b] for w,t in zip(M[i],A)) for i in ix for b in range(5)]
            cols=sorted({(1,)+tuple(int(t==k) for k in ts)+tuple(w[i]*w[j] for i,j in ij)+tuple(w[i]*u for i in ix for u in L[t]) for t,items in ws.items() for w,*_ in items})
            if replay:y=certs.get(seq)
            else:y=separate(cols,target)
            if y is not None:
                assert dot(y,target)<0 and all(dot(y,c)>=0 for c in cols)
                entry.update(y=y,ix=ix);certs[seq]=y;used.add(seq);fail['farkas']+=1;return
        if not coord_test(M,A,N,ws):entry['coordinate']=True;fail['coordinate']+=1;return
        if lev>=depth or not ws:unresolved.append(path);return
        ts=[t for t,v in ws.items() if any(q[3] for q in v)] or list(ws)
        # Prefer few orbits rather than raw word counts at the branching vertex.
        def reps(t):
            seen=set();ret=[]
            for v in ws[t]:
                x=v[0]
                if x in seen:continue
                seen.update(tuple(x[i] for i in p)+x[8:] for p in group);ret.append(v)
            return ret
        reps_by_t={t:reps(t) for t in ts}
        a=min(ts,key=lambda t:(len(reps_by_t[t]),len(ws[t]),-max(w[3] for w in ws[t]),t))
        entry['split']=a
        nn={t:n-(t==a) for t,n in N.items() if n>(t==a)}
        for x,b,c,h0 in reps_by_t[a]:
            nxt={}
            for t in nn:
                rows=[]
                for z,by,cy,h1 in ws[t]:
                    center=dot(c,by)
                    for j in values(a,t):
                        if (D*j-center)**2<=h0*h1:rows.append(z+(j,))
                nxt[t]=rows
                if not rows:break
            if len(nxt)!=len(nn) or not all(nxt.values()):fail['pair']+=1;continue
            M1=[r+[v] for r,v in zip(M,x)]+[list(x)+[h(a)]]
            stab=[p for p in group if all(x[i]==x[j] for i,j in enumerate(p))]
            visit(M1,A+[a],nn,nxt,stab,path+[[a,list(x)]])
    visit(core,anchors,N,pools,stabilizer(core),[])
    assert set(certs)==used
    r=dict(mask=mask,limit=limit,depth=depth,nodes=nodes,levels=sorted(stats.items()),prunes=dict(fail),open=len(unresolved),first=unresolved[:1],cuts=certs)
    if replay:assert data==json.loads(json.dumps(r))
    else:dest.write_text(json.dumps(r,separators=(',',':'))+'\n')
    if not unresolved:(P/f'tree_{mask}.json').write_text(json.dumps(tree,separators=(',',':'))+'\n')
    print(mask,nodes,len(unresolved),dict(fail),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('masks',type=int,nargs='+');p.add_argument('--depth',type=int,default=14);p.add_argument('--limit',type=int,default=600);a=p.parse_args()
    for m in a.masks:scan(m,a.depth,a.limit)

"""Independent orbit and positivity cover of all 65,536 labelled 4 by 4 blocks."""
import json
from collections import Counter
from itertools import permutations,product
from verify import P,check
def psd(M):
    # Congruence clearing the first available diagonal entry at each step.
    from fractions import Fraction as F
    C=[list(map(F,r)) for r in M]
    while C:
        if any(C[i][i]<0 for i in range(len(C))):return False
        i=next((i for i in range(len(C)) if C[i][i]>0),None)
        if i is None:return not any(v for row in C for v in row)
        J=[j for j in range(len(C)) if j!=i]
        C=[[C[a][b]-C[a][i]*C[i][b]/C[i][i] for b in J] for a in J]
    return True
def cover():
    # Pre-sort rows by size as binary integers. Minimise over the 24 column reorderings.
    perms=list(permutations(range(4)))
    tabs=[[sum(((r>>p[j])&1)<<j for j in range(4)) for r in range(16)] for p in perms]
    from itertools import combinations_with_replacement
    from math import factorial,prod
    result=Counter()
    for xs in combinations_with_replacement(range(16),4):
        can=min(sum(v<<(4*i) for i,v in enumerate(sorted((tab[r] for r in xs),reverse=True))) for tab in tabs)
        result[can]+=24//prod(factorial(n) for n in Counter(xs).values())
    assert sum(result.values())==65536 and len(result)==317
    out=[]
    for mask,n in sorted(result.items()):
        M=[[80 if i==j else -16 for j in range(8)]for i in range(8)]
        for i,j in product(range(4),repeat=2):M[i][4+j]=M[4+j][i]=16-48*((mask>>(4*i+j))&1)
        if psd(M):out.append((mask,n))
    assert len(out)==45 and sum(n for m,n in out)==8838
    return out
def one(case):
    m,n=case;r=check(m);r['labelled']=n;return r
if __name__=='__main__':
    rows=[]
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(3) as pool:
        for r in pool.map(one,cover()):rows.append(r);print(r,flush=True)
    f=P/'verified_full.json'
    if f.exists():assert json.loads(f.read_text())==rows
    else:f.write_text(json.dumps(rows,indent=1)+'\n')

"""Reconstruct the original rational cyclic STS(19) core search."""
import itertools as it
import json
import math
from pathlib import Path
import numpy as np
from fractions import Fraction

def orbit(t):
    return {tuple(sorted((i+a)%19 for i in t)) for a in range(19)}

def differences(t):
    return {min(b-a,19-b+a) for a,b in it.combinations(t,2)}

def representative(f):
    return min(tuple(sorted(min(orbit([(a*i)%19 for i in t])) for t in f))
               for a in range(1,19))

def search(f):
    blocks=sorted(set.union(*(orbit(t) for t in f)))
    assert len({p for t in blocks for p in it.combinations(t,2)})==171 and len(blocks)==57
    core=[set(t) for t in blocks if 0 not in t]
    G=[[2*len(a&b)-1 for b in core] for a in core]
    # A left-to-right exact echelon reduction supplies Gram pivot columns.
    E=[[Fraction(x) for x in row] for row in G]
    B=[]
    for j in range(48):
        i=len(B)
        k=next((k for k in range(i,48) if E[k][j]),None)
        if k is None:continue
        B.append(j)
        E[i],E[k]=E[k],E[i]
        E[i]=[x/E[i][j] for x in E[i]]
        for k in range(48):
            if k!=i and E[k][j]:
                E[k]=[a-E[k][j]*b for a,b in zip(E[k],E[i])]
    assert len(B)==17
    Q=E[:17]
    assert all(sum(G[i][k]*row[j] for k,row in zip(B,Q))==G[i][j]
               for i in range(48) for j in range(48))
    A=[[Fraction(G[i][j]) for j in B]+[Fraction(i==j) for j in B] for i in B]
    for k in range(17):
        assert A[k][k]>0
        A[k]=[x/A[k][k] for x in A[k]]
        for i in range(17):
            if i!=k:
                A[i]=[x-A[i][k]*y for x,y in zip(A[i],A[k])]
    D=math.lcm(*(x.denominator for row in Q+[r[17:] for r in A] for x in row))
    coeff=np.array([[int(D*x) for x in row] for row in Q],dtype=np.int64)
    assert max(abs(int(c)) for c in coeff.flat)*17<2**60
    signs=np.array([(1,)+s for s in it.product([-1,1],repeat=16)],dtype=np.int64)
    dots=signs@coeff
    consistent=signs[np.all(np.abs(dots)==D,axis=1)]
    assert len(consistent)==0
    return dict(base=f,basis=B,consistent=0,min_norm_num=None,denominator=D,options=0,maximum=0,rank=17,gram=G)

def main():
    triples=sorted({min(orbit(t)) for t in it.combinations(range(19),3)})
    families=[f for f in it.combinations(triples,3) if len(set.union(*(differences(t) for t in f)))==9]
    out=[search(f) for f in sorted(set(map(representative,families)))]
    assert len(families)==32 and len(out)==4
    Path(__file__).with_name('results.json').write_text(json.dumps(dict(labelled_families=len(families),cases=out),default=int))
if __name__=='__main__':main()

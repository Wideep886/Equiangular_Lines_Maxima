"""Rebuild the cyclic STS(19) branch using only Python's standard library."""
from itertools import combinations
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pasch19'))
from search import POINTS, assignments, design, gram, shift

def orbit_rep(t):
    return min(shift(t,k) for k in POINTS)

def differences(t):
    return {min(b-a,19-b+a) for a,b in combinations(t,2)}

def representative(f):
    return min(tuple(sorted(orbit_rep(tuple(a*i%19 for i in t)) for t in f)) for a in range(1,19))

def main():
    orbits=sorted({orbit_rep(t) for t in combinations(POINTS,3)})
    fam=[f for f in combinations(orbits,3) if len(set.union(*(differences(t) for t in f)))==9]
    cases=[]
    for f in sorted(set(map(representative,fam))):
        C=[set(t) for t in sorted(design(f)) if 0 not in t]
        G=gram(C)
        B,good=assignments(G)
        assert len(C)==48 and not good
        cases.append(dict(base=f,basis=B,consistent=0,options=0,maximum=0,rank=len(B),gram=G))
    assert len(fam)==32 and len(cases)==4
    saved=json.loads((HERE/'results.json').read_text())
    assert saved['labelled_families']==len(fam)
    for x,y in zip(cases,saved['cases']):
        assert all(x[k]==y[k] for k in ('gram','consistent','options','maximum','rank'))
    print('Verified four cyclic cores independently.')

if __name__=='__main__':main()

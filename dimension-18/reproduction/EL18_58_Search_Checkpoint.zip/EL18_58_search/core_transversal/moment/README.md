The 61 supplied row words are the output of the augmented local word sieve. Running `python3 verify.py` replays 18 exact exclusions using standard-library integer arithmetic. The other 43 have passed this relaxation. The 5 remaining occupancy types use profiles 2220 and 2211; all rank-eight row words of these profiles are excluded.

For a chosen row, G is its 12 by 12 residual Gram, I indexes a Gram basis, and each prospective external vector has the vector z of inner products with this basis. Switch the sign of every minus-labelled external vector so that each column has projected signed-coordinate +1. Exactly 12-2m_c vectors outside the given row belong to column c. Their sums are the negatives of the switched sums already present in that column. Frame tightness yields the second moment
`sum(z*z^T)=(16G-G^2)[I,I]`.
The feature vector for each option consists of the four column indicators, the four block vectors of signed column inner products, and the upper triangular part of zz^T. The required aggregate feature vector is b.

For rank eight the missing coordinate has a common rational squareclass. If D is the denominator of the inverse and the positive squared missing coordinates are d k²/D with d squarefree and k integral, their total 16 forces d to divide 16D. Each d is checked separately. For every rejected row and each relevant d the verifier finds an empty positive-count column or checks the strict integer inequality
`q*b < sum_c (12-2m_c) min_(v admissible in c) q*v`
for the explicit certificate q in moments.json. This proves there is no nonnegative solution of the aggregate feature equations.

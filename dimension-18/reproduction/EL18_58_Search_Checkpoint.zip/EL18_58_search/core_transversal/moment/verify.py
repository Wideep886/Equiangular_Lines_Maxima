"""Replay integer separating hyperplanes for tight-frame projection moments."""
from collections import Counter
from itertools import combinations_with_replacement
from math import isqrt
from pathlib import Path
import json
from anchor import candidates,geom

def sf(n):
    j=2
    while j*j<=n:
        while n%(j*j)==0:
            n//=j*j
        j+=1
    return n

def dot(u,v):
    return sum(a*b for a,b in zip(u,v))

def verify(line,proof):
    profile,parts,word,rank=line.split()
    word_ids,cycles,gram=geom(profile,parts,word)
    ids,den,inverse,pools=candidates(profile,parts,word)
    r=len(ids)
    assert r==int(rank)
    lower=[12-2*int(c) for c in profile]
    rhs=lower.copy()
    for col in range(4):
        for i in ids:
            rhs.append(-sum(gram[i][j]*(1-2*(w%2)) for j,w in enumerate(word_ids) if w//2==col))
    for i,j in combinations_with_replacement(ids,2):
        rhs.append(16*gram[i][j]-dot(gram[i],gram[j]))
    options=[]
    for c in range(4):
        group=[]
        for _,full,dual in pools[2*c]:
            z=[full[k] for k in ids];defect=3*den-dot(z,dual)
            feature=[int(j==c) for j in range(4)]
            for j in range(4):
                feature.extend(z if j==c else [0]*r)
            feature.extend(i*j for i,j in combinations_with_replacement(z,2))
            group.append((feature,defect))
        options.append(group)
    classes={0}
    if r==8:
        classes={sf(v) for group in options for _,v in group if v and not 16*den%sf(v)}
    assert {d for d,q in proof}==classes
    for d,q in proof:
        assert len(q)==len(rhs)
        bounds=[]
        for c,group in enumerate(options):
            scores=[dot(v,q) for v,h in group if not d or h%d==0 and isqrt(h//d)**2*d==h]
            if not scores:
                break
            bounds.append(min(scores))
        else:
            assert dot(rhs,q)<dot(lower,bounds)

def main():
    base=Path(__file__).resolve().parent
    data=json.loads((base/'moments.json').read_text())
    assert [q[0] for q in data]==(base/'words_aug7.txt').read_text().splitlines()
    accepted=Counter();excluded=0
    for line,ok,proof in data:
        if ok:
            parts=line.split();accepted[parts[0],parts[-1]]+=1
        else:
            verify(line,proof);excluded+=1
    assert excluded==18
    print('61 candidates, 18 excluded; remaining multiplicities (occupancy, rank)')
    print(sorted(accepted.items()))

if __name__=='__main__':
    main()

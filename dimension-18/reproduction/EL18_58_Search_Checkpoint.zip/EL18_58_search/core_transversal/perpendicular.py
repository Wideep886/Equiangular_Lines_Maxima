"""Exact rank and tight-frame test for a size-four cell and two perpendicular size-two cells."""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from math import isqrt
from pathlib import Path
import json
import transversal as prior

def inverse(matrix):
    size = len(matrix)
    work = [[Fraction(v) for v in row] + [int(i == j) for j in range(size)]
            for i, row in enumerate(matrix)]
    for j in range(size):
        pivot = next((i for i in range(j, size) if work[i][j]), None)
        if pivot is None:
            return None
        work[j], work[pivot] = work[pivot], work[j]
        q = work[j][j]
        work[j] = [x/q for x in work[j]]
        for i in range(size):
            if i != j:
                q = work[i][j]
                work[i] = [x-q*y for x, y in zip(work[i], work[j])]
    return [r[size:] for r in work]

def quadratic(e, f):
    return sum(x*y for x,y in zip(e,f))

def projections(gram, active):
    """One representative per sign pair, with exact squared projection norm."""
    basis = []
    for j in range(len(gram)):
        proposed = basis + [j]
        if inverse([[gram[u][v] for u in proposed] for v in proposed]) is not None:
            basis = proposed
    inv = inverse([[gram[u][v] for u in basis] for v in basis])
    output = []
    for rhs in product(*[(-1,1) if b else (0,) for b in active]):
        if next((v for v in rhs if v),1)<0:
            continue
        b = [rhs[u] for u in basis]
        coeff = [quadratic(r,b) for r in inv]
        if any(sum(gram[u][j]*a for u,a in zip(basis,coeff)) != rhs[j]
               for j in range(len(gram))):
            continue
        output.append((quadratic(coeff,b),rhs))
    return len(basis),output

def central(code):
    gram = [[3*int(i==j) for j in range(8)] for i in range(8)]
    for b,(i,j) in enumerate(combinations(range(8),2)):
        gram[i][j]=gram[j][i]=1-2*(code>>b&1)-2*int((i<4)==(j<4))
    return gram

def wings(code):
    gram=[[3 if i==j else 1 for j in range(4)] for i in range(4)]
    for b,(i,j) in enumerate(combinations(range(1,4),2)):
        gram[i][j]=gram[j][i]=1-2*(code>>b&1)
    return gram

def same_squareclass(q, klass):
    if not q:
        return True
    if not klass:
        return False
    r=q/klass
    return isqrt(r.numerator)**2==r.numerator and isqrt(r.denominator)**2==r.denominator

@lru_cache(None)
def feasible(code, counts):
    """Counts specify how many of 32 distant vectors pair nontrivially with each wing."""
    a,projs=projections(central(code),[1]*8)
    center_norms={n for n,z in projs if n<=3}
    for wing_code in range(8):
        data=[]
        for middle in range(4):
            active = [(middle>>1)&1]*2+[middle&1]*2
            b,images=projections(wings(wing_code),active)
            pool=[]
            for q,rhs in images:
                # A fixed direction u in the span of the four wing vectors has projection
                # norm q. The two copies of each wing representative contribute 2*sum(rhs^2).
                # Every occurrence of ±u as a projection contributes q^2 along u.
                cap=int((16*q-2*quadratic(rhs,rhs))//(q*q)) if q else 32
                for n in center_norms:
                    slack=3-q-n
                    if slack>=0 and (a+b==8 or (a+b==9 and not slack)):
                        pool.append((n,slack,cap))
            data.append(pool)
        if a+b>9:
            continue
        assert a+b>=8
        classes={q for pool in data for n,q,cap in pool if q}|{Fraction(0)}
        for klass in classes:
            energies={0}
            for count,pool in zip(counts,data):
                states={(0,0)}
                for n,q,cap in pool:
                    if not same_squareclass(q,klass):
                        continue
                    states={(i+j,s+j*n) for i,s in states
                            for j in range(min(cap,count-i)+1)}
                local={s for i,s in states if i==count}
                energies={x+y for x in energies for y in local}
            if 16*a-24 in energies:
                return True
    return False

def accepts(table,states):
    for r,c in product(range(4),repeat=2):
        if table[r][c]!=4:
            continue
        row=[j for j in range(4) if j!=c and table[r][j]]
        col=[i for i in range(4) if i!=r and table[i][c]]
        if len(row)!=1 or len(col)!=1:
            continue
        j,=row
        i,=col
        if states[r][j]!=45 or states[i][c]!=45:
            continue
        counts=[0]*4
        for x,y in product(range(4),repeat=2):
            if x!=r and y!=c:
                counts[2*int(y!=j)+int(x!=i)]+=2*table[x][y]
        if not feasible(states[r][c],tuple(counts)):
            return False,'perpendicular'
    return True,'open'

def main():
    base=prior.occupation.profile_states(prior.orig/'words_col8.txt')
    data=json.loads((prior.orig/'results_col8.json').read_text())
    prior.check=accepts
    for i in [7,81]:
        ans,stats=prior.solve(data[i]['table'],base)
        print(i,dict(stats),flush=True)
        assert not ans and stats['perpendicular']
    print('Five remaining occupancy IDs 216, 217, 218, 222, 223.')

if __name__=='__main__':
    main()

from collections import Counter
from itertools import combinations,permutations
from pathlib import Path
from functools import lru_cache
import sys,json
orig=Path(__file__).resolve().parent
sys.path.insert(0,str(orig))
import occupation
perms=list(permutations(range(4)))
def cell(m,s):
 l=2*m;g=[[0]*l for _ in range(l)]
 for e,(i,j) in enumerate(combinations(range(l),2)):
  g[i][j]=g[j][i]=1-2*(s>>e&1)-2*int((i<m)==(j<m))
 for i in range(l):g[i][i]=3
 sub=[p for p in range(l) if all(g[p][q]!=-3 for q in range(p))]
 q0=sum(g[i][j] for i in range(m) for j in range(m));q1=sum(g[i+m][j+m] for i in range(m) for j in range(m));ab=sum(g[i][j+m] for i in range(m) for j in range(m))
 return len(sub),q0,q1,ab
cell=lru_cache(None)(cell)
def check(t,states):
 weights=[[cell(t[r][c],states[r][c])[0] for c in range(4)] for r in range(4)]
 if any(sum(weights[r][p[r]] for r in range(4))>28 for p in perms):
  return False,'matching'
 if all(cell(t[r][c],states[r][c])[1:3]==(0,0) for r in range(4) for c in range(4)):
  return False,'centered'
 return True,'open'
def solve(t,base):
 pools=[]
 for h,prof in enumerate((*t,*zip(*t))):
  order=sorted(range(4),key=lambda j:-prof[j]);orig=tuple(prof[j] for j in order);ps=[]
  for v in base.get(orig,()):
   q=[None]*4
   for k,j in enumerate(order):q[j]=v[k] if h<4 else occupation.complement(prof[j],v[k])
   ps.append(tuple(q))
  pools.append(tuple(sorted(ps)))
 stats=Counter()
 def dfs(d):
  stats['nodes']+=1
  while True:
   change=False
   for i in range(4):
    for j in range(4):
     ok={x[j] for x in d[i]} & {x[i] for x in d[4+j]}
     if not ok:return None
     l=tuple(x for x in d[i] if x[j] in ok);r=tuple(x for x in d[4+j] if x[i] in ok)
     change|=(len(l)!=len(d[i]) or len(r)!=len(d[4+j]))
     d[i]=l;d[4+j]=r
   if not change:break
  ix=min((i for i in range(8) if len(d[i])>1),key=lambda z:len(d[z]),default=None)
  if ix is None:
   st=[row[0] for row in d];ok,reason=check(t,st);stats[reason]+=1
   return st if ok else None
  for q in d[ix]:
   e=d[:];e[ix]=(q,);res=dfs(e)
   if res:return res
  return None
 return dfs(pools),stats

def main():
 import subprocess,tempfile
 base=occupation.profile_states(orig/'words_col8.txt')
 rows=json.loads((orig/'results_col8.json').read_text())
 assert [tuple(map(tuple,e['table'])) for e in rows]==occupation.tables()
 surviving=[i for i,e in enumerate(rows) if e['states'] is not None]
 assert surviving==[0,7,9,19,47,81,216,217,218,222,223]
 centered=[]; passthrough=[]
 for i in surviving:
  t=tuple(map(tuple,rows[i]['table']));ans,stats=solve(t,base)
  print(i,dict(stats),flush=True)
  if ans:passthrough.append(i)
  if not ans and stats['centered']:
   assert all(q in (0,2,4) for v in t for q in v)
   centered.append(' '.join(map(str,[i,*(q for v in t for q in v)])))
 assert passthrough==[7,81,216,217,218,222,223]
 assert len(centered)==2
 with tempfile.TemporaryDirectory() as tmp:
  binary=Path(tmp)/'centered'
  subprocess.run(['c++','-O3','-std=c++17',str(orig/'centered.cpp'),'-o',str(binary)],check=True)
  proc=subprocess.run([str(binary)],input='\n'.join(centered)+'\n',text=True,capture_output=True,check=True)
  print(proc.stdout,end='')
  assert len(proc.stdout.splitlines())==len(centered) and all('IMPOSSIBLE' in l for l in proc.stdout.splitlines())
 print('7 surviving occupancy IDs',passthrough)
if __name__=='__main__':main()

#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <vector>
using Mask=std::uint64_t; using Domains=std::vector<std::vector<Mask>>;
Mask bit(int j){return Mask(1)<<j;}int pop(Mask m){return __builtin_popcountll(m);}
struct Block{int r,c,f,size;std::vector<int> idx;};
struct Solver{
 std::vector<Block>B; int n=0,lim=0;Mask anti=0;std::vector<int>d,which;std::vector<Mask>s,pos,neg,ans;
 uint64_t nodes=0;bool timeout=false;int depth=0;std::chrono::steady_clock::time_point stop;
 std::vector<std::pair<int,int>> symmetry;
 void fixed(int i,int j,bool negative){auto&t=negative?neg:pos;t[i]|=bit(j);t[j]|=bit(i);}
 bool compatible(int i,Mask x,int j,Mask y)const {
  if(((x>>j)^(y>>i))&1)return false;Mask common=s[i]&s[j],nn=(x^y)&common;
  int z=pop(common)+pop(common&anti)-2*pop(nn)-2*pop(nn&anti);
  int sign=(s[i]&bit(j))?((x&bit(j))?-1:1):0;
  return z==(16-3*d[i]-3*d[j])*sign;
 }
 bool dfs(const Domains&dom,Mask used,int h){
  ++nodes;depth=std::max(depth,h);if(lim&&!(nodes%256)&&std::chrono::steady_clock::now()>=stop){timeout=true;return false;}
  int i=-1;for(int j=0;j<n;j++)if(!(used&bit(j))&&(i<0||dom[j].size()<dom[i].size()))i=j;
  if(i<0)return true;used|=bit(i);
  std::vector<std::pair<int,int>> interchangeable;
  for(auto [j,k]:symmetry)if(!(used & (bit(j)|bit(k)))){
   bool same=true;
   for(int l=0;l<n;l++)if(l!=i&&(used&bit(l))&&((ans[l]>>j)^(ans[l]>>k))&1){same=false;break;}
   if(same)interchangeable.push_back({j,k});
  }
  for(Mask x:dom[i]){
   bool sorted=true;
   for(auto [j,k]:interchangeable)if((x&bit(j))&&!(x&bit(k))){sorted=false;break;}
   if(!sorted)continue;
   ans[i]=x;Domains next(n);bool ok=true;
   for(int j=0;j<n;j++)if(!(used&bit(j))){
    for(auto y:dom[j])if(compatible(i,x,j,y))next[j].push_back(y);
    if(next[j].empty()){ok=false;break;}
   }
   if(ok){ans[i]=x;if(dfs(next,used,h+1))return true;if(timeout)return false;}
  }
  return false;
 }
 bool run(){
  for(int id=0;id<B.size();id++){auto&b=B[id];for(int k=0;k<(b.size==4?4:1);k++){
   which.push_back(id);d.push_back(b.size==4?1:2);if(b.size==2)anti|=bit(n);b.idx.push_back(n++);}}
  s.resize(n);pos.resize(n);neg.resize(n);ans.resize(n);
  for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(i!=j){
   auto &b=B[which[i]],&c=B[which[j]];if((b.r==c.r)^(b.c==c.c))continue;
   s[i]|=bit(j);if(which[i]==which[j])fixed(i,j,true);
  }
  // A simultaneous permutation of four simplex vertices is allowed; each antipodal representative may be flipped.
  int start=0,best=0;for(int b=0;b<B.size();b++){int i=B[b].idx[0];int score=0;
   for(int j=0;j<B.size();j++)if(j!=b&&(s[i]&bit(B[j].idx[0])))score+=(B[j].size==4?3:1);
   if(score>best){best=score;start=b;}}
  std::vector<bool>seen(B.size());std::vector<int>queue{start};seen[start]=true;
  for(unsigned h=0;h<queue.size();h++){int b=queue[h],i=B[b].idx[0];
   for(int j=0;j<B.size();j++)if(!seen[j]&&(s[i]&bit(B[j].idx[0]))){
    seen[j]=true;queue.push_back(j);for(int k=0;k<B[j].idx.size();k++)fixed(i,B[j].idx[k],k>=2);
   }}
  for(const auto&b:B)if(b.size==4){
   Mask group=0;for(int j:b.idx)group|=bit(j);
   for(int j:b.idx)for(int k:b.idx)if(j<k && !((neg[j]^neg[k])&~group) && !((pos[j]^pos[k])&~group))symmetry.push_back({j,k});
  }
  Domains dom(n);
  for(int i=0;i<n;i++){
   std::vector<Mask>opts{0};
   for(int b=0;b<B.size();b++){
    auto &v=B[b].idx;Mask block=0;for(auto j:v)block|=bit(j);Mask act=s[i]&block;if(!act)continue;
    std::vector<Mask>partial;
    if(which[i]==b)partial={act};
    else if(v.size()==1)partial={0,act};
    else{for(int j=0;j<4;j++)for(int k=j+1;k<4;k++)partial.push_back(bit(v[j])|bit(v[k]));}
    std::vector<Mask>next;for(auto p:partial)if(!(p&pos[i])&&!(~p&neg[i]&act))for(auto a:opts)next.push_back(p|a);
    opts=std::move(next);
   }
   dom[i]=std::move(opts);
  }
  auto sz=[](const auto& o){return o.size();};std::cout<<"n="<<n<<" max-domain="<<sz(*std::max_element(dom.begin(),dom.end(),[](const auto&a,const auto&b){return a.size()<b.size();}))<<" "<<std::flush;
  stop=std::chrono::steady_clock::now()+std::chrono::seconds(lim);bool ok=dfs(dom,0,0);
  if(ok)for(int i=0;i<n;i++)for(int j=0;j<i;j++)assert(compatible(i,ans[i],j,ans[j]));return ok;
 }
};
int main(int argc,char**argv){int id;while(std::cin>>id){Solver v;v.lim=argc>1?std::stoi(argv[1]):0;
 for(int i=0;i<4;i++)for(int j=0;j<4;j++){int k;std::cin>>k;if(k)for(int f=0;f<2;f++)v.B.push_back({i,j,f,k,{}});}
 std::cout<<id<<" "<<std::flush;bool ok=v.run();std::cout<<(ok?"FEASIBLE":v.timeout?"TIMEOUT":"IMPOSSIBLE")<<" "<<v.nodes<<" "<<v.depth;
 if(ok)for(auto x:v.ans)std::cout<<" "<<x;std::cout<<std::endl;}}

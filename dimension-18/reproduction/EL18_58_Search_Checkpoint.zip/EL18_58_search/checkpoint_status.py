"""Join the current spectral ledgers by parent index and preserve open and untested sets."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
def read(path):return json.loads((P/path).read_text())
r=read('global_resume/status.json')
x=read('m5_scan/status.json');s=r['5']
s.update(tested=x['tested'],excluded=x['excluded'],open_tested=x['open_tested'],untested_ranges=x['pending'],cursor=x['cursor'])
s['stage_totals']['after_parent65_and_later_scan']=len(x['open_tested'])
front=P/'joint_frontier'
for m in range(5,13):
    layer=r[str(m)]
    unseen={i for a,b in layer['untested_ranges'] for i in range(a,b+1)}
    live=set(layer['open_tested'])
    if m==12:
        new=read('joint_frontier/next12.json')
        for _,i,tail,_,_,active in new:
            if i in unseen:
                unseen.remove(i)
                if active:live.add(i)
        layer['stage_totals']['new_batch_anchor_survivors']=sum(bool(q[-1]) for q in new)
    for path in (front/str(m)).glob('*.json'):
        record=json.loads(path.read_text());i=record['index']
        assert i not in unseen
        if not record['open']:live.discard(i)
    if m==5 and not read('joint_frontier/full179/179.json')['open']:live.discard(179)
    spans=[]
    for i in sorted(unseen):
        if spans and i==spans[-1][-1]+1:spans[-1][1]=i
        else:spans.append([i,i])
    layer.update(tested=layer['parent_count']-len(unseen),open_tested=sorted(live),
                 excluded=layer['parent_count']-len(unseen)-len(live),
                 untested_ranges=spans,cursor=min(unseen,default=None))
    layer['stage_totals']['after_polynomial_frontier']=len(live)
assert r['4']['excluded']==419
r['13']=dict(parents_file='m13/parents.json',parent_count=2965,tested=2965,excluded=2965,open_tested=[],untested_ranges=[],cursor=None,
             stage_totals={'anchor':143,'row_screen':26,'polynomial_rows':13,'earlier_decorations':7,'after_2087_and_2878':5,'remaining':0})
r['14']=dict(parents_file='m14/quartic_results.json',parent_count=373,tested=373,excluded=373,open_tested=[],untested_ranges=[],cursor=None)
for v in r.values():
    assert len(v['open_tested'])+v['excluded']==v['tested']
    assert sum(b-a+1 for a,b in v['untested_ranges'])+v['tested']==v['parent_count']
(P/'CHECKPOINT_STATUS.json').write_text(json.dumps(r,indent=1)+'\n')
for m in range(4,15):
 v=r[str(m)];print(m,v['parent_count'],v['tested'],v['excluded'],v['parent_count']-v['excluded'])
